# Guia de Integração: Novo Sistema de Mensagens

Este documento explica como integrar a nova funcionalidade de **Mensagens Internas** no frontend, detalhando as rotas disponíveis, as regras de permissão e sugerindo as melhores práticas de UX para a aplicação.

## 1. O que é a nova funcionalidade?

O módulo `Messages` foi construído para servir como uma caixa de entrada (inbox) interna para comunicação assíncrona entre os profissionais da clínica. Sendo semelhante a um e-mail tradicional:

*   **Identificação:** Tem remetente, destinatário, assunto e corpo da mensagem.
*   **Vínculo com Paciente:** É possível atrelar uma mensagem a um paciente específico (opcional), facilitando a discussão de casos clínicos.
*   **Caixa de Entrada:** Conta com sistema de lido/não lido (`isRead`). Lidas saem da visualização padrão, simulando uma caixa de pendências.
*   **Privacidade:** Um usuário comum só enxerga as mensagens onde ele é o `remetente` ou o `destinatário`. O administrador possui passe livre geral.

---

## 2. Integração no Frontend (Rotas da API)

### 2.1. Listar Caixa de Entrada
`GET /messages`

Por padrão, esta rota retorna apenas as mensagens **Não Lidas** (`isRead=false`) do usuário atual (enviadas ou recebidas por ele). 

**Query Parameters Disponíveis:**
*   `page` e `perPage`: Paginação (padrão em toda aplicação).
*   `isRead`: `true` ou `false`. (Se omitido, assume `false`. Passe `true` para ver "Mensagens Arquivadas/Lidas").
*   `query`: Termo de busca que varre o título, o corpo da mensagem e o nome de remetentes ou destinatários.

*Exemplo: `GET /messages?page=1&perPage=10&isRead=true&query=exame`*

### 2.2. Enviar Nova Mensagem
`POST /messages`

O `senderId` é extraído automaticamente do token JWT de quem está realizando a ação.
```json
{
  "subject": "Dúvida sobre o prontuário do paciente",
  "body": "Gostaria de saber se o retorno foi agendado para a próxima semana...",
  "receiverId": "UUID-DO-PROFISSIONAL-DESTINATARIO",
  "patientId": "UUID-DO-PACIENTE" // (Campo opcional)
}
```

### 2.3. Visualizar Mensagem (Automark as Read)
`GET /messages/{id}`

Ao realizar um GET específico para ler a mensagem, caso o usuário autenticado seja o **destinatário** e a mensagem esteja como `isRead: false`, o backend atualiza a mensagem silenciosamente para `lida` (`isRead: true`), funcionando de forma transparente e evitando chamadas extras de update.

### 2.4. Atualizar Status Manualmente
`PATCH /messages/{id}`

Usado primariamente para marcar uma mensagem de volta como "Não lida" (Unread) caso o usuário queira mantê-la como pendência. O Admin pode alterar qualquer uma.
```json
{
  "isRead": false
}
```

### 2.5. Excluir Mensagem
`DELETE /messages/{id}`

Deleta permanentemente o registro. Profissionais normais só podem deletar se estiverem envolvidos na mensagem (Remetente ou Destinatário). Admins deletam qualquer uma.

---

## 3. Regras e Fluxos de Permissões

| Perfil | Visão Geral (`GET`) | Criação (`POST`) | Edição/Exclusão | Validações Internas |
| :--- | :--- | :--- | :--- | :--- |
| **Profissionais (Doutor, Fisio, etc)** | Apenas envolvidas (originadas de si ou destinadas a si) | Liberação normal (não pode mandar pra si mesmo) | Apenas mensagens onde está envolvido. Apenas o destinatário pode trocar status de leitura. | Backend veta envios autônomos para "si mesmo". |
| **Administradores** | Acesso livre a TODAS | Liberação normal | Acesso geral, manipulação irrestrita. | Monitoramento silencioso da comunicação da clínica se necessário. |

---

## 4. Sugestões de Implementação (UX)

Para que a experiência fique natural e fluida no React/Frontend:

1.  **Badge de Notificação:** Faça um *polling* ocasional para `GET /messages?perPage=1` para checar o atributo `meta.total` retornado no wrapper da paginação. Se `total > 0`, mostre uma bolinha vermelha no menu com a contagem.
2.  **Lista Dividida (Tabs):** Crie abas "Caixa de Entrada" (não lidas) e "Lidas/Arquivadas". Intercale o envio do parâmetro `isRead=false` e `isRead=true`.
3.  **Campo Combo de Destinatário:** Na criação da mensagem, inclua um Dropdown combobox preenchido com todos os profissionais ativos usando a rota `GET /users`, exceto o próprio usuário logado.
4.  **Botão "Marcar como não lido":** Nas mensagens antigas, deixe uma opção usando a rota `PATCH /messages/{id}`, enviando `{ "isRead": false }`, para que ela volte à Caixa de Entrada principal.
