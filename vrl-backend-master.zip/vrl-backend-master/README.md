# VR-Leão Backend

Backend robusto desenvolvido em **NestJS** para o ecossistema **VR-Leão**, focado em gestão de saúde, acompanhamento de pacientes e integração de dados clínicos.

## 🚀 Tecnologias

- **Framework:** [NestJS](https://nestjs.com/) (Progressive Node.js framework)
- **ORM:** [Prisma](https://www.prisma.io/)
- **Banco de Dados:** PostgreSQL
- **Autenticação:** JWT (JSON Web Token) com RBAC (Role-Based Access Control)
- **Testes:** Jest
- **CI/CD:** GitHub Actions (Lint, Format, Test)
- **Documentação API:** Swagger/OpenAPI

## 📂 Estrutura do Projeto

O projeto segue uma arquitetura modular por funcionalidades:

- **Auth:** Gestão de autenticação, tokens e permissões.
- **Users:** Cadastro e gerenciamento de usuários do sistema (Admin, Médicos, Nutricionistas, etc).
- **Patients:** Módulo central para dados cadastrais de pacientes e histórico clínico.
- **Consultations:** Módulos específicos para consultas Nutricionais, Médicas, Psicológicas e Fisioterapêuticas.
- **Logs & Monitoramento:** Registros diários de alimentação, sono e performance.
- **Integrations:** Integração com dispositivos externos (ex: Fitbit).
- **Common:** Pipes, guards e utilitários compartilhados.

## ⚙️ Configuração Local

### Pré-requisitos
- Node.js (v20+)
- Docker (opcional, para o banco de dados)
- PostgreSQL

### Instalação

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Configure as variáveis de ambiente:
   - Copie o arquivo `.env.example` para `.env` e preencha as credenciais.

3. Prepare o banco de dados:
   ```bash
   # Gera o cliente do Prisma
   npm run db:generate

   # Executa as migrações
   npm run db:migrate
   ```

## 🌱 Populando o Banco (Seeding)

O projeto possui dois scripts de seed para diferentes finalidades:

### 1. Seed de Produção/Base
Cria os dados essenciais para o funcionamento do sistema, como o usuário administrador inicial.
```bash
npm run db:seed
```

### 2. Seed de Desenvolvimento
Gera uma grande quantidade de dados fictícios (pacientes, consultas, logs, exames, etc.) utilizando a biblioteca **Faker**. Ideal para testar a interface e performance.
```bash
npm run db:seed:dev
```

### Execução

```bash
# Modo desenvolvimento
npm run start:dev

# Modo produção
npm run build
npm run start:prod
```

## 🧪 Testes

O projeto prioriza a qualidade do código com testes unitários abrangentes:

```bash
# Executar todos os testes
npm test

# Modo watch
npm run test:watch

# Cobertura de testes
npm run test:cov
```

## 📝 Documentação da API

A documentação interativa (Swagger) fica disponível em:
`http://localhost:3003/docs` (ou na porta configurada).

## 🛡️ CI/CD

Configurado via **GitHub Actions** para garantir que todo commit:
1. Esteja devidamente formatado (**Prettier**).
2. Não possua erros de lint (**ESLint**).
3. Passe em todos os testes unitários.

---
Desenvolvido por **Thiago Marques (Marcuth)** e Rafael Fonseca.
