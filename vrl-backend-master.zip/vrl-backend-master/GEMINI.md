# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a NestJS-based healthcare management backend API for VR Leão, a medical platform handling patient data, consultations, and medical records. The application uses PostgreSQL with Prisma ORM and follows a modular architecture.

## Development Commands

### Core Commands
- `npm run start:dev` - Start development server with watch mode
- `npm run build` - Build for production
- `npm run start:prod` - Start production server
- `npm run lint` - Run ESLint with auto-fix
- `npm run format` - Format code with Prettier

### Testing
- `npm run test` - Run unit tests
- `npm run test:watch` - Run tests in watch mode
- `npm run test:cov` - Generate test coverage report
- `npm run test:e2e` - Run end-to-end tests
- `npm run test:debug` - Debug tests

### Database
- `npm run db:migrate` - Run Prisma migrations
- `npm run show-db` - Open Prisma Studio at http://localhost:5555

### Documentation
- `npm run open-docs` - Open Swagger API docs at http://localhost:3003/docs

## Architecture

### Module Structure
The application follows NestJS module architecture with distinct domains:

**Core Modules:**
- `auth/` - JWT authentication and role-based access control
- `users/` - User management with roles (EDUCATOR_VR, DOCTOR, PHYSIOTHERAPIST, PSYCHOLOGIST, NUTRITIONIST, ADMIN)
- `patients/` - Patient records and management
- `prisma/` - Database connection and Prisma client

**Medical Modules:**
- `medical-consultations/` - Medical consultations with vital signs
- `medications/` - Standalone medication management with history tracking
- `nutritional-consultations/` - Nutritional assessments with body measurements and dietary habits
- `psychological-consultations/` - Psychological evaluations
- `physiotherapy-consultations/` - Physiotherapy assessments
- `exams/` - Laboratory test results and medical examinations

**Health Tracking:**
- `daily-performance-logs/` - Daily vital signs and physical activity tracking
- `daily-food-logs/` - Comprehensive food intake logging with nutritional data
- `sleep-logs/` - Sleep quality and pattern tracking
- `clinical-infos/` - Patient clinical information and medical history

**Administrative:**
- `appointments/` - Appointment scheduling
- `forwardings/` - Medical referrals between professionals
- `reminders/` - Task and appointment reminders
- `messages/` - Internal messaging system between professionals
- `dashboard/` - Analytics and overview data
- `anamneses/` - Patient medical history intake

### Database Schema
The Prisma schema defines a comprehensive healthcare data model:

**User Roles:** EDUCATOR_VR, DOCTOR, PHYSIOTHERAPIST, PSYCHOLOGIST, NUTRITIONIST, ADMIN

**Key Entities:**
- Users with role-based permissions
- Patients with comprehensive clinical data
- Multiple consultation types (medical, nutritional, psychological, physiotherapy)
- Health tracking logs (sleep, performance, food intake)
- Medical data (exams, medications with history, vital signs)

### Authentication & Authorization
- JWT-based authentication with access/refresh token strategy
- Role-based access control using guards and decorators
- Ownership-based resource protection for patient data
- Session management with automatic cleanup

### API Documentation
- Swagger/OpenAPI documentation available at `/docs`
- Bearer token authentication required for protected endpoints
- Comprehensive endpoint coverage with request/response schemas

## Development Guidelines

### Code Style
- TypeScript strict mode enabled
- ESLint with Prettier integration
- Import sorting with prettier-plugin-sort-imports
- Consistent naming conventions (camelCase for properties, snake_case for database fields)

### Testing Strategy
- Unit tests for services (*.spec.ts files)
- Jest test runner with coverage reporting
- End-to-end tests for API endpoints
- Test files located alongside source code

### Database Migrations
- Use `npm run db:migrate` for schema changes
- Migration files stored in `prisma/migrations/`
- Seed data available via `prisma/seed.ts`

### Security Considerations
- Helmet middleware for security headers
- CORS configuration
- Password hashing with bcrypt
- Input validation using class-validator
- SQL injection protection via Prisma

## Key Files
- `src/main.ts` - Application bootstrap and Swagger setup
- `src/app.module.ts` - Root module with all feature imports
- `prisma/schema.prisma` - Database schema definition
- `src/helpers/config.helper.ts` - Environment configuration
- `src/common/` - Shared guards, interfaces, and utilities

When working with this codebase, always check existing modules for patterns and follow the established conventions for DTOs, services, and controllers.