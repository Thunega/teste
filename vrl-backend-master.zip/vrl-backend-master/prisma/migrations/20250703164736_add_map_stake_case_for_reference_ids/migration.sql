/*
  Warnings:

  - You are about to drop the column `patientId` on the `patient_anamneses` table. All the data in the column will be lost.
  - You are about to drop the column `patientId` on the `patient_clinical_infos` table. All the data in the column will be lost.
  - You are about to drop the column `patientId` on the `patient_examps` table. All the data in the column will be lost.
  - You are about to drop the column `ownerId` on the `patients` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[patient_id]` on the table `patient_anamneses` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[patient_id]` on the table `patient_clinical_infos` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `patient_id` to the `patient_anamneses` table without a default value. This is not possible if the table is not empty.
  - Added the required column `patient_id` to the `patient_clinical_infos` table without a default value. This is not possible if the table is not empty.
  - Added the required column `patient_id` to the `patient_examps` table without a default value. This is not possible if the table is not empty.
  - Added the required column `owner_id` to the `patients` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "patient_anamneses" DROP CONSTRAINT "patient_anamneses_patientId_fkey";

-- DropForeignKey
ALTER TABLE "patient_clinical_infos" DROP CONSTRAINT "patient_clinical_infos_patientId_fkey";

-- DropForeignKey
ALTER TABLE "patient_examps" DROP CONSTRAINT "patient_examps_patientId_fkey";

-- DropForeignKey
ALTER TABLE "patients" DROP CONSTRAINT "patients_ownerId_fkey";

-- DropIndex
DROP INDEX "patient_anamneses_patientId_key";

-- DropIndex
DROP INDEX "patient_clinical_infos_patientId_key";

-- AlterTable
ALTER TABLE "patient_anamneses" DROP COLUMN "patientId",
ADD COLUMN     "patient_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "patient_clinical_infos" DROP COLUMN "patientId",
ADD COLUMN     "patient_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "patient_examps" DROP COLUMN "patientId",
ADD COLUMN     "patient_id" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "patients" DROP COLUMN "ownerId",
ADD COLUMN     "owner_id" TEXT NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "patient_anamneses_patient_id_key" ON "patient_anamneses"("patient_id");

-- CreateIndex
CREATE UNIQUE INDEX "patient_clinical_infos_patient_id_key" ON "patient_clinical_infos"("patient_id");

-- AddForeignKey
ALTER TABLE "patients" ADD CONSTRAINT "patients_owner_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_clinical_infos" ADD CONSTRAINT "patient_clinical_infos_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_anamneses" ADD CONSTRAINT "patient_anamneses_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_examps" ADD CONSTRAINT "patient_examps_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
