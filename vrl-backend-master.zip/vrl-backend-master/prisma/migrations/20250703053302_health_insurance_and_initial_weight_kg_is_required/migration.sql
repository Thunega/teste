/*
  Warnings:

  - Made the column `initial_weight_kg` on table `patient_clinical_infos` required. This step will fail if there are existing NULL values in that column.
  - Made the column `height_cm` on table `patient_clinical_infos` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "patient_clinical_infos" ALTER COLUMN "initial_weight_kg" SET NOT NULL,
ALTER COLUMN "height_cm" SET NOT NULL;
