/*
  Warnings:

  - You are about to drop the column `gamma_gt` on the `patient_examps` table. All the data in the column will be lost.
  - You are about to drop the column `t3` on the `patient_examps` table. All the data in the column will be lost.
  - You are about to drop the column `urea` on the `patient_examps` table. All the data in the column will be lost.
  - You are about to drop the column `vldl` on the `patient_examps` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "patient_examps" DROP COLUMN "gamma_gt",
DROP COLUMN "t3",
DROP COLUMN "urea",
DROP COLUMN "vldl";

-- CreateTable
CREATE TABLE "weekly_weights" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "week_start_date" TEXT NOT NULL,
    "weight_kg" DOUBLE PRECISION NOT NULL,
    "observations" TEXT,
    "patient_id" TEXT NOT NULL,

    CONSTRAINT "weekly_weights_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "weekly_weights" ADD CONSTRAINT "weekly_weights_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;
