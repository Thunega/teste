/*
  Warnings:

  - You are about to drop the column `medical_consultation_id` on the `medications` table. All the data in the column will be lost.
  - You are about to drop the column `physiotherapy_consultation_id` on the `medications` table. All the data in the column will be lost.
  - You are about to drop the column `medications_in_use` on the `patient_clinical_infos` table. All the data in the column will be lost.
  - Added the required column `patient_id` to the `medications` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updated_at` to the `medications` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "MedicationStatus" AS ENUM ('ACTIVE', 'INACTIVE');

-- DropForeignKey
ALTER TABLE "medications" DROP CONSTRAINT "medications_medical_consultation_id_fkey";

-- DropForeignKey
ALTER TABLE "medications" DROP CONSTRAINT "medications_physiotherapy_consultation_id_fkey";

-- AlterTable
ALTER TABLE "medications" DROP COLUMN "medical_consultation_id",
DROP COLUMN "physiotherapy_consultation_id",
ADD COLUMN     "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "discontinued_at" TIMESTAMP(3),
ADD COLUMN     "discontinued_reason" TEXT,
ADD COLUMN     "patient_id" TEXT NOT NULL,
ADD COLUMN     "status" "MedicationStatus" NOT NULL DEFAULT 'ACTIVE',
ADD COLUMN     "updated_at" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "patient_clinical_infos" DROP COLUMN "medications_in_use";

-- CreateTable
CREATE TABLE "medication_history" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "medication_id" TEXT NOT NULL,
    "status" "MedicationStatus" NOT NULL,
    "dosage" TEXT NOT NULL,
    "timetables" TEXT NOT NULL,
    "duration" TEXT NOT NULL,
    "observations" TEXT,

    CONSTRAINT "medication_history_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "medications" ADD CONSTRAINT "medications_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medication_history" ADD CONSTRAINT "medication_history_medication_id_fkey" FOREIGN KEY ("medication_id") REFERENCES "medications"("id") ON DELETE CASCADE ON UPDATE CASCADE;
