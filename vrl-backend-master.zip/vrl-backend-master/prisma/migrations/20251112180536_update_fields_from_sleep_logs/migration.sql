/*
  Warnings:

  - You are about to drop the column `bed_time` on the `sleep_logs` table. All the data in the column will be lost.
  - You are about to drop the column `real_sleep_time` on the `sleep_logs` table. All the data in the column will be lost.
  - You are about to drop the column `sleep_goal` on the `sleep_logs` table. All the data in the column will be lost.
  - You are about to drop the column `sleep_latency` on the `sleep_logs` table. All the data in the column will be lost.

*/
-- AlterEnum
ALTER TYPE "UserRole" ADD VALUE 'DATA_COLLECTOR';

-- AlterTable
ALTER TABLE "sleep_logs" DROP COLUMN "bed_time",
DROP COLUMN "real_sleep_time",
DROP COLUMN "sleep_goal",
DROP COLUMN "sleep_latency",
ADD COLUMN     "avg_heart_rate" INTEGER,
ADD COLUMN     "avg_oxygen_saturation" DOUBLE PRECISION;
