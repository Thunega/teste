-- AlterTable
ALTER TABLE "nutritional_consultations" ALTER COLUMN "hip_cm" DROP NOT NULL;
