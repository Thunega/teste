-- AlterTable
ALTER TABLE "patient_examps" ADD COLUMN     "exam_date" TEXT;
