-- AlterTable
ALTER TABLE "patient_examps" ADD COLUMN     "acidoUrico" DOUBLE PRECISION,
ADD COLUMN     "hemoglobinaGlicada" DOUBLE PRECISION,
ADD COLUMN     "microalbuminuria" DOUBLE PRECISION,
ADD COLUMN     "potassio" DOUBLE PRECISION,
ADD COLUMN     "vitaminaB12" DOUBLE PRECISION,
ADD COLUMN     "vitaminaD_25_OH" DOUBLE PRECISION;
