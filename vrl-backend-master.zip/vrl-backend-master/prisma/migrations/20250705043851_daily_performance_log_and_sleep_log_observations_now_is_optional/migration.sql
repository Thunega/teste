-- AlterTable
ALTER TABLE "daily_performance_logs" ALTER COLUMN "observations" DROP NOT NULL;

-- AlterTable
ALTER TABLE "sleep_logs" ALTER COLUMN "observations" DROP NOT NULL;
