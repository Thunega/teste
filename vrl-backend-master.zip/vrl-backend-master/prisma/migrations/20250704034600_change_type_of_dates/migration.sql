/*
  Warnings:

  - A unique constraint covering the columns `[email]` on the table `patients` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "patient_clinical_infos" ALTER COLUMN "start_date" SET DATA TYPE TEXT;

-- AlterTable
ALTER TABLE "patient_examps" ALTER COLUMN "exam_date" SET DATA TYPE TEXT;

-- AlterTable
ALTER TABLE "patients" ALTER COLUMN "date_of_birth" SET DATA TYPE TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "patients_email_key" ON "patients"("email");
