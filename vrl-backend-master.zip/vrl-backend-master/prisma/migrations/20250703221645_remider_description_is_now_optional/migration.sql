-- AlterTable
ALTER TABLE "reminders" ALTER COLUMN "description" DROP NOT NULL;
