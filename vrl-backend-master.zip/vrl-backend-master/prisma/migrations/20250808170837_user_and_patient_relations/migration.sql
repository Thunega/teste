-- DropForeignKey
ALTER TABLE "appointments" DROP CONSTRAINT "appointments_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "appointments" DROP CONSTRAINT "appointments_responsible_user_id_fkey";

-- DropForeignKey
ALTER TABLE "daily_performance_logs" DROP CONSTRAINT "daily_performance_logs_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "forwardings" DROP CONSTRAINT "forwardings_from_user_id_fkey";

-- DropForeignKey
ALTER TABLE "forwardings" DROP CONSTRAINT "forwardings_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "forwardings" DROP CONSTRAINT "forwardings_to_user_id_fkey";

-- DropForeignKey
ALTER TABLE "medical_consultation" DROP CONSTRAINT "medical_consultation_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "medical_consultation" DROP CONSTRAINT "medical_consultation_user_id_fkey";

-- DropForeignKey
ALTER TABLE "nutritional_consultations" DROP CONSTRAINT "nutritional_consultations_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "nutritional_consultations" DROP CONSTRAINT "nutritional_consultations_user_id_fkey";

-- DropForeignKey
ALTER TABLE "patient_anamneses" DROP CONSTRAINT "patient_anamneses_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "patient_clinical_infos" DROP CONSTRAINT "patient_clinical_infos_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "patient_examps" DROP CONSTRAINT "patient_examps_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "patient_examps" DROP CONSTRAINT "patient_examps_responsible_user_id_fkey";

-- DropForeignKey
ALTER TABLE "patients" DROP CONSTRAINT "patients_owner_id_fkey";

-- DropForeignKey
ALTER TABLE "physical_activities" DROP CONSTRAINT "physical_activities_daily_performance_log_id_fkey";

-- DropForeignKey
ALTER TABLE "physiotherapy_consultations" DROP CONSTRAINT "physiotherapy_consultations_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "physiotherapy_consultations" DROP CONSTRAINT "physiotherapy_consultations_user_id_fkey";

-- DropForeignKey
ALTER TABLE "physiotherapy_sessions" DROP CONSTRAINT "physiotherapy_sessions_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "physiotherapy_sessions" DROP CONSTRAINT "physiotherapy_sessions_user_id_fkey";

-- DropForeignKey
ALTER TABLE "psychological_consultations" DROP CONSTRAINT "psychological_consultations_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "psychological_consultations" DROP CONSTRAINT "psychological_consultations_user_id_fkey";

-- DropForeignKey
ALTER TABLE "reminders" DROP CONSTRAINT "reminders_owner_id_fkey";

-- DropForeignKey
ALTER TABLE "sleep_logs" DROP CONSTRAINT "sleep_logs_patient_id_fkey";

-- AlterTable
ALTER TABLE "appointments" ALTER COLUMN "responsible_user_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "forwardings" ALTER COLUMN "from_user_id" DROP NOT NULL,
ALTER COLUMN "to_user_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "medical_consultation" ALTER COLUMN "user_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "nutritional_consultations" ALTER COLUMN "user_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "patient_examps" ALTER COLUMN "responsible_user_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "patients" ALTER COLUMN "owner_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "physiotherapy_consultations" ALTER COLUMN "user_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "physiotherapy_sessions" ALTER COLUMN "user_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "psychological_consultations" ALTER COLUMN "user_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "reminders" ALTER COLUMN "owner_id" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "patients" ADD CONSTRAINT "patients_owner_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_clinical_infos" ADD CONSTRAINT "patient_clinical_infos_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_anamneses" ADD CONSTRAINT "patient_anamneses_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_examps" ADD CONSTRAINT "patient_examps_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_examps" ADD CONSTRAINT "patient_examps_responsible_user_id_fkey" FOREIGN KEY ("responsible_user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "forwardings" ADD CONSTRAINT "forwardings_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "forwardings" ADD CONSTRAINT "forwardings_from_user_id_fkey" FOREIGN KEY ("from_user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "forwardings" ADD CONSTRAINT "forwardings_to_user_id_fkey" FOREIGN KEY ("to_user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_responsible_user_id_fkey" FOREIGN KEY ("responsible_user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reminders" ADD CONSTRAINT "reminders_owner_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "sleep_logs" ADD CONSTRAINT "sleep_logs_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physical_activities" ADD CONSTRAINT "physical_activities_daily_performance_log_id_fkey" FOREIGN KEY ("daily_performance_log_id") REFERENCES "daily_performance_logs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "daily_performance_logs" ADD CONSTRAINT "daily_performance_logs_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "nutritional_consultations" ADD CONSTRAINT "nutritional_consultations_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "nutritional_consultations" ADD CONSTRAINT "nutritional_consultations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "psychological_consultations" ADD CONSTRAINT "psychological_consultations_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "psychological_consultations" ADD CONSTRAINT "psychological_consultations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medical_consultation" ADD CONSTRAINT "medical_consultation_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medical_consultation" ADD CONSTRAINT "medical_consultation_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_consultations" ADD CONSTRAINT "physiotherapy_consultations_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_consultations" ADD CONSTRAINT "physiotherapy_consultations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_sessions" ADD CONSTRAINT "physiotherapy_sessions_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_sessions" ADD CONSTRAINT "physiotherapy_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
