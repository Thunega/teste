/*
  Warnings:

  - A unique constraint covering the columns `[physiotherapy_consultation_id]` on the table `medications` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateEnum
CREATE TYPE "FunctionalLevel" AS ENUM ('INDEPENDENT', 'SEMI_INDEPENDENT', 'DEPENDENT');

-- AlterEnum
ALTER TYPE "UserRole" ADD VALUE 'PHYSIOTHERAPIST';

-- AlterTable
ALTER TABLE "medications" ADD COLUMN     "physiotherapy_consultation_id" TEXT,
ALTER COLUMN "medical_consultation_id" DROP NOT NULL;

-- CreateTable
CREATE TABLE "physiotherapy_consultation" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "consultation_date" TEXT NOT NULL,
    "main_complaint" TEXT NOT NULL,
    "medical_history" TEXT NOT NULL,
    "pain_level" INTEGER NOT NULL,
    "functionalLevel" "FunctionalLevel" NOT NULL,
    "patient_id" TEXT NOT NULL,
    "short_term_goals" TEXT NOT NULL,
    "long_term_goals" TEXT NOT NULL,
    "treatment_plan" TEXT NOT NULL,
    "session_frequency" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,

    CONSTRAINT "physiotherapy_consultation_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "medications_physiotherapy_consultation_id_key" ON "medications"("physiotherapy_consultation_id");

-- AddForeignKey
ALTER TABLE "medications" ADD CONSTRAINT "medications_physiotherapy_consultation_id_fkey" FOREIGN KEY ("physiotherapy_consultation_id") REFERENCES "physiotherapy_consultation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_consultation" ADD CONSTRAINT "physiotherapy_consultation_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_consultation" ADD CONSTRAINT "physiotherapy_consultation_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
