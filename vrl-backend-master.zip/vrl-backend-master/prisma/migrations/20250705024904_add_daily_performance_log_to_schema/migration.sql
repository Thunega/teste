-- CreateEnum
CREATE TYPE "SleepQuality" AS ENUM ('GOOD', 'AVERAGE', 'BAD');

-- CreateEnum
CREATE TYPE "PhysicalActivityIntensity" AS ENUM ('MILD', 'MODERATE', 'INTENSIVE');

-- CreateTable
CREATE TABLE "sleep_logs" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "date_of_registration" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "bed_time" INTEGER NOT NULL,
    "sleep_latency" INTEGER NOT NULL,
    "sleep_time" INTEGER NOT NULL,
    "real_sleep_time" INTEGER NOT NULL,
    "sleep_goal" INTEGER NOT NULL,
    "agreed_time" INTEGER NOT NULL,
    "rem_time" INTEGER NOT NULL,
    "light_sleep" INTEGER NOT NULL,
    "deep_sleep" INTEGER NOT NULL,
    "observations" TEXT NOT NULL,
    "patient_id" TEXT NOT NULL,

    CONSTRAINT "sleep_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "physical_activities" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "duration" INTEGER NOT NULL,
    "intensity" "PhysicalActivityIntensity" NOT NULL,
    "daily_performance_log_id" TEXT NOT NULL,

    CONSTRAINT "physical_activities_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "daily_performance_logs" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "date_of_registration" TEXT NOT NULL,
    "blood_pressure" TEXT NOT NULL,
    "oxygen_saturation" INTEGER NOT NULL,
    "beats_per_minute" INTEGER NOT NULL,
    "sleep_quality" "SleepQuality" NOT NULL,
    "observations" TEXT NOT NULL,
    "patient_id" TEXT NOT NULL,

    CONSTRAINT "daily_performance_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "physical_activities_daily_performance_log_id_key" ON "physical_activities"("daily_performance_log_id");

-- AddForeignKey
ALTER TABLE "sleep_logs" ADD CONSTRAINT "sleep_logs_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physical_activities" ADD CONSTRAINT "physical_activities_daily_performance_log_id_fkey" FOREIGN KEY ("daily_performance_log_id") REFERENCES "daily_performance_logs"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "daily_performance_logs" ADD CONSTRAINT "daily_performance_logs_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
