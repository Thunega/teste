-- AlterTable
ALTER TABLE "patients" ADD COLUMN     "exercise_alert" TEXT;
