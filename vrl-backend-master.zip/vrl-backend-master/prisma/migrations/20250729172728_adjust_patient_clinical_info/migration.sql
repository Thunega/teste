-- DropIndex
DROP INDEX "patient_clinical_infos_patient_id_key";
