/*
  Warnings:

  - You are about to drop the `physiotherapy_consultation` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "medications" DROP CONSTRAINT "medications_physiotherapy_consultation_id_fkey";

-- DropForeignKey
ALTER TABLE "physiotherapy_consultation" DROP CONSTRAINT "physiotherapy_consultation_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "physiotherapy_consultation" DROP CONSTRAINT "physiotherapy_consultation_user_id_fkey";

-- DropTable
DROP TABLE "physiotherapy_consultation";

-- CreateTable
CREATE TABLE "physiotherapy_consultations" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "consultation_date" TEXT NOT NULL,
    "main_complaint" TEXT NOT NULL,
    "medical_history" TEXT NOT NULL,
    "pain_level" INTEGER NOT NULL,
    "functionalLevel" "FunctionalLevel" NOT NULL,
    "short_term_goals" TEXT NOT NULL,
    "long_term_goals" TEXT NOT NULL,
    "treatment_plan" TEXT NOT NULL,
    "session_frequency" TEXT NOT NULL,
    "patient_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,

    CONSTRAINT "physiotherapy_consultations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "physiotherapy_sessions" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "home_exercises" TEXT NOT NULL,
    "recommendations" TEXT NOT NULL,
    "patient_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,

    CONSTRAINT "physiotherapy_sessions_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "medications" ADD CONSTRAINT "medications_physiotherapy_consultation_id_fkey" FOREIGN KEY ("physiotherapy_consultation_id") REFERENCES "physiotherapy_consultations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_consultations" ADD CONSTRAINT "physiotherapy_consultations_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_consultations" ADD CONSTRAINT "physiotherapy_consultations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_sessions" ADD CONSTRAINT "physiotherapy_sessions_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "physiotherapy_sessions" ADD CONSTRAINT "physiotherapy_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
