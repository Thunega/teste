/*
  Warnings:

  - You are about to drop the column `imc` on the `nutritional_consultations` table. All the data in the column will be lost.
  - Added the required column `bmi` to the `nutritional_consultations` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "nutritional_consultations" DROP COLUMN "imc",
ADD COLUMN     "bmi" DOUBLE PRECISION NOT NULL;
