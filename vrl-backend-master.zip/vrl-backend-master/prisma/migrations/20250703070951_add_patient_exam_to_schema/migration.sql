-- AlterTable
ALTER TABLE "patient_clinical_infos" ALTER COLUMN "start_date" SET DATA TYPE DATE;

-- CreateTable
CREATE TABLE "patient_examps" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "exam_date" DATE NOT NULL,
    "total_cholesterol" DOUBLE PRECISION,
    "hdl" DOUBLE PRECISION,
    "ldl" DOUBLE PRECISION,
    "vldl" DOUBLE PRECISION,
    "fasting_glucose" DOUBLE PRECISION,
    "triglycerides" DOUBLE PRECISION,
    "sgot" DOUBLE PRECISION,
    "sgpt" DOUBLE PRECISION,
    "gamma_gt" DOUBLE PRECISION,
    "urea" DOUBLE PRECISION,
    "creatinine" DOUBLE PRECISION,
    "t3" DOUBLE PRECISION,
    "t4" DOUBLE PRECISION,
    "tsh" DOUBLE PRECISION,
    "other_exams" TEXT,
    "observations" TEXT,
    "patientId" TEXT NOT NULL,
    "responsibleUserId" TEXT NOT NULL,

    CONSTRAINT "patient_examps_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "patient_examps" ADD CONSTRAINT "patient_examps_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_examps" ADD CONSTRAINT "patient_examps_responsibleUserId_fkey" FOREIGN KEY ("responsibleUserId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
