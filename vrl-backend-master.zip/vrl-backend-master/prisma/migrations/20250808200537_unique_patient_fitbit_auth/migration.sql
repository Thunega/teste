-- DropIndex
DROP INDEX "fitbit_auths_user_id_key";
