/*
  Warnings:

  - You are about to drop the column `blood_type` on the `patient_clinical_infos` table. All the data in the column will be lost.
  - You are about to drop the column `initial_weight_kg` on the `patient_clinical_infos` table. All the data in the column will be lost.
  - Added the required column `weight_kg` to the `patient_clinical_infos` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "patient_clinical_infos" DROP COLUMN "blood_type",
DROP COLUMN "initial_weight_kg",
ADD COLUMN     "weight_kg" DOUBLE PRECISION NOT NULL;

-- AlterTable
ALTER TABLE "patients" ADD COLUMN     "blood_type" "BloodType";
