-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('EDUCATOR_VR', 'PHYSIOTHERAPIST', 'DOCTOR', 'PSYCHOLOGIST');

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "role" "UserRole" NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "patients" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "cpf" TEXT NOT NULL,
    "date_of_birth" TIMESTAMP(3) NOT NULL,
    "gender" TEXT NOT NULL,
    "email" TEXT,
    "phone" TEXT,
    "address" TEXT,
    "city" TEXT,
    "state" TEXT,
    "zip_code" TEXT,
    "emergency_contact" TEXT,
    "userId" TEXT NOT NULL,

    CONSTRAINT "patients_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "patient_clinical_infos" (
    "id" TEXT NOT NULL,
    "patientId" TEXT NOT NULL,
    "start_date" TIMESTAMP(3) NOT NULL,
    "health_insurance" TEXT,
    "initial_weight_kg" DOUBLE PRECISION,
    "height_cm" DOUBLE PRECISION,
    "allergies" TEXT,
    "comorbidities" TEXT,
    "medications_in_use" TEXT,
    "main_treatment_goal" TEXT,

    CONSTRAINT "patient_clinical_infos_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "patient_anamneses" (
    "id" TEXT NOT NULL,
    "patientId" TEXT NOT NULL,
    "chief_complaint" TEXT,
    "history_of_current_illness" TEXT,
    "personal_and_family_history" TEXT,
    "lifestyle_habits" TEXT,

    CONSTRAINT "patient_anamneses_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "patients_cpf_key" ON "patients"("cpf");

-- CreateIndex
CREATE UNIQUE INDEX "patient_clinical_infos_patientId_key" ON "patient_clinical_infos"("patientId");

-- CreateIndex
CREATE UNIQUE INDEX "patient_anamneses_patientId_key" ON "patient_anamneses"("patientId");

-- AddForeignKey
ALTER TABLE "patients" ADD CONSTRAINT "patients_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_clinical_infos" ADD CONSTRAINT "patient_clinical_infos_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patient_anamneses" ADD CONSTRAINT "patient_anamneses_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
