/*
  Warnings:

  - You are about to drop the column `muscle_percentage` on the `nutritional_consultations` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "nutritional_consultations" DROP COLUMN "muscle_percentage";
