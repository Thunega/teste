/*
  Warnings:

  - You are about to drop the column `waist_cm` on the `nutritional_consultations` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "nutritional_consultations" DROP COLUMN "waist_cm",
ADD COLUMN     "bust_cm" DOUBLE PRECISION,
ADD COLUMN     "glute_cm" DOUBLE PRECISION,
ADD COLUMN     "left_arm_cm" DOUBLE PRECISION,
ADD COLUMN     "left_calf_cm" DOUBLE PRECISION,
ADD COLUMN     "left_thigh_cm" DOUBLE PRECISION,
ADD COLUMN     "lower_waist_cm" DOUBLE PRECISION,
ADD COLUMN     "metabolic_age" INTEGER,
ADD COLUMN     "midline_waist_cm" DOUBLE PRECISION,
ADD COLUMN     "muscle_percentage" DOUBLE PRECISION,
ADD COLUMN     "neck_cm" DOUBLE PRECISION,
ADD COLUMN     "resting_metabolism_kcal" INTEGER,
ADD COLUMN     "right_arm_cm" DOUBLE PRECISION,
ADD COLUMN     "right_calf_cm" DOUBLE PRECISION,
ADD COLUMN     "right_thigh_cm" DOUBLE PRECISION,
ADD COLUMN     "stomach_cm" DOUBLE PRECISION,
ADD COLUMN     "upper_waist_cm" DOUBLE PRECISION,
ADD COLUMN     "visceral_fat_level" INTEGER,
ALTER COLUMN "hip_cm" SET DATA TYPE DOUBLE PRECISION;
