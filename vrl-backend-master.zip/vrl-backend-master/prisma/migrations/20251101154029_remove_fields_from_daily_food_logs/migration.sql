/*
  Warnings:

  - You are about to drop the column `observations` on the `daily_food_logs` table. All the data in the column will be lost.
  - You are about to drop the column `total_water_intake_ml` on the `daily_food_logs` table. All the data in the column will be lost.
  - You are about to drop the column `location` on the `meal_records` table. All the data in the column will be lost.
  - You are about to drop the column `meal_type` on the `meal_records` table. All the data in the column will be lost.
  - You are about to drop the column `observations` on the `meal_records` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "daily_food_logs" DROP COLUMN "observations",
DROP COLUMN "total_water_intake_ml";

-- AlterTable
ALTER TABLE "meal_records" DROP COLUMN "location",
DROP COLUMN "meal_type",
DROP COLUMN "observations";

-- DropEnum
DROP TYPE "MealType";
