-- AlterTable
ALTER TABLE "physical_activities" ALTER COLUMN "name" DROP NOT NULL,
ALTER COLUMN "duration" DROP NOT NULL,
ALTER COLUMN "intensity" DROP NOT NULL;
