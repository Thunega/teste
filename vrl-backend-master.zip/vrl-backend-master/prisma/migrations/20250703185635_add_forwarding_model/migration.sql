/*
  Warnings:

  - The values [EDUCATOR_VR] on the enum `UserRole` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "UserRole_new" AS ENUM ('EDUCATOR_IN_VR', 'PHYSIOTHERAPIST', 'DOCTOR', 'PSYCHOLOGIST', 'ADMIN');
ALTER TABLE "users" ALTER COLUMN "role" TYPE "UserRole_new" USING ("role"::text::"UserRole_new");
ALTER TYPE "UserRole" RENAME TO "UserRole_old";
ALTER TYPE "UserRole_new" RENAME TO "UserRole";
DROP TYPE "UserRole_old";
COMMIT;

-- CreateTable
CREATE TABLE "forwardings" (
    "id" TEXT NOT NULL,
    "patient_id" TEXT NOT NULL,
    "from_user_id" TEXT NOT NULL,
    "to_user_id" TEXT NOT NULL,
    "medical_notes" TEXT NOT NULL,

    CONSTRAINT "forwardings_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "forwardings" ADD CONSTRAINT "forwardings_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "forwardings" ADD CONSTRAINT "forwardings_from_user_id_fkey" FOREIGN KEY ("from_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "forwardings" ADD CONSTRAINT "forwardings_to_user_id_fkey" FOREIGN KEY ("to_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
