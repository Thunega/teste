/*
  Warnings:

  - You are about to drop the column `temperature` on the `vital_signs` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "vital_signs" DROP COLUMN "temperature";
