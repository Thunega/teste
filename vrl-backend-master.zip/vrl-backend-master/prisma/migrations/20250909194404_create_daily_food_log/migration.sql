-- CreateEnum
CREATE TYPE "MealType" AS ENUM ('BREAKFAST', 'MORNING_SNACK', 'LUNCH', 'AFTERNOON_SNACK', 'DINNER', 'EVENING_SNACK', 'OTHER');

-- CreateTable
CREATE TABLE "daily_food_logs" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "date_of_registration" TEXT NOT NULL,
    "observations" TEXT,
    "total_water_intake_ml" DOUBLE PRECISION,
    "patient_id" TEXT NOT NULL,

    CONSTRAINT "daily_food_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "meal_records" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "meal_type" "MealType" NOT NULL,
    "meal_time" TEXT NOT NULL,
    "description" TEXT,
    "location" TEXT,
    "observations" TEXT,
    "daily_food_log_id" TEXT NOT NULL,

    CONSTRAINT "meal_records_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "food_items" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "name" TEXT NOT NULL,
    "brand" TEXT,
    "quantity" DOUBLE PRECISION NOT NULL,
    "unit" TEXT NOT NULL,
    "calories" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "carbohydrates_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "proteins_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "total_fats_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "saturated_fats_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "trans_fats_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "monounsaturated_fats_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "polyunsaturated_fats_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "cholesterol_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "fiber_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "sugar_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "sodium_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_a_mcg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_b1_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_b2_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_b3_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_b5_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_b6_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_b7_mcg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_b9_mcg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_b12_mcg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_c_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_d_mcg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_e_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "vitamin_k_mcg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "calcium_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "iron_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "magnesium_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "phosphorus_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "potassium_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "zinc_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "copper_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "manganese_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "selenium_mcg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "iodine_mcg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "omega_3_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "omega_6_g" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "caffeine_mg" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "notes" TEXT,
    "meal_record_id" TEXT NOT NULL,

    CONSTRAINT "food_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "meal_photos" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "url" TEXT NOT NULL,
    "description" TEXT,
    "meal_record_id" TEXT NOT NULL,

    CONSTRAINT "meal_photos_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "daily_food_logs_patient_id_date_of_registration_key" ON "daily_food_logs"("patient_id", "date_of_registration");

-- AddForeignKey
ALTER TABLE "daily_food_logs" ADD CONSTRAINT "daily_food_logs_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "meal_records" ADD CONSTRAINT "meal_records_daily_food_log_id_fkey" FOREIGN KEY ("daily_food_log_id") REFERENCES "daily_food_logs"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "food_items" ADD CONSTRAINT "food_items_meal_record_id_fkey" FOREIGN KEY ("meal_record_id") REFERENCES "meal_records"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "meal_photos" ADD CONSTRAINT "meal_photos_meal_record_id_fkey" FOREIGN KEY ("meal_record_id") REFERENCES "meal_records"("id") ON DELETE CASCADE ON UPDATE CASCADE;
