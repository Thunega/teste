/*
  Warnings:

  - You are about to drop the column `refresh_token` on the `sessions` table. All the data in the column will be lost.

*/
-- DropIndex
DROP INDEX "sessions_refresh_token_key";

-- AlterTable
ALTER TABLE "sessions" DROP COLUMN "refresh_token";
