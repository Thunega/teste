-- AlterTable
ALTER TABLE "medical_consultation" ADD COLUMN     "bmi" DOUBLE PRECISION,
ADD COLUMN     "height_cm" DOUBLE PRECISION,
ADD COLUMN     "weight_kg" DOUBLE PRECISION;
