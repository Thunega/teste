-- CreateTable
CREATE TABLE "fitbit_auths" (
    "id" TEXT NOT NULL,
    "access_token" TEXT NOT NULL,
    "expires_in" INTEGER NOT NULL,
    "refresh_token" TEXT NOT NULL,
    "scope" TEXT NOT NULL,
    "token_type" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,
    "patient_id" TEXT NOT NULL,

    CONSTRAINT "fitbit_auths_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "fitbit_auths_user_id_key" ON "fitbit_auths"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "fitbit_auths_patient_id_key" ON "fitbit_auths"("patient_id");

-- AddForeignKey
ALTER TABLE "fitbit_auths" ADD CONSTRAINT "fitbit_auths_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE CASCADE ON UPDATE CASCADE;
