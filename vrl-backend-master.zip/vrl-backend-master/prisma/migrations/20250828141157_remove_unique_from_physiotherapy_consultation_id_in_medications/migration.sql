-- DropIndex
DROP INDEX "medications_physiotherapy_consultation_id_key";
