-- AlterEnum
ALTER TYPE "UserRole" ADD VALUE 'NUTRITIONIST';

-- CreateTable
CREATE TABLE "nutritional_consultations" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "user_id" TEXT NOT NULL,
    "consultation_date" TEXT NOT NULL,
    "reason" TEXT NOT NULL,
    "main_objective" TEXT NOT NULL,
    "weight_kg" DOUBLE PRECISION NOT NULL,
    "height_cm" DOUBLE PRECISION NOT NULL,
    "imc" DOUBLE PRECISION NOT NULL,
    "fat_percentage" DOUBLE PRECISION NOT NULL,
    "lean_mass_percentage" DOUBLE PRECISION NOT NULL,
    "waist_cm" INTEGER NOT NULL,
    "hip_cm" INTEGER NOT NULL,
    "dietary_restrictions" TEXT NOT NULL,
    "dietary_preferences" TEXT NOT NULL,
    "meal_frequency" TEXT NOT NULL,
    "meal_times" TEXT NOT NULL,
    "sedentary_habits" BOOLEAN NOT NULL,
    "sleep_duration_adequate" BOOLEAN NOT NULL,
    "has_been_on_diet" BOOLEAN NOT NULL,
    "cooks_own_meals" BOOLEAN NOT NULL,
    "regular_bowel_function" BOOLEAN NOT NULL,
    "practices_physical_activity" BOOLEAN NOT NULL,
    "uses_licit_drugs" BOOLEAN NOT NULL,
    "balanced_diet" BOOLEAN NOT NULL,
    "frequent_liquid_intake" BOOLEAN NOT NULL,
    "is_pregnant" BOOLEAN NOT NULL,
    "nutritional_guidance" TEXT,
    "patient_id" TEXT NOT NULL,

    CONSTRAINT "nutritional_consultations_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "nutritional_consultations" ADD CONSTRAINT "nutritional_consultations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "nutritional_consultations" ADD CONSTRAINT "nutritional_consultations_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
