-- AlterTable
ALTER TABLE "medical_consultation" ADD COLUMN     "observations" TEXT;
