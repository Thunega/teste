/*
  Warnings:

  - You are about to drop the `meal_photos` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "meal_photos" DROP CONSTRAINT "meal_photos_meal_record_id_fkey";

-- DropTable
DROP TABLE "meal_photos";
