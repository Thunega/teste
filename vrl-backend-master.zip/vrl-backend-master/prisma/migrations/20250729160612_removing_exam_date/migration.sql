/*
  Warnings:

  - You are about to drop the column `exam_date` on the `patient_examps` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "patient_examps" DROP COLUMN "exam_date";
