/*
  Warnings:

  - You are about to drop the column `responsibleUserId` on the `patient_examps` table. All the data in the column will be lost.
  - Added the required column `responsible_user_id` to the `patient_examps` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "patient_examps" DROP CONSTRAINT "patient_examps_responsibleUserId_fkey";

-- AlterTable
ALTER TABLE "patient_examps" DROP COLUMN "responsibleUserId",
ADD COLUMN     "responsible_user_id" TEXT NOT NULL;

-- AddForeignKey
ALTER TABLE "patient_examps" ADD CONSTRAINT "patient_examps_responsible_user_id_fkey" FOREIGN KEY ("responsible_user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
