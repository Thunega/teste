-- CreateTable
CREATE TABLE "medications" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "dosage" TEXT NOT NULL,
    "timetables" TEXT NOT NULL,
    "duration" TEXT NOT NULL,
    "medical_consultation_id" TEXT NOT NULL,

    CONSTRAINT "medications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "vital_signs" (
    "id" TEXT NOT NULL,
    "bloodPressure" TEXT NOT NULL,
    "heartRate" INTEGER NOT NULL,
    "temperature" DOUBLE PRECISION NOT NULL,
    "medical_consultation_id" TEXT NOT NULL,

    CONSTRAINT "vital_signs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "medical_consultation" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "consultation_date" TEXT NOT NULL,
    "vital_signs_id" TEXT,
    "patient_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,

    CONSTRAINT "medical_consultation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_MedicalConsultationToPatientExam" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL,

    CONSTRAINT "_MedicalConsultationToPatientExam_AB_pkey" PRIMARY KEY ("A","B")
);

-- CreateIndex
CREATE UNIQUE INDEX "vital_signs_medical_consultation_id_key" ON "vital_signs"("medical_consultation_id");

-- CreateIndex
CREATE UNIQUE INDEX "medical_consultation_vital_signs_id_key" ON "medical_consultation"("vital_signs_id");

-- CreateIndex
CREATE INDEX "_MedicalConsultationToPatientExam_B_index" ON "_MedicalConsultationToPatientExam"("B");

-- AddForeignKey
ALTER TABLE "medications" ADD CONSTRAINT "medications_medical_consultation_id_fkey" FOREIGN KEY ("medical_consultation_id") REFERENCES "medical_consultation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "vital_signs" ADD CONSTRAINT "vital_signs_medical_consultation_id_fkey" FOREIGN KEY ("medical_consultation_id") REFERENCES "medical_consultation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medical_consultation" ADD CONSTRAINT "medical_consultation_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "medical_consultation" ADD CONSTRAINT "medical_consultation_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_MedicalConsultationToPatientExam" ADD CONSTRAINT "_MedicalConsultationToPatientExam_A_fkey" FOREIGN KEY ("A") REFERENCES "medical_consultation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_MedicalConsultationToPatientExam" ADD CONSTRAINT "_MedicalConsultationToPatientExam_B_fkey" FOREIGN KEY ("B") REFERENCES "patient_examps"("id") ON DELETE CASCADE ON UPDATE CASCADE;
