/*
  Warnings:

  - You are about to drop the column `start_date` on the `patient_clinical_infos` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "patient_clinical_infos" DROP COLUMN "start_date";
