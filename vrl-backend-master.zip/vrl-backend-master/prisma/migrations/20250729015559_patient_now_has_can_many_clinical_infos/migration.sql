/*
  Warnings:

  - Added the required column `updatedAt` to the `patient_clinical_infos` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "patient_clinical_infos" ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL;
