-- AlterTable
ALTER TABLE "nutritional_consultations" ALTER COLUMN "dietary_restrictions" DROP NOT NULL,
ALTER COLUMN "dietary_preferences" DROP NOT NULL,
ALTER COLUMN "meal_frequency" DROP NOT NULL,
ALTER COLUMN "meal_times" DROP NOT NULL;
