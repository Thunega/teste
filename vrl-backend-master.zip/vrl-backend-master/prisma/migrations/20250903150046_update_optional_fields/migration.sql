-- AlterTable
ALTER TABLE "public"."nutritional_consultations" ALTER COLUMN "weight_kg" DROP NOT NULL,
ALTER COLUMN "height_cm" DROP NOT NULL,
ALTER COLUMN "fat_percentage" DROP NOT NULL,
ALTER COLUMN "lean_mass_percentage" DROP NOT NULL,
ALTER COLUMN "bmi" DROP NOT NULL;
