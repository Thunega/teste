-- CreateTable
CREATE TABLE "psychological_consultations" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "consultation_date" TEXT NOT NULL,
    "humor" TEXT NOT NULL,
    "anxiety_level" TEXT NOT NULL,
    "observations" TEXT,
    "patient_id" TEXT NOT NULL,
    "user_id" TEXT NOT NULL,

    CONSTRAINT "psychological_consultations_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "psychological_consultations" ADD CONSTRAINT "psychological_consultations_patient_id_fkey" FOREIGN KEY ("patient_id") REFERENCES "patients"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "psychological_consultations" ADD CONSTRAINT "psychological_consultations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
