-- AlterTable
ALTER TABLE "public"."physiotherapy_consultations" ALTER COLUMN "main_complaint" DROP NOT NULL,
ALTER COLUMN "short_term_goals" DROP NOT NULL,
ALTER COLUMN "long_term_goals" DROP NOT NULL,
ALTER COLUMN "treatment_plan" DROP NOT NULL,
ALTER COLUMN "session_frequency" DROP NOT NULL;
