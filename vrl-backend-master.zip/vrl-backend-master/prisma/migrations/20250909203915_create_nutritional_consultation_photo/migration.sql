-- CreateTable
CREATE TABLE "consultation_photos" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "photo_url" TEXT NOT NULL,
    "photo_type" TEXT,
    "description" TEXT,
    "nutritional_consultation_id" TEXT NOT NULL,

    CONSTRAINT "consultation_photos_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "consultation_photos" ADD CONSTRAINT "consultation_photos_nutritional_consultation_id_fkey" FOREIGN KEY ("nutritional_consultation_id") REFERENCES "nutritional_consultations"("id") ON DELETE CASCADE ON UPDATE CASCADE;
