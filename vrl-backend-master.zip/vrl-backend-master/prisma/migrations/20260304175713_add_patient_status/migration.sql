/*
  Warnings:

  - You are about to drop the `physiotherapy_sessions` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "PatientStatus" AS ENUM ('ACTIVE', 'TREATMENT_INTERRUPTED', 'TREATMENT_COMPLETED');

-- DropForeignKey
ALTER TABLE "physiotherapy_sessions" DROP CONSTRAINT "physiotherapy_sessions_patient_id_fkey";

-- DropForeignKey
ALTER TABLE "physiotherapy_sessions" DROP CONSTRAINT "physiotherapy_sessions_user_id_fkey";

-- AlterTable
ALTER TABLE "patients" ADD COLUMN     "status" "PatientStatus" NOT NULL DEFAULT 'ACTIVE';

-- DropTable
DROP TABLE "physiotherapy_sessions";
