import { PrismaPg } from "@prisma/adapter-pg"
import * as bcrypt from "bcrypt"
import { Pool } from "pg"

import { PrismaClient } from "../src/generated/prisma/client"
import { env } from "../src/helpers/env.helper"

const pool = new Pool({ connectionString: env("DATABASE_URL") })
const adapter = new PrismaPg(pool)
const prisma = new PrismaClient({ adapter: adapter })

const adminData = {
    email: env("ADMIN_DEFAULT_EMAIL"),
    name: env("ADMIN_DEFAULT_NAME"),
    password: env("ADMIN_DEFAULT_PASSWORD"),
}

async function seedAdminUser() {
    console.log("Checking for existing admin user...")

    const existingAdmin = await prisma.user.findUnique({
        where: { email: adminData.email },
        select: { id: true },
    })

    if (existingAdmin) {
        console.log("Admin already exists!")
        return
    }

    console.log("Creating admin user...")

    const hashSalts = parseInt(env("BCRYPT_SALT_ROUNDS"))
    const hashedPassword = await bcrypt.hash(adminData.password, hashSalts)

    await prisma.user.create({
        data: {
            name: adminData.name,
            email: adminData.email,
            role: "ADMIN",
            password: hashedPassword,
        },
    })

    console.log("Admin created successfully!")
}

async function main() {
    console.log("Starting database seeding...")

    try {
        await seedAdminUser()

        console.log("Database seeding completed successfully")
    } catch (error) {
        console.error("Seeding failed:", error)
        throw error
    } finally {
        console.log("Disconnecting Prisma client...")

        await prisma.$disconnect()

        console.log("Prisma client disconnected")
    }
}

if (require.main === module) {
    main().catch((error) => {
        console.error(error)
        process.exit(1)
    })
}
