import { fakerPT_BR as faker } from "@faker-js/faker"
import { PrismaPg } from "@prisma/adapter-pg"
import * as bcrypt from "bcrypt"
import { Pool } from "pg"

import * as crypto from "node:crypto"

import {
    UserRole,
    Gender,
    BloodType,
    SleepQuality,
    FunctionalLevel,
    MedicationStatus,
} from "../src/generated/prisma/enums"
import { PrismaClient } from "../src/generated/prisma/client"
import { env } from "../src/helpers/env.helper"

const pool = new Pool({ connectionString: env("DATABASE_URL") })
const adapter = new PrismaPg(pool)
const prisma = new PrismaClient({ adapter: adapter })

const hashSalts = parseInt(env("BCRYPT_SALT_ROUNDS") || "10")

const encryptionAlgorithm = env("ENCRYPTION_ALGORITHM")
const encryptionKey = Buffer.from(env("ENCRYPTION_KEY"), "hex")
const encryptionIv = Buffer.from(env("ENCRYPTION_IV"), "hex")

function encrypt(text: string): string {
    const cipher = crypto.createCipheriv(encryptionAlgorithm, encryptionKey, encryptionIv)
    let encrypted = cipher.update(text, "utf8", "hex")
    encrypted += cipher.final("hex")
    return encrypted
}

const adminData = {
    email: env("ADMIN_DEFAULT_EMAIL") || "admin@vrl.com",
    name: env("ADMIN_DEFAULT_NAME") || "Administrador",
    password: env("ADMIN_DEFAULT_PASSWORD") || "Admin@123",
}

async function seedAdminUser() {
    console.log("Checking for existing admin user...")

    const existingAdmin = await prisma.user.findUnique({
        where: { email: adminData.email },
        select: { id: true },
    })

    if (existingAdmin) {
        console.log("Admin already exists!")
        return existingAdmin.id
    }

    console.log("Creating admin user...")

    const hashedPassword = await bcrypt.hash(adminData.password, hashSalts)

    const admin = await prisma.user.create({
        data: {
            name: adminData.name,
            email: adminData.email,
            role: "ADMIN" as UserRole,
            password: hashedPassword,
        },
    })

    console.log("Admin created successfully!")

    return admin.id
}

async function seedOtherUsers() {
    console.log("Seeding users for each role...")

    const roles: UserRole[] = [
        "DOCTOR",
        "PHYSIOTHERAPIST",
        "PSYCHOLOGIST",
        "NUTRITIONIST",
        "EDUCATOR_VR",
        "DATA_COLLECTOR",
    ]

    const users: any[] = []

    for (const role of roles) {
        const email = role.toLowerCase() + "@vrl.com"
        const existing = await prisma.user.findUnique({ where: { email } })

        if (!existing) {
            console.log(`Creating user for role ${role}...`)
            const hashedPassword = await bcrypt.hash("Password@123", hashSalts)
            const user = await prisma.user.create({
                data: {
                    name: faker.person.fullName(),
                    email,
                    role: role as UserRole,
                    password: hashedPassword,
                },
            })
            users.push(user)
        } else {
            users.push(existing)
        }
    }
    return users
}

async function seedPatients(professionalUsers: any[]) {
    console.log("Seeding patients...")

    const patients: any[] = []

    for (let i = 0; i < 15; i++) {
        const rawCpf = faker.string.numeric(11)
        const encryptedCpf = encrypt(rawCpf)
        const existing = await prisma.patient.findUnique({ where: { cpf: encryptedCpf } })

        if (!existing) {
            const owner = faker.helpers.arrayElement(professionalUsers)
            const patient = await prisma.patient.create({
                data: {
                    name: faker.person.fullName(),
                    cpf: encryptedCpf,
                    dateOfBirth: faker.date.birthdate({ min: 18, max: 90, mode: "age" }).toISOString().split("T")[0],
                    gender: faker.helpers.arrayElement(["MALE", "FEMALE", "OTHER"] as Gender[]),
                    email: faker.internet.email(),
                    phone: faker.phone.number(),
                    address: faker.location.streetAddress(),
                    city: faker.location.city(),
                    state: faker.location.state({ abbreviated: true }),
                    zipCode: faker.location.zipCode(),
                    bloodType: faker.helpers.arrayElement(Object.values(BloodType)),
                    ownerId: owner.id,
                },
            })

            // Clinical info
            await prisma.patientClinicalInfo.create({
                data: {
                    patientId: patient.id,
                    heightCm: faker.number.float({ min: 150, max: 200, multipleOf: 0.1 }),
                    weightKg: faker.number.float({ min: 50, max: 120, multipleOf: 0.1 }),
                    healthInsurance: faker.helpers.arrayElement(["Unimed", "Bradesco", "Amil", "SulAmérica", "SUS"]),
                    allergies: faker.helpers.arrayElement(["Dipirona", "Lactose", "Glúten", "Nenhuma"]),
                    comorbidities: faker.helpers.arrayElement(["Hipertensão", "Diabetes Tipo 2", "Asma", "Nenhuma"]),
                    mainTreatmentGoal: "Melhorar qualidade de vida e condicionamento físico",
                },
            })

            // Anamnesis
            await prisma.patientAnamnesis.create({
                data: {
                    patientId: patient.id,
                    chiefComplaint: "Dores recorrentes e fadiga",
                    historyOfCurrentIllness: "Paciente relata início dos sintomas há 6 meses...",
                    lifestyleHabits: "Sedentário, fumante ocasional",
                    personalAndFamilyHistory: "Pai hipertenso, mãe saudável",
                },
            })

            patients.push(patient)
        } else {
            patients.push(existing)
        }
    }
    return patients
}

async function seedConsultations(patients: any[], users: any[]) {
    console.log("Seeding consultations and logs...")

    const nurses = users.filter((u) => u.role === "NUTRITIONIST")
    const doctors = users.filter((u) => u.role === "DOCTOR")
    const physios = users.filter((u) => u.role === "PHYSIOTHERAPIST")
    const psychs = users.filter((u) => u.role === "PSYCHOLOGIST")

    for (const patient of patients) {
        if (nurses.length > 0) {
            await prisma.nutritionalConsultation.create({
                data: {
                    patientId: patient.id,
                    userId: faker.helpers.arrayElement(nurses).id,
                    consultationDate: faker.date.recent({ days: 30 }).toISOString().split("T")[0],
                    reason: "Avaliação inicial",
                    mainObjective: "Perda de peso",
                    weightKg: 85,
                    heightCm: 180,
                    bmi: 26.2,
                    sedentaryHabits: true,
                    sleepDurationAdequate: false,
                    hasBeenOnDiet: true,
                    cooksOwnMeals: false,
                    regularBowelFunction: true,
                    practicesPhysicalActivity: false,
                    usesLicitDrugs: false,
                    balancedDiet: false,
                    frequentLiquidIntake: true,
                    isPregnant: false,
                },
            })
        }

        // Psychological Consultations
        if (psychs.length > 0) {
            await prisma.psychologicalConsultation.create({
                data: {
                    patientId: patient.id,
                    userId: faker.helpers.arrayElement(psychs).id,
                    consultationDate: faker.date.recent({ days: 30 }).toISOString().split("T")[0],
                    humor: "Estável",
                    anxietyLevel: "Moderada",
                    observations: "Indícios de burnout",
                },
            })
        }

        // Medical Consultations
        if (doctors.length > 0) {
            await prisma.medicalConsultation.create({
                data: {
                    patientId: patient.id,
                    userId: faker.helpers.arrayElement(doctors).id,
                    consultationDate: faker.date.recent({ days: 30 }).toISOString().split("T")[0],
                    observations: "Paciente estável",
                    vitalSigns: {
                        create: {
                            bloodPressure: "12/8",
                            heartRate: 75,
                        },
                    },
                },
            })
        }

        // Physiotherapy Consultations
        if (physios.length > 0) {
            await prisma.physiotherapyConsultation.create({
                data: {
                    patientId: patient.id,
                    userId: faker.helpers.arrayElement(physios).id,
                    consultationDate: faker.date.recent({ days: 30 }).toISOString().split("T")[0],
                    medicalHistory: "Trauma no joelho direito há 2 anos",
                    painLevel: 6,
                    functionalLevel: "SEMI_INDEPENDENT" as FunctionalLevel,
                    shortTermGoals: "Redução de quadro álgico",
                    treatmentPlan: "Fortalecimento de quadríceps",
                },
            })
        }

        // Performance Logs
        for (let j = 0; j < 5; j++) {
            await prisma.dailyPerformanceLog.create({
                data: {
                    patientId: patient.id,
                    dateOfRegistration: faker.date.recent({ days: 7 }).toISOString().split("T")[0],
                    bloodPressure: "120/80",
                    oxygenSaturation: 98,
                    beatsPerMinute: 70,
                    sleepQuality: faker.helpers.arrayElement(["GOOD", "AVERAGE", "BAD"] as SleepQuality[]),
                    observations: "Tudo normal",
                },
            })

            await prisma.sleepLog.create({
                data: {
                    patientId: patient.id,
                    dateOfRegistration: faker.date.recent({ days: 7 }).toISOString().split("T")[0],
                    score: faker.number.int({ min: 50, max: 100 }),
                    sleepTime: 480, // 8h
                    agreedTime: 420,
                    remTime: 90,
                    lightSleep: 200,
                    deepSleep: 100,
                    observations: "Recuperado",
                },
            })
        }
    }
}

async function seedExtraPatientData(patients: any[], users: any[]) {
    console.log("Seeding extra patient data (Exams, Appointments, Forwardings, Food Logs, etc.)...")

    const doctors = users.filter((u) => u.role === "DOCTOR")
    const educators = users.filter((u) => u.role === "EDUCATOR_VR")

    for (const patient of patients) {
        await prisma.patientExam.create({
            data: {
                patientId: patient.id,
                responsibleUserId: faker.helpers.arrayElement(doctors).id,
                examDate: faker.date.recent({ days: 15 }).toISOString().split("T")[0],
                totalCholesterol: faker.number.float({ min: 150, max: 240, multipleOf: 0.1 }),
                hdl: faker.number.float({ min: 40, max: 60, multipleOf: 0.1 }),
                ldl: faker.number.float({ min: 100, max: 160, multipleOf: 0.1 }),
                fastingGlucose: faker.number.float({ min: 70, max: 110, multipleOf: 0.1 }),
                triglycerides: faker.number.float({ min: 100, max: 200, multipleOf: 0.1 }),
                hemoglobinaGlicada: faker.number.float({ min: 4.5, max: 6.5, multipleOf: 0.1 }),
                observations: "Resultados dentro da normalidade esperada para o perfil.",
            },
        })

        // Appointments
        await prisma.appointment.create({
            data: {
                patientId: patient.id,
                responsibleUserId: faker.helpers.arrayElement(users).id,
                scheduledAt: faker.date.soon({ days: 30 }),
                description: "Consulta de retorno para avaliação de exames.",
            },
        })

        // Forwardings
        const fromUser = faker.helpers.arrayElement(users)
        const toUser = faker.helpers.arrayElement(users.filter((u) => u.id !== fromUser.id))
        await prisma.forwarding.create({
            data: {
                patientId: patient.id,
                fromUserId: fromUser.id,
                toUserId: toUser.id,
                medicalNotes: "Encaminhado para avaliação complementar de especialista.",
            },
        })

        // Weekly Weights
        for (let w = 0; w < 4; w++) {
            await prisma.weeklyWeight.create({
                data: {
                    patientId: patient.id,
                    weekStartDate: faker.date.recent({ days: 30 }).toISOString().split("T")[0],
                    weightKg: faker.number.float({ min: 60, max: 95, multipleOf: 0.1 }),
                    observations: "Monitoramento semanal regular.",
                },
            })
        }

        // Daily Food Logs
        const foodLog = await prisma.dailyFoodLog.create({
            data: {
                patientId: patient.id,
                dateOfRegistration: faker.date.recent({ days: 3 }).toISOString().split("T")[0],
            },
        })

        const mealTypes = ["Café da Manhã", "Almoço", "Jantar", "Lanche"]
        for (const type of mealTypes) {
            const meal = await prisma.mealRecord.create({
                data: {
                    dailyFoodLogId: foodLog.id,
                    mealTime: "12:00",
                    description: type,
                },
            })

            await prisma.foodItem.create({
                data: {
                    mealRecordId: meal.id,
                    name: "Alimento Exemplo",
                    brand: "Marca Genérica",
                    quantity: 100,
                    unit: "g",
                    calories: 250,
                    proteins: 20,
                    carbohydrates: 30,
                    totalFats: 10,
                },
            })
        }
    }
}

async function seedReminders(users: any[]) {
    console.log("Seeding reminders for users...")
    for (const user of users) {
        await prisma.reminder.create({
            data: {
                ownerId: user.id,
                title: "Lembrete: Revisão de Relatórios",
                description: "Completar a revisão dos logs semanais dos pacientes.",
                scheduledAt: faker.date.soon({ days: 7 }),
            },
        })
    }
}

async function seedMedications(patients: any[]) {
    console.log("Seeding medications and history...")
    for (const patient of patients) {
        const medsCount = faker.number.int({ min: 1, max: 3 })
        for (let i = 0; i < medsCount; i++) {
            const medication = await prisma.medication.create({
                data: {
                    patientId: patient.id,
                    name: faker.commerce.productName(),
                    dosage: `${faker.number.int({ min: 10, max: 500 })}mg`,
                    timetables: faker.helpers.arrayElement(["8h em 8h", "12h em 12h", "Uma vez ao dia", "Ao deitar"]),
                    duration: faker.helpers.arrayElement(["7 dias", "15 dias", "Uso contínuo"]),
                    status: faker.helpers.arrayElement(["ACTIVE", "INACTIVE"] as MedicationStatus[]),
                },
            })

            await prisma.medicationHistory.create({
                data: {
                    medicationId: medication.id,
                    status: "ACTIVE" as MedicationStatus,
                    dosage: medication.dosage,
                    timetables: medication.timetables,
                    duration: medication.duration,
                    observations: "Prescrição inicial no seed",
                },
            })

            // If inactive, add a reason and a history entry for the change
            if (medication.status === "INACTIVE") {
                await prisma.medication.update({
                    where: { id: medication.id },
                    data: {
                        discontinuedAt: faker.date.recent(),
                        discontinuedReason: faker.helpers.arrayElement([
                            "Tratamento concluído",
                            "Efeito colateral",
                            "Substituição",
                        ]),
                    },
                })

                await prisma.medicationHistory.create({
                    data: {
                        medicationId: medication.id,
                        status: "INACTIVE" as MedicationStatus,
                        dosage: medication.dosage,
                        timetables: medication.timetables,
                        duration: medication.duration,
                        observations: "Uso interrompido no seed",
                    },
                })
            }
        }
    }
}

async function seedMessages(users: any[], patients: any[]) {
    console.log("Seeding messages...")

    for (const sender of users) {
        const messagesCount = faker.number.int({ min: 3, max: 6 })
        for (let i = 0; i < messagesCount; i++) {
            const receiver = faker.helpers.arrayElement(users.filter((u) => u.id !== sender.id))
            if (!receiver) continue

            const addPatient = faker.datatype.boolean()
            const patientId = addPatient && patients.length > 0 ? faker.helpers.arrayElement(patients).id : null

            await prisma.message.create({
                data: {
                    subject: faker.lorem.sentence({ min: 3, max: 6 }),
                    body: faker.lorem.paragraphs({ min: 1, max: 3 }),
                    isRead: faker.datatype.boolean(),
                    senderId: sender.id,
                    receiverId: receiver.id,
                    patientId: patientId,
                },
            })
        }
    }
}

async function main() {
    console.log("Starting local development seeding...")

    try {
        console.log("Cleaning up existing data...")

        await prisma.message.deleteMany()
        await prisma.appointment.deleteMany()
        await prisma.forwarding.deleteMany()
        await prisma.reminder.deleteMany()
        await prisma.dailyFoodLog.deleteMany()
        await prisma.medication.deleteMany()
        await prisma.patient.deleteMany()

        const adminId = await seedAdminUser()
        const users = await seedOtherUsers()

        const patients = await seedPatients(users)
        await seedConsultations(patients, users)
        await seedExtraPatientData(patients, users)
        await seedMedications(patients)
        await seedReminders([{ id: adminId }, ...users])
        await seedMessages([{ id: adminId }, ...users], patients)

        console.log("Database development seeding completed successfully")
    } catch (error) {
        console.error("Seeding failed:", error)
        throw error
    } finally {
        console.log("Disconnecting Prisma client...")
        await prisma.$disconnect()
        console.log("Prisma client disconnected")
    }
}

main().catch((error) => {
    console.error(error)
    process.exit(1)
})
