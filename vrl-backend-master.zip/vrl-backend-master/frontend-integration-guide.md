# Guia de Integração Frontend: Busca, Filtro e Ordenação nas Listagens

Este documento detalha as recentes atualizações na API relativas à padronização e aprimoramento dos endpoints de listagem (GET). As mudanças visam fornecer flexibilidade total para implementação de tabelas dinâmicas, listas filtráveis e buscas textuais no frontend.

## Visão Geral das Mudanças

Todos os principais endpoints de listagem foram refatorados para aceitar um conjunto padrão de *query parameters*. Além da paginação existente (`page` e `perPage`), agora você pode usar:

*   **`query`** (`string`, opcional): Um termo de busca geral. A API fará uma busca *case-insensitive* (ignorando maiúsculas/minúsculas) em campos relevantes da entidade principal e de seus relacionamentos (ex: busca por nome de paciente, email, descrição, título, etc.).
*   **`orderBy`** (`string`, opcional): O nome do campo pelo qual os resultados devem ser ordenados (camelCase, idêntico à resposta da API, ex: `createdAt`, `name`, `scheduledAt`).
*   **`sort`** (`'asc'` | `'desc'`, opcional): A direção da ordenação. Crescente (`asc`) ou decrescente (`desc`).

### Comportamento Padrão

*   **Busca (`query`)**: Se for omitido, a API retornará todos os registros (respeitando a paginação e os filtros específicos).
*   **Ordenação (`orderBy` / `sort`)**:
    *   Se não for fornecido, a API aplicará uma ordenação padrão lógica baseada na entidade. Regra geral:
        *   Entidades baseadas em tempo (logs, consultas, exames, mensagens): padrão é `createdAt` ou `scheduledAt` em ordem `desc` (mais recentes primeiro).
        *   Entidades cadastrais (usuários, pacientes, medicamentos): padrão é `name` em ordem `asc` (ordem alfabética).
    *   Se for fornecido um `orderBy`, mas o `sort` for omitido, a API assumirá o valor padrão configurado globalmente (atualmente `'asc'`).

## Endpoints Atualizados

Os seguintes módulos agora suportam integralmente os novos padrões:

*   `/users`
*   `/patients`
*   `/appointments`
*   `/reminders`
*   `/medications/patient/:patientId`
*   `/exams`
*   `/forwardings`
*   `/daily-performance-logs`
*   `/daily-food-logs`
*   `/sleep-logs`
*   `/medical-consultations`
*   `/messages`

*Nota: Alguns endpoints ainda mantêm filtros específicos (ex: `patientId`, `startDate`, `endDate`, `cpf`, `isRead`). Esses filtros funcionam em conjunto com a nova `query`.*

---

## Dicas Gerais de Integração

Abaixo estão algumas dicas genéricas focadas na melhor experiência de uso das novas APIs no cliente:

### 1. Chamadas com Debounce
Ao implementar a busca via campo de texto (`query`), evite fazer uma requisição a cada caractere digitado pelo usuário. Utilize uma técnica de *debounce* (ex: 500ms) para aguardar o fim da digitação antes de disparar a requisição. Isso reduz consideravelmente a carga na API e evita problemas de condições de corrida (*race conditions*).

### 2. Reset na Paginação ao Buscar/Ordenar
Lembre-se de sempre redefinir o parâmetro `page` para `1` (primeira página) sempre que o usuário realizar uma nova busca textual (`query`) ou mudar a ordenação da tabela (`orderBy` ou `sort`). Caso contrário, se o usuário estiver na página 5 de uma listagem e fizer uma pesquisa que retorne apenas 2 páginas, a interface tentará buscar itens que não existem.

### 3. Cancelamento de Requisições Prévias
Especialmente por conta de buscas e navegação rápida, o cliente pode disparar múltiplas requisições sequencialmente. Garanta que a sua biblioteca HTTP no frontend (como Axios ou Fetch) intercepte e cancele requisições pendentes se uma nova requisição para a mesma listagem for disparada antes da anterior finalizar. Isso pode ser feito usando `AbortController`.

### 4. Sincronização com URL Parameters (Opcional)
Se possível, reflita os parâmetros `query`, `orderBy` e `sort` nos *query parameters* da própria URL do navegador. Isso melhora a experiência do usuário permitindo o recarregamento da página ou envio de links para terceiros, mantendo o estado da tabela onde estava.
