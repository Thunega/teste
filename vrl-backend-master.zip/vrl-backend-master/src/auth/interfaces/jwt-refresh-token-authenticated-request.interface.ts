import { Request } from "express"

export interface JwtRefreshTokenAuthenticatedUser {
    sub: string
    email: string
    role: string
    name: string
    type: "access"
}

export interface JwtRefreshTokenAuthenticatedRequest extends Request {
    user: JwtRefreshTokenAuthenticatedUser
}
