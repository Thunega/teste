import { Request } from "express"

import { User } from "../../generated/prisma/client"

export type LocalAuthenticatedUser = User

export interface LocalAuthenticatedRequest extends Request {
    user: LocalAuthenticatedUser
}
