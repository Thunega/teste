export interface JwtAccessPayload {
    sub: string
    email: string
    role: string
    name: string
    type: "access"
    sessionId: string
}

export interface JwtRefreshPayload {
    sub: string
    type: "refresh"
    jti: string
}
