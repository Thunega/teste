import { Test, TestingModule } from "@nestjs/testing"
import { ConfigService } from "@nestjs/config"
import { JwtService } from "@nestjs/jwt"
import * as bcrypt from "bcrypt"

import { PrismaService } from "../prisma/prisma.service"
import { UsersService } from "../users/users.service"
import { AuthService } from "./auth.service"

describe("AuthService", () => {
    let service: AuthService
    let usersService: UsersService

    const mockUsersService = {
        findOneByEmail: jest.fn(),
        findOne: jest.fn(),
    }

    const mockJwtService = {
        sign: jest.fn(),
        verify: jest.fn(),
    }

    const mockConfigService = {
        getOrThrow: jest.fn().mockReturnValue("7d"),
    }

    const mockPrismaService = {
        session: {
            create: jest.fn(),
            findUnique: jest.fn(),
            update: jest.fn(),
        },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                AuthService,
                { provide: UsersService, useValue: mockUsersService },
                { provide: JwtService, useValue: mockJwtService },
                { provide: ConfigService, useValue: mockConfigService },
                { provide: PrismaService, useValue: mockPrismaService },
            ],
        }).compile()

        service = module.get<AuthService>(AuthService)
        usersService = module.get<UsersService>(UsersService)
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("validateUser", () => {
        it("should return user without password if valid", async () => {
            const user = { email: "a@a.com", password: "hashed" }
            mockUsersService.findOneByEmail.mockResolvedValue(user)
            jest.spyOn(bcrypt, "compare").mockImplementation(() => Promise.resolve(true))

            const result = await service.validateUser("a@a.com", "123")
            expect(result).toBeDefined()
            expect(result?.email).toBe("a@a.com")
        })

        it("should return null if invalid password", async () => {
            const user = { email: "a@a.com", password: "hashed" }
            mockUsersService.findOneByEmail.mockResolvedValue(user)
            jest.spyOn(bcrypt, "compare").mockImplementation(() => Promise.resolve(false))

            const result = await service.validateUser("a@a.com", "123")
            expect(result).toBeNull()
        })
    })
})
