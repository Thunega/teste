import { Body, Controller, Get, Post, Req, UseGuards } from "@nestjs/common"

import { ApiBody, ApiOperation, ApiTags, ApiBearerAuth } from "@nestjs/swagger"

import { Request } from "express"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"
import { LocalAuthenticatedRequest } from "./interfaces/local-authenticated-request.interface"
import { JwtAuthenticatedUser } from "./interfaces/jwt-authenticated-request.interface"
import { JwtRefreshTokenAuthGuard } from "./guards/jwt-refresh-token.guard"
import { InjectUser } from "./decorators/inject-user.decorator"
import { LocalAuthGuard } from "./guards/local-auth.guard"
import { RefreshTokenDto } from "./dto/refresh-token.dto"
import { JwtAuthGuard } from "./guards/jwt-auth.guard"
import { SignInDto } from "./dto/sign-in.dto"
import { AuthService } from "./auth.service"

@ApiTags("Autenticação")
@Controller("auth")
@ApiStandardErrorResponses()
export class AuthController {
    constructor(private readonly authService: AuthService) {}

    @ApiOperation({
        summary: "Autenticar usuário",
        description: "Espera e-mail e senha. Retorna tokens de acesso e refresh.",
    })
    @ApiBody({ type: SignInDto })
    @Post("sign-in")
    @UseGuards(LocalAuthGuard)
    async signIn(@Req() req: LocalAuthenticatedRequest, @Req() expressRequest: Request) {
        return await this.authService.signIn(
            req.user,
            expressRequest.ip ?? "",
            expressRequest.headers["user-agent"] ?? "",
        )
    }

    @ApiOperation({
        summary: "Renovar tokens via Refresh Token",
        description: "Pede um JWT válido de 'Refresh' na header Authorization, além da cópia dele no body.",
    })
    @ApiBearerAuth()
    @Post("refresh-token")
    @UseGuards(JwtRefreshTokenAuthGuard)
    async refreshToken(
        @InjectUser() user: JwtAuthenticatedUser,
        @Body() refreshTokenDto: RefreshTokenDto,
        @Req() expressRequest: Request,
    ) {
        return await this.authService.refreshToken(
            user.id,
            refreshTokenDto,
            expressRequest.ip ?? "",
            expressRequest.headers["user-agent"] ?? "",
        )
    }

    @ApiOperation({
        summary: "Retornar dados do usuário dono do token",
        description: "Exige o Access Token JWT. Retorna os dados resumidos do perfil extraídos do Payload.",
    })
    @ApiBearerAuth()
    @Get("me")
    @UseGuards(JwtAuthGuard)
    async getMe(@InjectUser() user: JwtAuthenticatedUser) {
        return user
    }
}
