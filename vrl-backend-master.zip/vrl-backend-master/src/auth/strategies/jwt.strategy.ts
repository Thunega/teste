import { Injectable, UnauthorizedException } from "@nestjs/common"
import { plainToInstance } from "class-transformer"
import { PassportStrategy } from "@nestjs/passport"
import { ExtractJwt, Strategy } from "passport-jwt"
import { validateSync } from "class-validator"
import { ConfigService } from "@nestjs/config"

import { JwtAccessPayload } from "../interfaces/jwt-payload.interface"
import { JwtAccessPayloadDto } from "../dto/jwt-access-payload.dto"
import { messagesHelper } from "../../helpers/messages.helper"
import { PrismaService } from "../../prisma/prisma.service"

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, "jwt") {
    constructor(
        readonly configService: ConfigService,
        private readonly prismaService: PrismaService,
    ) {
        super({
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            secretOrKey: configService.getOrThrow<string>("JWT_PRIVATE_KEY"),
        })
    }

    async validate(payload: JwtAccessPayload) {
        const dto = plainToInstance(JwtAccessPayloadDto, payload)
        const errors = validateSync(dto)

        if (errors.length > 0) {
            throw new UnauthorizedException(messagesHelper.INVALID_AUTHORIZATION_TOKEN)
        }

        if (!payload.sessionId) throw new UnauthorizedException("Sessão inválida ou revogada")

        const session = await this.prismaService.session.findUnique({
            where: { id: payload.sessionId },
        })

        if (!session || session.revokedAt) {
            throw new UnauthorizedException("Sessão inválida ou revogada")
        }

        return {
            id: payload.sub,
            email: payload.email,
            role: payload.role,
            name: payload.name,
            type: payload.type,
            sessionId: payload.sessionId,
        }
    }
}
