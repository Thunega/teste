import { Injectable, UnauthorizedException } from "@nestjs/common"
import { plainToInstance } from "class-transformer"
import { PassportStrategy } from "@nestjs/passport"
import { ExtractJwt, Strategy } from "passport-jwt"
import { validateSync } from "class-validator"
import { ConfigService } from "@nestjs/config"

import { JwtAccessPayload } from "../interfaces/jwt-payload.interface"
import { JwtAccessPayloadDto } from "../dto/jwt-access-payload.dto"
import { messagesHelper } from "../../helpers/messages.helper"

@Injectable()
export class JwtRefreshTokenStrategy extends PassportStrategy(Strategy, "jwt-refresh-token") {
    constructor(readonly configService: ConfigService) {
        super({
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            secretOrKey: configService.getOrThrow<string>("JWT_PRIVATE_KEY"),
            ignoreExpiration: true,
        })
    }

    validate(payload: JwtAccessPayload) {
        const dto = plainToInstance(JwtAccessPayloadDto, payload)
        const errors = validateSync(dto)

        if (errors.length > 0) {
            throw new UnauthorizedException(messagesHelper.INVALID_AUTHORIZATION_TOKEN)
        }

        return {
            id: payload.sub,
            email: payload.email,
            role: payload.role,
            name: payload.name,
            type: payload.type,
        }
    }
}
