import { Injectable, UnauthorizedException } from "@nestjs/common"
import { plainToInstance } from "class-transformer"
import { validateSync } from "class-validator"
import { ConfigService } from "@nestjs/config"
import { JwtService } from "@nestjs/jwt"
import * as bcrypt from "bcrypt"

import * as crypto from "node:crypto"
import type { StringValue } from "ms"

import { JwtAccessPayload, JwtRefreshPayload } from "./interfaces/jwt-payload.interface"
import { JwtRefreshPayloadDto } from "./dto/jwt-refresh-payload.dto"
import { messagesHelper } from "../helpers/messages.helper"
import { UserWithoutPassword } from "../users/users.types"
import { RefreshTokenDto } from "./dto/refresh-token.dto"
import { PrismaService } from "../prisma/prisma.service"
import { UsersService } from "../users/users.service"
import { User } from "../generated/prisma/client"

@Injectable()
export class AuthService {
    private readonly refreshSignExpiresIn: StringValue

    constructor(
        private readonly usersService: UsersService,
        private readonly jwtService: JwtService,
        private readonly configService: ConfigService,
        private readonly prismaService: PrismaService,
    ) {
        this.refreshSignExpiresIn = configService.getOrThrow<StringValue>("REFRESH_SIGN_EXPIRES_IN")
    }

    async signIn(user: Omit<User, "password">, ip: string, userAgent: string) {
        const sessionId = crypto.randomUUID()

        const refreshTokenExpiresIn = new Date()
        // Simple parsing for "7d" format
        const days = parseInt(this.refreshSignExpiresIn.replace("d", ""))
        refreshTokenExpiresIn.setDate(refreshTokenExpiresIn.getDate() + days)

        const session = await this.prismaService.session.create({
            data: {
                id: sessionId,
                userId: user.id,
                ip,
                userAgent,
                expiresAt: refreshTokenExpiresIn,
            },
        })

        const accessPayload: JwtAccessPayload = {
            sub: user.id,
            email: user.email,
            role: user.role,
            name: user.name,
            type: "access",
            sessionId: session.id,
        }

        const refreshPayload: JwtRefreshPayload = {
            sub: user.id,
            type: "refresh",
            jti: session.id,
        }

        return {
            accessToken: this.jwtService.sign(accessPayload),
            refreshToken: this.jwtService.sign(refreshPayload, {
                expiresIn: this.refreshSignExpiresIn,
            }),
        }
    }

    async refreshToken(userId: string, refreshTokenDto: RefreshTokenDto, ip: string, userAgent: string) {
        let payload: JwtRefreshPayload

        try {
            payload = this.jwtService.verify<JwtRefreshPayload>(refreshTokenDto.refreshToken, {
                secret: this.configService.getOrThrow<string>("JWT_PRIVATE_KEY"),
            })
        } catch (error) {
            throw new UnauthorizedException(messagesHelper.INVALID_AUTHORIZATION_TOKEN)
        }

        const dto = plainToInstance(JwtRefreshPayloadDto, payload)
        const errors = validateSync(dto)

        if (errors.length > 0 || payload.sub !== userId) {
            throw new UnauthorizedException(messagesHelper.INVALID_AUTHORIZATION_TOKEN)
        }

        const oldSession = await this.prismaService.session.findUnique({
            where: { id: payload.jti },
        })

        if (!oldSession || oldSession.revokedAt || oldSession.expiresAt < new Date()) {
            throw new UnauthorizedException("Sessão inválida ou expirada")
        }

        // Invalidate old session
        await this.prismaService.session.update({
            where: { id: oldSession.id },
            data: { revokedAt: new Date() },
        })

        const user = await this.usersService.findOne(payload.sub)

        // Create new session and tokens
        return this.signIn(user, ip, userAgent)
    }

    async validateUser(email: string, password: string): Promise<UserWithoutPassword | null> {
        let user: User

        try {
            user = await this.usersService.findOneByEmail(email)
        } catch (error) {
            return null
        }

        const isValidPassword = await bcrypt.compare(password, user.password)

        if (!isValidPassword) {
            return null
        }

        const { password: _, ...rest } = user

        return rest
    }
}
