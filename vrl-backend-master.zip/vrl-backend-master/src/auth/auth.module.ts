import { forwardRef, Module } from "@nestjs/common"
import { PassportModule } from "@nestjs/passport"
import { ConfigService } from "@nestjs/config"
import { JwtModule } from "@nestjs/jwt"

import type { StringValue } from "ms"

import { JwtRefreshTokenStrategy } from "./strategies/jwt-refresh-token.strategy"
import { LocalStrategy } from "./strategies/local.strategy"
import { JwtStrategy } from "./strategies/jwt.strategy"
import { PrismaModule } from "../prisma/prisma.module"
import { CryptoModule } from "../crypto/crypto.module"
import { UsersModule } from "../users/users.module"
import { AuthController } from "./auth.controller"
import { AuthService } from "./auth.service"

@Module({
    imports: [
        PrismaModule,
        PassportModule,
        forwardRef(() => UsersModule),
        CryptoModule,
        JwtModule.registerAsync({
            useFactory: (configService: ConfigService) => ({
                privateKey: configService.getOrThrow<string>("JWT_PRIVATE_KEY"),
                signOptions: { expiresIn: configService.getOrThrow<StringValue>("ACCESS_SIGN_EXPIRES_IN") },
            }),
            inject: [ConfigService],
        }),
    ],
    providers: [AuthService, LocalStrategy, JwtStrategy, JwtRefreshTokenStrategy],
    controllers: [AuthController],
    exports: [AuthService],
})
export class AuthModule {}
