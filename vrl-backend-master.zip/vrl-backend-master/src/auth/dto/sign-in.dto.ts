import { IsEmail, IsString } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class SignInDto {
    @ApiProperty({
        description: "E-mail de acesso do usuário",
        example: "joao.silva@vrleao.com.br",
    })
    @IsEmail()
    email: string

    @ApiProperty({
        description: "Senha do usuário",
        example: "Senha@2024",
    })
    @IsString()
    password: string
}
