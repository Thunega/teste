import { ApiProperty } from "@nestjs/swagger"
import { IsJWT } from "class-validator"

export class RefreshTokenDto {
    @ApiProperty({
        description: "Token JWT de atualização (Refresh Token)",
        example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NT...",
    })
    @IsJWT()
    refreshToken: string
}
