import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { DailyFoodLogsService } from "./daily-food-logs.service"
import { PatientsService } from "../patients/patients.service"
import { PrismaService } from "../prisma/prisma.service"

describe("DailyFoodLogsService", () => {
    let service: DailyFoodLogsService
    let prisma: PrismaService

    const mockPrisma = {
        dailyFoodLog: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = { findOne: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                DailyFoodLogsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<DailyFoodLogsService>(DailyFoodLogsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a food log", async () => {
            const dto = { patientId: "pid", meals: [] }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.dailyFoodLog.create.mockResolvedValue({ id: "lid", ...dto })

            const result = await service.create(dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.dailyFoodLog.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a log", async () => {
            mockPrisma.dailyFoodLog.findUnique.mockResolvedValue({ id: "lid" })
            const result = await service.findOne("lid")
            expect(result).toEqual({ id: "lid" })
        })

        it("should throw not found", async () => {
            mockPrisma.dailyFoodLog.findUnique.mockResolvedValue(null)
            await expect(service.findOne("lid")).rejects.toThrow(NotFoundException)
        })
    })
})
