import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateDailyFoodLogDto } from "./dto/update-daily-food-log.dto"
import { CreateDailyFoodLogDto } from "./dto/create-daily-food-log.dto"
import { Prisma, DailyFoodLog } from "../generated/prisma/client"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class DailyFoodLogsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(createDailyFoodLogDto: CreateDailyFoodLogDto) {
        const { patientId, meals, ...rest } = createDailyFoodLogDto

        await this.patientsService.findOne(patientId)

        const createData: Prisma.DailyFoodLogCreateInput = {
            ...rest,
            patient: {
                connect: {
                    id: patientId,
                },
            },
        }

        if (meals && meals.length > 0) {
            createData.meals = {
                create: meals.map((meal) => ({
                    mealTime: meal.mealTime,
                    description: meal.description,
                    foods:
                        meal.foods && meal.foods.length > 0
                            ? {
                                  create: meal.foods.map((food) => ({
                                      name: food.name,
                                      brand: food.brand,
                                      quantity: food.quantity,
                                      unit: food.unit,
                                      calories: food.calories || 0,
                                      carbohydrates: food.carbohydrates || 0,
                                      proteins: food.proteins || 0,
                                      totalFats: food.totalFats || 0,
                                      saturatedFats: food.saturatedFats || 0,
                                      transFats: food.transFats || 0,
                                      monounsaturatedFats: food.monounsaturatedFats || 0,
                                      polyunsaturatedFats: food.polyunsaturatedFats || 0,
                                      cholesterol: food.cholesterol || 0,
                                      fiber: food.fiber || 0,
                                      sugar: food.sugar || 0,
                                      sodium: food.sodium || 0,
                                      vitaminA: food.vitaminA || 0,
                                      vitaminB1: food.vitaminB1 || 0,
                                      vitaminB2: food.vitaminB2 || 0,
                                      vitaminB3: food.vitaminB3 || 0,
                                      vitaminB5: food.vitaminB5 || 0,
                                      vitaminB6: food.vitaminB6 || 0,
                                      vitaminB7: food.vitaminB7 || 0,
                                      vitaminB9: food.vitaminB9 || 0,
                                      vitaminB12: food.vitaminB12 || 0,
                                      vitaminC: food.vitaminC || 0,
                                      vitaminD: food.vitaminD || 0,
                                      vitaminE: food.vitaminE || 0,
                                      vitaminK: food.vitaminK || 0,
                                      calcium: food.calcium || 0,
                                      iron: food.iron || 0,
                                      magnesium: food.magnesium || 0,
                                      phosphorus: food.phosphorus || 0,
                                      potassium: food.potassium || 0,
                                      zinc: food.zinc || 0,
                                      copper: food.copper || 0,
                                      manganese: food.manganese || 0,
                                      selenium: food.selenium || 0,
                                      iodine: food.iodine || 0,
                                      omega3: food.omega3 || 0,
                                      omega6: food.omega6 || 0,
                                      caffeine: food.caffeine || 0,
                                      notes: food.notes,
                                  })),
                              }
                            : undefined,
                })),
            }
        }

        return await this.prisma.dailyFoodLog.create({
            data: createData,
            include: {
                patient: true,
                meals: {
                    include: {
                        foods: true,
                    },
                },
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        { startDate, endDate, query, orderBy, sort }: SearchOptions,
        patientId?: string,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const whereClause: Prisma.DailyFoodLogWhereInput = {
            patientId: patientId,
            createdAt: {
                gte: startDate,
                lte: endDate,
            },
        }

        if (query) {
            const cleanQuery = query.trim()

            whereClause.OR = [
                {
                    patient: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
            ]
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.createdAt = "desc"
        }

        return await paginate<DailyFoodLog, Prisma.DailyFoodLogFindManyArgs>(this.prisma.dailyFoodLog, {
            where: whereClause,
            orderBy: order,
            include: {
                patient: patientId ? false : true,
                meals: {
                    include: {
                        foods: true,
                    },
                },
            },
        })
    }

    async findOne(id: string) {
        const dailyFoodLog = await this.prisma.dailyFoodLog.findUnique({
            where: {
                id: id,
            },
            include: {
                patient: true,
                meals: {
                    include: {
                        foods: true,
                    },
                },
            },
        })

        if (!dailyFoodLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "DailyFoodLog",
                    value: id,
                }),
            )
        }

        return dailyFoodLog
    }

    async update(id: string, updateDailyFoodLogDto: UpdateDailyFoodLogDto) {
        const { patientId, meals, ...rest } = updateDailyFoodLogDto

        const existingDailyFoodLog = await this.prisma.dailyFoodLog.findUnique({
            where: {
                id: id,
                patientId: patientId,
            },
            select: {
                id: true,
            },
        })

        if (!existingDailyFoodLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "DailyFoodLog",
                    value: id,
                }),
            )
        }

        const updateData: Prisma.DailyFoodLogUpdateInput = {
            ...rest,
        }

        if (meals && meals.length > 0) {
            // Deleta as meals antigas e cria as novas
            updateData.meals = {
                deleteMany: {},
                create: meals.map((meal) => ({
                    mealTime: meal.mealTime,
                    description: meal.description,
                    foods:
                        meal.foods && meal.foods.length > 0
                            ? {
                                  create: meal.foods.map((food) => ({
                                      name: food.name,
                                      brand: food.brand,
                                      quantity: food.quantity,
                                      unit: food.unit,
                                      calories: food.calories || 0,
                                      carbohydrates: food.carbohydrates || 0,
                                      proteins: food.proteins || 0,
                                      totalFats: food.totalFats || 0,
                                      saturatedFats: food.saturatedFats || 0,
                                      transFats: food.transFats || 0,
                                      monounsaturatedFats: food.monounsaturatedFats || 0,
                                      polyunsaturatedFats: food.polyunsaturatedFats || 0,
                                      cholesterol: food.cholesterol || 0,
                                      fiber: food.fiber || 0,
                                      sugar: food.sugar || 0,
                                      sodium: food.sodium || 0,
                                      vitaminA: food.vitaminA || 0,
                                      vitaminB1: food.vitaminB1 || 0,
                                      vitaminB2: food.vitaminB2 || 0,
                                      vitaminB3: food.vitaminB3 || 0,
                                      vitaminB5: food.vitaminB5 || 0,
                                      vitaminB6: food.vitaminB6 || 0,
                                      vitaminB7: food.vitaminB7 || 0,
                                      vitaminB9: food.vitaminB9 || 0,
                                      vitaminB12: food.vitaminB12 || 0,
                                      vitaminC: food.vitaminC || 0,
                                      vitaminD: food.vitaminD || 0,
                                      vitaminE: food.vitaminE || 0,
                                      vitaminK: food.vitaminK || 0,
                                      calcium: food.calcium || 0,
                                      iron: food.iron || 0,
                                      magnesium: food.magnesium || 0,
                                      phosphorus: food.phosphorus || 0,
                                      potassium: food.potassium || 0,
                                      zinc: food.zinc || 0,
                                      copper: food.copper || 0,
                                      manganese: food.manganese || 0,
                                      selenium: food.selenium || 0,
                                      iodine: food.iodine || 0,
                                      omega3: food.omega3 || 0,
                                      omega6: food.omega6 || 0,
                                      caffeine: food.caffeine || 0,
                                      notes: food.notes,
                                  })),
                              }
                            : undefined,
                })),
            }
        }

        return await this.prisma.dailyFoodLog.update({
            where: {
                id: id,
            },
            data: updateData,
            include: {
                patient: true,
                meals: {
                    include: {
                        foods: true,
                    },
                },
            },
        })
    }

    async remove(id: string) {
        const existingDailyFoodLog = await this.prisma.dailyFoodLog.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingDailyFoodLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "DailyFoodLog",
                    value: id,
                }),
            )
        }

        await this.prisma.dailyFoodLog.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
