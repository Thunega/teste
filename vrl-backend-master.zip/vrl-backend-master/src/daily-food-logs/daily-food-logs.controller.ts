﻿import { Controller, Get, ParseUUIDPipe, Query, UseGuards, Delete, Patch, Body, Post } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { UpdateDailyFoodLogDto } from "./dto/update-daily-food-log.dto"
import { CreateDailyFoodLogDto } from "./dto/create-daily-food-log.dto"
import { StartDate } from "../common/decorators/start-date.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { DailyFoodLogsService } from "./daily-food-logs.service"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("daily-food-logs")
@ApiStandardErrorResponses({ notFoundName: "DailyFoodLogs" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class DailyFoodLogsController {
    constructor(private readonly dailyFoodLogsService: DailyFoodLogsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.NUTRITIONIST, UserRole.DATA_COLLECTOR)
    async createDailyFoodLog(@Body() createDailyFoodLogDto: CreateDailyFoodLogDto) {
        return await this.dailyFoodLogsService.create(createDailyFoodLogDto)
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.dailyFoodLogsService.findOne(id)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.dailyFoodLogsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
            patientId,
        )
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.NUTRITIONIST, UserRole.DATA_COLLECTOR)
    async update(@Id() id: string, @Body() updateDailyFoodLogDto: UpdateDailyFoodLogDto) {
        return await this.dailyFoodLogsService.update(id, updateDailyFoodLogDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.NUTRITIONIST, UserRole.DATA_COLLECTOR)
    async remove(@Id() id: string) {
        return await this.dailyFoodLogsService.remove(id)
    }
}
