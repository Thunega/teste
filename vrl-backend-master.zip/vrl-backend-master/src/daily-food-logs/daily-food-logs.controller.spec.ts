import { Test, TestingModule } from "@nestjs/testing"

import { DailyFoodLogsController } from "./daily-food-logs.controller"
import { DailyFoodLogsService } from "./daily-food-logs.service"

describe("DailyFoodLogsController", () => {
    let controller: DailyFoodLogsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [DailyFoodLogsController],
            providers: [{ provide: DailyFoodLogsService, useValue: mockService }],
        }).compile()

        controller = module.get<DailyFoodLogsController>(DailyFoodLogsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
