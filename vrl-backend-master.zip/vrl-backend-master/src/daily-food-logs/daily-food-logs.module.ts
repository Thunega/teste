import { forwardRef, Module } from "@nestjs/common"

import { DailyFoodLogsController } from "./daily-food-logs.controller"
import { DailyFoodLogsService } from "./daily-food-logs.service"
import { PatientsModule } from "../patients/patients.module"
import { PrismaModule } from "../prisma/prisma.module"

@Module({
    imports: [PrismaModule, forwardRef(() => PatientsModule)],
    controllers: [DailyFoodLogsController],
    providers: [DailyFoodLogsService],
    exports: [DailyFoodLogsService],
})
export class DailyFoodLogsModule {}
