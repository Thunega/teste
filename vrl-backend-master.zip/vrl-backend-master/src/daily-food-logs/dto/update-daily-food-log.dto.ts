import { PartialType } from "@nestjs/swagger"

import { CreateDailyFoodLogDto } from "./create-daily-food-log.dto"

export class UpdateDailyFoodLogDto extends PartialType(CreateDailyFoodLogDto) {}
