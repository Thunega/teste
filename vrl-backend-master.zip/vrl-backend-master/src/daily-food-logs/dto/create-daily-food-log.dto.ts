import { IsDateString, IsNumber, IsOptional, IsString, IsUUID, IsArray, ValidateNested } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"
import { Type } from "class-transformer"

export class CreateFoodItemDto {
    @ApiProperty({ description: "Nome do alimento", example: "Arroz branco cozido" })
    @IsString()
    name: string

    @ApiProperty({ description: "Marca do produto (se aplicável)", required: false, example: "Camil" })
    @IsOptional()
    @IsString()
    brand?: string

    @ApiProperty({ description: "Quantidade consumida", example: 100 })
    @IsNumber()
    quantity: number

    @ApiProperty({ description: "Unidade de medida da quantidade", example: "g" })
    @IsString()
    unit: string

    @ApiProperty({ description: "Calorias totais (kcal)", required: false, example: 130 })
    @IsOptional()
    @IsNumber()
    calories?: number

    @ApiProperty({ description: "Carboidratos totais (g)", required: false, example: 28.1 })
    @IsOptional()
    @IsNumber()
    carbohydrates?: number

    @ApiProperty({ description: "Proteínas (g)", required: false, example: 2.5 })
    @IsOptional()
    @IsNumber()
    proteins?: number

    @ApiProperty({ description: "Gorduras totais (g)", required: false, example: 0.2 })
    @IsOptional()
    @IsNumber()
    totalFats?: number

    @ApiProperty({ description: "Gorduras saturadas (g)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    saturatedFats?: number

    @ApiProperty({ description: "Gorduras trans (g)", required: false, example: 0 })
    @IsOptional()
    @IsNumber()
    transFats?: number

    @ApiProperty({ description: "Gorduras monoinsaturadas (g)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    monounsaturatedFats?: number

    @ApiProperty({ description: "Gorduras poli-insaturadas (g)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    polyunsaturatedFats?: number

    @ApiProperty({ description: "Colesterol (mg)", required: false, example: 0 })
    @IsOptional()
    @IsNumber()
    cholesterol?: number

    @ApiProperty({ description: "Fibras alimentares (g)", required: false, example: 0.4 })
    @IsOptional()
    @IsNumber()
    fiber?: number

    @ApiProperty({ description: "Açúcares totais (g)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    sugar?: number

    @ApiProperty({ description: "Sódio (mg)", required: false, example: 1 })
    @IsOptional()
    @IsNumber()
    sodium?: number

    @ApiProperty({ description: "Vitamina A (mcg RAE)", required: false, example: 0 })
    @IsOptional()
    @IsNumber()
    vitaminA?: number

    @ApiProperty({ description: "Vitamina B1 / Tiamina (mg)", required: false, example: 0.02 })
    @IsOptional()
    @IsNumber()
    vitaminB1?: number

    @ApiProperty({ description: "Vitamina B2 / Riboflavina (mg)", required: false, example: 0.01 })
    @IsOptional()
    @IsNumber()
    vitaminB2?: number

    @ApiProperty({ description: "Vitamina B3 / Niacina (mg)", required: false, example: 1.5 })
    @IsOptional()
    @IsNumber()
    vitaminB3?: number

    @ApiProperty({ description: "Vitamina B5 / Ácido pantotênico (mg)", required: false, example: 0.4 })
    @IsOptional()
    @IsNumber()
    vitaminB5?: number

    @ApiProperty({ description: "Vitamina B6 / Piridoxina (mg)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    vitaminB6?: number

    @ApiProperty({ description: "Vitamina B7 / Biotina (mcg)", required: false, example: 1 })
    @IsOptional()
    @IsNumber()
    vitaminB7?: number

    @ApiProperty({ description: "Vitamina B9 / Folato (mcg DFE)", required: false, example: 3 })
    @IsOptional()
    @IsNumber()
    vitaminB9?: number

    @ApiProperty({ description: "Vitamina B12 / Cobalamina (mcg)", required: false, example: 0 })
    @IsOptional()
    @IsNumber()
    vitaminB12?: number

    @ApiProperty({ description: "Vitamina C / Ácido ascórbico (mg)", required: false, example: 0 })
    @IsOptional()
    @IsNumber()
    vitaminC?: number

    @ApiProperty({ description: "Vitamina D (mcg)", required: false, example: 0 })
    @IsOptional()
    @IsNumber()
    vitaminD?: number

    @ApiProperty({ description: "Vitamina E / Tocoferol (mg)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    vitaminE?: number

    @ApiProperty({ description: "Vitamina K (mcg)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    vitaminK?: number

    @ApiProperty({ description: "Cálcio (mg)", required: false, example: 5 })
    @IsOptional()
    @IsNumber()
    calcium?: number

    @ApiProperty({ description: "Ferro (mg)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    iron?: number

    @ApiProperty({ description: "Magnésio (mg)", required: false, example: 10 })
    @IsOptional()
    @IsNumber()
    magnesium?: number

    @ApiProperty({ description: "Fósforo (mg)", required: false, example: 37 })
    @IsOptional()
    @IsNumber()
    phosphorus?: number

    @ApiProperty({ description: "Potássio (mg)", required: false, example: 27 })
    @IsOptional()
    @IsNumber()
    potassium?: number

    @ApiProperty({ description: "Zinco (mg)", required: false, example: 0.5 })
    @IsOptional()
    @IsNumber()
    zinc?: number

    @ApiProperty({ description: "Cobre (mg)", required: false, example: 0.1 })
    @IsOptional()
    @IsNumber()
    copper?: number

    @ApiProperty({ description: "Manganês (mg)", required: false, example: 0.5 })
    @IsOptional()
    @IsNumber()
    manganese?: number

    @ApiProperty({ description: "Selênio (mcg)", required: false, example: 8 })
    @IsOptional()
    @IsNumber()
    selenium?: number

    @ApiProperty({ description: "Iodo (mcg)", required: false, example: 2 })
    @IsOptional()
    @IsNumber()
    iodine?: number

    @ApiProperty({ description: "Ômega-3 (g)", required: false, example: 0.02 })
    @IsOptional()
    @IsNumber()
    omega3?: number

    @ApiProperty({ description: "Ômega-6 (g)", required: false, example: 0.08 })
    @IsOptional()
    @IsNumber()
    omega6?: number

    @ApiProperty({ description: "Cafeína (mg)", required: false, example: 0 })
    @IsOptional()
    @IsNumber()
    caffeine?: number

    @ApiProperty({ description: "Observações adicionais sobre o alimento", required: false, example: "Cozido sem sal" })
    @IsOptional()
    @IsString()
    notes?: string
}

export class CreateMealRecordDto {
    @ApiProperty({
        description: "Horário da refeição (texto livre ou horário formatado)",
        example: "Café da manhã - 07:30",
    })
    @IsString()
    mealTime: string

    @ApiProperty({
        description: "Descrição geral da refeição",
        required: false,
        example: "Café da manhã leve com frutas e pão integral",
    })
    @IsOptional()
    @IsString()
    description?: string

    @ApiProperty({
        description: "Lista de alimentos consumidos nesta refeição",
        type: [CreateFoodItemDto],
        required: false,
    })
    @IsOptional()
    @IsArray()
    @ValidateNested({ each: true })
    @Type(() => CreateFoodItemDto)
    foods?: CreateFoodItemDto[]
}

export class CreateDailyFoodLogDto {
    @ApiProperty({
        description: "Data do registro alimentar (formato ISO 8601)",
        example: "2024-08-20",
    })
    @IsDateString()
    dateOfRegistration: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual o registro alimentar pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string

    @ApiProperty({
        description: "Lista de refeições registradas no dia",
        type: [CreateMealRecordDto],
        required: false,
    })
    @IsOptional()
    @IsArray()
    @ValidateNested({ each: true })
    @Type(() => CreateMealRecordDto)
    meals?: CreateMealRecordDto[]
}
