import {
    ApiUnauthorizedResponse,
    ApiForbiddenResponse,
    ApiNotFoundResponse,
    ApiBadRequestResponse,
} from "@nestjs/swagger"
import { applyDecorators } from "@nestjs/common"

import { messagesHelper } from "../../helpers/messages.helper"

export function ApiStandardErrorResponses(options?: {
    notFoundName?: string
    notFoundProperty?: string
    notFoundValue?: string
    badRequest?: string
}) {
    const decorators = [
        ApiUnauthorizedResponse({ description: messagesHelper.UNAUTHORIZED_USER }),
        ApiForbiddenResponse({ description: messagesHelper.RESOURCE_ACCESS_UNAUTHORIZED }),
    ]

    if (options?.badRequest) {
        decorators.push(ApiBadRequestResponse({ description: options.badRequest }))
    } else {
        decorators.push(
            ApiBadRequestResponse({ description: "Requisição inválida (ex: falha na validação dos campos do DTO)" }),
        )
    }

    if (options?.notFoundName) {
        decorators.push(
            ApiNotFoundResponse({
                description: messagesHelper.OBJECT_NOT_FOUND({
                    name: options.notFoundName,
                    property: options.notFoundProperty || "id",
                    value: options.notFoundValue || "{id}",
                }),
            }),
        )
    } else {
        decorators.push(ApiNotFoundResponse({ description: messagesHelper.RESOURCE_NOT_FOUND }))
    }

    return applyDecorators(...decorators)
}
