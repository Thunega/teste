import { Query } from "@nestjs/common"

export function OrderBy(): ParameterDecorator {
    return Query("orderBy")
}
