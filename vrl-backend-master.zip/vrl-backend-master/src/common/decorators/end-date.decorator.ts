import { Query, ParseDatePipe } from "@nestjs/common"

export function EndDate(): ParameterDecorator {
    return Query("endDate", new ParseDatePipe({ optional: true }))
}
