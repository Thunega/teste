import { applyDecorators } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

export function ApiDateRange() {
    return applyDecorators(
        ApiQuery({
            name: "startDate",
            required: false,
            type: String,
        }),
        ApiQuery({
            name: "endDate",
            required: false,
            type: String,
        }),
    )
}
