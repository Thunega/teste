import { Query, ParseDatePipe } from "@nestjs/common"

export function StartDate(): ParameterDecorator {
    return Query("startDate", new ParseDatePipe({ optional: true }))
}
