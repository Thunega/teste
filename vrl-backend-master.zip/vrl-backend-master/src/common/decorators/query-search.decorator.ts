import { Query } from "@nestjs/common"

export function QuerySearch(): ParameterDecorator {
    return Query("query")
}
