import { Query, DefaultValuePipe, ParseEnumPipe } from "@nestjs/common"

import { configHelper } from "../../helpers/config.helper"

export function Sort(): ParameterDecorator {
    return Query(
        "sort",
        new DefaultValuePipe(configHelper.pagination.defaultSort),
        new ParseEnumPipe(["asc", "desc"], {
            exceptionFactory: () => ({ error: "Invalid sort value. Use 'asc' or 'desc'." }),
        }),
    )
}
