import { PipeTransform, Injectable, BadRequestException } from "@nestjs/common"

export type RegexValidationPipeOptions = {
    mesage?: string
    optional?: boolean
}

@Injectable()
export class RegexValidationPipe implements PipeTransform {
    constructor(
        private readonly pattern: RegExp,
        private readonly options: RegexValidationPipeOptions = {
            mesage: "Invalid input pattern",
            optional: false,
        },
    ) {}

    transform(value: any) {
        if (this.options.optional && (value === undefined || value === null || value === "")) {
            return value
        }

        if (typeof value !== "string") {
            throw new BadRequestException("Validation failed: not a string")
        }

        if (!this.pattern.test(value)) {
            throw new BadRequestException(`Validation failed: ${this.options.mesage || "Invalid input pattern"}`)
        }

        return value
    }
}
