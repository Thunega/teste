import { writeFile, mkdir, unlink } from "fs/promises"
import { Injectable } from "@nestjs/common"
import { randomUUID } from "crypto"
import { existsSync } from "fs"
import { join } from "path"

@Injectable()
export class UploadProvider {
    private readonly uploadDir = join(process.cwd(), "uploads", "consultation-photos")

    constructor() {
        this.ensureUploadDirectory()
    }

    private async ensureUploadDirectory() {
        if (!existsSync(this.uploadDir)) {
            await mkdir(this.uploadDir, { recursive: true })
        }
    }

    async uploadFile(file: Express.Multer.File): Promise<string> {
        const fileExtension = file.originalname.split(".").pop()
        const fileName = `${randomUUID()}.${fileExtension}`
        const filePath = join(this.uploadDir, fileName)

        await writeFile(filePath, file.buffer)

        return `/uploads/consultation-photos/${fileName}`
    }

    async deleteFile(fileUrl: string): Promise<void> {
        try {
            const fileName = fileUrl.split("/").pop()
            if (fileName) {
                const filePath = join(this.uploadDir, fileName)
                if (existsSync(filePath)) {
                    await unlink(filePath)
                }
            }
        } catch (error) {
            console.error("Error deleting file:", error)
        }
    }
}
