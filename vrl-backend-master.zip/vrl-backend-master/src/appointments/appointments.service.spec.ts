import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PatientsService } from "../patients/patients.service"
import { AppointmentsService } from "./appointments.service"
import { PrismaService } from "../prisma/prisma.service"

describe("AppointmentsService", () => {
    let service: AppointmentsService
    let prisma: PrismaService
    let patientsService: PatientsService

    const mockPrisma = {
        appointment: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = {
        findOne: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                AppointmentsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<AppointmentsService>(AppointmentsService)
        prisma = module.get<PrismaService>(PrismaService)
        patientsService = module.get<PatientsService>(PatientsService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create an appointment", async () => {
            const dto = { patientId: "pid", scheduledAt: new Date().toISOString(), description: "desc" }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.appointment.create.mockResolvedValue({ id: "aid", ...dto })

            const result = await service.create("uid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.appointment.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return an appointment", async () => {
            mockPrisma.appointment.findUnique.mockResolvedValue({ id: "aid" })
            const result = await service.findOne("aid")
            expect(result).toEqual({ id: "aid" })
        })

        it("should throw not found", async () => {
            mockPrisma.appointment.findUnique.mockResolvedValue(null)
            await expect(service.findOne("aid")).rejects.toThrow(NotFoundException)
        })
    })
})
