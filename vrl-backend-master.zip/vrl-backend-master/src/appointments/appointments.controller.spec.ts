import { Test, TestingModule } from "@nestjs/testing"

import { AppointmentsController } from "./appointments.controller"
import { AppointmentsService } from "./appointments.service"

describe("AppointmentsController", () => {
    let controller: AppointmentsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [AppointmentsController],
            providers: [{ provide: AppointmentsService, useValue: mockService }],
        }).compile()

        controller = module.get<AppointmentsController>(AppointmentsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
