﻿import { Controller, Get, Post, Body, Patch, Delete, ParseUUIDPipe, UseGuards, Query } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { UpdateAppointmentDto } from "./dto/update-appointment.dto"
import { CreateAppointmentDto } from "./dto/create-appointment.dto"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { AppointmentsService } from "./appointments.service"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Id } from "../common/decorators/id.decorator"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("appointments")
@ApiStandardErrorResponses({ notFoundName: "Appointments" })
@UseGuards(JwtAuthGuard)
export class AppointmentsController {
    constructor(private readonly appointmentsService: AppointmentsService) {}

    @Post()
    async create(@Body() createAppointmentDto: CreateAppointmentDto, @InjectUser() user: JwtAuthenticatedUser) {
        return await this.appointmentsService.create(user.id, createAppointmentDto)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
        @QuerySearch() query?: string,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.appointmentsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
            patientId,
        )
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.appointmentsService.findOne(id)
    }

    @Patch(":id")
    async update(@Id() id: string, @Body() updateAppointmentDto: UpdateAppointmentDto) {
        return await this.appointmentsService.update(id, updateAppointmentDto)
    }

    @Delete(":id")
    async remove(@Id() id: string) {
        return await this.appointmentsService.remove(id)
    }
}
