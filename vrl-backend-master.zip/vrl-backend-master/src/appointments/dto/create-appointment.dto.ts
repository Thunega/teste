import { IsDateString, IsString, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateAppointmentDto {
    @ApiProperty({
        description: "Data e hora agendada para o compromisso (formato ISO 8601)",
        example: "2024-08-20T14:30:00.000Z",
    })
    @IsDateString()
    scheduledAt: string

    @ApiProperty({
        description: "Descrição ou observações sobre o compromisso agendado",
        example: "Retorno de avaliação física trimestral",
    })
    @IsString()
    description: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual o compromisso pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string
}
