import { Module } from "@nestjs/common"

import { AppointmentsController } from "./appointments.controller"
import { PatientsModule } from "../patients/patients.module"
import { AppointmentsService } from "./appointments.service"
import { PrismaModule } from "../prisma/prisma.module"
import { UsersModule } from "../users/users.module"

@Module({
    imports: [PrismaModule, UsersModule, PatientsModule],
    controllers: [AppointmentsController],
    providers: [AppointmentsService],
})
export class AppointmentsModule {}
