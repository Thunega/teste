import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateAppointmentDto } from "./dto/update-appointment.dto"
import { CreateAppointmentDto } from "./dto/create-appointment.dto"
import { Appointment, Prisma } from "../generated/prisma/client"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class AppointmentsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(userId: string, createAppointmentDto: CreateAppointmentDto) {
        await this.patientsService.findOne(createAppointmentDto.patientId)

        return await this.prisma.appointment.create({
            data: {
                scheduledAt: createAppointmentDto.scheduledAt,
                description: createAppointmentDto.description,
                patient: {
                    connect: {
                        id: createAppointmentDto.patientId,
                    },
                },
                responsibleUser: {
                    connect: {
                        id: userId,
                    },
                },
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        { startDate, endDate, query, orderBy, sort }: SearchOptions,
        patientId?: string,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const whereClause: Prisma.AppointmentWhereInput = {
            patientId: patientId,
            scheduledAt: {
                gte: startDate,
                lte: endDate,
            },
        }

        if (query) {
            const cleanQuery = query.trim()

            whereClause.OR = [
                {
                    description: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
                {
                    patient: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
                {
                    responsibleUser: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
            ]
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.scheduledAt = "desc"
        }

        return await paginate<Appointment, Prisma.AppointmentFindManyArgs>(this.prisma.appointment, {
            where: whereClause,
            orderBy: order,
            include: {
                patient: true,
                responsibleUser: {
                    omit: {
                        password: true,
                    },
                },
            },
        })
    }

    async findOne(id: string) {
        const appointment = await this.prisma.appointment.findUnique({
            where: {
                id: id,
            },
        })

        if (!appointment) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Appointment",
                    value: id,
                }),
            )
        }

        return appointment
    }

    async update(id: string, updateAppointmentDto: UpdateAppointmentDto) {
        const existingAppointment = await this.prisma.appointment.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingAppointment) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Appointment",
                    value: id,
                }),
            )
        }

        return await this.prisma.appointment.update({
            where: {
                id: id,
            },
            data: updateAppointmentDto,
        })
    }

    async remove(id: string) {
        const existingAppointment = await this.prisma.appointment.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingAppointment) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Appointment",
                    value: id,
                }),
            )
        }

        await this.prisma.appointment.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
