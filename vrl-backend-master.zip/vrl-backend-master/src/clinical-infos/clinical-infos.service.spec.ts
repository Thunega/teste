import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { ClinicalInfosService } from "./clinical-infos.service"
import { PrismaService } from "../prisma/prisma.service"

describe("ClinicalInfosService", () => {
    let service: ClinicalInfosService
    let prisma: PrismaService

    const mockPrisma = {
        patientClinicalInfo: {
            findUnique: jest.fn(),
            findFirst: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            findMany: jest.fn(),
        },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [ClinicalInfosService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<ClinicalInfosService>(ClinicalInfosService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a clinical info", async () => {
            const dto = { weight: 70 }
            mockPrisma.patientClinicalInfo.create.mockResolvedValue({ id: "1", ...dto })

            const result = await service.create("pid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.patientClinicalInfo.create).toHaveBeenCalled()
        })
    })

    describe("findLast", () => {
        it("should return last clinical info", async () => {
            mockPrisma.patientClinicalInfo.findFirst.mockResolvedValue({ id: "1" })
            const result = await service.findLast("pid")
            expect(result).toEqual({ id: "1" })
        })

        it("should throw not found", async () => {
            mockPrisma.patientClinicalInfo.findFirst.mockResolvedValue(null)
            await expect(service.findLast("pid")).rejects.toThrow(NotFoundException)
        })
    })
})
