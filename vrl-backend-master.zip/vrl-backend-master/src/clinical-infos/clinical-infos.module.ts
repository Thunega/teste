import { Module } from "@nestjs/common"

import { ClinicalInfosService } from "./clinical-infos.service"
import { PrismaModule } from "../prisma/prisma.module"

@Module({
    imports: [PrismaModule],
    providers: [ClinicalInfosService],
    exports: [ClinicalInfosService],
})
export class ClinicalInfosModule {}
