import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateClinicalInfoDto } from "./dto/update-clinical-info.dto"
import { CreateClinicalInfoDto } from "./dto/create-clinical-info.dto"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
}

@Injectable()
export class ClinicalInfosService {
    constructor(private readonly prisma: PrismaService) {}

    async create(patientId: string, createClinicalInfoDto: CreateClinicalInfoDto) {
        return await this.prisma.patientClinicalInfo.create({
            data: {
                ...createClinicalInfoDto,
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
            },
        })
    }

    async findLast(patientId: string) {
        const clinicalInfo = await this.prisma.patientClinicalInfo.findFirst({
            where: {
                patientId: patientId,
            },
            orderBy: {
                createdAt: "desc",
            },
        })

        if (!clinicalInfo) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PatientClinicalInfo",
                    property: "patientId",
                    value: patientId,
                }),
            )
        }

        return clinicalInfo
    }

    async findAll(patientId: string, { startDate, endDate }: SearchOptions) {
        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        return await this.prisma.patientClinicalInfo.findMany({
            where: {
                patientId: patientId,
                createdAt: {
                    gte: startDate,
                    lte: endDate,
                },
            },
        })
    }

    async update(id: string, patientId: string, updateClinicalInfoDto: UpdateClinicalInfoDto) {
        const existingClinicalInfo = await this.prisma.patientClinicalInfo.findUnique({
            where: {
                patientId: patientId,
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingClinicalInfo) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PatientClinicalInfo",
                    property: "patientId",
                    value: patientId,
                }),
            )
        }

        return await this.prisma.patientClinicalInfo.update({
            where: {
                id: id,
            },
            data: updateClinicalInfoDto,
        })
    }

    async remove(id: string, patientId: string) {
        const existingClinicalInfo = await this.prisma.patientClinicalInfo.findUnique({
            where: {
                patientId: patientId,
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingClinicalInfo) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PatientClinicalInfo",
                    property: "patientId",
                    value: patientId,
                }),
            )
        }

        await this.prisma.patientClinicalInfo.delete({
            where: {
                id: id,
            },
        })
    }
}
