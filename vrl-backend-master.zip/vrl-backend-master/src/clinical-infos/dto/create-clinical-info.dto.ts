import { IsInt, IsNotEmpty, IsOptional, IsPositive, IsString } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateClinicalInfoDto {
    @ApiProperty({ required: false })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    healthInsurance?: string

    @ApiProperty()
    @IsPositive()
    weightKg: number

    @ApiProperty()
    @IsPositive()
    @IsInt()
    heightCm: number

    @ApiProperty({ required: false })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    allergies?: string

    @ApiProperty({ required: false })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    comorbidities?: string

    @ApiProperty({ required: false })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    mainTreatmentGoal?: string
}
