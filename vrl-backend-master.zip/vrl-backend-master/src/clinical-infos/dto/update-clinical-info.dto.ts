import { PartialType } from "@nestjs/swagger"

import { CreateClinicalInfoDto } from "./create-clinical-info.dto"

export class UpdateClinicalInfoDto extends PartialType(CreateClinicalInfoDto) {}
