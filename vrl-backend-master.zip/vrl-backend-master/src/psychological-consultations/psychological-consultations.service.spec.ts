import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PsychologicalConsultationsService } from "./psychological-consultations.service"
import { PatientsService } from "../patients/patients.service"
import { PrismaService } from "../prisma/prisma.service"

describe("PsychologicalConsultationsService", () => {
    let service: PsychologicalConsultationsService
    let prisma: PrismaService

    const mockPrisma = {
        psychologicalConsultation: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = { findOne: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                PsychologicalConsultationsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<PsychologicalConsultationsService>(PsychologicalConsultationsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a consultation", async () => {
            const dto = { patientId: "pid", humor: "GOOD" }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.psychologicalConsultation.create.mockResolvedValue({ id: "pcid", ...dto })

            const result = await service.create("uid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.psychologicalConsultation.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a consultation", async () => {
            mockPrisma.psychologicalConsultation.findUnique.mockResolvedValue({ id: "pcid" })
            const result = await service.findOne("pcid")
            expect(result).toEqual({ id: "pcid" })
        })

        it("should throw not found", async () => {
            mockPrisma.psychologicalConsultation.findUnique.mockResolvedValue(null)
            await expect(service.findOne("pcid")).rejects.toThrow(NotFoundException)
        })
    })
})
