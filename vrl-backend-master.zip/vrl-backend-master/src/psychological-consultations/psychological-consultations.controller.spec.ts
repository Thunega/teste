import { Test, TestingModule } from "@nestjs/testing"

import { PsychologicalConsultationsController } from "./psychological-consultations.controller"
import { PsychologicalConsultationsService } from "./psychological-consultations.service"

describe("PsychologicalConsultationsController", () => {
    let controller: PsychologicalConsultationsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [PsychologicalConsultationsController],
            providers: [{ provide: PsychologicalConsultationsService, useValue: mockService }],
        }).compile()

        controller = module.get<PsychologicalConsultationsController>(PsychologicalConsultationsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
