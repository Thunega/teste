﻿import { Controller, Get, Post, Body, Patch, Delete, UseGuards, ParseUUIDPipe, Query } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { UpdatePsychologicalConsultationDto } from "./dto/update-psychological-consultation.dto"
import { CreatePsychologicalConsultationDto } from "./dto/create-psychological-consultation.dto"
import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { PsychologicalConsultationsService } from "./psychological-consultations.service"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("psychological-consultations")
@ApiStandardErrorResponses({ notFoundName: "PsychologicalConsultations" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class PsychologicalConsultationsController {
    constructor(private readonly psychologicalConsultationsService: PsychologicalConsultationsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.PSYCHOLOGIST)
    async create(
        @Body() createPsychologicalConsultationDto: CreatePsychologicalConsultationDto,
        @InjectUser() user: JwtAuthenticatedUser,
    ) {
        return await this.psychologicalConsultationsService.create(user.id, createPsychologicalConsultationDto)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
    ) {
        return await this.psychologicalConsultationsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
            },
            patientId,
        )
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.psychologicalConsultationsService.findOne(id)
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.PSYCHOLOGIST)
    async update(@Id() id: string, @Body() updatePsychologicalConsultationDto: UpdatePsychologicalConsultationDto) {
        return await this.psychologicalConsultationsService.update(id, updatePsychologicalConsultationDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.PSYCHOLOGIST)
    async remove(@Id() id: string) {
        return await this.psychologicalConsultationsService.remove(id)
    }
}
