import { IsDateString, IsNotEmpty, IsOptional, IsString, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreatePsychologicalConsultationDto {
    @ApiProperty({
        description: "Data da consulta psicológica (formato ISO 8601)",
        example: "2024-08-15",
    })
    @IsDateString()
    consultationDate: string

    @ApiProperty({
        description: "Estado de humor do paciente avaliado na sessão",
        example: "Eutímico com episódios de irritabilidade",
    })
    @IsString()
    @IsNotEmpty()
    humor: string

    @ApiProperty({
        description: "Nível de ansiedade reportado ou avaliado na sessão",
        example: "Ansiedade moderada com manifestações somáticas",
    })
    @IsString()
    @IsNotEmpty()
    anxietyLevel: string

    @ApiProperty({
        description: "Observações clínicas e notas do psicólogo sobre a sessão",
        required: false,
        example: "Paciente relatou melhora no sono após técnicas de respiração. Mantendo TCC semanal.",
    })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    observations: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual a consulta pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string
}
