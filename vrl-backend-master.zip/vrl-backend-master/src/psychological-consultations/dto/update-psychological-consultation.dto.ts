import { PartialType } from "@nestjs/swagger"

import { CreatePsychologicalConsultationDto } from "./create-psychological-consultation.dto"

export class UpdatePsychologicalConsultationDto extends PartialType(CreatePsychologicalConsultationDto) {}
