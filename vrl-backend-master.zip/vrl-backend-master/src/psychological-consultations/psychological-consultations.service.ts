import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdatePsychologicalConsultationDto } from "./dto/update-psychological-consultation.dto"
import { CreatePsychologicalConsultationDto } from "./dto/create-psychological-consultation.dto"
import { Prisma, PsychologicalConsultation } from "../generated/prisma/client"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
}

@Injectable()
export class PsychologicalConsultationsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(userId: string, createPsychologicalConsultationDto: CreatePsychologicalConsultationDto) {
        const { patientId, ...rest } = createPsychologicalConsultationDto

        await this.patientsService.findOne(patientId)

        return await this.prisma.psychologicalConsultation.create({
            data: {
                ...rest,
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
                user: {
                    connect: {
                        id: userId,
                    },
                },
            },
        })
    }

    async findAll({ page, perPage }: PaginateOptions, { startDate, endDate }: SearchOptions, patientId?: string) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        return await paginate<PsychologicalConsultation, Prisma.PsychologicalConsultationFindManyArgs>(
            this.prisma.psychologicalConsultation,
            {
                where: {
                    patientId: patientId,
                    createdAt: {
                        gte: startDate,
                        lte: endDate,
                    },
                },
                select: {
                    id: true,
                    createdAt: true,
                    updatedAt: true,
                    consultationDate: true,
                    anxietyLevel: true,
                    humor: true,
                    user: {
                        select: {
                            id: true,
                            name: true,
                        },
                    },
                    patient: {
                        select: {
                            id: true,
                            cpf: true,
                            name: true,
                        },
                    },
                },
            },
        )
    }

    async findOne(id: string) {
        const psychologicalConsultation = await this.prisma.psychologicalConsultation.findUnique({
            where: {
                id: id,
            },
        })

        if (!psychologicalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PsychologicalConsultation",
                    value: id,
                }),
            )
        }

        return psychologicalConsultation
    }

    async update(id: string, updatePsychologicalConsultationDto: UpdatePsychologicalConsultationDto) {
        const existingPsychologicalConsultation = await this.prisma.psychologicalConsultation.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingPsychologicalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PsychologicalConsultation",
                    value: id,
                }),
            )
        }

        return await this.prisma.psychologicalConsultation.update({
            where: {
                id: id,
            },
            data: updatePsychologicalConsultationDto,
        })
    }

    async remove(id: string) {
        const existingPsychologicalConsultation = await this.prisma.psychologicalConsultation.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingPsychologicalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PsychologicalConsultation",
                    value: id,
                }),
            )
        }

        await this.prisma.psychologicalConsultation.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
