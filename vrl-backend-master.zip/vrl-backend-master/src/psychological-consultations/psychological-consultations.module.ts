import { Module } from "@nestjs/common"

import { PsychologicalConsultationsController } from "./psychological-consultations.controller"
import { PsychologicalConsultationsService } from "./psychological-consultations.service"
import { PatientsModule } from "../patients/patients.module"
import { PrismaModule } from "../prisma/prisma.module"

@Module({
    imports: [PrismaModule, PatientsModule],
    controllers: [PsychologicalConsultationsController],
    providers: [PsychologicalConsultationsService],
})
export class PsychologicalConsultationsModule {}
