import { DocumentBuilder, OpenAPIObject, SwaggerModule } from "@nestjs/swagger"
import { NestExpressApplication } from "@nestjs/platform-express"
import { NestFactory } from "@nestjs/core"
import * as path from "path"
import helmet from "helmet"

import { configHelper } from "./helpers/config.helper"
import { AppModule } from "./app.module"

async function createSwaggerSpec(document: OpenAPIObject) {
    const fs = await import("fs")

    document.servers = [
        {
            url: `http://localhost:${configHelper.app.port}`,
            description: "Dev",
        },
    ]

    await fs.promises.writeFile("./swagger-spec.json", JSON.stringify(document))
}

async function bootstrap() {
    const app = await NestFactory.create<NestExpressApplication>(AppModule)

    app.use(helmet())
    app.enableCors(configHelper.app.cors)
    app.useGlobalPipes(configHelper.app.validationPipe)

    app.useStaticAssets(path.join(process.cwd(), "uploads"), {
        prefix: "/uploads",
    })

    const config = new DocumentBuilder()
        .setTitle(`${configHelper.app.meta.name} - API Documentation`)
        .setVersion(configHelper.app.meta.version)
        .addBearerAuth()
        .build()

    const document = SwaggerModule.createDocument(app, config)

    if (!configHelper.isProduction) {
        await createSwaggerSpec(document)
    }

    SwaggerModule.setup("docs", app, document)

    await app.listen(configHelper.app.port)
}

bootstrap()
