import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { MedicationStatus } from "../generated/prisma/client"
import { MedicationsService } from "./medications.service"
import { PrismaService } from "../prisma/prisma.service"

describe("MedicationsService", () => {
    let service: MedicationsService
    let prisma: PrismaService

    const mockPrisma = {
        medication: {
            create: jest.fn(),
            findMany: jest.fn(),
            findUnique: jest.fn(),
            update: jest.fn(),
        },
        medicationHistory: {
            create: jest.fn(),
        },
        $transaction: jest.fn((callback) => callback(mockPrisma)),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [MedicationsService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<MedicationsService>(MedicationsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a medication and log history", async () => {
            const dto = {
                patientId: "patient-id",
                name: "Aspirin",
                dosage: "500mg",
                timetables: "8h",
                duration: "5 days",
            }
            mockPrisma.medication.create.mockResolvedValue({ id: "med-id", ...dto, status: MedicationStatus.ACTIVE })

            const result = await service.create(dto as any)

            expect(result.id).toBe("med-id")
            expect(mockPrisma.medication.create).toHaveBeenCalled()
            expect(mockPrisma.medicationHistory.create).toHaveBeenCalledWith({
                data: expect.objectContaining({
                    medicationId: "med-id",
                    status: MedicationStatus.ACTIVE,
                    dosage: "500mg",
                }),
            })
        })
    })

    describe("findOne", () => {
        it("should return a medication if found", async () => {
            mockPrisma.medication.findUnique.mockResolvedValue({ id: "med-id", name: "Aspirin" })

            const result = await service.findOne("med-id")

            expect(result.name).toBe("Aspirin")
        })

        it("should throw NotFoundException if not found", async () => {
            mockPrisma.medication.findUnique.mockResolvedValue(null)

            await expect(service.findOne("non-existent")).rejects.toThrow(NotFoundException)
        })
    })

    describe("updateStatus", () => {
        it("should update status and log history", async () => {
            const existingMed = { id: "med-id", dosage: "500mg", timetables: "8h", duration: "5 days" }
            mockPrisma.medication.findUnique.mockResolvedValue(existingMed)
            mockPrisma.medication.update.mockResolvedValue({ ...existingMed, status: MedicationStatus.INACTIVE })

            const updateStatusDto = {
                status: MedicationStatus.INACTIVE,
                discontinuedReason: "Side effects",
            }

            const result = await service.updateStatus("med-id", updateStatusDto)

            expect(result.status).toBe(MedicationStatus.INACTIVE)
            expect(mockPrisma.medication.update).toHaveBeenCalledWith({
                where: { id: "med-id" },
                data: expect.objectContaining({
                    status: MedicationStatus.INACTIVE,
                    discontinuedReason: "Side effects",
                }),
            })
            expect(mockPrisma.medicationHistory.create).toHaveBeenCalled()
        })
    })
})
