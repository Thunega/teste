import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { Medication, Prisma, MedicationStatus } from "../generated/prisma/client"
import { UpdateMedicationStatusDto } from "./dto/update-medication-status.dto"
import { UpdateMedicationDto } from "./dto/update-medication.dto"
import { CreateMedicationDto } from "./dto/create-medication.dto"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class MedicationsService {
    constructor(private readonly prisma: PrismaService) {}

    async create(createMedicationDto: CreateMedicationDto) {
        const { patientId, ...rest } = createMedicationDto

        return await this.prisma.$transaction(async (tx) => {
            const medication = await tx.medication.create({
                data: {
                    ...rest,
                    patientId,
                },
            })

            await tx.medicationHistory.create({
                data: {
                    medicationId: medication.id,
                    status: medication.status,
                    dosage: medication.dosage,
                    timetables: medication.timetables,
                    duration: medication.duration,
                },
            })

            return medication
        })
    }

    async findAllByPatient(
        patientId: string,
        { page, perPage }: PaginateOptions,
        { query, orderBy, sort }: SearchOptions,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        const whereClause: Prisma.MedicationWhereInput = {
            patientId,
        }

        if (query) {
            const cleanQuery = query.trim()
            whereClause.OR = [
                {
                    name: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
            ]
        }

        const order: any = {}
        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.name = "asc"
        }

        return await paginate<Medication, Prisma.MedicationFindManyArgs>(this.prisma.medication, {
            where: whereClause,
            include: {
                history: {
                    orderBy: {
                        createdAt: "desc",
                    },
                },
            },
            orderBy: order,
        })
    }

    async findOne(id: string) {
        const medication = await this.prisma.medication.findUnique({
            where: { id: id },
            include: {
                history: {
                    orderBy: {
                        createdAt: "desc",
                    },
                },
            },
        })

        if (!medication) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Medication",
                    value: id,
                }),
            )
        }

        return medication
    }

    async update(id: string, updateMedicationDto: UpdateMedicationDto) {
        const medication = await this.findOne(id)

        return await this.prisma.$transaction(async (tx) => {
            const updatedMedication = await tx.medication.update({
                where: { id },
                data: updateMedicationDto,
            })

            const hasPrescriptionChanged =
                (updateMedicationDto.dosage && updateMedicationDto.dosage !== medication.dosage) ||
                (updateMedicationDto.timetables && updateMedicationDto.timetables !== medication.timetables) ||
                (updateMedicationDto.duration && updateMedicationDto.duration !== medication.duration)

            if (hasPrescriptionChanged) {
                await tx.medicationHistory.create({
                    data: {
                        medicationId: id,
                        status: updatedMedication.status,
                        dosage: updatedMedication.dosage,
                        timetables: updatedMedication.timetables,
                        duration: updatedMedication.duration,
                        observations: "Medication prescription updated",
                    },
                })
            }

            return updatedMedication
        })
    }

    async updateStatus(id: string, updateStatusDto: UpdateMedicationStatusDto) {
        const medication = await this.findOne(id)

        const { status, discontinuedReason, discontinuedAt, observations } = updateStatusDto

        const hasStatusChanged = status !== medication.status
        const hasReasonChanged = discontinuedReason !== medication.discontinuedReason
        const hasDateChanged =
            discontinuedAt && new Date(discontinuedAt).getTime() !== medication.discontinuedAt?.getTime()
        const hasObservations = !!observations

        const hasChanges = hasStatusChanged || hasReasonChanged || hasDateChanged || hasObservations

        return await this.prisma.$transaction(async (tx) => {
            const updatedMedication = await tx.medication.update({
                where: { id: id },
                data: {
                    status: status,
                    discontinuedAt:
                        status === MedicationStatus.INACTIVE
                            ? (discontinuedAt ?? medication.discontinuedAt ?? new Date())
                            : null,
                    discontinuedReason: status === MedicationStatus.INACTIVE ? discontinuedReason : null,
                },
            })

            if (hasChanges) {
                await tx.medicationHistory.create({
                    data: {
                        medicationId: id,
                        status,
                        dosage: medication.dosage,
                        timetables: medication.timetables,
                        duration: medication.duration,
                        observations:
                            observations ||
                            (status === MedicationStatus.INACTIVE
                                ? `Discontinued: ${discontinuedReason}`
                                : "Status updated"),
                    },
                })
            }

            return updatedMedication
        })
    }
}
