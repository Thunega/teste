import { IsDateString, IsEnum, IsNotEmpty, IsOptional, IsString } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

import { MedicationStatus } from "../../generated/prisma/client"

export class UpdateMedicationStatusDto {
    @ApiProperty({ enum: MedicationStatus })
    @IsEnum(MedicationStatus)
    @IsNotEmpty()
    status: MedicationStatus

    @ApiProperty()
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    discontinuedReason?: string

    @ApiProperty()
    @IsOptional()
    @IsDateString()
    discontinuedAt?: Date

    @ApiProperty()
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    observations?: string
}
