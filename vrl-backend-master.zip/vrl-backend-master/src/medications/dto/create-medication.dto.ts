import { IsDateString, IsNotEmpty, IsOptional, IsString, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateMedicationDto {
    @ApiProperty({
        description: "Nome comercial ou genérico do medicamento",
        example: "Metformina",
    })
    @IsString()
    @IsNotEmpty()
    name: string

    @ApiProperty({
        description: "Dosagem do medicamento",
        example: "500mg",
    })
    @IsString()
    @IsNotEmpty()
    dosage: string

    @ApiProperty({
        description: "Horários de administração do medicamento",
        example: "08:00, 12:00, 20:00",
    })
    @IsString()
    @IsNotEmpty()
    timetables: string

    @ApiProperty({
        description: "Duração prevista do tratamento",
        example: "30 dias",
    })
    @IsString()
    @IsNotEmpty()
    duration: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual o medicamento pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string

    @ApiProperty({
        description: "Data e hora em que o medicamento foi descontinuado (se aplicável)",
        required: false,
        example: "2024-09-01T00:00:00.000Z",
    })
    @IsOptional()
    @IsDateString()
    discontinuedAt?: Date
}
