﻿import { Body, Controller, Get, Param, Patch, Post, UseGuards } from "@nestjs/common"
import { ApiBearerAuth, ApiQuery, ApiTags } from "@nestjs/swagger"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"
import { UpdateMedicationStatusDto } from "./dto/update-medication-status.dto"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { UpdateMedicationDto } from "./dto/update-medication.dto"
import { CreateMedicationDto } from "./dto/create-medication.dto"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { MedicationsService } from "./medications.service"

@ApiTags("medications")
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller("medications")
@ApiStandardErrorResponses({ notFoundName: "Medications" })
export class MedicationsController {
    constructor(private readonly medicationsService: MedicationsService) {}

    @Post()
    async create(@Body() createMedicationDto: CreateMedicationDto) {
        return await this.medicationsService.create(createMedicationDto)
    }

    @Get("patient/:patientId")
    @ApiPaginated()
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    async findAllByPatient(
        @Param("patientId") patientId: string,
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.medicationsService.findAllByPatient(
            patientId,
            {
                page: page,
                perPage: perPage,
            },
            {
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
        )
    }

    @Get(":id")
    async findOne(@Param("id") id: string) {
        return await this.medicationsService.findOne(id)
    }

    @Patch(":id")
    async update(@Param("id") id: string, @Body() updateMedicationDto: UpdateMedicationDto) {
        return await this.medicationsService.update(id, updateMedicationDto)
    }

    @Patch(":id/status")
    async updateStatus(@Param("id") id: string, @Body() updateStatusDto: UpdateMedicationStatusDto) {
        return await this.medicationsService.updateStatus(id, updateStatusDto)
    }
}
