import { Test, TestingModule } from "@nestjs/testing"

import { PrismaService } from "../prisma/prisma.service"
import { DashboardService } from "./dashboard.service"

describe("DashboardService", () => {
    let service: DashboardService
    let prisma: PrismaService

    const mockPrisma = {
        patient: { findMany: jest.fn(), count: jest.fn() },
        medicalConsultation: { count: jest.fn() },
        psychologicalConsultation: { count: jest.fn() },
        nutritionalConsultation: { count: jest.fn() },
        physiotherapyConsultation: { count: jest.fn() },
        appointment: { findMany: jest.fn(), count: jest.fn() },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [DashboardService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<DashboardService>(DashboardService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("getDisplayData", () => {
        it("should return dashboard data", async () => {
            mockPrisma.patient.findMany.mockResolvedValue([])
            mockPrisma.medicalConsultation.count.mockResolvedValue(1)
            mockPrisma.psychologicalConsultation.count.mockResolvedValue(1)
            mockPrisma.nutritionalConsultation.count.mockResolvedValue(1)
            mockPrisma.physiotherapyConsultation.count.mockResolvedValue(1)
            mockPrisma.patient.count.mockResolvedValue(5)
            mockPrisma.appointment.findMany.mockResolvedValue([])
            mockPrisma.appointment.count.mockResolvedValue(2)

            const result = await service.getDisplayData()

            expect(result).toBeDefined()
            expect(result.activePatientsCount).toBe(5)
            expect(result.consultationsCount).toBe(4)
        })
    })
})
