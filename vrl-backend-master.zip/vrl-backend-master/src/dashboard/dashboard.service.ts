import { Injectable } from "@nestjs/common"

import { PrismaService } from "../prisma/prisma.service"
import { configHelper } from "../helpers/config.helper"

@Injectable()
export class DashboardService {
    constructor(private readonly prisma: PrismaService) {}

    async getDisplayData() {
        const recentPatients = await this.prisma.patient.findMany({
            orderBy: {
                updatedAt: "desc",
            },
            take: configHelper.dashboard.displayData.recentPatientsCount,
        })

        const medicalConsultationsCount = await this.prisma.medicalConsultation.count()
        const psychologicalConsultationsCount = await this.prisma.psychologicalConsultation.count()
        const nutritionalConsultationsCount = await this.prisma.nutritionalConsultation.count()
        const physiotherapyConsultationsCount = await this.prisma.physiotherapyConsultation.count()
        const activePatientsCount = await this.prisma.patient.count({ where: { status: "ACTIVE" } })

        const startOfDay = new Date()

        startOfDay.setHours(0, 0, 0, 0)

        const endOfDay = new Date()

        endOfDay.setHours(23, 59, 59, 999)

        const previewDailyAppointments = await this.prisma.appointment.findMany({
            where: {
                scheduledAt: {
                    gte: startOfDay,
                    lte: endOfDay,
                },
            },
            include: {
                patient: true,
            },
            take: configHelper.dashboard.displayData.previewDailyAppointmentsCount,
        })

        const dailyAppointmentsCount = await this.prisma.appointment.count({
            where: {
                scheduledAt: {
                    gte: startOfDay,
                    lte: endOfDay,
                },
            },
        })

        const nextAppointmentsCount = await this.prisma.appointment.count({
            where: {
                scheduledAt: {
                    gt: new Date(),
                },
            },
        })

        const patientsWithConsecutiveAbsences = await this.getPatientsWithConsecutiveAbsences()

        return {
            recentPatients: recentPatients,
            activePatientsCount: activePatientsCount,
            previewDailyAppointments: previewDailyAppointments,
            dailyAppointmentsCount: dailyAppointmentsCount,
            nextAppointmentsCount: nextAppointmentsCount,
            consultationsCount:
                medicalConsultationsCount +
                psychologicalConsultationsCount +
                nutritionalConsultationsCount +
                physiotherapyConsultationsCount,
            patientsWithConsecutiveAbsences: patientsWithConsecutiveAbsences,
        }
    }

    private async getPatientsWithConsecutiveAbsences() {
        const threshold = configHelper.dashboard.displayData.consecutiveAbsencesThreshold

        const patients = await this.prisma.patient.findMany({
            where: {
                dailyPerformanceLog: {
                    some: {},
                },
                status: "ACTIVE",
            },
            select: {
                id: true,
                name: true,
                dailyPerformanceLog: {
                    orderBy: {
                        dateOfRegistration: "desc",
                    },
                    select: {
                        dateOfRegistration: true,
                        physicalActivity: {
                            select: {
                                id: true,
                            },
                        },
                    },
                },
            },
        })

        const result: { id: string; name: string; consecutiveAbsences: number }[] = []

        for (const patient of patients) {
            let consecutiveAbsences = 0

            for (const log of patient.dailyPerformanceLog) {
                if (log.physicalActivity === null) {
                    consecutiveAbsences++
                } else {
                    break
                }
            }

            if (consecutiveAbsences >= threshold) {
                result.push({
                    id: patient.id,
                    name: patient.name,
                    consecutiveAbsences: consecutiveAbsences,
                })
            }
        }

        result.sort((a, b) => b.consecutiveAbsences - a.consecutiveAbsences)

        return result
    }
}
