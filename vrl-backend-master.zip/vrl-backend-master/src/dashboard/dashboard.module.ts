import { Module } from "@nestjs/common"

import { DashboardController } from "./dashboard.controller"
import { PrismaModule } from "../prisma/prisma.module"
import { DashboardService } from "./dashboard.service"

@Module({
    imports: [PrismaModule],
    providers: [DashboardService],
    controllers: [DashboardController],
})
export class DashboardModule {}
