﻿import { Controller, Get, UseGuards } from "@nestjs/common"

import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { DashboardService } from "./dashboard.service"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("dashboard")
@ApiStandardErrorResponses({ notFoundName: "Dashboard" })
@UseGuards(JwtAuthGuard)
export class DashboardController {
    constructor(private readonly dashboardService: DashboardService) {}

    @Get("display-data")
    async getDisplayData() {
        return await this.dashboardService.getDisplayData()
    }
}
