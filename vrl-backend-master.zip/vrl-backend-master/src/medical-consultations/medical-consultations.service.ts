import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateMedicalConsultationDto } from "./dto/update-medical-consultation.dto"
import { CreateMedicalConsultationDto } from "./dto/create-medical-consultation.dto"
import { MedicalConsultation, Prisma } from "../generated/prisma/client"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class MedicalConsultationsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(userId: string, createMedicalConsultationDto: CreateMedicalConsultationDto) {
        const { patientId, examIds, vitalSigns, ...rest } = createMedicalConsultationDto

        await this.patientsService.findOne(patientId)

        return await this.prisma.medicalConsultation.create({
            data: {
                ...rest,
                vitalSigns: {
                    create: vitalSigns,
                },
                exams: {
                    connect: examIds.map((examId) => ({
                        id: examId,
                    })),
                },
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
                user: {
                    connect: {
                        id: userId,
                    },
                },
            },
            include: {
                exams: {
                    select: {
                        id: true,
                        createdAt: true,
                        updatedAt: true,
                        responsibleUser: {
                            select: {
                                id: true,
                                name: true,
                            },
                        },
                    },
                },
                vitalSigns: true,
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        { startDate, endDate, query, orderBy, sort }: SearchOptions,
        patientId?: string,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const whereClause: Prisma.MedicalConsultationWhereInput = {
            patientId: patientId,
            createdAt: {
                gte: startDate,
                lte: endDate,
            },
        }

        if (query) {
            const cleanQuery = query.trim()

            whereClause.OR = [
                {
                    patient: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
            ]
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.createdAt = "desc"
        }

        return await paginate<MedicalConsultation, Prisma.MedicalConsultationFindManyArgs>(
            this.prisma.medicalConsultation,
            {
                where: whereClause,
                orderBy: order,
                select: {
                    id: true,
                    createdAt: true,
                    updatedAt: true,
                    consultationDate: true,
                    user: {
                        select: {
                            id: true,
                            name: true,
                        },
                    },
                    patient: {
                        select: {
                            id: true,
                            cpf: true,
                            name: true,
                        },
                    },
                },
            },
        )
    }

    async findOne(id: string) {
        const medicalConsultation = await this.prisma.medicalConsultation.findUnique({
            where: {
                id: id,
            },
            include: {
                exams: {
                    select: {
                        id: true,
                        createdAt: true,
                        updatedAt: true,
                        responsibleUser: {
                            select: {
                                id: true,
                                name: true,
                            },
                        },
                    },
                },
                vitalSigns: true,
            },
        })

        if (!medicalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "MedicalConsultation",
                    value: id,
                }),
            )
        }

        return medicalConsultation
    }

    async update(id: string, updateMedicalConsultationDto: UpdateMedicalConsultationDto) {
        const existingMedicalConsultation = await this.prisma.medicalConsultation.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingMedicalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "MedicalConsultation",
                    value: id,
                }),
            )
        }

        const { patientId, examIds, vitalSigns, ...rest } = updateMedicalConsultationDto

        return await this.prisma.medicalConsultation.update({
            where: {
                id: id,
                patientId: patientId,
            },
            data: {
                ...rest,
                vitalSigns: {
                    create: vitalSigns,
                },
                exams: {
                    connect: examIds?.map((examId) => ({
                        id: examId,
                    })),
                },
            },
            include: {
                exams: {
                    select: {
                        id: true,
                        createdAt: true,
                        updatedAt: true,
                        responsibleUser: {
                            select: {
                                id: true,
                                name: true,
                            },
                        },
                    },
                },
                vitalSigns: true,
            },
        })
    }

    async remove(id: string) {
        const existingMedicalConsultation = await this.prisma.medicalConsultation.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingMedicalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "MedicalConsultation",
                    value: id,
                }),
            )
        }

        await this.prisma.medicalConsultation.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
