import { Test, TestingModule } from "@nestjs/testing"

import { MedicalConsultationsController } from "./medical-consultations.controller"
import { MedicalConsultationsService } from "./medical-consultations.service"

describe("MedicalConsultationsController", () => {
    let controller: MedicalConsultationsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [MedicalConsultationsController],
            providers: [{ provide: MedicalConsultationsService, useValue: mockService }],
        }).compile()

        controller = module.get<MedicalConsultationsController>(MedicalConsultationsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
