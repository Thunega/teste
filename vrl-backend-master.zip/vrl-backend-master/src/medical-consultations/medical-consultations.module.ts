import { Module } from "@nestjs/common"

import { MedicalConsultationsController } from "./medical-consultations.controller"
import { MedicalConsultationsService } from "./medical-consultations.service"
import { PatientsModule } from "../patients/patients.module"
import { PrismaModule } from "../prisma/prisma.module"
import { ExamsModule } from "../exams/exams.module"

@Module({
    imports: [PrismaModule, ExamsModule, PatientsModule],
    controllers: [MedicalConsultationsController],
    providers: [MedicalConsultationsService],
})
export class MedicalConsultationsModule {}
