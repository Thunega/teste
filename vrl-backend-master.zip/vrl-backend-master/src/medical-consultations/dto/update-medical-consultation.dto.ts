import { PartialType } from "@nestjs/swagger"

import { CreateMedicalConsultationDto } from "./create-medical-consultation.dto"

export class UpdateMedicalConsultationDto extends PartialType(CreateMedicalConsultationDto) {}
