import {
    IsArray,
    IsDateString,
    IsInt,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsPositive,
    IsString,
    IsUUID,
    Matches,
    ValidateNested,
} from "class-validator"
import { ApiProperty } from "@nestjs/swagger"
import { Type } from "class-transformer"

import { regexHelper } from "../../helpers/regex.helper"

export class CreateVitalSignsDto {
    @ApiProperty({
        description: "Pressão arterial no formato sistólica/diastólica (ex: 120/80)",
        example: "120/80",
    })
    @Matches(regexHelper.bloodPressure)
    bloodPressure: string

    @ApiProperty({
        description: "Frequência cardíaca em batimentos por minuto (bpm)",
        example: 72,
        minimum: 1,
    })
    @IsPositive()
    @IsInt()
    heartRate: number
}

export class CreateMedicalConsultationDto {
    @ApiProperty({
        description: "Data da consulta médica (formato ISO 8601)",
        example: "2024-08-15",
    })
    @IsDateString()
    consultationDate: string

    @ApiProperty({
        description: "Peso do paciente em quilogramas",
        required: false,
        example: 72.5,
    })
    @IsOptional()
    weightKg?: number

    @ApiProperty({
        description: "Altura do paciente em centímetros",
        required: false,
        example: 170,
    })
    @IsOptional()
    heightCm?: number

    @ApiProperty({
        description: "Índice de Massa Corporal (IMC) do paciente",
        required: false,
        example: 25.1,
    })
    @IsNumber()
    @IsOptional()
    bmi?: number

    @ApiProperty({
        description: "Lista de IDs (UUIDs) de exames laboratoriais associados a esta consulta",
        type: [String],
        example: ["a1b2c3d4-e5f6-7890-abcd-ef1234567890"],
    })
    @IsArray()
    @IsUUID(undefined, { each: true })
    examIds: string[]

    @ApiProperty({
        description: "Sinais vitais aferidos na consulta",
        type: () => CreateVitalSignsDto,
    })
    @ValidateNested()
    @Type(() => CreateVitalSignsDto)
    vitalSigns: CreateVitalSignsDto

    @ApiProperty({
        description: "Observações clínicas e notas do médico sobre a consulta",
        required: false,
        example: "Paciente refere melhora na tolerância ao exercício. Manter plano atual.",
    })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    observations?: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual a consulta pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string
}
