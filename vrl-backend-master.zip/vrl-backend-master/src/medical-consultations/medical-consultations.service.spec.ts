import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { MedicalConsultationsService } from "./medical-consultations.service"
import { PatientsService } from "../patients/patients.service"
import { PrismaService } from "../prisma/prisma.service"

describe("MedicalConsultationsService", () => {
    let service: MedicalConsultationsService
    let prisma: PrismaService

    const mockPrisma = {
        medicalConsultation: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = { findOne: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                MedicalConsultationsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<MedicalConsultationsService>(MedicalConsultationsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a consultation", async () => {
            const dto = { patientId: "pid", examIds: [], medicationsInUse: [], vitalSigns: {} }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.medicalConsultation.create.mockResolvedValue({ id: "mcid", ...dto })

            const result = await service.create("uid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.medicalConsultation.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a consultation", async () => {
            mockPrisma.medicalConsultation.findUnique.mockResolvedValue({ id: "mcid" })
            const result = await service.findOne("mcid")
            expect(result).toEqual({ id: "mcid" })
        })

        it("should throw not found", async () => {
            mockPrisma.medicalConsultation.findUnique.mockResolvedValue(null)
            await expect(service.findOne("mcid")).rejects.toThrow(NotFoundException)
        })
    })
})
