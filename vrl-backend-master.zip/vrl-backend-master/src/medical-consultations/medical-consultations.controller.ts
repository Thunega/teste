﻿import { Controller, Get, Post, Body, Patch, Delete, ParseUUIDPipe, UseGuards, Query } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { UpdateMedicalConsultationDto } from "./dto/update-medical-consultation.dto"
import { CreateMedicalConsultationDto } from "./dto/create-medical-consultation.dto"
import { MedicalConsultationsService } from "./medical-consultations.service"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("medical-consultations")
@ApiStandardErrorResponses({ notFoundName: "MedicalConsultations" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class MedicalConsultationsController {
    constructor(private readonly medicalConsultationsService: MedicalConsultationsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async create(
        @Body() createMedicalConsultationDto: CreateMedicalConsultationDto,
        @InjectUser() user: JwtAuthenticatedUser,
    ) {
        return await this.medicalConsultationsService.create(user.id, createMedicalConsultationDto)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.medicalConsultationsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
            patientId,
        )
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.medicalConsultationsService.findOne(id)
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async update(@Id() id: string, @Body() updateMedicalConsultationDto: UpdateMedicalConsultationDto) {
        return await this.medicalConsultationsService.update(id, updateMedicalConsultationDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async remove(@Id() id: string) {
        return await this.medicalConsultationsService.remove(id)
    }
}
