import { Test, TestingModule } from "@nestjs/testing"

import { PrismaService } from "../prisma/prisma.service"
import { SessionsService } from "./sessions.service"

describe("SessionsService", () => {
    let service: SessionsService
    let prisma: PrismaService

    const mockPrisma = {
        session: {
            update: jest.fn(),
            findMany: jest.fn(),
        },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [SessionsService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<SessionsService>(SessionsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("revoke", () => {
        it("should revoke a session", async () => {
            mockPrisma.session.update.mockResolvedValue({ id: "sid", revokedAt: new Date() })
            const result = await service.revoke("sid")
            expect(result.revokedAt).toBeDefined()
            expect(mockPrisma.session.update).toHaveBeenCalled()
        })
    })
})
