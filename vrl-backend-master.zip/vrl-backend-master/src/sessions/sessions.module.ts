import { Module } from "@nestjs/common"

import { SessionsController } from "./sessions.controller"
import { PrismaModule } from "../prisma/prisma.module"
import { SessionsService } from "./sessions.service"

@Module({
    imports: [PrismaModule],
    controllers: [SessionsController],
    providers: [SessionsService],
})
export class SessionsModule {}
