﻿import { Controller, DefaultValuePipe, Get, Param, ParseIntPipe, Post, Query, UseGuards } from "@nestjs/common"

import { MinValueValidationPipe } from "../common/pipes/min-number-validation.pipe"
import { MaxValueValidationPipe } from "../common/pipes/max-number-validation.pipe"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { configHelper } from "../helpers/config.helper"
import { UserRole } from "../generated/prisma/client"
import { SessionsService } from "./sessions.service"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("sessions")
@ApiStandardErrorResponses({ notFoundName: "Sessions" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class SessionsController {
    constructor(private readonly sessionsService: SessionsService) {}

    @Get()
    @Roles(UserRole.ADMIN)
    findAll(
        @Query(
            "page",
            new DefaultValuePipe(configHelper.pagination.defaultPage),
            ParseIntPipe,
            new MinValueValidationPipe(configHelper.pagination.minPage),
        )
        page: number,
        @Query(
            "perPage",
            new DefaultValuePipe(configHelper.pagination.defaultPerPage),
            ParseIntPipe,
            new MinValueValidationPipe(configHelper.pagination.minPerPage),
            new MaxValueValidationPipe(configHelper.pagination.maxPerPage),
        )
        perPage: number,
    ) {
        return this.sessionsService.findAll({
            page: page,
            perPage: perPage,
        })
    }

    @Post(":id/revoke")
    @Roles(UserRole.ADMIN)
    revoke(@Param("id") id: string) {
        return this.sessionsService.revoke(id)
    }
}
