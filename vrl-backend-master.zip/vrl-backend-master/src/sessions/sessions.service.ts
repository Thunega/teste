import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable } from "@nestjs/common"

import { Prisma, Session } from "../generated/prisma/client"
import { PrismaService } from "../prisma/prisma.service"

@Injectable()
export class SessionsService {
    constructor(private readonly prismaService: PrismaService) {}

    async findAll({ page, perPage }: PaginateOptions) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        return await paginate<Session, Prisma.SessionFindManyArgs>(this.prismaService.session, {
            where: { revokedAt: null },
            orderBy: { createdAt: "desc" },

            include: {
                user: true,
            },
        })
    }

    async revoke(id: string) {
        return await this.prismaService.session.update({
            where: { id },
            data: { revokedAt: new Date() },
        })
    }
}
