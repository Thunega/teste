import { Test, TestingModule } from "@nestjs/testing"

import { PhysiotherapyConsultationsController } from "./physiotherapy-consultations.controller"
import { PhysiotherapyConsultationsService } from "./physiotherapy-consultations.service"

describe("PhysiotherapyConsultationsController", () => {
    let controller: PhysiotherapyConsultationsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [PhysiotherapyConsultationsController],
            providers: [{ provide: PhysiotherapyConsultationsService, useValue: mockService }],
        }).compile()

        controller = module.get<PhysiotherapyConsultationsController>(PhysiotherapyConsultationsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
