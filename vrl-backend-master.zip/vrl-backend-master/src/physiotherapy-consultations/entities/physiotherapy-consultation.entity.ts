export class PhysiotherapyConsultation {}
