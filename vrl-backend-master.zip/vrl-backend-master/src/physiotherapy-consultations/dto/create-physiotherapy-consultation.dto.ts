import { IsDateString, IsEnum, IsInt, IsString, IsUUID, Max, Min } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

import { FunctionalLevel } from "../../generated/prisma/client"
import { configHelper } from "../../helpers/config.helper"

export class CreatePhysiotherapyConsultationDto {
    @ApiProperty({
        description: "Data da consulta fisioterapêutica (formato ISO 8601)",
        example: "2024-08-15",
    })
    @IsDateString()
    consultationDate: string

    @ApiProperty({
        description: "Queixa principal do paciente nesta sessão",
        example: "Dor na região lombar ao se levantar pela manhã, com irradiação para perna direita",
    })
    @IsString()
    mainComplaint: string

    @ApiProperty({
        description: "Histórico médico relevante do paciente para a fisioterapia",
        example: "Hérnia de disco L4-L5 diagnosticada em 2022. Cirurgia negada. Em tratamento conservador.",
    })
    @IsString()
    medicalHistory: string

    @ApiProperty({
        description: `Nível de dor do paciente na Escala Visual Analógica (EVA), de ${configHelper.physiotherapyConsultations.minPainLevel} (sem dor) a ${configHelper.physiotherapyConsultations.maxPainLevel} (pior dor possível)`,
        example: 6,
        minimum: configHelper.physiotherapyConsultations.minPainLevel,
        maximum: configHelper.physiotherapyConsultations.maxPainLevel,
    })
    @IsInt()
    @Min(configHelper.physiotherapyConsultations.minPainLevel)
    @Max(configHelper.physiotherapyConsultations.maxPainLevel)
    painLevel: number

    @ApiProperty({
        description: "Nível funcional atual do paciente avaliado pelo fisioterapeuta",
        enum: FunctionalLevel,
        enumName: "FunctionalLevel",
        example: FunctionalLevel.INDEPENDENT,
    })
    @IsEnum(FunctionalLevel)
    functionalLevel: FunctionalLevel

    @ApiProperty({
        description: "Metas de curto prazo para a evolução fisioterapêutica do paciente",
        example: "Redução da dor para EVA ≤ 3 em 4 semanas. Melhora da amplitude de movimento lombar.",
    })
    @IsString()
    shortTermGoals: string

    @ApiProperty({
        description: "Metas de longo prazo para a reabilitação do paciente",
        example: "Retorno às atividades de vida diária sem limitação funcional em 3 meses.",
    })
    @IsString()
    longTermGoals: string

    @ApiProperty({
        description: "Plano de tratamento fisioterapêutico proposto pelo profissional",
        example: "Cinesioterapia, TENS lombar, alongamento da cadeia posterior e mobilização neural.",
    })
    @IsString()
    treatmentPlan: string

    @ApiProperty({
        description: "Frequência das sessões de fisioterapia recomendada",
        example: "2x por semana",
    })
    @IsString()
    sessionFrequency: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual a consulta pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string
}
