import { PartialType } from "@nestjs/swagger"

import { CreatePhysiotherapyConsultationDto } from "./create-physiotherapy-consultation.dto"

export class UpdatePhysiotherapyConsultationDto extends PartialType(CreatePhysiotherapyConsultationDto) {}
