import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PhysiotherapyConsultationsService } from "./physiotherapy-consultations.service"
import { PatientsService } from "../patients/patients.service"
import { PrismaService } from "../prisma/prisma.service"

describe("PhysiotherapyConsultationsService", () => {
    let service: PhysiotherapyConsultationsService
    let prisma: PrismaService

    const mockPrisma = {
        physiotherapyConsultation: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = { findOne: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                PhysiotherapyConsultationsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<PhysiotherapyConsultationsService>(PhysiotherapyConsultationsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a consultation", async () => {
            const dto = { patientId: "pid", medicationsInUse: [] }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.physiotherapyConsultation.create.mockResolvedValue({ id: "pcid", ...dto })

            const result = await service.create("uid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.physiotherapyConsultation.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a consultation", async () => {
            mockPrisma.physiotherapyConsultation.findUnique.mockResolvedValue({ id: "pcid" })
            const result = await service.findOne("pcid")
            expect(result).toEqual({ id: "pcid" })
        })

        it("should throw not found", async () => {
            mockPrisma.physiotherapyConsultation.findUnique.mockResolvedValue(null)
            await expect(service.findOne("pcid")).rejects.toThrow(NotFoundException)
        })
    })
})
