﻿import { Controller, Get, Post, Body, Patch, Delete, ParseUUIDPipe, Query, UseGuards } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { UpdatePhysiotherapyConsultationDto } from "./dto/update-physiotherapy-consultation.dto"
import { CreatePhysiotherapyConsultationDto } from "./dto/create-physiotherapy-consultation.dto"
import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { PhysiotherapyConsultationsService } from "./physiotherapy-consultations.service"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("physiotherapy-consultations")
@ApiStandardErrorResponses({ notFoundName: "PhysiotherapyConsultations" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class PhysiotherapyConsultationsController {
    constructor(private readonly physiotherapyConsultationsService: PhysiotherapyConsultationsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.PHYSIOTHERAPIST)
    async create(
        @Body() createPhysiotherapyConsultationDto: CreatePhysiotherapyConsultationDto,
        @InjectUser() user: JwtAuthenticatedUser,
    ) {
        return await this.physiotherapyConsultationsService.create(user.id, createPhysiotherapyConsultationDto)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
    ) {
        return await this.physiotherapyConsultationsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
            },
            patientId,
        )
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.physiotherapyConsultationsService.findOne(id)
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.PHYSIOTHERAPIST)
    async update(@Id() id: string, @Body() updatePhysiotherapyConsultationDto: UpdatePhysiotherapyConsultationDto) {
        return await this.physiotherapyConsultationsService.update(id, updatePhysiotherapyConsultationDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.PHYSIOTHERAPIST)
    async remove(@Id() id: string) {
        return await this.physiotherapyConsultationsService.remove(id)
    }
}
