import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdatePhysiotherapyConsultationDto } from "./dto/update-physiotherapy-consultation.dto"
import { CreatePhysiotherapyConsultationDto } from "./dto/create-physiotherapy-consultation.dto"
import { PhysiotherapyConsultation, Prisma } from "../generated/prisma/client"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
}

@Injectable()
export class PhysiotherapyConsultationsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(userId: string, createPhysiotherapyConsultationDto: CreatePhysiotherapyConsultationDto) {
        const { patientId, ...rest } = createPhysiotherapyConsultationDto

        await this.patientsService.findOne(patientId)

        return await this.prisma.physiotherapyConsultation.create({
            data: {
                ...rest,
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
                user: {
                    connect: {
                        id: userId,
                    },
                },
            },
        })
    }

    async findAll({ page, perPage }: PaginateOptions, { startDate, endDate }: SearchOptions, patientId?: string) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        return await paginate<PhysiotherapyConsultation, Prisma.PhysiotherapyConsultationFindManyArgs>(
            this.prisma.physiotherapyConsultation,
            {
                where: {
                    patientId: patientId,
                    createdAt: {
                        gte: startDate,
                        lte: endDate,
                    },
                },
                select: {
                    id: true,
                    createdAt: true,
                    updatedAt: true,
                    consultationDate: true,
                    user: {
                        select: {
                            id: true,
                            name: true,
                        },
                    },
                    patient: {
                        select: {
                            id: true,
                            cpf: true,
                            name: true,
                        },
                    },
                },
            },
        )
    }

    async findOne(id: string) {
        const physiotherapyConsultaion = await this.prisma.physiotherapyConsultation.findUnique({
            where: {
                id: id,
            },
        })

        if (!physiotherapyConsultaion) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PhysiotherapyConsultation",
                    value: id,
                }),
            )
        }

        return physiotherapyConsultaion
    }

    async update(id: string, updatePhysiotherapyConsultationDto: UpdatePhysiotherapyConsultationDto) {
        const { patientId, ...rest } = updatePhysiotherapyConsultationDto

        const existingPhysiotherapyConsultaion = await this.prisma.physiotherapyConsultation.findUnique({
            where: {
                id: id,
                patientId: patientId,
            },
            select: {
                id: true,
            },
        })

        if (!existingPhysiotherapyConsultaion) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PhysiotherapyConsultation",
                    value: id,
                }),
            )
        }

        return await this.prisma.physiotherapyConsultation.update({
            where: {
                id: id,
                patientId: patientId,
            },
            data: {
                ...rest,
            },
        })
    }

    async remove(id: string, patientId?: string) {
        const existingPhysiotherapyConsultaion = await this.prisma.physiotherapyConsultation.findUnique({
            where: {
                id: id,
                patientId: patientId,
            },
            select: {
                id: true,
            },
        })

        if (!existingPhysiotherapyConsultaion) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PhysiotherapyConsultation",
                    value: id,
                }),
            )
        }

        await this.prisma.physiotherapyConsultation.delete({
            where: {
                id: id,
                patientId: patientId,
            },
        })
    }
}
