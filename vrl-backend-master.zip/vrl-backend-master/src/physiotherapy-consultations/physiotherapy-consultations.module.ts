import { Module } from "@nestjs/common"

import { PhysiotherapyConsultationsController } from "./physiotherapy-consultations.controller"
import { PhysiotherapyConsultationsService } from "./physiotherapy-consultations.service"
import { PatientsModule } from "../patients/patients.module"
import { PrismaModule } from "../prisma/prisma.module"

@Module({
    imports: [PrismaModule, PatientsModule],
    controllers: [PhysiotherapyConsultationsController],
    providers: [PhysiotherapyConsultationsService],
})
export class PhysiotherapyConsultationsModule {}
