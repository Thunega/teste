import { IsDateString, IsNotEmpty, IsOptional, IsString } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateReminderDto {
    @ApiProperty({
        description: "Título do lembrete",
        example: "Verificar exames de sangue do paciente João",
    })
    @IsString()
    @IsNotEmpty()
    title: string

    @ApiProperty({
        description: "Data e hora programada para o lembrete (formato ISO 8601)",
        example: "2024-08-21T09:00:00.000Z",
    })
    @IsDateString()
    scheduledAt: string

    @ApiProperty({
        description: "Descrição detalhada ou observações adicionais sobre o lembrete",
        required: false,
        example: "Verificar colesterol total e triglicérides. Solicitar nova coleta caso fora do intervalo.",
    })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    description?: string
}
