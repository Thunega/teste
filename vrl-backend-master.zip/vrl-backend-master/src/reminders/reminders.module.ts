import { Module } from "@nestjs/common"

import { RemindersController } from "./reminders.controller"
import { PrismaModule } from "../prisma/prisma.module"
import { RemindersService } from "./reminders.service"

@Module({
    imports: [PrismaModule],
    controllers: [RemindersController],
    providers: [RemindersService],
})
export class RemindersModule {}
