import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { Prisma, Reminder } from "../generated/prisma/client"
import { UpdateReminderDto } from "./dto/update-reminder.dto"
import { CreateReminderDto } from "./dto/create-reminder.dto"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class RemindersService {
    constructor(private readonly prisma: PrismaService) {}

    async create(userId: string, createReminderDto: CreateReminderDto) {
        return await this.prisma.reminder.create({
            data: {
                ...createReminderDto,
                owner: {
                    connect: {
                        id: userId,
                    },
                },
            },
        })
    }

    async findAll({ page, perPage }: PaginateOptions, { startDate, endDate, query, orderBy, sort }: SearchOptions) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const whereClause: Prisma.ReminderWhereInput = {
            scheduledAt: {
                gte: startDate,
                lte: endDate,
            },
        }

        if (query) {
            const cleanQuery = query.trim()

            whereClause.OR = [
                {
                    title: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
                {
                    description: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
            ]
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.scheduledAt = "desc"
        }

        return await paginate<Reminder, Prisma.ReminderFindManyArgs>(this.prisma.reminder, {
            where: whereClause,
            orderBy: order,
            include: {
                owner: {
                    omit: {
                        password: true,
                    },
                },
            },
        })
    }

    async findOne(id: string) {
        const reminder = await this.prisma.reminder.findUnique({
            where: {
                id: id,
            },
            include: {
                owner: {
                    omit: {
                        password: true,
                    },
                },
            },
        })

        if (!reminder) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Reminder",
                    value: id,
                }),
            )
        }

        return reminder
    }

    async update(id: string, updateReminderDto: UpdateReminderDto) {
        const existingReminder = await this.prisma.reminder.findUnique({
            where: {
                id: id,
            },
        })

        if (!existingReminder) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Reminder",
                    value: id,
                }),
            )
        }

        return await this.prisma.reminder.update({
            where: {
                id: id,
            },
            data: updateReminderDto,
        })
    }

    async remove(id: string) {
        const existingReminder = await this.prisma.reminder.findUnique({
            where: {
                id: id,
            },
        })

        if (!existingReminder) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Reminder",
                    value: id,
                }),
            )
        }

        return await this.prisma.reminder.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
