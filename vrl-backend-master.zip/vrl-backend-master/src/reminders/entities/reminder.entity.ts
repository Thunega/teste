export class Reminder {}
