import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PrismaService } from "../prisma/prisma.service"
import { RemindersService } from "./reminders.service"

describe("RemindersService", () => {
    let service: RemindersService
    let prisma: PrismaService

    const mockPrisma = {
        reminder: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [RemindersService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<RemindersService>(RemindersService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a reminder", async () => {
            const dto = { title: "rem", scheduledAt: new Date().toISOString() }
            mockPrisma.reminder.create.mockResolvedValue({ id: "rid", ...dto })

            const result = await service.create("uid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.reminder.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a reminder", async () => {
            mockPrisma.reminder.findUnique.mockResolvedValue({ id: "rid" })
            const result = await service.findOne("rid")
            expect(result).toEqual({ id: "rid" })
        })

        it("should throw not found", async () => {
            mockPrisma.reminder.findUnique.mockResolvedValue(null)
            await expect(service.findOne("rid")).rejects.toThrow(NotFoundException)
        })
    })
})
