﻿import { Controller, Get, Post, Body, Patch, Delete, UseGuards } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { UpdateReminderDto } from "./dto/update-reminder.dto"
import { CreateReminderDto } from "./dto/create-reminder.dto"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Id } from "../common/decorators/id.decorator"
import { RemindersService } from "./reminders.service"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("reminders")
@ApiStandardErrorResponses({ notFoundName: "Reminders" })
@UseGuards(JwtAuthGuard)
export class RemindersController {
    constructor(private readonly remindersService: RemindersService) {}

    @Post()
    async create(@Body() createReminderDto: CreateReminderDto, @InjectUser() user: JwtAuthenticatedUser) {
        return await this.remindersService.create(user.id, createReminderDto)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
        @QuerySearch() query?: string,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.remindersService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
        )
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.remindersService.findOne(id)
    }

    @Patch(":id")
    async update(@Id() id: string, @Body() updateReminderDto: UpdateReminderDto) {
        return await this.remindersService.update(id, updateReminderDto)
    }

    @Delete(":id")
    async remove(@Id() id: string) {
        return await this.remindersService.remove(id)
    }
}
