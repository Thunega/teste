import { Test, TestingModule } from "@nestjs/testing"

import { ForwardingsController } from "./forwardings.controller"
import { ForwardingsService } from "./forwardings.service"

describe("ForwardingsController", () => {
    let controller: ForwardingsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [ForwardingsController],
            providers: [{ provide: ForwardingsService, useValue: mockService }],
        }).compile()

        controller = module.get<ForwardingsController>(ForwardingsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
