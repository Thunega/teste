import { Module } from "@nestjs/common"

import { ForwardingsController } from "./forwardings.controller"
import { PatientsModule } from "../patients/patients.module"
import { ForwardingsService } from "./forwardings.service"
import { PrismaModule } from "../prisma/prisma.module"
import { UsersModule } from "../users/users.module"

@Module({
    imports: [PrismaModule, UsersModule, PatientsModule],
    controllers: [ForwardingsController],
    providers: [ForwardingsService],
})
export class ForwardingsModule {}
