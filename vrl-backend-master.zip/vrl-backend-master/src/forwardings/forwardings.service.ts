import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateForwardingDto } from "./dto/update-forwarding.dto"
import { CreateForwardingDto } from "./dto/create-forwarding.dto"
import { Forwarding, Prisma } from "../generated/prisma/client"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"
import { UsersService } from "../users/users.service"

type SearchOptions = {
    fromUserId?: string
    toUserId?: string
    patientId?: string
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class ForwardingsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly usersService: UsersService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(userId: string, createForwardingDto: CreateForwardingDto) {
        await this.usersService.findOne(createForwardingDto.toUserId)
        await this.patientsService.findOne(createForwardingDto.patientId)

        return await this.prisma.forwarding.create({
            data: {
                medicalNotes: createForwardingDto.medicalNotes,
                fromUser: {
                    connect: {
                        id: userId,
                    },
                },
                toUser: {
                    connect: {
                        id: createForwardingDto.toUserId,
                    },
                },
                patient: {
                    connect: {
                        id: createForwardingDto.patientId,
                    },
                },
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        { patientId, fromUserId, toUserId, query, orderBy, sort }: SearchOptions,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        const whereClause: Prisma.ForwardingWhereInput = {
            fromUserId: fromUserId,
            toUserId: toUserId,
            patientId: patientId,
        }

        if (query) {
            const cleanQuery = query.trim()

            whereClause.OR = [
                {
                    medicalNotes: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
                {
                    patient: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
                {
                    fromUser: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
                {
                    toUser: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
            ]
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.createdAt = "desc"
        }

        return await paginate<Forwarding, Prisma.ForwardingFindManyArgs>(this.prisma.forwarding, {
            where: whereClause,
            orderBy: order,
            include: {
                fromUser: {
                    omit: {
                        password: true,
                    },
                },
                toUser: {
                    omit: {
                        password: true,
                    },
                },
                patient: true,
            },
        })
    }

    async findOne(id: string) {
        const forwarding = await this.prisma.forwarding.findUnique({
            where: {
                id: id,
            },
        })

        if (!forwarding) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Forwarding",
                    value: id,
                }),
            )
        }

        return forwarding
    }

    async update(id: string, updateForwardingDto: UpdateForwardingDto) {
        const existingForwarding = await this.prisma.forwarding.findUnique({
            where: {
                id: id,
            },
        })

        if (!existingForwarding) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Forwarding",
                    value: id,
                }),
            )
        }

        return await this.prisma.forwarding.update({
            where: {
                id: id,
            },
            data: updateForwardingDto,
        })
    }

    async remove(id: string) {
        const existingForwarding = await this.prisma.forwarding.findUnique({
            where: {
                id: id,
            },
        })

        if (!existingForwarding) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Forwarding",
                    value: id,
                }),
            )
        }

        await this.prisma.forwarding.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
