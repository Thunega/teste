﻿import { Controller, Get, Post, Body, Patch, Delete, ParseUUIDPipe, UseGuards, Query } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { UpdateForwardingDto } from "./dto/update-forwarding.dto"
import { CreateForwardingDto } from "./dto/create-forwarding.dto"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { ForwardingsService } from "./forwardings.service"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("forwardings")
@ApiStandardErrorResponses({ notFoundName: "Forwardings" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class ForwardingsController {
    constructor(private readonly forwardingsService: ForwardingsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async create(@Body() createForwardingDto: CreateForwardingDto, @InjectUser() user: JwtAuthenticatedUser) {
        return await this.forwardingsService.create(user.id, createForwardingDto)
    }

    @Get()
    @ApiPaginated()
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "fromUserId",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "toUserId",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("fromUserId", new ParseUUIDPipe({ optional: true })) fromUserId?: string,
        @Query("toUserId", new ParseUUIDPipe({ optional: true })) toUserId?: string,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.forwardingsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                fromUserId: fromUserId,
                toUserId: toUserId,
                patientId: patientId,
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
        )
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.forwardingsService.findOne(id)
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async update(@Id() id: string, @Body() updateForwardingDto: UpdateForwardingDto) {
        return await this.forwardingsService.update(id, updateForwardingDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async remove(@Id() id: string) {
        return await this.forwardingsService.remove(id)
    }
}
