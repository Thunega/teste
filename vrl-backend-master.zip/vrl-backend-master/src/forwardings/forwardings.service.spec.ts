import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PatientsService } from "../patients/patients.service"
import { ForwardingsService } from "./forwardings.service"
import { PrismaService } from "../prisma/prisma.service"
import { UsersService } from "../users/users.service"

describe("ForwardingsService", () => {
    let service: ForwardingsService
    let prisma: PrismaService

    const mockPrisma = {
        forwarding: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockUsersService = { findOne: jest.fn() }
    const mockPatientsService = { findOne: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                ForwardingsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: UsersService, useValue: mockUsersService },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<ForwardingsService>(ForwardingsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a forwarding", async () => {
            const dto = { toUserId: "tuid", patientId: "pid", medicalNotes: "notes" }
            mockUsersService.findOne.mockResolvedValue({ id: "tuid" })
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.forwarding.create.mockResolvedValue({ id: "fid", ...dto })

            const result = await service.create("uid", dto)

            expect(result).toBeDefined()
            expect(mockPrisma.forwarding.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a forwarding", async () => {
            mockPrisma.forwarding.findUnique.mockResolvedValue({ id: "fid" })
            const result = await service.findOne("fid")
            expect(result).toEqual({ id: "fid" })
        })

        it("should throw not found", async () => {
            mockPrisma.forwarding.findUnique.mockResolvedValue(null)
            await expect(service.findOne("fid")).rejects.toThrow(NotFoundException)
        })
    })
})
