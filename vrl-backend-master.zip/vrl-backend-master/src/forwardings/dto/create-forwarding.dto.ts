import { IsNotEmpty, IsString, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateForwardingDto {
    @ApiProperty({
        description: "ID (UUID) do paciente que está sendo encaminhado",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string

    @ApiProperty({
        description: "ID (UUID) do profissional de saúde que receberá o encaminhamento",
        example: "b2c3d4e5-f6a7-8901-bcde-f01234567890",
    })
    @IsUUID()
    toUserId: string

    @ApiProperty({
        description: "Notas médicas e justificativa clínica para o encaminhamento",
        example:
            "Paciente apresenta dores lombares persistentes. Encaminho para avaliação fisioterápica. HAS controlada com Losartana 50mg.",
    })
    @IsString()
    @IsNotEmpty()
    medicalNotes: string
}
