import { Module } from "@nestjs/common"

import { MessagesController } from "./messages.controller"
import { PrismaModule } from "../prisma/prisma.module"
import { MessagesService } from "./messages.service"

@Module({
    imports: [PrismaModule],
    controllers: [MessagesController],
    providers: [MessagesService],
})
export class MessagesModule {}
