﻿import { Controller, Get, Post, Body, Patch, Delete, UseGuards, Query, ParseBoolPipe } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { UpdateMessageDto } from "./dto/update-message.dto"
import { CreateMessageDto } from "./dto/create-message.dto"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { MessagesService } from "./messages.service"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("messages")
@ApiStandardErrorResponses({ notFoundName: "Messages" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class MessagesController {
    constructor(private readonly messagesService: MessagesService) {}

    @Post()
    async create(@InjectUser() user: JwtAuthenticatedUser, @Body() createMessageDto: CreateMessageDto) {
        return await this.messagesService.create(user.id, createMessageDto)
    }

    @Get()
    @ApiPaginated()
    @ApiQuery({ name: "query", required: false, type: String })
    @ApiQuery({ name: "isRead", required: false, type: Boolean })
    async findAll(
        @InjectUser() user: JwtAuthenticatedUser,
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("isRead", new ParseBoolPipe({ optional: true })) isRead?: boolean,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.messagesService.findAll({ page, perPage }, user.id, user.role, {
            query,
            isRead,
            orderBy,
            sort,
        })
    }

    @Get(":id")
    async findOne(@Id() id: string, @InjectUser() user: JwtAuthenticatedUser) {
        return await this.messagesService.findOne(id, user.id, user.role)
    }

    @Patch(":id")
    async update(
        @Id() id: string,
        @InjectUser() user: JwtAuthenticatedUser,
        @Body() updateMessageDto: UpdateMessageDto,
    ) {
        return await this.messagesService.update(id, updateMessageDto, user.id, user.role)
    }

    @Delete(":id")
    async remove(@Id() id: string, @InjectUser() user: JwtAuthenticatedUser) {
        return await this.messagesService.remove(id, user.id, user.role)
    }
}
