import { IsString, IsNotEmpty, IsOptional, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateMessageDto {
    @IsString()
    @IsNotEmpty()
    @ApiProperty({
        description: "Assunto da mensagem",
        example: "Dúvida sobre prescrição do paciente João",
    })
    subject: string

    @IsString()
    @IsNotEmpty()
    @ApiProperty({
        description: "Corpo/conteúdo da mensagem",
        example:
            "Gostaria de discutir a posologia da metformina prescrita na última consulta. O paciente relatou desconforto gástrico.",
    })
    body: string

    @IsUUID()
    @IsNotEmpty()
    @ApiProperty({
        description: "ID (UUID) do usuário destinatário da mensagem",
        example: "b2c3d4e5-f6a7-8901-bcde-f01234567890",
    })
    receiverId: string

    @IsUUID()
    @IsOptional()
    @ApiProperty({
        description: "ID (UUID) do paciente relacionado à mensagem (opcional)",
        required: false,
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    patientId?: string
}
