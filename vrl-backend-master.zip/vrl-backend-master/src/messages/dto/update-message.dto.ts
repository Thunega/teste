import { IsBoolean, IsOptional } from "class-validator"
import { PartialType } from "@nestjs/swagger"

import { CreateMessageDto } from "./create-message.dto"

export class UpdateMessageDto extends PartialType(CreateMessageDto) {
    @IsBoolean()
    @IsOptional()
    isRead?: boolean
}
