import { Test, TestingModule } from "@nestjs/testing"
import { BadRequestException } from "@nestjs/common"

import { PrismaService } from "../prisma/prisma.service"
import { UserRole } from "../generated/prisma/client"
import { MessagesService } from "./messages.service"

jest.mock("prisma-pagination", () => ({
    createPaginator: jest.fn().mockReturnValue(
        jest.fn().mockResolvedValue({
            data: [],
            meta: { total: 0, lastPage: 0, currentPage: 1, perPage: 10, prev: null, next: null },
        }),
    ),
}))

describe("MessagesService", () => {
    let service: MessagesService

    const mockPrisma = {
        message: {
            create: jest.fn(),
            findMany: jest.fn(),
            findUnique: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
        },
        user: {
            findUnique: jest.fn(),
        },
        patient: {
            findUnique: jest.fn(),
        },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [MessagesService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<MessagesService>(MessagesService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should throw error if sender is receiver", async () => {
            const dto = { receiverId: "same-id", subject: "Test", body: "Test" }
            await expect(service.create("same-id", dto)).rejects.toThrow(BadRequestException)
        })

        it("should throw error if receiver not found", async () => {
            mockPrisma.user.findUnique.mockResolvedValueOnce(null)
            const dto = { receiverId: "receiver-id", subject: "Test", body: "Test" }
            await expect(service.create("sender-id", dto)).rejects.toThrow(BadRequestException)
        })

        it("should throw error if patient not found", async () => {
            mockPrisma.user.findUnique.mockResolvedValueOnce({ id: "receiver-id" })
            mockPrisma.patient.findUnique.mockResolvedValueOnce(null)
            const dto = { receiverId: "receiver-id", patientId: "patient-id", subject: "Test", body: "Test" }
            await expect(service.create("sender-id", dto)).rejects.toThrow(BadRequestException)
        })

        it("should create a message", async () => {
            mockPrisma.user.findUnique.mockResolvedValueOnce({ id: "receiver-id" })
            const dto = { receiverId: "receiver-id", subject: "Test", body: "Test" }
            mockPrisma.message.create.mockResolvedValueOnce({ id: "msg-id", ...dto })

            const result = await service.create("sender-id", dto)
            expect(result.id).toBe("msg-id")
            expect(mockPrisma.message.create).toHaveBeenCalled()
        })
    })

    describe("findAll", () => {
        it("should return paginated results", async () => {
            const options = { page: 1, perPage: 10 }
            const result = await service.findAll(options, "user-id", UserRole.ADMIN, {})
            expect(result).toHaveProperty("data")
        })
    })

    describe("findOne", () => {
        it("should throw if not found", async () => {
            mockPrisma.message.findUnique.mockResolvedValueOnce(null)
            await expect(service.findOne("msg-id", "user-id", UserRole.ADMIN)).rejects.toThrow(BadRequestException)
        })

        it("should return message", async () => {
            mockPrisma.message.findUnique.mockResolvedValueOnce({ id: "msg-id", receiverId: "other-id", isRead: true })
            const result = await service.findOne("msg-id", "user-id", UserRole.ADMIN)
            expect(result.id).toBe("msg-id")
        })

        it("should mark as read if receiver opens it and it is unread", async () => {
            mockPrisma.message.findUnique.mockResolvedValueOnce({ id: "msg-id", receiverId: "user-id", isRead: false })
            mockPrisma.message.update.mockResolvedValueOnce({ id: "msg-id", isRead: true })
            const result = await service.findOne("msg-id", "user-id", UserRole.DOCTOR)
            expect(result.isRead).toBe(true)
            expect(mockPrisma.message.update).toHaveBeenCalled()
        })
    })

    describe("remove", () => {
        it("should throw if message not found", async () => {
            mockPrisma.message.findUnique.mockResolvedValueOnce(null)
            await expect(service.remove("msg-id", "user-id", UserRole.ADMIN)).rejects.toThrow(BadRequestException)
        })

        it("should remove message if admin", async () => {
            mockPrisma.message.findUnique.mockResolvedValueOnce({
                id: "msg-id",
                senderId: "other-id",
                receiverId: "another-id",
            })
            mockPrisma.message.delete.mockResolvedValueOnce({ id: "msg-id" })

            await service.remove("msg-id", "admin-id", UserRole.ADMIN)
            expect(mockPrisma.message.delete).toHaveBeenCalled()
        })
    })
})
