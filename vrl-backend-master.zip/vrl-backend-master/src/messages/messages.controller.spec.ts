import { Test, TestingModule } from "@nestjs/testing"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { MessagesController } from "./messages.controller"
import { UserRole } from "../generated/prisma/client"
import { MessagesService } from "./messages.service"

describe("MessagesController", () => {
    let controller: MessagesController
    let service: MessagesService

    const mockMessagesService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    const mockUser: JwtAuthenticatedUser = {
        id: "user-id",
        email: "test@vrl.com",
        username: "test",
        role: UserRole.DOCTOR,
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [MessagesController],
            providers: [{ provide: MessagesService, useValue: mockMessagesService }],
        }).compile()

        controller = module.get<MessagesController>(MessagesController)
        service = module.get<MessagesService>(MessagesService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })

    it("should call create", async () => {
        const dto = { receiverId: "receiver-id", subject: "Test", body: "Test" }
        mockMessagesService.create.mockResolvedValueOnce({ id: "msg-id" })

        await controller.create(mockUser, dto)
        expect(service.create).toHaveBeenCalledWith("user-id", dto)
    })

    it("should call findAll", async () => {
        mockMessagesService.findAll.mockResolvedValueOnce({ data: [], meta: {} })

        await controller.findAll(mockUser, 1, 10, "query", false)
        expect(service.findAll).toHaveBeenCalledWith({ page: 1, perPage: 10 }, mockUser.id, mockUser.role, {
            query: "query",
            isRead: false,
        })
    })

    it("should call findOne", async () => {
        mockMessagesService.findOne.mockResolvedValueOnce({ id: "msg-id" })

        await controller.findOne("msg-id", mockUser)
        expect(service.findOne).toHaveBeenCalledWith("msg-id", mockUser.id, mockUser.role)
    })

    it("should call update", async () => {
        const dto = { isRead: true }
        mockMessagesService.update.mockResolvedValueOnce({ id: "msg-id", isRead: true })

        await controller.update("msg-id", mockUser, dto)
        expect(service.update).toHaveBeenCalledWith("msg-id", dto, mockUser.id, mockUser.role)
    })

    it("should call remove", async () => {
        mockMessagesService.remove.mockResolvedValueOnce(undefined)

        await controller.remove("msg-id", mockUser)
        expect(service.remove).toHaveBeenCalledWith("msg-id", mockUser.id, mockUser.role)
    })
})
