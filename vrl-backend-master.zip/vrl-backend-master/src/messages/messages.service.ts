import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, BadRequestException } from "@nestjs/common"

import { Prisma, Message, UserRole } from "../generated/prisma/client"
import { messagesHelper } from "../helpers/messages.helper"
import { UpdateMessageDto } from "./dto/update-message.dto"
import { CreateMessageDto } from "./dto/create-message.dto"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    query?: string
    isRead?: boolean
    orderBy?: string
    sort?: string
}

@Injectable()
export class MessagesService {
    constructor(private readonly prisma: PrismaService) {}

    async create(senderId: string, createMessageDto: CreateMessageDto) {
        if (senderId === createMessageDto.receiverId) {
            throw new BadRequestException(messagesHelper.SELF_MESSAGE)
        }

        const receiver = await this.prisma.user.findUnique({
            where: {
                id: createMessageDto.receiverId,
            },
        })

        if (!receiver) {
            throw new BadRequestException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "User",
                    value: createMessageDto.receiverId,
                }),
            )
        }

        if (createMessageDto.patientId) {
            const patient = await this.prisma.patient.findUnique({
                where: {
                    id: createMessageDto.patientId,
                },
            })

            if (!patient) {
                throw new BadRequestException(
                    messagesHelper.OBJECT_NOT_FOUND({
                        name: "Patient",
                        value: createMessageDto.patientId,
                    }),
                )
            }
        }

        return await this.prisma.message.create({
            data: {
                ...createMessageDto,
                senderId,
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        userId: string,
        userRole: UserRole,
        { query, isRead, orderBy, sort }: SearchOptions,
    ) {
        const paginate = createPaginator({ page, perPage })
        const whereClauses: Prisma.MessageWhereInput[] = []

        if (userRole !== UserRole.ADMIN) {
            whereClauses.push({
                OR: [{ senderId: userId }, { receiverId: userId }],
            })
        }

        if (isRead !== undefined) {
            whereClauses.push({ isRead })
        } else {
            whereClauses.push({ isRead: false })
        }

        if (query) {
            const cleanQuery = query.trim()

            whereClauses.push({
                OR: [
                    { subject: { contains: cleanQuery, mode: "insensitive" } },
                    { body: { contains: cleanQuery, mode: "insensitive" } },
                    { sender: { name: { contains: cleanQuery, mode: "insensitive" } } },
                    { receiver: { name: { contains: cleanQuery, mode: "insensitive" } } },
                ],
            })
        }

        const whereClause: Prisma.MessageWhereInput = whereClauses.length > 0 ? { AND: whereClauses } : {}

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.createdAt = "desc"
        }

        return await paginate<Message, Prisma.MessageFindManyArgs>(this.prisma.message, {
            where: whereClause,
            include: {
                sender: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                    },
                },
                receiver: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                    },
                },
                patient: {
                    select: {
                        id: true,
                        name: true,
                    },
                },
            },
            orderBy: order,
        })
    }

    async findOne(id: string, userId: string, userRole: UserRole) {
        const message = await this.prisma.message.findUnique({
            where: {
                id: id,
            },
            include: {
                sender: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                    },
                },
                receiver: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                    },
                },
                patient: {
                    select: {
                        id: true,
                        name: true,
                    },
                },
            },
        })

        if (!message) {
            throw new BadRequestException(messagesHelper.OBJECT_NOT_FOUND({ name: "Message", value: id }))
        }

        if (userRole !== UserRole.ADMIN && message.senderId !== userId && message.receiverId !== userId) {
            throw new BadRequestException(messagesHelper.RESOURCE_ACCESS_UNAUTHORIZED)
        }

        if (message.receiverId === userId && !message.isRead) {
            const updatedMessage = await this.prisma.message.update({
                where: {
                    id: id,
                },
                data: { isRead: true },
                include: {
                    sender: {
                        select: {
                            id: true,
                            name: true,
                            email: true,
                            role: true,
                        },
                    },
                    receiver: {
                        select: {
                            id: true,
                            name: true,
                            email: true,
                            role: true,
                        },
                    },
                    patient: {
                        select: {
                            id: true,
                            name: true,
                        },
                    },
                },
            })
            return updatedMessage
        }

        return message
    }

    async update(id: string, updateMessageDto: UpdateMessageDto, userId: string, userRole: UserRole) {
        const message = await this.prisma.message.findUnique({
            where: {
                id: id,
            },
        })

        if (!message) {
            throw new BadRequestException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Message",
                    value: id,
                }),
            )
        }

        if (userRole !== UserRole.ADMIN && message.senderId !== userId && message.receiverId !== userId) {
            throw new BadRequestException(messagesHelper.RESOURCE_ACCESS_UNAUTHORIZED)
        }

        if (updateMessageDto.isRead !== undefined && message.receiverId !== userId && userRole !== UserRole.ADMIN) {
            if (message.senderId === userId && message.receiverId !== userId) {
                throw new BadRequestException(messagesHelper.RESOURCE_ACCESS_UNAUTHORIZED)
            }
        }

        return await this.prisma.message.update({
            where: {
                id: id,
            },
            data: updateMessageDto,
            include: {
                sender: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                    },
                },
                receiver: {
                    select: {
                        id: true,
                        name: true,
                        email: true,
                        role: true,
                    },
                },
                patient: {
                    select: {
                        id: true,
                        name: true,
                    },
                },
            },
        })
    }

    async remove(id: string, userId: string, userRole: UserRole) {
        const message = await this.prisma.message.findUnique({
            where: {
                id: id,
            },
        })

        if (!message) {
            throw new BadRequestException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Message",
                    value: id,
                }),
            )
        }

        if (userRole !== UserRole.ADMIN) {
            if (message.senderId !== userId && message.receiverId !== userId) {
                throw new BadRequestException(messagesHelper.RESOURCE_ACCESS_UNAUTHORIZED)
            }
        }

        await this.prisma.message.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
