import { Test, TestingModule } from "@nestjs/testing"
import { ConfigService } from "@nestjs/config"

import { PrismaService } from "../prisma/prisma.service"
import { FitbitService } from "./fitbit.service"

describe("FitbitService", () => {
    let service: FitbitService
    let prisma: PrismaService

    const mockPrisma = {
        fitbitAuth: {
            findUnique: jest.fn(),
            upsert: jest.fn(),
            delete: jest.fn(),
        },
        sleepLog: {
            upsert: jest.fn(),
        },
    }

    const mockConfigService = {
        getOrThrow: jest.fn((key: string) => {
            if (key === "FITBIT_CLIENT_ID") return "id"
            if (key === "FITBIT_CLIENT_SECRET") return "secret"
            if (key === "FITBIT_REDIRECT_URI") return "uri"
            return null
        }),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                FitbitService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: ConfigService, useValue: mockConfigService },
            ],
        }).compile()

        service = module.get<FitbitService>(FitbitService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("getAuthorizationUrl", () => {
        it("should return a url", () => {
            const url = service.getAuthorizationUrl("pid")
            expect(url).toContain("client_id=id")
            expect(url).toContain("state=pid")
        })
    })

    describe("deleteAuthInfo", () => {
        it("should delete auth info", async () => {
            mockPrisma.fitbitAuth.findUnique.mockResolvedValue({ id: "aid" })
            mockPrisma.fitbitAuth.delete.mockResolvedValue({})
            await service.deleteAuthInfo("pid")
            expect(mockPrisma.fitbitAuth.delete).toHaveBeenCalled()
        })
    })
})
