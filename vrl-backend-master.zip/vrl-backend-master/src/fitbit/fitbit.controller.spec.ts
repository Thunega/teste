import { Test, TestingModule } from "@nestjs/testing"

import { FitbitController } from "./fitbit.controller"
import { FitbitService } from "./fitbit.service"

describe("FitbitController", () => {
    let controller: FitbitController

    const mockService = {
        getAuthorizationUrl: jest.fn(),
        getAccessToken: jest.fn(),
        syncSleepLogs: jest.fn(),
        getAuthInfo: jest.fn(),
        deleteAuthInfo: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [FitbitController],
            providers: [{ provide: FitbitService, useValue: mockService }],
        }).compile()

        controller = module.get<FitbitController>(FitbitController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
