import { Module } from "@nestjs/common"

import { PrismaModule } from "../prisma/prisma.module"
import { FitbitController } from "./fitbit.controller"
import { FitbitService } from "./fitbit.service"

@Module({
    imports: [PrismaModule],
    controllers: [FitbitController],
    providers: [FitbitService],
})
export class FitbitModule {}
