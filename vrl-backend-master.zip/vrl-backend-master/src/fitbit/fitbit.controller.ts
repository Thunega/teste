﻿import { Controller, Get, Query, Param, Delete, ParseDatePipe, Redirect } from "@nestjs/common"

import { FitbitService } from "./fitbit.service"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("fitbit")
@ApiStandardErrorResponses({ notFoundName: "Fitbit" })
export class FitbitController {
    constructor(private readonly fitbitService: FitbitService) {}

    @Get("auth/:patientId")
    authorize(@Param("patientId") patientId: string) {
        const authorizationUrl = this.fitbitService.getAuthorizationUrl(patientId)
        return { url: authorizationUrl }
    }

    @Get("callback")
    @Redirect("https://www.vrleao.com/fitbit-auth-success", 302)
    async callback(@Query("code") code: string, @Query("state") state: string) {
        const authData = await this.fitbitService.getAccessToken(code, state)
        const syncMessage = await this.fitbitService.syncSleepLogs(state, {})
    }

    @Get("sync-sleep-logs/:patientId")
    async syncSleepLogs(
        @Param("patientId") patientId: string,
        @Query("startDate", new ParseDatePipe({ optional: true })) startDate?: Date,
        @Query("endDate", new ParseDatePipe({ optional: true })) endDate?: Date,
    ) {
        return this.fitbitService.syncSleepLogs(patientId, { startDate, endDate })
    }

    @Get("auth-info/:patientId")
    async getAuthInfo(@Param("patientId") patientId: string) {
        return this.fitbitService.getAuthInfo(patientId)
    }

    @Delete("auth-info/:patientId")
    async deleteAuthInfo(@Param("patientId") patientId: string) {
        return this.fitbitService.deleteAuthInfo(patientId)
    }
}
