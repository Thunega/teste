import { HttpException, HttpStatus, Injectable, Logger } from "@nestjs/common"
import { ConfigService } from "@nestjs/config"

import { PrismaService } from "../prisma/prisma.service"

type DateOptions = {
    startDate?: Date
    endDate?: Date
}

@Injectable()
export class FitbitService {
    private readonly clientId: string
    private readonly clientSecret: string
    private readonly redirectUri: string
    private readonly logger = new Logger(FitbitService.name)

    constructor(
        private readonly prisma: PrismaService,
        configService: ConfigService,
    ) {
        this.clientId = configService.getOrThrow<string>("FITBIT_CLIENT_ID")
        this.clientSecret = configService.getOrThrow<string>("FITBIT_CLIENT_SECRET")
        this.redirectUri = configService.getOrThrow<string>("FITBIT_REDIRECT_URI")
    }

    getAuthorizationUrl(patientId: string): string {
        const state = patientId
        const scope = "activity heartrate location nutrition profile settings sleep social weight"
        const prompt = "login consent"
        const url = `https://www.fitbit.com/oauth2/authorize?response_type=code&client_id=${this.clientId}&scope=${encodeURIComponent(scope)}&redirect_uri=${encodeURIComponent(this.redirectUri)}&state=${state}&prompt=${prompt}`
        return url
    }

    async getAccessToken(code: string, state: string) {
        const credentials = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString("base64")

        const response = await fetch("https://api.fitbit.com/oauth2/token", {
            method: "POST",
            headers: {
                Authorization: `Basic ${credentials}`,
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: `code=${code}&grant_type=authorization_code&redirect_uri=${encodeURIComponent(this.redirectUri)}`,
        })

        const data = await response.json()

        const patientId = state

        const fitbitAuth = await this.prisma.fitbitAuth.upsert({
            where: { patientId: patientId },
            update: {
                accessToken: data.access_token,
                refreshToken: data.refresh_token,
                expiresIn: data.expires_in,
                userId: data.user_id,
            },
            create: {
                accessToken: data.access_token,
                expiresIn: data.expires_in,
                refreshToken: data.refresh_token,
                scope: data.scope,
                tokenType: data.token_type,
                userId: data.user_id,
                patientId: patientId,
            },
        })

        return fitbitAuth
    }

    async syncSleepLogs(patientId: string, { startDate, endDate }: DateOptions) {
        const fitbitAuth = await this.prisma.fitbitAuth.findUnique({
            where: { patientId },
        })

        if (!fitbitAuth) {
            throw new Error("Patient not authenticated with Fitbit.")
        }

        const refreshedAuth = await this.refreshAccessTokenIfNeeded(fitbitAuth)

        this.logger.log(`sincronizando dados fitbit ${startDate} - ${endDate}`)

        if (!startDate) {
            startDate = new Date(new Date().getTime() - 100 * 24 * 60 * 60 * 1000)
        }

        if (!endDate) {
            endDate = new Date()
        }

        this.logger.log(
            `sincronizando dados fitbit ${startDate.toISOString().slice(0, 10)} - ${endDate.toISOString().slice(0, 10)}`,
        )

        const response = await fetch(
            `https://api.fitbit.com/1.2/user/${refreshedAuth.userId}/sleep/date/${startDate.toISOString().slice(0, 10)}/${endDate.toISOString().slice(0, 10)}.json`,
            {
                headers: {
                    Authorization: `Bearer ${refreshedAuth.accessToken}`,
                },
            },
        )

        const sleepData = await response.json()

        this.logger.log(`sincronizando dados fitbit ${JSON.stringify(sleepData, null, 2)}`)

        if (!sleepData.sleep || sleepData.sleep.length === 0) {
            return { message: "Nenhum registro de sono novo encontrado." }
        }

        const newLogs: any = []

        for (const sleepLog of sleepData.sleep) {
            const existingLog = await this.prisma.sleepLog.findFirst({
                where: {
                    patientId,
                    dateOfRegistration: sleepLog.dateOfSleep,
                },
            })

            if (!existingLog) {
                const sleepGoal = await fetch(
                    `https://api.fitbit.com/1.2/user/${refreshedAuth.userId}/sleep/goal.json`,
                    {
                        headers: {
                            Authorization: `Bearer ${refreshedAuth.accessToken}`,
                        },
                    },
                )

                const createdLog = await this.prisma.sleepLog.create({
                    data: {
                        patientId: patientId,
                        dateOfRegistration: sleepLog.dateOfSleep,
                        score: sleepLog.efficiency,
                        sleepTime: sleepLog.minutesAsleep,
                        agreedTime: 0,
                        remTime: sleepLog.levels.summary.rem?.minutes || 0,
                        lightSleep: sleepLog.levels.summary.light?.minutes || 0,
                        deepSleep: sleepLog.levels.summary.deep?.minutes || 0,
                    },
                })
                newLogs.push(createdLog)
            }
        }

        return { message: `${newLogs.length} Novos registros de sono criados.`, newLogs: newLogs }
    }

    async getAuthInfo(patientId: string) {
        let fitbitAuth: any = await this.prisma.fitbitAuth.findUnique({
            where: { patientId },
        })

        if (!fitbitAuth) {
            throw new HttpException("Forbidden", HttpStatus.FORBIDDEN)
        }

        const introspectionResponse = await fetch("https://api.fitbit.com/1.1/oauth2/introspect", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${fitbitAuth.accessToken}`,
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: `token=${fitbitAuth.accessToken}`,
        })

        const introspectionData = await introspectionResponse.json()

        if (!introspectionData.active) {
            fitbitAuth = await this.refreshAccessTokenIfNeeded(fitbitAuth)
        }

        const profileResponse = await fetch(`https://api.fitbit.com/1/user/${fitbitAuth.userId}/profile.json`, {
            headers: {
                Authorization: `Bearer ${fitbitAuth.accessToken}`,
            },
        })

        const profileData = await profileResponse.json()

        return {
            patientId: fitbitAuth.patientId,
            userId: fitbitAuth.userId,
            profile: profileData.user,
            tokenType: fitbitAuth.tokenType,
            scope: fitbitAuth.scope,
            expiresIn: fitbitAuth.expiresIn,
            active: introspectionData.active,
        }
    }

    async deleteAuthInfo(patientId: string) {
        this.prisma.fitbitAuth.delete({
            where: {
                patientId: patientId,
            },
            select: {
                id: true,
            },
        })
    }

    private async refreshAccessTokenIfNeeded(fitbitAuth) {
        const credentials = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString("base64")

        const response = await fetch("https://api.fitbit.com/oauth2/token", {
            method: "POST",
            headers: {
                Authorization: `Basic ${credentials}`,
                "Content-Type": "application/x-www-form-urlencoded",
            },
            body: `grant_type=refresh_token&refresh_token=${fitbitAuth.refreshToken}`,
        })

        const data = await response.json()

        if (data.access_token) {
            const updatedAuth = await this.prisma.fitbitAuth.update({
                where: { id: fitbitAuth.id },
                data: {
                    accessToken: data.access_token,
                    refreshToken: data.refresh_token,
                    expiresIn: data.expires_in,
                },
            })
            return updatedAuth
        }

        return fitbitAuth
    }
}
