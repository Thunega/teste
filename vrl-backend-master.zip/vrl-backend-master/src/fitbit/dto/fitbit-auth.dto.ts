import { IsString, IsNotEmpty, IsNumber } from "class-validator"

export class FitbitAuthDto {
    @IsString()
    @IsNotEmpty()
    accessToken: string

    @IsNumber()
    @IsNotEmpty()
    expiresIn: number

    @IsString()
    @IsNotEmpty()
    refreshToken: string

    @IsString()
    @IsNotEmpty()
    scope: string

    @IsString()
    @IsNotEmpty()
    tokenType: string

    @IsString()
    @IsNotEmpty()
    userId: string

    @IsString()
    @IsNotEmpty()
    patientId: string
}
