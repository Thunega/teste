import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateNutritionalConsultationDto } from "./dto/update-nutritional-consultation.dto"
import { CreateNutritionalConsultationDto } from "./dto/create-nutritional-consultation.dto"
import { NutritionalConsultation, Prisma } from "../generated/prisma/client"
import { UploadProvider } from "../common/providers/upload.provider"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
}

@Injectable()
export class NutritionalConsultationsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
        private readonly uploadProvider: UploadProvider,
    ) {}

    async create(
        userId: string,
        createNutritionalConsultationDto: CreateNutritionalConsultationDto,
        photos?: Express.Multer.File[],
    ) {
        await this.patientsService.findOne(createNutritionalConsultationDto.patientId)
        const { patientId, ...rest } = createNutritionalConsultationDto

        const photoUrls: string[] = []
        if (photos && photos.length > 0) {
            for (const photo of photos) {
                const url = await this.uploadProvider.uploadFile(photo)
                photoUrls.push(url)
            }
        }

        return await this.prisma.nutritionalConsultation.create({
            data: {
                ...rest,
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
                user: {
                    connect: {
                        id: userId,
                    },
                },
                photos: {
                    create: photoUrls.map((url) => ({
                        photoUrl: url,
                    })),
                },
            },
            include: {
                photos: true,
            },
        })
    }

    async findAll({ page, perPage }: PaginateOptions, { startDate, endDate }: SearchOptions, patientId?: string) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        return await paginate<NutritionalConsultation, Prisma.NutritionalConsultationFindManyArgs>(
            this.prisma.nutritionalConsultation,
            {
                where: {
                    patientId: patientId,
                    createdAt: {
                        gte: startDate,
                        lte: endDate,
                    },
                },
                include: {
                    user: {
                        select: {
                            id: true,
                            name: true,
                        },
                    },
                    patient: {
                        select: {
                            id: true,
                            name: true,
                        },
                    },
                    photos: true,
                },
            },
        )
    }

    async findOne(id: string) {
        const nutritionalConsultation = await this.prisma.nutritionalConsultation.findUnique({
            where: {
                id: id,
            },
            include: {
                photos: true,
            },
        })

        if (!nutritionalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "NutritionalConsultation",
                    value: id,
                }),
            )
        }

        return nutritionalConsultation
    }

    async update(
        id: string,
        updateNutritionalConsultationDto: UpdateNutritionalConsultationDto,
        photos?: Express.Multer.File[],
    ) {
        const existingNutritionalConsultation = await this.prisma.nutritionalConsultation.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingNutritionalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "NutritionalConsultation",
                    value: id,
                }),
            )
        }

        const photoUrls: string[] = []
        if (photos && photos.length > 0) {
            for (const photo of photos) {
                const url = await this.uploadProvider.uploadFile(photo)
                photoUrls.push(url)
            }
        }

        return await this.prisma.nutritionalConsultation.update({
            where: {
                id: id,
            },
            data: {
                ...updateNutritionalConsultationDto,
                ...(photoUrls.length > 0 && {
                    photos: {
                        create: photoUrls.map((url) => ({
                            photoUrl: url,
                        })),
                    },
                }),
            },
            include: {
                user: {
                    select: {
                        id: true,
                        name: true,
                    },
                },
                photos: true,
            },
        })
    }

    async remove(id: string) {
        const existingNutritionalConsultation = await this.prisma.nutritionalConsultation.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingNutritionalConsultation) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "NutritionalConsultation",
                    value: id,
                }),
            )
        }

        await this.prisma.nutritionalConsultation.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
