import { Module } from "@nestjs/common"

import { NutritionalConsultationsController } from "./nutritional-consultations.controller"
import { NutritionalConsultationsService } from "./nutritional-consultations.service"
import { UploadProvider } from "../common/providers/upload.provider"
import { PatientsModule } from "../patients/patients.module"
import { PrismaModule } from "../prisma/prisma.module"

@Module({
    imports: [PrismaModule, PatientsModule],
    controllers: [NutritionalConsultationsController],
    providers: [NutritionalConsultationsService, UploadProvider],
})
export class NutritionalConsultationsModule {}
