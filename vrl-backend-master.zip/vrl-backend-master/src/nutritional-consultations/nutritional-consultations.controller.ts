﻿import { Controller, Get, Post, Body, Patch, Delete, UseGuards, ParseUUIDPipe, Query } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { UpdateNutritionalConsultationDto } from "./dto/update-nutritional-consultation.dto"
import { CreateNutritionalConsultationDto } from "./dto/create-nutritional-consultation.dto"
import { NutritionalConsultationsService } from "./nutritional-consultations.service"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("nutritional-consultations")
@ApiStandardErrorResponses({ notFoundName: "NutritionalConsultations" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class NutritionalConsultationsController {
    constructor(private readonly nutritionalConsultationsService: NutritionalConsultationsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.NUTRITIONIST)
    async create(
        @Body() createNutritionalConsultationDto: CreateNutritionalConsultationDto,
        @InjectUser() user: JwtAuthenticatedUser,
    ) {
        return await this.nutritionalConsultationsService.create(user.id, createNutritionalConsultationDto)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
    ) {
        return await this.nutritionalConsultationsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
            },
            patientId,
        )
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.nutritionalConsultationsService.findOne(id)
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.NUTRITIONIST)
    async update(@Id() id: string, @Body() updateNutritionalConsultationDto: UpdateNutritionalConsultationDto) {
        return await this.nutritionalConsultationsService.update(id, updateNutritionalConsultationDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.NUTRITIONIST)
    async remove(@Id() id: string) {
        return await this.nutritionalConsultationsService.remove(id)
    }
}
