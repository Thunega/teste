import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { NutritionalConsultationsService } from "./nutritional-consultations.service"
import { UploadProvider } from "../common/providers/upload.provider"
import { PatientsService } from "../patients/patients.service"
import { PrismaService } from "../prisma/prisma.service"

describe("NutritionalConsultationsService", () => {
    let service: NutritionalConsultationsService
    let prisma: PrismaService

    const mockPrisma = {
        nutritionalConsultation: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = { findOne: jest.fn() }
    const mockUploadProvider = { uploadFile: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                NutritionalConsultationsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
                { provide: UploadProvider, useValue: mockUploadProvider },
            ],
        }).compile()

        service = module.get<NutritionalConsultationsService>(NutritionalConsultationsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a consultation", async () => {
            const dto = { patientId: "pid", weight: 70 }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.nutritionalConsultation.create.mockResolvedValue({ id: "ncid", ...dto })

            const result = await service.create("uid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.nutritionalConsultation.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a consultation", async () => {
            mockPrisma.nutritionalConsultation.findUnique.mockResolvedValue({ id: "ncid" })
            const result = await service.findOne("ncid")
            expect(result).toEqual({ id: "ncid" })
        })

        it("should throw not found", async () => {
            mockPrisma.nutritionalConsultation.findUnique.mockResolvedValue(null)
            await expect(service.findOne("ncid")).rejects.toThrow(NotFoundException)
        })
    })
})
