import { Test, TestingModule } from "@nestjs/testing"

import { NutritionalConsultationsController } from "./nutritional-consultations.controller"
import { NutritionalConsultationsService } from "./nutritional-consultations.service"

describe("NutritionalConsultationsController", () => {
    let controller: NutritionalConsultationsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [NutritionalConsultationsController],
            providers: [{ provide: NutritionalConsultationsService, useValue: mockService }],
        }).compile()

        controller = module.get<NutritionalConsultationsController>(NutritionalConsultationsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
