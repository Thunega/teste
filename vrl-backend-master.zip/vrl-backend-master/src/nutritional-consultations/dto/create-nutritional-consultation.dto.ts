import { IsBoolean, IsDateString, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"
import { Type } from "class-transformer"

export class CreateNutritionalConsultationDto {
    @ApiProperty({
        description: "ID (UUID) do paciente ao qual a consulta pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string

    @ApiProperty({
        description: "Data da consulta nutricional (formato ISO 8601)",
        example: "2024-08-15",
    })
    @IsDateString()
    consultationDate: string

    @ApiProperty({
        description: "Motivo principal para marcar a consulta",
        example: "Dificuldade para perder peso e cansaço excessivo",
    })
    @IsString()
    @IsNotEmpty()
    reason: string

    @ApiProperty({
        description: "Objetivo principal almejado pelo paciente com o tratamento",
        example: "Hipertrofia muscular e melhora da composição corporal",
    })
    @IsString()
    @IsNotEmpty()
    mainObjective: string

    // --- Medidas Principais ---
    @ApiProperty({
        description: "Peso do paciente em quilogramas",
        required: false,
        example: 72.5,
    })
    @IsOptional()
    @Type(() => Number)
    weightKg?: number

    @ApiProperty({
        description: "Altura do paciente em centímetros",
        required: false,
        example: 170,
    })
    @IsOptional()
    @Type(() => Number)
    heightCm?: number

    @ApiProperty({
        description: "Índice de Massa Corporal (IMC)",
        required: false,
        example: 25.1,
    })
    @IsNumber()
    @IsOptional()
    @Type(() => Number)
    bmi?: number

    @ApiProperty({
        description: "Percentual de gordura corporal estimado (%)",
        required: false,
        example: 22.5,
    })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    fatPercentage?: number

    @ApiProperty({
        description: "Percentual de massa magra estimado (%)",
        required: false,
        example: 77.5,
    })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    leanMassPercentage?: number

    @ApiProperty({
        description: "Nível de gordura visceral (1-59, depende do aparelho)",
        required: false,
        example: 5,
    })
    @IsOptional()
    @IsInt()
    @Type(() => Number)
    visceralFatLevel?: number

    @ApiProperty({
        description: "Taxa de metabolismo basal / repouso (Kcal/dia)",
        required: false,
        example: 1650,
    })
    @IsOptional()
    @IsInt()
    @Type(() => Number)
    restingMetabolismKcal?: number

    @ApiProperty({
        description: "Idade metabólica estimada pelo aparelho de bioimpedância",
        required: false,
        example: 30,
    })
    @IsOptional()
    @IsInt()
    @Type(() => Number)
    metabolicAge?: number

    // --- Circunferências ---
    @ApiProperty({ description: "Circunferência do pescoço (cm)", required: false, example: 38 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    neckCm?: number

    @ApiProperty({ description: "Circunferência do busto/tórax (cm)", required: false, example: 95 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    bustCm?: number

    @ApiProperty({ description: "Circunferência do braço direito (cm)", required: false, example: 30 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    rightArmCm?: number

    @ApiProperty({ description: "Circunferência do braço esquerdo (cm)", required: false, example: 30 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    leftArmCm?: number

    @ApiProperty({ description: "Circunferência da cintura alta (cm)", required: false, example: 80 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    upperWaistCm?: number

    @ApiProperty({
        description: "Circunferência da cintura média / cicatriz umbilical (cm)",
        required: false,
        example: 85,
    })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    midlineWaistCm?: number

    @ApiProperty({ description: "Circunferência da cintura baixa / abdômen (cm)", required: false, example: 88 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    lowerWaistCm?: number

    @ApiProperty({ description: "Espessura da dobra cutânea do estômago (mm)", required: false, example: 15 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    stomachCm?: number

    @ApiProperty({ description: "Circunferência do quadril (cm)", required: false, example: 102 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    hipCm?: number

    @ApiProperty({ description: "Circunferência do glúteo (cm)", required: false, example: 100 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    gluteCm?: number

    @ApiProperty({ description: "Circunferência da coxa direita (cm)", required: false, example: 55 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    rightThighCm?: number

    @ApiProperty({ description: "Circunferência da coxa esquerda (cm)", required: false, example: 54.5 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    leftThighCm?: number

    @ApiProperty({ description: "Circunferência da panturrilha direita (cm)", required: false, example: 38 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    rightCalfCm?: number

    @ApiProperty({ description: "Circunferência da panturrilha esquerda (cm)", required: false, example: 38 })
    @IsOptional()
    @IsNumber()
    @Type(() => Number)
    leftCalfCm?: number

    // --- Hábitos e Preferências ---
    @ApiProperty({
        description: "Alergias, intolerâncias ou aversões alimentares",
        required: false,
        example: "Intolerância leve à lactose",
    })
    @IsOptional()
    @IsString()
    dietaryRestrictions?: string

    @ApiProperty({
        description: "Preferências e gostos alimentares",
        required: false,
        example: "Gosta de massas e doces após almoço",
    })
    @IsOptional()
    @IsString()
    dietaryPreferences?: string

    @ApiProperty({
        description: "Número de refeições realizadas por dia e seu padrão",
        required: false,
        example: "3 a 4 refeições, costuma beliscar à tarde",
    })
    @IsOptional()
    @IsString()
    mealFrequency?: string

    @ApiProperty({
        description: "Horários em que o paciente costuma se alimentar",
        required: false,
        example: "08h, 13h, 20h",
    })
    @IsOptional()
    @IsString()
    mealTimes?: string

    @ApiProperty({ description: "Paciente se considera sedentário?" })
    @IsBoolean()
    @Type(() => Boolean)
    sedentaryHabits: boolean

    @ApiProperty({ description: "O tempo de sono é adequado para descanso?" })
    @IsBoolean()
    @Type(() => Boolean)
    sleepDurationAdequate: boolean

    @ApiProperty({ description: "Paciente já fez dieta antes?" })
    @IsBoolean()
    @Type(() => Boolean)
    hasBeenOnDiet: boolean

    @ApiProperty({ description: "O próprio paciente prepara suas refeições?" })
    @IsBoolean()
    @Type(() => Boolean)
    cooksOwnMeals: boolean

    @ApiProperty({ description: "O funcionamento intestinal do paciente é regular?" })
    @IsBoolean()
    @Type(() => Boolean)
    regularBowelFunction: boolean

    @ApiProperty({ description: "Paciente pratica atividade física atualmente?" })
    @IsBoolean()
    @Type(() => Boolean)
    practicesPhysicalActivity: boolean

    @ApiProperty({ description: "Faz uso de drogas lícitas (álcool, tabaco)?" })
    @IsBoolean()
    @Type(() => Boolean)
    usesLicitDrugs: boolean

    @ApiProperty({ description: "Considera manter uma alimentação balanceada e saudável?" })
    @IsBoolean()
    @Type(() => Boolean)
    balancedDiet: boolean

    @ApiProperty({ description: "Tem o hábito de ingerir líquidos frequentemente ao longo do dia?" })
    @IsBoolean()
    @Type(() => Boolean)
    frequentLiquidIntake: boolean

    @ApiProperty({ description: "A paciente está gestante?" })
    @IsBoolean()
    @Type(() => Boolean)
    isPregnant: boolean

    @ApiProperty({
        description: "Orientações da conduta nutricional passadas na consulta",
        required: false,
        example: "Aumentar ingestão de água para 2.5L. Reduzir carboidratos simples à noite.",
    })
    @IsOptional()
    @IsString()
    nutritionalGuidance?: string
}
