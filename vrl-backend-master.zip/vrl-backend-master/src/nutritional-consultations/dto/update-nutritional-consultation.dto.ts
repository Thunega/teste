import { PartialType } from "@nestjs/swagger"

import { CreateNutritionalConsultationDto } from "./create-nutritional-consultation.dto"

export class UpdateNutritionalConsultationDto extends PartialType(CreateNutritionalConsultationDto) {}
