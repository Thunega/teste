import { ConflictException, Injectable, NotFoundException } from "@nestjs/common"
import { createPaginator, PaginateOptions } from "prisma-pagination"
import { TDocumentDefinitions } from "pdfmake/interfaces"
import * as pdfMake from "pdfmake"

import { CreatePatientWithRelatedDto } from "./dto/create-patient-with-related.dto"
import { Patient, Prisma } from "../generated/prisma/client"
import { messagesHelper } from "../helpers/messages.helper"
import { UpdatePatientDto } from "./dto/update-patient.dto"
import { CreatePatientDto } from "./dto/create-patient.dto"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    query?: string
    cpf?: string
    orderBy?: string
    sort?: string
}

type GetReportOptions = {
    startDate?: Date
    endDate?: Date
}

export type HistoryItem = {
    id: string
    type:
        | "EXAM"
        | "NUTRITIONAL_CONSULTATION"
        | "MEDICAL_CONSULTATION"
        | "PSYCHOLOGICAL_CONSULTATION"
        | "PHYSIOTHERAPY_CONSULTATION"
    date: Date
    responsibleUserName: string | null
}

export interface PaginateOpts {
    page?: number
    perPage?: number
}

// Tipo para a resposta final da função
export interface PaginatedHistoryResponse {
    data: HistoryItem[]
    meta: {
        total: number
        lastPage: number
        currentPage: number
        perPage: number
        prev: number | null
        next: number | null
    }
}

@Injectable()
export class PatientsService {
    constructor(private readonly prisma: PrismaService) {}

    async create(userId: string, createPatientDto: CreatePatientDto) {
        const existingPatient = await this.prisma.patient.findFirst({
            where: {
                OR: [{ cpf: createPatientDto.cpf }, { email: createPatientDto.email }],
            },
            select: {
                id: true,
                cpf: true,
                email: true,
            },
        })

        if (existingPatient) {
            let conflictField: string
            let conflictValue: string

            if (existingPatient.cpf === createPatientDto.cpf) {
                conflictField = "cpf"
                conflictValue = createPatientDto.cpf
            } else {
                conflictField = "email"
                conflictValue = createPatientDto.email as string
            }

            throw new ConflictException(
                messagesHelper.OBJECT_ALREADY_EXISTS({
                    name: "Patient",
                    value: conflictValue,
                    property: conflictField,
                }),
            )
        }

        return await this.prisma.patient.create({
            data: {
                ...createPatientDto,
                owner: {
                    connect: {
                        id: userId,
                    },
                },
            },
        })
    }

    async createWithRelated(userId: string, createPatientDto: CreatePatientWithRelatedDto) {
        const existingPatient = await this.prisma.patient.findFirst({
            where: {
                OR: [{ cpf: createPatientDto.cpf }, { email: createPatientDto.email }],
            },
            select: {
                id: true,
                cpf: true,
                email: true,
            },
        })

        if (existingPatient) {
            let conflictField: string
            let conflictValue: string

            if (existingPatient.cpf === createPatientDto.cpf) {
                conflictField = "cpf"
                conflictValue = createPatientDto.cpf
            } else {
                conflictField = "email"
                conflictValue = createPatientDto.email as string
            }

            throw new ConflictException(
                messagesHelper.OBJECT_ALREADY_EXISTS({
                    name: "Patient",
                    value: conflictValue,
                    property: conflictField,
                }),
            )
        }

        const { clinicalInfo, anamnesis, ...patientData } = createPatientDto

        return await this.prisma.patient.create({
            data: {
                ...patientData,
                owner: {
                    connect: {
                        id: userId,
                    },
                },
                ...(clinicalInfo && {
                    clinicalInfos: {
                        create: clinicalInfo,
                    },
                }),
                ...(anamnesis && {
                    anamnesis: {
                        create: anamnesis,
                    },
                }),
            },
            include: {
                clinicalInfos: true,
                anamnesis: true,
                owner: {
                    omit: {
                        password: true,
                    },
                },
            },
        })
    }

    async findAll({ page, perPage }: PaginateOptions, { query, cpf, orderBy, sort }: SearchOptions) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        const whereClause: any = {}

        if (query) {
            const cleanQuery = query.trim()
            const cpfDigits = cleanQuery.replace(/\D/g, "")

            whereClause.OR = [
                {
                    name: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
                {
                    email: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
            ]

            if (cpfDigits) {
                whereClause.OR.push({
                    cpf: {
                        contains: cpfDigits,
                        mode: "insensitive",
                    },
                })
            }
        }

        if (cpf) {
            const cpfDigits = cpf.replace(/\D/g, "")
            if (cpfDigits) {
                whereClause.cpf = {
                    contains: cpfDigits,
                    mode: "insensitive",
                }
            }
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.name = "asc"
        }

        return await paginate<Patient, Prisma.PatientFindManyArgs>(this.prisma.patient, {
            where: whereClause,
            orderBy: order,
            include: {
                anamnesis: true,
                clinicalInfos: true,
                owner: {
                    omit: {
                        password: true,
                    },
                },
            },
        })
    }

    async getHistory(patientId: string, options: PaginateOpts = {}): Promise<PaginatedHistoryResponse> {
        // 1. Define os valores padrão para a paginação
        const { page = 1, perPage = 10 } = options
        const offset = (page - 1) * perPage

        // 2. Cria uma subquery base com a união de todas as tabelas.
        //    Isso evita repetição de código nas queries de contagem e de dados.
        const historySubQuery = Prisma.sql`
            -- Exames
            SELECT id, 'EXAM' AS type, exam_date AS date, responsible_user_id AS user_id, patient_id FROM "patient_examps"
            UNION ALL
            -- Consultas Nutricionais
            SELECT id, 'NUTRITIONAL_CONSULTATION' AS type, consultation_date AS date, user_id, patient_id FROM "nutritional_consultations"
            UNION ALL
            -- Consultas Médicas
            SELECT id, 'MEDICAL_CONSULTATION' AS type, consultation_date AS date, user_id, patient_id FROM "medical_consultation"
            UNION ALL
            SELECT id, 'PSYCHOLOGICAL_CONSULTATION' AS type, consultation_date AS date, user_id, patient_id FROM "psychological_consultations"
            UNION ALL
            SELECT id, 'PHYSIOTHERAPY_CONSULTATION' AS type, consultation_date AS date, user_id, patient_id FROM "physiotherapy_consultations"
        `

        // 3. Executa a query de contagem e a de busca de dados em uma única transação
        const [totalResult, dataResult] = await this.prisma.$transaction([
            // Query para contar o total de itens
            this.prisma.$queryRaw<{ total: bigint }[]>(
                Prisma.sql`
                    SELECT COUNT(*) as total
                    FROM (${historySubQuery}) as history
                    WHERE history.patient_id = ${patientId}`,
            ),
            // Query para buscar os dados da página atual com o nome do usuário
            this.prisma.$queryRaw<HistoryItem[]>(
                Prisma.sql`
                    SELECT
                        h.id,
                        h.type,
                        h.date,
                        u.name as "responsibleUserName"
                    FROM (${historySubQuery}) AS h
                    LEFT JOIN "users" AS u ON h.user_id = u.id
                    WHERE h.patient_id = ${patientId}
                    ORDER BY h.date DESC
                    LIMIT ${perPage}
                    OFFSET ${offset}`,
            ),
        ])

        // 4. Processa os resultados e calcula os metadados
        const total = Number(totalResult[0]?.total ?? 0)
        const lastPage = total > 0 ? Math.ceil(total / perPage) : 1

        // 5. Constrói e retorna o objeto final
        return {
            data: dataResult,
            meta: {
                total: total,
                lastPage: lastPage,
                currentPage: page,
                perPage: perPage,
                prev: page > 1 ? page - 1 : null,
                next: page < lastPage ? page + 1 : null,
            },
        }
    }

    async findOne(id: string) {
        const patient = await this.prisma.patient.findUnique({
            where: {
                id: id,
            },
        })

        if (!patient) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Patient",
                    value: id,
                }),
            )
        }

        return patient
    }

    async update(id: string, updatePatientDto: UpdatePatientDto) {
        const existingPatient = await this.prisma.patient.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingPatient) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Patient",
                    value: id,
                }),
            )
        }

        return await this.prisma.patient.update({
            where: {
                id: id,
            },
            data: updatePatientDto,
        })
    }

    async remove(id: string) {
        const existingPatient = await this.prisma.patient.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingPatient) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "Patient",
                    value: id,
                }),
            )
        }

        await this.prisma.patient.delete({
            where: {
                id: id,
            },
        })
    }

    async getReport(id: string, { startDate, endDate }: GetReportOptions) {
        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const exams = await this.prisma.patientExam.findMany({
            where: {
                patientId: id,
                createdAt: {
                    lte: startDate,
                    gte: endDate,
                },
            },
        })

        const dailyPerformanceLogs = await this.prisma.dailyPerformanceLog.findMany({
            where: {
                patientId: id,
                createdAt: {
                    lte: startDate,
                    gte: endDate,
                },
            },
        })

        const sleepLogs = await this.prisma.sleepLog.findMany({
            where: {
                patientId: id,
                createdAt: {
                    lte: startDate,
                    gte: endDate,
                },
            },
        })

        const nutritionalConsultations = await this.prisma.nutritionalConsultation.findMany({
            where: {
                patientId: id,
                createdAt: {
                    lte: startDate,
                    gte: endDate,
                },
            },
        })

        const medicalConsultations = await this.prisma.medicalConsultation.findMany({
            where: {
                patientId: id,
                createdAt: {
                    lte: startDate,
                    gte: endDate,
                },
            },
        })

        const psychologicalConsultations = await this.prisma.psychologicalConsultation.findMany({
            where: {
                patientId: id,
                createdAt: {
                    lte: startDate,
                    gte: endDate,
                },
            },
        })

        const physiotherapyConsultations = await this.prisma.physiotherapyConsultation.findMany({
            where: {
                patientId: id,
                createdAt: {
                    lte: startDate,
                    gte: endDate,
                },
            },
        })

        const dailyFoodLogs = await this.prisma.dailyFoodLog.findMany({
            where: {
                patientId: id,
                createdAt: {
                    lte: startDate,
                    gte: endDate,
                },
            },
            include: {
                meals: {
                    include: {
                        foods: true,
                    },
                },
            },
        })

        return {
            exams: exams,
            dailyPerformanceLogs: dailyPerformanceLogs,
            sleepLogs: sleepLogs,
            nutritionalConsultations: nutritionalConsultations,
            medicalConsultations: medicalConsultations,
            psychologicalConsultations: psychologicalConsultations,
            physiotherapyConsultations: physiotherapyConsultations,
            dailyFoodLogs: dailyFoodLogs,
        }
    }

    async exportReport(id: string, options: GetReportOptions): Promise<Buffer> {
        const report = await this.getReport(id, options)
        const patient = await this.findOne(id)

        const fonts = {
            Helvetica: {
                normal: "Helvetica",
                bold: "Helvetica-Bold",
                italics: "Helvetica-Oblique",
                bolditalics: "Helvetica-BoldOblique",
            },
        }

        pdfMake.setFonts(fonts)

        const content: any[] = [
            { text: `Relatório do Paciente`, style: "header" },
            { text: `Nome: ${patient.name}`, style: "subheader" },
            { text: `CPF: ${patient.cpf}`, style: "subheader" },
            { text: `Email: ${patient.email}\n\n`, style: "subheader" },
        ]

        if (report.exams && report.exams.length > 0) {
            content.push({ text: "Exames Cadastrados", style: "sectionHeader" })

            content.push({
                table: {
                    headerRows: 1,
                    widths: ["auto", "*", "*", "*", "*", "*"],
                    body: [
                        [
                            { text: "Data", style: "tableHeader" },
                            { text: "Colesterol Tot.", style: "tableHeader" },
                            { text: "HDL", style: "tableHeader" },
                            { text: "LDL", style: "tableHeader" },
                            { text: "Glicose", style: "tableHeader" },
                            { text: "Triglicérides", style: "tableHeader" },
                        ],
                        ...report.exams.map((e) => [
                            e.examDate || new Date(e.createdAt).toLocaleDateString(),
                            e.totalCholesterol?.toString() || "-",
                            e.hdl?.toString() || "-",
                            e.ldl?.toString() || "-",
                            e.fastingGlucose?.toString() || "-",
                            e.triglycerides?.toString() || "-",
                        ]),
                    ],
                },
                layout: "lightHorizontalLines",
                margin: [0, 5, 0, 15],
            })
        }

        if (report.nutritionalConsultations && report.nutritionalConsultations.length > 0) {
            content.push({ text: "Consultas Nutricionais", style: "sectionHeader" })

            content.push({
                table: {
                    headerRows: 1,
                    widths: ["auto", "*", "auto", "auto", "auto"],
                    body: [
                        [
                            { text: "Data", style: "tableHeader" },
                            { text: "Motivo", style: "tableHeader" },
                            { text: "Peso (kg)", style: "tableHeader" },
                            { text: "Altura (cm)", style: "tableHeader" },
                            { text: "IMC", style: "tableHeader" },
                        ],
                        ...report.nutritionalConsultations.map((c) => [
                            c.consultationDate,
                            c.reason || "-",
                            c.weightKg?.toString() || "-",
                            c.heightCm?.toString() || "-",
                            c.bmi?.toString() || "-",
                        ]),
                    ],
                },
                layout: "lightHorizontalLines",
                margin: [0, 5, 0, 15],
            })
        }

        if (report.medicalConsultations && report.medicalConsultations.length > 0) {
            content.push({ text: "Consultas Médicas", style: "sectionHeader" })

            content.push({
                table: {
                    headerRows: 1,
                    widths: ["auto", "auto", "auto", "auto", "*"],
                    body: [
                        [
                            { text: "Data", style: "tableHeader" },
                            { text: "Peso (kg)", style: "tableHeader" },
                            { text: "Altura (cm)", style: "tableHeader" },
                            { text: "IMC", style: "tableHeader" },
                            { text: "Observações", style: "tableHeader" },
                        ],
                        ...report.medicalConsultations.map((c) => [
                            c.consultationDate,
                            c.weightKg?.toString() || "-",
                            c.heightCm?.toString() || "-",
                            c.bmi?.toString() || "-",
                            c.observations || "-",
                        ]),
                    ],
                },
                layout: "lightHorizontalLines",
                margin: [0, 5, 0, 15],
            })
        }

        if (report.psychologicalConsultations && report.psychologicalConsultations.length > 0) {
            content.push({ text: "Consultas Psicológicas", style: "sectionHeader" })

            content.push({
                table: {
                    headerRows: 1,
                    widths: ["auto", "auto", "auto", "*"],
                    body: [
                        [
                            { text: "Data", style: "tableHeader" },
                            { text: "Nív. Ansiedade", style: "tableHeader" },
                            { text: "Humor", style: "tableHeader" },
                            { text: "Observações", style: "tableHeader" },
                        ],
                        ...report.psychologicalConsultations.map((c) => [
                            c.consultationDate,
                            c.anxietyLevel || "-",
                            c.humor || "-",
                            c.observations || "-",
                        ]),
                    ],
                },
                layout: "lightHorizontalLines",
                margin: [0, 5, 0, 15],
            })
        }

        if (report.physiotherapyConsultations && report.physiotherapyConsultations.length > 0) {
            content.push({ text: "Consultas de Fisioterapia", style: "sectionHeader" })

            const functionalLevelMap: Record<string, string> = {
                INDEPENDENT: "Independente",
                SEMI_INDEPENDENT: "Semi-Independente",
                DEPENDENT: "Dependente",
            }

            content.push({
                table: {
                    headerRows: 1,
                    widths: ["auto", "auto", "auto", "*"],
                    body: [
                        [
                            { text: "Data", style: "tableHeader" },
                            { text: "Nív. Dor", style: "tableHeader" },
                            { text: "Nív. Funcional", style: "tableHeader" },
                            { text: "Queixa Principal", style: "tableHeader" },
                        ],
                        ...report.physiotherapyConsultations.map((c) => [
                            c.consultationDate,
                            c.painLevel?.toString() || "-",
                            functionalLevelMap[c.functionalLevel] || c.functionalLevel || "-",
                            c.mainComplaint || "-",
                        ]),
                    ],
                },
                layout: "lightHorizontalLines",
                margin: [0, 5, 0, 15],
            })
        }

        if (report.dailyPerformanceLogs && report.dailyPerformanceLogs.length > 0) {
            content.push({ text: "Registros de Desempenho Diário", style: "sectionHeader" })

            const sleepQualityMap: Record<string, string> = {
                GOOD: "Boa",
                AVERAGE: "Regular",
                BAD: "Ruim",
            }

            content.push({
                table: {
                    headerRows: 1,
                    widths: ["auto", "auto", "auto", "auto", "auto"],
                    body: [
                        [
                            { text: "Data", style: "tableHeader" },
                            { text: "Pressão Arterial", style: "tableHeader" },
                            { text: "SpO2 (%)", style: "tableHeader" },
                            { text: "BPM", style: "tableHeader" },
                            { text: "Qualid. Sono", style: "tableHeader" },
                        ],
                        ...report.dailyPerformanceLogs.map((l) => [
                            l.dateOfRegistration,
                            l.bloodPressure || "-",
                            l.oxygenSaturation?.toString() || "-",
                            l.beatsPerMinute?.toString() || "-",
                            sleepQualityMap[l.sleepQuality] || l.sleepQuality || "-",
                        ]),
                    ],
                },
                layout: "lightHorizontalLines",
                margin: [0, 5, 0, 15],
            })
        }

        if (report.sleepLogs && report.sleepLogs.length > 0) {
            content.push({ text: "Registros de Sono", style: "sectionHeader" })

            content.push({
                table: {
                    headerRows: 1,
                    widths: ["auto", "auto", "auto", "auto", "auto"],
                    body: [
                        [
                            { text: "Data", style: "tableHeader" },
                            { text: "Tempo (min)", style: "tableHeader" },
                            { text: "Score", style: "tableHeader" },
                            { text: "Sono Leve (min)", style: "tableHeader" },
                            { text: "Sono Prof. (min)", style: "tableHeader" },
                        ],
                        ...report.sleepLogs.map((l) => [
                            l.dateOfRegistration,
                            l.sleepTime?.toString() || "-",
                            l.score?.toString() || "-",
                            l.lightSleep?.toString() || "-",
                            l.deepSleep?.toString() || "-",
                        ]),
                    ],
                },
                layout: "lightHorizontalLines",
                margin: [0, 5, 0, 15],
            })
        }

        if (report.dailyFoodLogs && report.dailyFoodLogs.length > 0) {
            content.push({ text: "Registros de Alimentação", style: "sectionHeader" })

            report.dailyFoodLogs.forEach((log) => {
                content.push({
                    text: `Data do Registro: ${log.dateOfRegistration}`,
                    margin: [0, 10, 0, 5],
                    fontSize: 12,
                    bold: true,
                })

                if (log.meals && log.meals.length > 0) {
                    const mealsBody: any[][] = [
                        [
                            { text: "Horário", style: "tableHeader" },
                            { text: "Descrição", style: "tableHeader" },
                            { text: "Alimentos Consumidos", style: "tableHeader" },
                            { text: "Kcal", style: "tableHeader" },
                            { text: "Carbos (g)", style: "tableHeader" },
                            { text: "Proteínas (g)", style: "tableHeader" },
                        ],
                    ]

                    log.meals.forEach((meal) => {
                        const foodNames =
                            meal.foods && meal.foods.length > 0
                                ? meal.foods.map((f) => `${f.quantity}${f.unit} de ${f.name}`).join("\n")
                                : "Nenhum alimento registrado"
                        const totalCalories = meal.foods.reduce((acc, f) => acc + (f.calories || 0), 0)
                        const totalCarbos = meal.foods.reduce((acc, f) => acc + (f.carbohydrates || 0), 0)
                        const totalProteins = meal.foods.reduce((acc, f) => acc + (f.proteins || 0), 0)

                        mealsBody.push([
                            meal.mealTime,
                            meal.description || "-",
                            foodNames,
                            totalCalories.toFixed(1),
                            totalCarbos.toFixed(1),
                            totalProteins.toFixed(1),
                        ])
                    })

                    content.push({
                        table: {
                            headerRows: 1,
                            widths: ["auto", "*", "*", "auto", "auto", "auto"],
                            body: mealsBody,
                        },
                        layout: "lightHorizontalLines",
                        margin: [0, 5, 0, 15],
                    })
                } else {
                    content.push({
                        text: "Nenhuma refeição detalhada para este dia.",
                        italics: true,
                        margin: [0, 0, 0, 10],
                    })
                }
            })
        }

        content.push({ text: "\n\nGerado automaticamente pelo sistema VR Leão.", italics: true, fontSize: 10 })

        const docDefinition: TDocumentDefinitions = {
            info: {
                title: `Relatório do Paciente - ${patient.name}`,
                author: "VR Leão",
                subject: "Relatório de Atendimentos",
            },
            defaultStyle: {
                font: "Helvetica",
            },
            content: content,
            styles: {
                header: {
                    fontSize: 18,
                    bold: true,
                    margin: [0, 0, 0, 10],
                },
                subheader: {
                    fontSize: 12,
                    margin: [0, 5, 0, 5],
                },
                sectionHeader: {
                    fontSize: 14,
                    bold: true,
                    margin: [0, 15, 0, 5],
                },
                tableHeader: {
                    bold: true,
                    fontSize: 11,
                    color: "black",
                },
            },
        }

        const pdfDoc = pdfMake.createPdf(docDefinition)

        return await pdfDoc.getBuffer()
    }
}
