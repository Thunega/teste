import { Test, TestingModule } from "@nestjs/testing"

import { ClinicalInfosService } from "../clinical-infos/clinical-infos.service"
import { AnamnesesService } from "../anamneses/anamneses.service"
import { PatientsController } from "./patients.controller"
import { PatientsService } from "./patients.service"

describe("PatientsController", () => {
    let controller: PatientsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
        search: jest.fn(),
        createWithRelated: jest.fn(),
        getReport: jest.fn(),
        getHistory: jest.fn(),
    }

    const mockClinicalInfosService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
        findLast: jest.fn(),
    }

    const mockAnamnesesService = {
        create: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [PatientsController],
            providers: [
                { provide: PatientsService, useValue: mockService },
                { provide: ClinicalInfosService, useValue: mockClinicalInfosService },
                { provide: AnamnesesService, useValue: mockAnamnesesService },
            ],
        }).compile()

        controller = module.get<PatientsController>(PatientsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
