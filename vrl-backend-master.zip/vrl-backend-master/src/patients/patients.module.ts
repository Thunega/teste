import { Module } from "@nestjs/common"

import { ClinicalInfosModule } from "../clinical-infos/clinical-infos.module"
import { AnamnesesModule } from "../anamneses/anamneses.module"
import { PatientsController } from "./patients.controller"
import { PrismaModule } from "../prisma/prisma.module"
import { PatientsService } from "./patients.service"

@Module({
    imports: [ClinicalInfosModule, AnamnesesModule, PrismaModule],
    controllers: [PatientsController],
    providers: [PatientsService],
    exports: [PatientsService],
})
export class PatientsModule {}
