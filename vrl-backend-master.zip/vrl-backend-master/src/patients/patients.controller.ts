﻿import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Query, ParseUUIDPipe } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"
import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { UpdateClinicalInfoDto } from "../clinical-infos/dto/update-clinical-info.dto"
import { CreateClinicalInfoDto } from "../clinical-infos/dto/create-clinical-info.dto"
import { CreatePatientWithRelatedDto } from "./dto/create-patient-with-related.dto"
import { ClinicalInfosService } from "../clinical-infos/clinical-infos.service"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { RegexValidationPipe } from "../common/pipes/regex-validation.pipe"
import { UpdateAnamnesisDto } from "../anamneses/dto/update-anamnesis.dto"
import { CreateAnamnesisDto } from "../anamneses/dto/create-anamnesis.dto"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { AnamnesesService } from "../anamneses/anamneses.service"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { UpdatePatientDto } from "./dto/update-patient.dto"
import { CreatePatientDto } from "./dto/create-patient.dto"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"
import { regexHelper } from "../helpers/regex.helper"
import { PatientsService } from "./patients.service"

@Controller("patients")
@ApiStandardErrorResponses({ notFoundName: "Patient" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class PatientsController {
    constructor(
        private readonly patientsService: PatientsService,
        private readonly clinicalInfosService: ClinicalInfosService,
        private readonly anamnesesService: AnamnesesService,
    ) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async create(@Body() createPatientDto: CreatePatientDto, @InjectUser() user: JwtAuthenticatedUser) {
        return await this.patientsService.create(user.id, createPatientDto)
    }

    @Post("with-related")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async createWithRelated(
        @Body() createPatientDto: CreatePatientWithRelatedDto,
        @InjectUser() user: JwtAuthenticatedUser,
    ) {
        return await this.patientsService.createWithRelated(user.id, createPatientDto)
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.patientsService.findOne(id)
    }

    @Get()
    @ApiPaginated()
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "cpf",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("cpf", new RegexValidationPipe(regexHelper.cpf, { optional: true })) cpf?: string,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.patientsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                query: query,
                cpf: cpf,
                orderBy: orderBy,
                sort: sort,
            },
        )
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async update(@Id() id: string, @Body() updatePatientDto: UpdatePatientDto) {
        return await this.patientsService.update(id, updatePatientDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async remove(@Id() id: string) {
        return await this.patientsService.remove(id)
    }

    @Get(":id/anamneses")
    async findAnamneses(@Id() id: string) {
        return await this.anamnesesService.findOne(id)
    }

    @Post(":id/anamneses")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async createAnamneses(@Id() id: string, @Body() createAnamnesesDto: CreateAnamnesisDto) {
        return await this.anamnesesService.create(id, createAnamnesesDto)
    }

    @Patch(":id/anamneses")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async updateAnamneses(@Id() id: string, @Body() updateAnamnesesDto: UpdateAnamnesisDto) {
        return await this.anamnesesService.update(id, updateAnamnesesDto)
    }

    @Get(":id/clinical-info")
    @ApiDateRange()
    async findClinicalInfos(@Id() id: string, @StartDate() startDate?: Date, @EndDate() endDate?: Date) {
        return await this.clinicalInfosService.findAll(id, { startDate: startDate, endDate: endDate })
    }

    @Get(":id/clinical-info/last")
    async findLastClinicalInfo(@Id() id: string) {
        return await this.clinicalInfosService.findLast(id)
    }

    @Post(":id/clinical-info")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async createClinicalInfo(@Id() id: string, @Body() createClinicalInfoDto: CreateClinicalInfoDto) {
        return await this.clinicalInfosService.create(id, createClinicalInfoDto)
    }

    @Patch(":id/clinical-info/:clinicalInfoId")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async updateClinicalInfo(
        @Id() id: string,
        @Param("clinicalInfoId", ParseUUIDPipe) clinicalInfoId: string,
        @Body() updateClinicalInfoDto: UpdateClinicalInfoDto,
    ) {
        return await this.clinicalInfosService.update(clinicalInfoId, id, updateClinicalInfoDto)
    }

    @Delete(":id/clinical-info/:clinicalInfoId")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async removeClinicalInfo(@Id() id: string, @Param("clinicalInfoId", ParseUUIDPipe) clinicalInfoId: string) {
        return await this.clinicalInfosService.remove(clinicalInfoId, id)
    }

    @Get(":id/report")
    @ApiDateRange()
    async getReport(@Id() id: string, @StartDate() startDate?: Date, @EndDate() endDate?: Date) {
        return await this.patientsService.getReport(id, {
            startDate: startDate,
            endDate: endDate,
        })
    }

    @Get(":id/history")
    @ApiPaginated()
    async getHistory(@Id() id: string, @Page() page: number, @PerPage() perPage: number) {
        return await this.patientsService.getHistory(id, {
            page: page,
            perPage: perPage,
        })
    }
}
