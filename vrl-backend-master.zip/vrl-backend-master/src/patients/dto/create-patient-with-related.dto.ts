import { IsOptional, ValidateNested } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"
import { Type } from "class-transformer"

import { CreateClinicalInfoDto } from "../../clinical-infos/dto/create-clinical-info.dto"
import { CreateAnamnesisDto } from "../../anamneses/dto/create-anamnesis.dto"
import { CreatePatientDto } from "./create-patient.dto"

export class CreatePatientWithRelatedDto extends CreatePatientDto {
    @ApiProperty({ required: false, type: CreateClinicalInfoDto })
    @IsOptional()
    @ValidateNested()
    @Type(() => CreateClinicalInfoDto)
    clinicalInfo?: CreateClinicalInfoDto

    @ApiProperty({ required: false, type: CreateAnamnesisDto })
    @IsOptional()
    @ValidateNested()
    @Type(() => CreateAnamnesisDto)
    anamnesis?: CreateAnamnesisDto
}
