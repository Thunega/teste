import {
    IsDateString,
    IsEmail,
    IsEnum,
    IsNotEmpty,
    IsOptional,
    IsPhoneNumber,
    IsString,
    Matches,
} from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

import { BloodType, Gender, PatientStatus } from "../../generated/prisma/client"
import { regexHelper } from "../../helpers/regex.helper"

export class CreatePatientDto {
    @ApiProperty({
        description: "Nome completo do paciente",
        example: "Maria Aparecida Costa",
    })
    @IsString()
    name: string

    @ApiProperty({
        description: "Status do paciente no sistema",
        enum: PatientStatus,
        enumName: "PatientStatus",
        example: PatientStatus.ACTIVE,
        required: false,
    })
    @IsOptional()
    @IsEnum(PatientStatus)
    status?: PatientStatus

    @ApiProperty({
        description: "Tipo sanguíneo do paciente",
        required: false,
        enum: BloodType,
        enumName: "BloodType",
        example: BloodType.A_POSITIVE,
    })
    @IsOptional()
    @IsEnum(BloodType)
    bloodType: BloodType

    @ApiProperty({
        description:
            "Alerta ou restrição de exercícios específica para o paciente (ex: evitar impacto no joelho direito)",
        required: false,
        example: "Evitar exercícios de alto impacto. Restrição: joelho direito com lesão de menisco.",
    })
    @IsOptional()
    @IsString()
    exerciseAlert?: string

    @ApiProperty({
        description: "CPF do paciente (somente números ou formatado com pontos e traço)",
        example: "123.456.789-00",
    })
    @Matches(regexHelper.cpf)
    cpf: string

    @ApiProperty({
        description: "Data de nascimento no formato ISO 8601",
        example: "1985-07-15",
    })
    @IsDateString()
    dateOfBirth: string

    @ApiProperty({
        description: "Sexo biológico do paciente",
        enum: Gender,
        enumName: "Gender",
        example: Gender.FEMALE,
    })
    @IsEnum(Gender)
    gender: Gender

    @ApiProperty({
        description: "Endereço de e-mail do paciente",
        required: false,
        example: "maria.costa@email.com",
    })
    @IsOptional()
    @IsEmail()
    email?: string

    @ApiProperty({
        description: "Número de telefone do paciente no formato internacional",
        example: "+5511999998888",
    })
    @IsPhoneNumber()
    phone: string

    @ApiProperty({
        description: "Endereço residencial completo do paciente",
        required: false,
        example: "Rua das Flores, 123, Apto 45",
    })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    address?: string

    @ApiProperty({
        description: "CEP do endereço do paciente",
        required: false,
        example: "01310-100",
    })
    @IsOptional()
    @Matches(regexHelper.zipCode)
    zipCode?: string

    @ApiProperty({
        description: "Cidade de residência do paciente",
        required: false,
        example: "São Paulo",
    })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    city?: string

    @ApiProperty({
        description: "Estado de residência do paciente (sigla da UF)",
        required: false,
        example: "SP",
    })
    @IsOptional()
    @IsString()
    @IsNotEmpty()
    state?: string

    @ApiProperty({
        description: "Nome e telefone do contato de emergência do paciente",
        required: false,
        example: "José Costa (pai) - +5511988887777",
    })
    @IsOptional()
    @IsString()
    emergencyContact?: string
}
