import { ConflictException, NotFoundException } from "@nestjs/common"
import { Test, TestingModule } from "@nestjs/testing"

import { PrismaService } from "../prisma/prisma.service"
import { PatientsService } from "./patients.service"

describe("PatientsService", () => {
    let service: PatientsService
    let prisma: PrismaService

    const mockPrisma = {
        patient: {
            findUnique: jest.fn(),
            findFirst: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
            count: jest.fn(),
        },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [PatientsService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<PatientsService>(PatientsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a patient", async () => {
            const dto = {
                cpf: "123",
                name: "Patient",
                dateOfBirth: "2000-01-01",
                gender: "MALE" as any,
                phone: "+5511999999999",
                bloodType: "A_POSITIVE" as any,
            }
            mockPrisma.patient.findFirst.mockResolvedValue(null)
            mockPrisma.patient.create.mockResolvedValue({ id: "1", ...dto })

            const result = await service.create("uid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.patient.create).toHaveBeenCalled()
        })

        it("should throw conflict if cpf exists", async () => {
            const dto = {
                cpf: "123",
                name: "Patient",
                dateOfBirth: "2000-01-01",
                gender: "MALE" as any,
                phone: "+5511999999999",
                bloodType: "A_POSITIVE" as any,
            }
            mockPrisma.patient.findFirst.mockResolvedValue({ id: "1", cpf: "123" })

            await expect(service.create("uid", dto as any)).rejects.toThrow(ConflictException)
        })
    })

    describe("findOne", () => {
        it("should return a patient", async () => {
            mockPrisma.patient.findUnique.mockResolvedValue({ id: "1", name: "Patient" })
            const result = await service.findOne("1")
            expect(result).toEqual({ id: "1", name: "Patient" })
        })

        it("should throw not found if not exists", async () => {
            mockPrisma.patient.findUnique.mockResolvedValue(null)
            await expect(service.findOne("1")).rejects.toThrow(NotFoundException)
        })
    })
})
