export const regexHelper = {
    password: /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$ %^&*-]).{8,64}$/,
    cpf: /^\d{11}$/,
    zipCode: /^\d{8}$/,
    bloodPressure: /^\d{2,3}\/\d{2,3}$/,
}
