import { ValidationPipe } from "@nestjs/common"

import { version } from "../../package.json"
import { env } from "./env.helper"

const isProduction = env("NODE_ENV", false) === "production"

export const configHelper = {
    isProduction: isProduction,
    app: {
        port: env("PORT", false) || 3003,
        validationPipe: new ValidationPipe({
            whitelist: true,
            forbidNonWhitelisted: true,
            transform: true,
        }),
        cors: {
            methods: "GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS",
            origin: env("CORS_ORIGIN", false) || true,
            credentials: true,
        },
        meta: {
            name: "VR Leão",
            version: version,
        },
    },
    dashboard: {
        displayData: {
            recentPatientsCount: 5,
            previewDailyAppointmentsCount: 10,
            consecutiveAbsencesThreshold: 3,
        },
    },
    physiotherapyConsultations: {
        minPainLevel: 0,
        maxPainLevel: 10,
    },
    pagination: {
        minPage: 1,
        defaultPage: 1,
        minPerPage: 2,
        defaultPerPage: 20,
        maxPerPage: 50,
        defaultSort: "asc",
    },
}
