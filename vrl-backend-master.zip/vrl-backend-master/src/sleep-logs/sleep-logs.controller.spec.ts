import { Test, TestingModule } from "@nestjs/testing"

import { SleepLogsController } from "./sleep-logs.controller"
import { SleepLogsService } from "./sleep-logs.service"

describe("SleepLogsController", () => {
    let controller: SleepLogsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [SleepLogsController],
            providers: [{ provide: SleepLogsService, useValue: mockService }],
        }).compile()

        controller = module.get<SleepLogsController>(SleepLogsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
