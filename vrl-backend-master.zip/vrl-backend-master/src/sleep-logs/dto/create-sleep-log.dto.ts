import { IsDateString, IsInt, IsNotEmpty, IsOptional, IsString, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateSleepLogDto {
    @ApiProperty({
        description: "Data do registro de sono (formato ISO 8601)",
        example: "2024-08-20",
    })
    @IsDateString()
    dateOfRegistration: string

    @ApiProperty({
        description: "Pontuação geral do sono (geralmente de 1 a 100, conforme dispositivo)",
        example: 82,
    })
    @IsInt()
    score: number

    @ApiProperty({
        description: "Tempo total de sono em minutos",
        example: 420,
    })
    @IsInt()
    sleepTime: number

    @ApiProperty({
        description: "Tempo que o paciente estava deitado antes de dormir (tempo acordado na cama), em minutos",
        example: 15,
    })
    @IsInt()
    agreedTime: number

    @ApiProperty({
        description: "Tempo em fase REM (movimento rápido dos olhos) em minutos",
        example: 90,
    })
    @IsInt()
    remTime: number

    @ApiProperty({
        description: "Tempo em sono leve em minutos",
        example: 200,
    })
    @IsInt()
    lightSleep: number

    @ApiProperty({
        description: "Tempo em sono profundo em minutos",
        example: 130,
    })
    @IsInt()
    deepSleep: number

    @ApiProperty({
        description: "Saturação média de oxigênio durante o sono (%)",
        example: 97,
    })
    @IsNotEmpty()
    avgOxygenSaturation: number

    @ApiProperty({
        description: "Frequência cardíaca média durante o sono (bpm)",
        example: 58,
    })
    @IsInt()
    avgHeartRate: number

    @ApiProperty({
        description: "Observações adicionais sobre o sono do paciente",
        required: false,
        example: "Paciente relatou acordar duas vezes durante a noite.",
    })
    @IsOptional()
    @IsString()
    observations?: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual o registro de sono pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string
}
