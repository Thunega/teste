import { PartialType } from "@nestjs/swagger"

import { CreateSleepLogDto } from "./create-sleep-log.dto"

export class UpdateSleepLogDto extends PartialType(CreateSleepLogDto) {}
