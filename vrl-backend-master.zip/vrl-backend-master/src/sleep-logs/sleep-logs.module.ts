import { forwardRef, Module } from "@nestjs/common"

import { SleepLogsController } from "./sleep-logs.controller"
import { PatientsModule } from "../patients/patients.module"
import { SleepLogsService } from "./sleep-logs.service"
import { PrismaModule } from "../prisma/prisma.module"

@Module({
    imports: [PrismaModule, forwardRef(() => PatientsModule)],
    controllers: [SleepLogsController],
    providers: [SleepLogsService],
    exports: [SleepLogsService],
})
export class SleepLogsModule {}
