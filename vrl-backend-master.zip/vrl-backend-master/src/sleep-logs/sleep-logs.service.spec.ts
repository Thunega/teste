import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PatientsService } from "../patients/patients.service"
import { PrismaService } from "../prisma/prisma.service"
import { SleepLogsService } from "./sleep-logs.service"

describe("SleepLogsService", () => {
    let service: SleepLogsService
    let prisma: PrismaService

    const mockPrisma = {
        sleepLog: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = { findOne: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                SleepLogsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<SleepLogsService>(SleepLogsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a sleep log", async () => {
            const dto = { patientId: "pid", startSleepTime: "22:00", endSleepTime: "06:00" }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.sleepLog.create.mockResolvedValue({ id: "sid", ...dto })

            const result = await service.create(dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.sleepLog.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a log", async () => {
            mockPrisma.sleepLog.findUnique.mockResolvedValue({ id: "sid" })
            const result = await service.findOne("sid")
            expect(result).toEqual({ id: "sid" })
        })

        it("should throw not found", async () => {
            mockPrisma.sleepLog.findUnique.mockResolvedValue(null)
            await expect(service.findOne("sid")).rejects.toThrow(NotFoundException)
        })
    })
})
