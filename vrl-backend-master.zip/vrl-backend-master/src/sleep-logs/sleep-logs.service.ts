import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { PatientsService } from "../patients/patients.service"
import { UpdateSleepLogDto } from "./dto/update-sleep-log.dto"
import { CreateSleepLogDto } from "./dto/create-sleep-log.dto"
import { Prisma, SleepLog } from "../generated/prisma/client"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class SleepLogsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(createSleepLogDto: CreateSleepLogDto) {
        const { patientId, ...rest } = createSleepLogDto

        await this.patientsService.findOne(patientId)

        return await this.prisma.sleepLog.create({
            data: {
                ...rest,

                patient: {
                    connect: {
                        id: patientId,
                    },
                },
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        { startDate, endDate, query, orderBy, sort }: SearchOptions,
        patientId?: string,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const whereClause: Prisma.SleepLogWhereInput = {
            patientId: patientId,
            createdAt: {
                gte: startDate,
                lte: endDate,
            },
        }

        if (query) {
            const cleanQuery = query.trim()

            whereClause.OR = [
                {
                    patient: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
            ]
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.createdAt = "desc"
        }

        return await paginate<SleepLog, Prisma.SleepLogFindManyArgs>(this.prisma.sleepLog, {
            where: whereClause,
            orderBy: order,
            include: {
                patient: patientId ? false : true,
            },
        })
    }

    async findOne(id: string) {
        const sleepLog = await this.prisma.sleepLog.findUnique({
            where: {
                id: id,
            },
        })

        if (!sleepLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "SleepLog",
                    value: id,
                }),
            )
        }

        return sleepLog
    }

    async update(id: string, updateSleepLogDto: UpdateSleepLogDto) {
        const { patientId, ...rest } = updateSleepLogDto

        const existingSleepLog = await this.prisma.sleepLog.findUnique({
            where: {
                id: id,
                patientId: patientId,
            },
            select: {
                id: true,
            },
        })

        if (!existingSleepLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "SleepLog",
                    value: id,
                }),
            )
        }

        return await this.prisma.sleepLog.update({
            where: {
                id: id,
            },
            data: rest,
        })
    }

    async remove(id: string) {
        const existingSleepLog = await this.prisma.sleepLog.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingSleepLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "SleepLog",
                    value: id,
                }),
            )
        }

        await this.prisma.sleepLog.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
