﻿import { Controller, Get, ParseUUIDPipe, Query, UseGuards, Delete, Patch, Body, Post } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { UpdateSleepLogDto } from "./dto/update-sleep-log.dto"
import { CreateSleepLogDto } from "./dto/create-sleep-log.dto"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { SleepLogsService } from "./sleep-logs.service"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("sleep-logs")
@ApiStandardErrorResponses({ notFoundName: "SleepLogs" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class SleepLogsController {
    constructor(private readonly sleepLogsService: SleepLogsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DATA_COLLECTOR)
    async createSleepLog(@Body() createSleepLogDto: CreateSleepLogDto) {
        return await this.sleepLogsService.create(createSleepLogDto)
    }

    @Get(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR, UserRole.DATA_COLLECTOR)
    async findOne(@Id() id: string) {
        return await this.sleepLogsService.findOne(id)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR, UserRole.DATA_COLLECTOR)
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.sleepLogsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
            patientId,
        )
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DATA_COLLECTOR)
    async update(@Id() id: string, @Body() updateSleepLogDto: UpdateSleepLogDto) {
        return await this.sleepLogsService.update(id, updateSleepLogDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DATA_COLLECTOR)
    async remove(@Id() id: string) {
        return await this.sleepLogsService.remove(id)
    }
}
