import { forwardRef, Module } from "@nestjs/common"

import { DailyPerformanceLogsController } from "./daily-performance-logs.controller"
import { DailyPerformanceLogsService } from "./daily-performance-logs.service"
import { PatientsModule } from "../patients/patients.module"
import { PrismaModule } from "../prisma/prisma.module"

@Module({
    imports: [PrismaModule, forwardRef(() => PatientsModule)],
    controllers: [DailyPerformanceLogsController],
    providers: [DailyPerformanceLogsService],
    exports: [DailyPerformanceLogsService],
})
export class DailyPerformanceLogsModule {}
