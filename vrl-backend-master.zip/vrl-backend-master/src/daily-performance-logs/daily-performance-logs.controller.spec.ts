import { Test, TestingModule } from "@nestjs/testing"

import { DailyPerformanceLogsController } from "./daily-performance-logs.controller"
import { DailyPerformanceLogsService } from "./daily-performance-logs.service"

describe("DailyPerformanceLogsController", () => {
    let controller: DailyPerformanceLogsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [DailyPerformanceLogsController],
            providers: [{ provide: DailyPerformanceLogsService, useValue: mockService }],
        }).compile()

        controller = module.get<DailyPerformanceLogsController>(DailyPerformanceLogsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
