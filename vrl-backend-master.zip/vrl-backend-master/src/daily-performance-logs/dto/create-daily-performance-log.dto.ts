import { IsDateString, IsEnum, IsInt, IsOptional, IsString, IsUUID, Matches, ValidateNested } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"
import { Type } from "class-transformer"

import { PhysicalActivityIntensity, SleepQuality } from "../../generated/prisma/client"
import { regexHelper } from "../../helpers/regex.helper"

export class CreatePhysicalActivityDto {
    @ApiProperty({
        description: "Nome da atividade física realizada",
        required: false,
        example: "Caminhada na esteira",
    })
    @IsOptional()
    @IsString()
    name?: string

    @ApiProperty({
        description: "Duração da atividade em minutos",
        required: false,
        example: 45,
    })
    @IsOptional()
    @IsInt()
    duration?: number

    @ApiProperty({
        description: "Intensidade da atividade física realizada",
        enum: PhysicalActivityIntensity,
        enumName: "PhysicalActivityIntensity",
        example: PhysicalActivityIntensity.MODERATE,
    })
    @IsEnum(PhysicalActivityIntensity)
    intensity?: PhysicalActivityIntensity
}

export class CreateDailyPerformanceLogDto {
    @ApiProperty({
        description: "Data do registro de desempenho (formato ISO 8601)",
        example: "2024-08-20",
    })
    @IsDateString()
    dateOfRegistration: string

    @ApiProperty({
        description: "Pressão arterial aferida no formato sistólica/diastólica",
        example: "120/80",
    })
    @Matches(regexHelper.bloodPressure)
    bloodPressure: string

    @ApiProperty({
        description: "Saturação de oxigênio no sangue (%)",
        example: 98,
        minimum: 0,
        maximum: 100,
    })
    @IsInt()
    oxygenSaturation: number

    @ApiProperty({
        description: "Frequência cardíaca em batimentos por minuto (bpm)",
        example: 72,
        minimum: 1,
    })
    @IsInt()
    beatsPerMinute: number

    @ApiProperty({
        description: "Qualidade do sono reportada pelo paciente",
        enum: SleepQuality,
        enumName: "SleepQuality",
        example: SleepQuality.GOOD,
    })
    @IsEnum(SleepQuality)
    sleepQuality: SleepQuality

    @ApiProperty({
        description: "Dados da atividade física realizada no dia (omitir se o paciente faltou ao exercício)",
        required: false,
        type: () => CreatePhysicalActivityDto,
    })
    @IsOptional()
    @ValidateNested()
    @Type(() => CreatePhysicalActivityDto)
    physicalActivity?: CreatePhysicalActivityDto

    @ApiProperty({
        description: "Observações adicionais sobre o desempenho do paciente no dia",
        required: false,
        example: "Paciente relatou leve tontura no início do exercício. Pressão monitorada durante a sessão.",
    })
    @IsOptional()
    @IsString()
    observations?: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual o registro pertence",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string
}
