import { PartialType } from "@nestjs/swagger"

import { CreateDailyPerformanceLogDto } from "./create-daily-performance-log.dto"

export class UpdateDailyPerformanceLogDto extends PartialType(CreateDailyPerformanceLogDto) {}
