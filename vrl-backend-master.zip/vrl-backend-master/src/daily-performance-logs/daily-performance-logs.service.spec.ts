import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { DailyPerformanceLogsService } from "./daily-performance-logs.service"
import { PatientsService } from "../patients/patients.service"
import { PrismaService } from "../prisma/prisma.service"

describe("DailyPerformanceLogsService", () => {
    let service: DailyPerformanceLogsService
    let prisma: PrismaService

    const mockPrisma = {
        dailyPerformanceLog: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = { findOne: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                DailyPerformanceLogsService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<DailyPerformanceLogsService>(DailyPerformanceLogsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a log", async () => {
            const dto = { patientId: "pid", mood: "GOOD" as any }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.dailyPerformanceLog.create.mockResolvedValue({ id: "lid", ...dto })

            const result = await service.create(dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.dailyPerformanceLog.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a log", async () => {
            mockPrisma.dailyPerformanceLog.findUnique.mockResolvedValue({ id: "lid" })
            const result = await service.findOne("lid")
            expect(result).toEqual({ id: "lid" })
        })

        it("should throw not found", async () => {
            mockPrisma.dailyPerformanceLog.findUnique.mockResolvedValue(null)
            await expect(service.findOne("lid")).rejects.toThrow(NotFoundException)
        })
    })
})
