﻿import { Controller, Get, Query, ParseUUIDPipe, Patch, Body, Delete, Post, UseGuards } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { UpdateDailyPerformanceLogDto } from "./dto/update-daily-performance-log.dto"
import { CreateDailyPerformanceLogDto } from "./dto/create-daily-performance-log.dto"
import { DailyPerformanceLogsService } from "./daily-performance-logs.service"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("daily-performance-logs")
@ApiStandardErrorResponses({ notFoundName: "DailyPerformanceLogs" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class DailyPerformanceLogsController {
    constructor(private readonly dailyPerformanceLogsService: DailyPerformanceLogsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR)
    async createDailyPerformanceLog(@Body() createDailyPerformanceLogDto: CreateDailyPerformanceLogDto) {
        return await this.dailyPerformanceLogsService.create(createDailyPerformanceLogDto)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.dailyPerformanceLogsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
            patientId,
        )
    }

    @Get(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async findOne(@Id() id: string) {
        return await this.dailyPerformanceLogsService.findOne(id)
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR)
    async update(@Id() id: string, @Body() updateDailyPerformanceLogDto: UpdateDailyPerformanceLogDto) {
        return await this.dailyPerformanceLogsService.update(id, updateDailyPerformanceLogDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR)
    async remove(@Id() id: string) {
        return await this.dailyPerformanceLogsService.remove(id)
    }
}
