import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateDailyPerformanceLogDto } from "./dto/update-daily-performance-log.dto"
import { CreateDailyPerformanceLogDto } from "./dto/create-daily-performance-log.dto"
import { DailyPerformanceLog, Prisma } from "../generated/prisma/client"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class DailyPerformanceLogsService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(createDailyPerformanceLogDto: CreateDailyPerformanceLogDto) {
        const { patientId, ...rest } = createDailyPerformanceLogDto

        await this.patientsService.findOne(patientId)

        return await this.prisma.dailyPerformanceLog.create({
            data: {
                ...rest,
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
                physicalActivity: {
                    create: createDailyPerformanceLogDto.physicalActivity,
                },
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        { startDate, endDate, query, orderBy, sort }: SearchOptions,
        patientId?: string,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const whereClause: Prisma.DailyPerformanceLogWhereInput = {
            patientId: patientId,
            createdAt: {
                gte: startDate,
                lte: endDate,
            },
        }

        if (query) {
            const cleanQuery = query.trim()

            whereClause.OR = [
                {
                    patient: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
            ]
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.createdAt = "desc"
        }

        return await paginate<DailyPerformanceLog, Prisma.DailyPerformanceLogFindManyArgs>(
            this.prisma.dailyPerformanceLog,
            {
                where: whereClause,
                orderBy: order,
                include: {
                    patient: patientId ? false : true,
                    physicalActivity: true,
                },
            },
        )
    }

    async findOne(id: string) {
        const dailyPerformanceLog = await this.prisma.dailyPerformanceLog.findUnique({
            where: {
                id: id,
            },
            include: {
                patient: true,
                physicalActivity: true,
            },
        })

        if (!dailyPerformanceLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "DailyPerformanceLog",
                    value: id,
                }),
            )
        }

        return dailyPerformanceLog
    }

    async update(id: string, updateDailyPerformanceLogDto: UpdateDailyPerformanceLogDto) {
        const existingDailyPerfomanceLog = await this.prisma.dailyPerformanceLog.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingDailyPerfomanceLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "DailyPerformanceLog",
                    value: id,
                }),
            )
        }

        return await this.prisma.dailyPerformanceLog.update({
            where: {
                id: id,
            },
            data: {
                ...updateDailyPerformanceLogDto,
                physicalActivity: {
                    upsert: {
                        update: { ...updateDailyPerformanceLogDto.physicalActivity },
                        create: { ...updateDailyPerformanceLogDto.physicalActivity },
                    },
                },
            },
        })
    }

    async remove(id: string) {
        const existingDailyPerfomanceLog = await this.prisma.dailyPerformanceLog.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingDailyPerfomanceLog) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "DailyPerformanceLog",
                    value: id,
                }),
            )
        }

        await this.prisma.dailyPerformanceLog.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
