import { Module } from "@nestjs/common"

import { CryptoModule } from "../crypto/crypto.module"
import { PrismaService } from "./prisma.service"

@Module({
    imports: [CryptoModule],
    providers: [PrismaService],
    exports: [PrismaService],
})
export class PrismaModule {}
