import { Injectable, OnModuleInit } from "@nestjs/common"
import { PrismaPg } from "@prisma/adapter-pg"
import { Pool } from "pg"

import { PrismaClient } from "../generated/prisma/client"
import { CryptoService } from "../crypto/crypto.service"
import { env } from "../helpers/env.helper"

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
    constructor(cryptoService: CryptoService) {
        const url = env("DATABASE_URL")

        const pool = new Pool({ connectionString: url })
        const adapter = new PrismaPg(pool)

        super({ adapter: adapter })

        const extended = this.$extends({
            name: "EncryptPatientCPF",
            query: {
                patient: {
                    async create({ args, query }) {
                        if (args.data.cpf) {
                            args.data.cpf = cryptoService.encrypt(args.data.cpf)
                        }

                        const result = await query(args)
                        result.cpf = result.cpf ? cryptoService.decrypt(result.cpf) : undefined

                        return result
                    },
                    async update({ args, query }) {
                        if (args.data.cpf) {
                            args.data.cpf = cryptoService.encrypt(args.data.cpf as string)
                        }

                        const result = await query(args)
                        result.cpf = result.cpf ? cryptoService.decrypt(result.cpf) : undefined

                        return result
                    },
                    async findUnique({ args, query }) {
                        const result = await query(args)

                        if (args.where.cpf) {
                            args.where.cpf = cryptoService.encrypt(args.where.cpf)
                        }

                        if (result?.cpf) {
                            result.cpf = cryptoService.decrypt(result.cpf)
                        }

                        return result
                    },
                    async findUniqueOrThrow({ args, query }) {
                        const result = await query(args)

                        if (result?.cpf) {
                            result.cpf = cryptoService.decrypt(result.cpf)
                        }

                        return result
                    },
                    async findFirst({ args, query }) {
                        const result = await query(args)

                        if (result?.cpf) {
                            result.cpf = cryptoService.decrypt(result.cpf)
                        }

                        return result
                    },
                    async findFirstOrThrow({ args, query }) {
                        const result = await query(args)

                        if (result?.cpf) {
                            result.cpf = cryptoService.decrypt(result.cpf)
                        }

                        return result
                    },
                    async findMany({ args, query }) {
                        if (args.where?.cpf) {
                            args.where.cpf = cryptoService.encrypt(args.where.cpf as string)
                        }

                        const results = await query(args)

                        return results.map((rresult) => ({
                            ...rresult,
                            cpf: rresult.cpf ? cryptoService.decrypt(rresult.cpf) : null,
                        }))
                    },
                },
            },
        })

        Object.assign(this, extended)
    }

    async onModuleInit() {
        await this.$connect()
    }
}
