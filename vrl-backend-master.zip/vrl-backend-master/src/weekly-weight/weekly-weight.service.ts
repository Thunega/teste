import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateWeeklyWeightDto } from "./dto/update-weekly-weight.dto"
import { CreateWeeklyWeightDto } from "./dto/create-weekly-weight.dto"
import { Prisma, WeeklyWeight } from "../generated/prisma/client"
import { PatientsService } from "../patients/patients.service"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
    orderBy?: string
    sort?: string
}

@Injectable()
export class WeeklyWeightService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly patientsService: PatientsService,
    ) {}

    async create(createWeeklyWeightDto: CreateWeeklyWeightDto) {
        const { patientId, ...rest } = createWeeklyWeightDto

        await this.patientsService.findOne(patientId)

        return await this.prisma.weeklyWeight.create({
            data: {
                ...rest,
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        { startDate, endDate, orderBy, sort }: SearchOptions,
        patientId?: string,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        }

        return await paginate<WeeklyWeight, Prisma.WeeklyWeightFindManyArgs>(this.prisma.weeklyWeight, {
            orderBy: Object.keys(order).length > 0 ? order : undefined,
            where: {
                patientId: patientId,
                createdAt: {
                    gte: startDate,
                    lte: endDate,
                },
            },
            include: {
                patient: patientId ? false : true,
            },
        })
    }

    async findOne(id: string) {
        const weeklyWeight = await this.prisma.weeklyWeight.findUnique({
            where: {
                id: id,
            },
            include: {
                patient: true,
            },
        })

        if (!weeklyWeight) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "WeeklyWeight",
                    value: id,
                }),
            )
        }

        return weeklyWeight
    }

    async update(id: string, updateWeeklyWeightDto: UpdateWeeklyWeightDto) {
        const { patientId, ...rest } = updateWeeklyWeightDto

        const existingWeeklyWeight = await this.prisma.weeklyWeight.findUnique({
            where: {
                id: id,
                patientId: patientId,
            },
            select: {
                id: true,
            },
        })

        if (!existingWeeklyWeight) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "WeeklyWeight",
                    value: id,
                }),
            )
        }

        return await this.prisma.weeklyWeight.update({
            where: {
                id: id,
            },
            data: rest,
        })
    }

    async remove(id: string) {
        const existingWeeklyWeight = await this.prisma.weeklyWeight.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingWeeklyWeight) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "WeeklyWeight",
                    value: id,
                }),
            )
        }

        await this.prisma.weeklyWeight.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
