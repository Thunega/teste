import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PatientsService } from "../patients/patients.service"
import { WeeklyWeightService } from "./weekly-weight.service"
import { PrismaService } from "../prisma/prisma.service"

describe("WeeklyWeightService", () => {
    let service: WeeklyWeightService
    let prisma: PrismaService

    const mockPrisma = {
        weeklyWeight: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    const mockPatientsService = { findOne: jest.fn() }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                WeeklyWeightService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: PatientsService, useValue: mockPatientsService },
            ],
        }).compile()

        service = module.get<WeeklyWeightService>(WeeklyWeightService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a weekly weight record", async () => {
            const dto = { patientId: "pid", weight: 70 }
            mockPatientsService.findOne.mockResolvedValue({ id: "pid" })
            mockPrisma.weeklyWeight.create.mockResolvedValue({ id: "wwid", ...dto })

            const result = await service.create(dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.weeklyWeight.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return a record", async () => {
            mockPrisma.weeklyWeight.findUnique.mockResolvedValue({ id: "wwid" })
            const result = await service.findOne("wwid")
            expect(result).toEqual({ id: "wwid" })
        })

        it("should throw not found", async () => {
            mockPrisma.weeklyWeight.findUnique.mockResolvedValue(null)
            await expect(service.findOne("wwid")).rejects.toThrow(NotFoundException)
        })
    })
})
