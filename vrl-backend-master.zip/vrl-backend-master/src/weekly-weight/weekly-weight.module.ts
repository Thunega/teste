import { forwardRef, Module } from "@nestjs/common"

import { WeeklyWeightController } from "./weekly-weight.controller"
import { WeeklyWeightService } from "./weekly-weight.service"
import { PatientsModule } from "../patients/patients.module"
import { PrismaModule } from "../prisma/prisma.module"

@Module({
    imports: [PrismaModule, forwardRef(() => PatientsModule)],
    controllers: [WeeklyWeightController],
    providers: [WeeklyWeightService],
    exports: [WeeklyWeightService],
})
export class WeeklyWeightModule {}
