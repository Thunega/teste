﻿import { Controller, Get, ParseUUIDPipe, Query, UseGuards, Delete, Patch, Body, Post } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { UpdateWeeklyWeightDto } from "./dto/update-weekly-weight.dto"
import { CreateWeeklyWeightDto } from "./dto/create-weekly-weight.dto"
import { StartDate } from "../common/decorators/start-date.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { WeeklyWeightService } from "./weekly-weight.service"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("weekly-weight")
@ApiStandardErrorResponses({ notFoundName: "WeeklyWeight" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class WeeklyWeightController {
    constructor(private readonly weeklyWeightService: WeeklyWeightService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR)
    async createWeeklyWeight(@Body() createWeeklyWeightDto: CreateWeeklyWeightDto) {
        return await this.weeklyWeightService.create(createWeeklyWeightDto)
    }

    @Get(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async findOne(@Id() id: string) {
        return await this.weeklyWeightService.findOne(id)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR, UserRole.DOCTOR)
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
        @Query("orderBy") orderBy?: string,
        @Query("sort") sort?: string,
    ) {
        return await this.weeklyWeightService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
                orderBy: orderBy,
                sort: sort,
            },
            patientId,
        )
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR)
    async update(@Id() id: string, @Body() updateWeeklyWeightDto: UpdateWeeklyWeightDto) {
        return await this.weeklyWeightService.update(id, updateWeeklyWeightDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.EDUCATOR_VR)
    async remove(@Id() id: string) {
        return await this.weeklyWeightService.remove(id)
    }
}
