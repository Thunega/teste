import { Test, TestingModule } from "@nestjs/testing"

import { WeeklyWeightController } from "./weekly-weight.controller"
import { WeeklyWeightService } from "./weekly-weight.service"

describe("WeeklyWeightController", () => {
    let controller: WeeklyWeightController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [WeeklyWeightController],
            providers: [{ provide: WeeklyWeightService, useValue: mockService }],
        }).compile()

        controller = module.get<WeeklyWeightController>(WeeklyWeightController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
