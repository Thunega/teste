import { PartialType } from "@nestjs/swagger"

import { CreateWeeklyWeightDto } from "./create-weekly-weight.dto"

export class UpdateWeeklyWeightDto extends PartialType(CreateWeeklyWeightDto) {}
