import { IsDateString, IsNumber, IsOptional, IsString, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateWeeklyWeightDto {
    @ApiProperty()
    @IsDateString()
    weekStartDate: string

    @ApiProperty()
    @IsNumber()
    weightKg: number

    @ApiProperty({ required: false })
    @IsOptional()
    @IsString()
    observations?: string

    @ApiProperty()
    @IsUUID()
    patientId: string
}
