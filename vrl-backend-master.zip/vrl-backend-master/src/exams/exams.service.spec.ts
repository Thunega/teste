import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PrismaService } from "../prisma/prisma.service"
import { ExamsService } from "./exams.service"

describe("ExamsService", () => {
    let service: ExamsService
    let prisma: PrismaService

    const mockPrisma = {
        patientExam: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
            findMany: jest.fn(),
        },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [ExamsService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<ExamsService>(ExamsService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create an exam", async () => {
            const dto = { patientId: "pid", examDate: "2023-01-01" }
            mockPrisma.patientExam.create.mockResolvedValue({ id: "eid", ...dto })

            const result = await service.create("uid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.patientExam.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return an exam", async () => {
            mockPrisma.patientExam.findUnique.mockResolvedValue({ id: "eid" })
            const result = await service.findOne("eid")
            expect(result).toEqual({ id: "eid" })
        })

        it("should throw not found", async () => {
            mockPrisma.patientExam.findUnique.mockResolvedValue(null)
            await expect(service.findOne("eid")).rejects.toThrow(NotFoundException)
        })
    })
})
