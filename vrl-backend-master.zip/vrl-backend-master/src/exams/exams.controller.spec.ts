import { Test, TestingModule } from "@nestjs/testing"

import { ExamsController } from "./exams.controller"
import { ExamsService } from "./exams.service"

describe("ExamsController", () => {
    let controller: ExamsController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [ExamsController],
            providers: [{ provide: ExamsService, useValue: mockService }],
        }).compile()

        controller = module.get<ExamsController>(ExamsController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
