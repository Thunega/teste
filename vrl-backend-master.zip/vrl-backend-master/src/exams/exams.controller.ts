﻿import { Body, Controller, Delete, Get, ParseUUIDPipe, Patch, Post, Query, UseGuards } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { ApiDateRange } from "../common/decorators/api-date-range.decorator"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { StartDate } from "../common/decorators/start-date.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { EndDate } from "../common/decorators/end-date.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"
import { UpdateExamDto } from "./dto/update-exam.dto"
import { CreateExamDto } from "./dto/create-exam.dto"
import { ExamsService } from "./exams.service"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("exams")
@ApiStandardErrorResponses({ notFoundName: "Exams" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class ExamsController {
    constructor(private readonly examsService: ExamsService) {}

    @Post()
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async createExam(@Body() createExamDto: CreateExamDto, @InjectUser() user: JwtAuthenticatedUser) {
        return await this.examsService.create(user.id, createExamDto)
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.examsService.findOne(id)
    }

    @Get()
    @ApiPaginated()
    @ApiDateRange()
    @ApiQuery({
        name: "patientId",
        required: false,
        type: String,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("patientId", new ParseUUIDPipe({ optional: true })) patientId?: string,
        @StartDate() startDate?: Date,
        @EndDate() endDate?: Date,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.examsService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                startDate: startDate,
                endDate: endDate,
                query: query,
                orderBy: orderBy,
                sort: sort,
            },
            patientId,
        )
    }

    @Patch(":id")
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async updateExam(@Id() id: string, @Body() updateExamDto: UpdateExamDto) {
        return await this.examsService.update(id, updateExamDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN, UserRole.DOCTOR)
    async removeExam(@Id() id: string) {
        return await this.examsService.remove(id)
    }
}
