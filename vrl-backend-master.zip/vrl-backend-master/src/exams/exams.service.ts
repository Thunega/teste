import { createPaginator, PaginateOptions } from "prisma-pagination"
import { Injectable, NotFoundException } from "@nestjs/common"

import { PatientExam, Prisma } from "../generated/prisma/client"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"
import { UpdateExamDto } from "./dto/update-exam.dto"
import { CreateExamDto } from "./dto/create-exam.dto"

type SearchOptions = {
    startDate?: Date
    endDate?: Date
    query?: string
    orderBy?: string
    sort?: string
}

@Injectable()
export class ExamsService {
    constructor(private readonly prisma: PrismaService) {}

    async create(userId: string, createExamDto: CreateExamDto) {
        const { patientId, createdAt, examDate, ...rest } = createExamDto

        const createdAtDate = createdAt ? new Date(createdAt) : undefined

        return await this.prisma.patientExam.create({
            data: {
                ...rest,
                examDate: examDate,
                createdAt: createdAtDate,
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
                responsibleUser: {
                    connect: {
                        id: userId,
                    },
                },
            },
        })
    }

    async findAll(
        { page, perPage }: PaginateOptions,
        { startDate, endDate, query, orderBy, sort }: SearchOptions,
        patientId?: string,
    ) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        if (startDate) {
            startDate.setHours(0, 0, 0, 0)
        }

        if (endDate) {
            endDate.setHours(23, 59, 59, 999)
        }

        const whereClause: Prisma.PatientExamWhereInput = {
            patientId: patientId,
            createdAt: {
                gte: startDate,
                lte: endDate,
            },
        }

        if (query) {
            const cleanQuery = query.trim()
            whereClause.OR = [
                {
                    observations: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
                {
                    patient: {
                        name: {
                            contains: cleanQuery,
                            mode: "insensitive",
                        },
                    },
                },
            ]
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.createdAt = "desc"
        }

        return await paginate<PatientExam, Prisma.PatientExamFindManyArgs>(this.prisma.patientExam, {
            where: whereClause,
            orderBy: order,
            include: {
                patient: true,
                responsibleUser: {
                    select: {
                        id: true,
                        name: true,
                    },
                },
            },
        })
    }

    async findOne(id: string) {
        const exam = await this.prisma.patientExam.findUnique({
            where: {
                id: id,
            },
        })

        if (!exam) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PatientExam",
                    value: id,
                }),
            )
        }

        return exam
    }

    async update(id: string, updateExamDto: UpdateExamDto) {
        const { patientId, ...rest } = updateExamDto

        const existingExam = await this.prisma.patientExam.findUnique({
            where: {
                patientId: patientId,
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingExam) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PatientExam",
                    value: id,
                }),
            )
        }

        return await this.prisma.patientExam.update({
            where: {
                id: id,
                patientId: patientId,
            },
            data: rest,
        })
    }

    async remove(id: string) {
        const existingExam = await this.prisma.patientExam.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingExam) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PatientExam",
                    value: id,
                }),
            )
        }

        await this.prisma.patientExam.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
