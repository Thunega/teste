import { IsDateString, IsNumber, IsOptional, IsString, IsUUID } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

export class CreateExamDto {
    @ApiProperty({
        description: "Data de criação do exame (sobrescreve a data automática se informada)",
        required: false,
        example: "2024-08-10T00:00:00.000Z",
    })
    @IsOptional()
    @IsString()
    createdAt: string

    @ApiProperty({
        description: "Colesterol total (mg/dL)",
        required: false,
        example: 190,
    })
    @IsOptional()
    @IsNumber()
    totalCholesterol?: number

    @ApiProperty({
        description: "HDL - Colesterol bom (mg/dL)",
        required: false,
        example: 55,
    })
    @IsOptional()
    @IsNumber()
    hdl?: number

    @ApiProperty({
        description: "LDL - Colesterol ruim (mg/dL)",
        required: false,
        example: 110,
    })
    @IsOptional()
    @IsNumber()
    ldl?: number

    @ApiProperty({
        description: "Glicose em jejum (mg/dL)",
        required: false,
        example: 95,
    })
    @IsOptional()
    @IsNumber()
    fastingGlucose?: number

    @ApiProperty({
        description: "Triglicerídeos (mg/dL)",
        required: false,
        example: 130,
    })
    @IsOptional()
    @IsNumber()
    triglycerides?: number

    @ApiProperty({
        description: "TGO / SGOT - Aspartato aminotransferase (U/L)",
        required: false,
        example: 28,
    })
    @IsOptional()
    @IsNumber()
    sgot?: number

    @ApiProperty({
        description: "TGP / SGPT - Alanina aminotransferase (U/L)",
        required: false,
        example: 32,
    })
    @IsOptional()
    @IsNumber()
    sgpt?: number

    @ApiProperty({
        description: "Creatinina sérica (mg/dL)",
        required: false,
        example: 0.9,
    })
    @IsOptional()
    @IsNumber()
    creatinine?: number

    @ApiProperty({
        description: "T4 livre - Tiroxina livre (ng/dL)",
        required: false,
        example: 1.2,
    })
    @IsOptional()
    @IsNumber()
    t4?: number

    @ApiProperty({
        description: "TSH - Hormônio estimulante da tireoide (μUI/mL)",
        required: false,
        example: 2.5,
    })
    @IsOptional()
    @IsNumber()
    tsh?: number

    @ApiProperty({
        description: "Outros exames não listados acima (texto livre)",
        required: false,
        example: "Hemograma completo: normal",
    })
    @IsOptional()
    @IsString()
    others?: string

    @ApiProperty({
        description: "Observações gerais do responsável sobre os exames",
        required: false,
        example: "Colesterol levemente elevado. Orientado sobre dieta.",
    })
    @IsOptional()
    @IsString()
    observations?: string

    @ApiProperty({
        description: "Hemoglobina glicada / HbA1c (%)",
        required: false,
        example: 5.8,
    })
    @IsOptional()
    @IsNumber()
    hemoglobinaGlicada?: number

    @ApiProperty({
        description: "Vitamina D 25-OH (ng/mL)",
        required: false,
        example: 38,
    })
    @IsOptional()
    @IsNumber()
    vitaminaD_25_OH?: number

    @ApiProperty({
        description: "Potássio sérico (mEq/L)",
        required: false,
        example: 4.2,
    })
    @IsOptional()
    @IsNumber()
    potassio?: number

    @ApiProperty({
        description: "Microalbuminúria (mg/g Cr)",
        required: false,
        example: 15,
    })
    @IsOptional()
    @IsNumber()
    microalbuminuria?: number

    @ApiProperty({
        description: "Vitamina B12 (pg/mL)",
        required: false,
        example: 380,
    })
    @IsOptional()
    @IsNumber()
    vitaminaB12?: number

    @ApiProperty({
        description: "Ácido úrico sérico (mg/dL)",
        required: false,
        example: 5.5,
    })
    @IsOptional()
    @IsNumber()
    acidoUrico?: number

    @ApiProperty({
        description: "Data da coleta/realização do exame (formato ISO 8601)",
        required: false,
        example: "2024-08-05",
    })
    @IsOptional()
    @IsDateString()
    examDate?: string

    @ApiProperty({
        description: "ID (UUID) do paciente ao qual os exames pertencem",
        example: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    })
    @IsUUID()
    patientId: string
}
