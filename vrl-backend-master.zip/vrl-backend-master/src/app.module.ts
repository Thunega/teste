import { ConfigModule } from "@nestjs/config"
import { Module } from "@nestjs/common"

import { PsychologicalConsultationsModule } from "./psychological-consultations/psychological-consultations.module"
import { PhysiotherapyConsultationsModule } from "./physiotherapy-consultations/physiotherapy-consultations.module"
import { NutritionalConsultationsModule } from "./nutritional-consultations/nutritional-consultations.module"
import { DailyPerformanceLogsModule } from "./daily-performance-logs/daily-performance-logs.module"
import { MedicalConsultationsModule } from "./medical-consultations/medical-consultations.module"
import { DailyFoodLogsModule } from "./daily-food-logs/daily-food-logs.module"
import { ClinicalInfosModule } from "./clinical-infos/clinical-infos.module"
import { WeeklyWeightModule } from "./weekly-weight/weekly-weight.module"
import { AppointmentsModule } from "./appointments/appointments.module"
import { MedicationsModule } from "./medications/medications.module"
import { ForwardingsModule } from "./forwardings/forwardings.module"
import { SleepLogsModule } from "./sleep-logs/sleep-logs.module"
import { RemindersModule } from "./reminders/reminders.module"
import { DashboardModule } from "./dashboard/dashboard.module"
import { AnamnesesModule } from "./anamneses/anamneses.module"
import { SessionsModule } from "./sessions/sessions.module"
import { PatientsModule } from "./patients/patients.module"
import { MessagesModule } from "./messages/messages.module"
import { PrismaModule } from "./prisma/prisma.module"
import { FitbitModule } from "./fitbit/fitbit.module"
import { UsersModule } from "./users/users.module"
import { ExamsModule } from "./exams/exams.module"
import { AuthModule } from "./auth/auth.module"

@Module({
    imports: [
        ConfigModule.forRoot({ isGlobal: true }),
        AuthModule,
        UsersModule,
        PatientsModule,
        ClinicalInfosModule,
        AnamnesesModule,
        ExamsModule,
        ForwardingsModule,
        AppointmentsModule,
        RemindersModule,
        PrismaModule,
        DailyPerformanceLogsModule,
        DailyFoodLogsModule,
        SleepLogsModule,
        NutritionalConsultationsModule,
        PsychologicalConsultationsModule,
        MedicalConsultationsModule,
        DashboardModule,
        PhysiotherapyConsultationsModule,
        FitbitModule,
        SessionsModule,
        WeeklyWeightModule,
        MedicationsModule,
        MessagesModule,
    ],
})
export class AppModule {}
