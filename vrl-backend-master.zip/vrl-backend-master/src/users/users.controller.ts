﻿import { Controller, Get, Post, Body, Patch, Delete, UseGuards, Query } from "@nestjs/common"
import { ApiQuery } from "@nestjs/swagger"

import { JwtAuthenticatedUser } from "../auth/interfaces/jwt-authenticated-request.interface"
import { OwnershipGuardFactory } from "../common/factories/ownership-guard.factory"
import { ApiPaginated } from "../common/decorators/api-paginated.decorator"
import { QuerySearch } from "../common/decorators/query-search.decorator"
import { InjectUser } from "../auth/decorators/inject-user.decorator"
import { PerPage } from "../common/decorators/per-page.decorator"
import { OrderBy } from "../common/decorators/order-by.decorator"
import { JwtAuthGuard } from "../auth/guards/jwt-auth.guard"
import { Sort } from "../common/decorators/sort.decorator"
import { Page } from "../common/decorators/page.decorator"
import { Roles } from "../auth/decorators/roles.decorator"
import { RolesGuard } from "../auth/guards/roles.guard"
import { Id } from "../common/decorators/id.decorator"
import { UserRole } from "../generated/prisma/client"
import { UpdateUserDto } from "./dto/update-user.dto"
import { CreateUserDto } from "./dto/create-user.dto"
import { UsersService } from "./users.service"

import { ApiStandardErrorResponses } from "../common/decorators/api-standard-error-responses.decorator"

@Controller("users")
@ApiStandardErrorResponses({ notFoundName: "Users" })
@UseGuards(JwtAuthGuard, RolesGuard)
export class UsersController {
    constructor(private readonly usersService: UsersService) {}
    @Post()
    @Roles(UserRole.ADMIN)
    async create(@Body() createUserDto: CreateUserDto) {
        return await this.usersService.create(createUserDto)
    }

    @Get()
    @ApiPaginated()
    @ApiQuery({
        name: "query",
        required: false,
        type: String,
    })
    @ApiQuery({
        name: "role",
        required: false,
        enum: UserRole,
    })
    async findAll(
        @Page() page: number,
        @PerPage() perPage: number,
        @QuerySearch() query?: string,
        @Query("role") role?: UserRole,
        @OrderBy() orderBy?: string,
        @Sort() sort?: string,
    ) {
        return await this.usersService.findAll(
            {
                page: page,
                perPage: perPage,
            },
            {
                query: query,
                role: role,
                orderBy: orderBy,
                sort: sort,
            },
        )
    }

    @Get(":id")
    async findOne(@Id() id: string) {
        return await this.usersService.findOne(id)
    }

    @Patch(":id")
    @UseGuards(OwnershipGuardFactory("id"))
    async update(@Id() id: string, @Body() updateUserDto: UpdateUserDto) {
        return await this.usersService.update(id, updateUserDto)
    }

    @Delete(":id")
    @Roles(UserRole.ADMIN)
    async remove(@Id() id: string, @InjectUser() user: JwtAuthenticatedUser) {
        return await this.usersService.remove(user.id, id)
    }
}
