import { ConflictException, BadRequestException, UnauthorizedException } from "@nestjs/common"
import { Test, TestingModule } from "@nestjs/testing"

import { PrismaService } from "../prisma/prisma.service"
import { CryptoService } from "../crypto/crypto.service"
import { UsersService } from "./users.service"

describe("UsersService", () => {
    let service: UsersService
    let prisma: PrismaService
    let crypto: CryptoService

    const mockPrisma = {
        user: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            delete: jest.fn(),
        },
    }

    const mockCrypto = {
        hashPassword: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                UsersService,
                { provide: PrismaService, useValue: mockPrisma },
                { provide: CryptoService, useValue: mockCrypto },
            ],
        }).compile()

        service = module.get<UsersService>(UsersService)
        prisma = module.get<PrismaService>(PrismaService)
        crypto = module.get<CryptoService>(CryptoService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create a user", async () => {
            const dto = { email: "test@test.com", password: "123", name: "Test", role: "ADMIN" as any }
            mockPrisma.user.findUnique.mockResolvedValue(null)
            mockCrypto.hashPassword.mockResolvedValue("hashed")
            mockPrisma.user.create.mockResolvedValue({ id: "1", ...dto, password: "hashed" })

            const result = await service.create(dto)

            expect(result).toBeDefined()
            expect(mockPrisma.user.create).toHaveBeenCalled()
        })

        it("should throw conflict exception if user exists", async () => {
            const dto = { email: "test@test.com", password: "123", name: "Test", role: "ADMIN" as any }
            mockPrisma.user.findUnique.mockResolvedValue({ id: "1" })

            await expect(service.create(dto)).rejects.toThrow(ConflictException)
        })
    })

    describe("findOne", () => {
        it("should return a user", async () => {
            mockPrisma.user.findUnique.mockResolvedValue({ id: "1", name: "Test" })
            const result = await service.findOne("1")
            expect(result).toEqual({ id: "1", name: "Test" })
        })

        it("should throw bad request if not found", async () => {
            mockPrisma.user.findUnique.mockResolvedValue(null)
            await expect(service.findOne("1")).rejects.toThrow(BadRequestException)
        })
    })

    describe("remove", () => {
        it("should remove user", async () => {
            mockPrisma.user.findUnique.mockResolvedValue({ id: "2" })
            await service.remove("1", "2")
            expect(mockPrisma.user.delete).toHaveBeenCalled()
        })

        it("should throw unauthorized if self delete", async () => {
            await expect(service.remove("1", "1")).rejects.toThrow(UnauthorizedException)
        })
    })
})
