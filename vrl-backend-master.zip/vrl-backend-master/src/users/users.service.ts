import { BadRequestException, ConflictException, Injectable, UnauthorizedException } from "@nestjs/common"
import { createPaginator, PaginateOptions } from "prisma-pagination"

import { Prisma, User, UserRole } from "../generated/prisma/client"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"
import { CryptoService } from "../crypto/crypto.service"
import { UpdateUserDto } from "./dto/update-user.dto"
import { CreateUserDto } from "./dto/create-user.dto"

type SearchOptions = {
    query?: string
    role?: UserRole
    orderBy?: string
    sort?: string
}

@Injectable()
export class UsersService {
    constructor(
        private readonly prisma: PrismaService,
        private readonly cryptoService: CryptoService,
    ) {}

    async create(createUserDto: CreateUserDto) {
        const existingUser = await this.prisma.user.findUnique({
            where: {
                email: createUserDto.email,
            },
            select: {
                id: true,
            },
        })

        if (existingUser) {
            throw new ConflictException(
                messagesHelper.OBJECT_ALREADY_EXISTS({
                    name: "User",
                    property: "email",
                    value: createUserDto.email,
                }),
            )
        }

        const { password, ...rest } = createUserDto

        const hashPassword = await this.cryptoService.hashPassword(password)

        return await this.prisma.user.create({
            data: {
                ...rest,
                password: hashPassword,
            },
            omit: {
                password: true,
            },
        })
    }

    async findAll({ page, perPage }: PaginateOptions, { query, role, orderBy, sort }: SearchOptions) {
        const paginate = createPaginator({
            page: page,
            perPage: perPage,
        })

        const whereClause: any = {}

        if (query) {
            const cleanQuery = query.trim()
            whereClause.OR = [
                {
                    name: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
                {
                    email: {
                        contains: cleanQuery,
                        mode: "insensitive",
                    },
                },
            ]
        }

        if (role) {
            whereClause.role = role
        }

        const order: any = {}

        if (orderBy) {
            order[orderBy] = sort || "asc"
        } else {
            order.name = "asc"
        }

        return await paginate<User, Prisma.UserFindManyArgs>(this.prisma.user, {
            where: whereClause,
            orderBy: order,
            omit: {
                password: true,
            },
        })
    }

    async findOne(id: string) {
        const user = await this.prisma.user.findUnique({
            where: {
                id: id,
            },
            omit: {
                password: true,
            },
        })

        if (!user) {
            throw new BadRequestException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "User",
                    value: id,
                }),
            )
        }

        return user
    }

    async findOneByEmail(email: string) {
        const user = await this.prisma.user.findUnique({
            where: {
                email: email,
            },
        })

        if (!user) {
            throw new BadRequestException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "User",
                    value: email,
                }),
            )
        }

        return user
    }

    async update(id: string, updateUserDto: UpdateUserDto) {
        const existingUser = await this.prisma.user.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingUser) {
            throw new BadRequestException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "User",
                    value: id,
                }),
            )
        }

        if (updateUserDto?.password) {
            const { password, ...rest } = updateUserDto
            const hashPassword = await this.cryptoService.hashPassword(password)

            return await this.prisma.user.update({
                where: {
                    id: id,
                },
                data: { ...rest, password: hashPassword },
                omit: { password: true },
            })
        }

        const user = await this.prisma.user.update({
            where: {
                id: id,
            },
            data: updateUserDto,
            omit: { password: true },
        })

        return user
    }

    async remove(userId: string, id: string) {
        if (userId === id) {
            throw new UnauthorizedException(messagesHelper.CANNOT_DELETE_SELF)
        }

        const existingUser = await this.prisma.user.findUnique({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })

        if (!existingUser) {
            throw new BadRequestException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "User",
                    value: id,
                }),
            )
        }

        await this.prisma.user.delete({
            where: {
                id: id,
            },
            select: {
                id: true,
            },
        })
    }
}
