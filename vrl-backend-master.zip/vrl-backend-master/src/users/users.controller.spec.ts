﻿import { Test, TestingModule } from "@nestjs/testing"

import { UsersController } from "./users.controller"
import { UsersService } from "./users.service"

describe("UsersController", () => {
    let controller: UsersController

    const mockService = {
        create: jest.fn(),
        findAll: jest.fn(),
        findOne: jest.fn(),
        update: jest.fn(),
        remove: jest.fn(),
        getInjectUser: jest.fn(),
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            controllers: [UsersController],
            providers: [
                { provide: UsersService, useValue: mockService },
                { provide: "RESOURCE_SERVICE", useValue: mockService },
            ],
        }).compile()

        controller = module.get<UsersController>(UsersController)
    })

    it("should be defined", () => {
        expect(controller).toBeDefined()
    })
})
