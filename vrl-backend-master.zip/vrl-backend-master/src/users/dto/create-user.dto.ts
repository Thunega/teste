import { IsEmail, IsEnum, IsNotEmpty, IsString, Matches } from "class-validator"
import { ApiProperty } from "@nestjs/swagger"

import { UserRole } from "../../generated/prisma/client"
import { regexHelper } from "../../helpers/regex.helper"

export class CreateUserDto {
    @ApiProperty({
        description: "Nome completo do usuário",
        example: "Dr. João da Silva",
    })
    @IsString()
    @IsNotEmpty()
    name: string

    @ApiProperty({
        description: "Endereço de e-mail do usuário (deve ser único no sistema)",
        example: "joao.silva@vrleao.com.br",
    })
    @IsEmail()
    email: string

    @ApiProperty({
        description: "Função/papel do usuário no sistema",
        enum: UserRole,
        enumName: "UserRole",
        example: UserRole.DOCTOR,
    })
    @IsEnum(UserRole)
    role: UserRole

    @ApiProperty({
        description:
            "Senha do usuário. Deve conter ao menos 8 caracteres, uma letra maiúscula, uma minúscula, um número e um caractere especial",
        example: "Senha@2024",
    })
    @Matches(regexHelper.password)
    password: string
}
