import { Injectable, NotFoundException } from "@nestjs/common"

import { UpdateAnamnesisDto } from "./dto/update-anamnesis.dto"
import { CreateAnamnesisDto } from "./dto/create-anamnesis.dto"
import { messagesHelper } from "../helpers/messages.helper"
import { PrismaService } from "../prisma/prisma.service"

@Injectable()
export class AnamnesesService {
    constructor(private readonly prisma: PrismaService) {}

    async create(patientId: string, createAnamnesisDto: CreateAnamnesisDto) {
        return await this.prisma.patientAnamnesis.create({
            data: {
                ...createAnamnesisDto,
                patient: {
                    connect: {
                        id: patientId,
                    },
                },
            },
        })
    }

    async findOne(patientId: string) {
        const anamnesis = await this.prisma.patientAnamnesis.findUnique({
            where: {
                patientId: patientId,
            },
        })

        if (!anamnesis) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PatientAnamnesis",
                    property: "patientId",
                    value: patientId,
                }),
            )
        }

        return anamnesis
    }

    async update(patientId: string, updateAnamnesisDto: UpdateAnamnesisDto) {
        const existingAnamnesis = await this.prisma.patientAnamnesis.findUnique({
            where: {
                patientId: patientId,
            },
            select: {
                id: true,
            },
        })

        if (!existingAnamnesis) {
            throw new NotFoundException(
                messagesHelper.OBJECT_NOT_FOUND({
                    name: "PatientAnamnesis",
                    property: "patientId",
                    value: patientId,
                }),
            )
        }

        return await this.prisma.patientAnamnesis.update({
            where: {
                patientId: patientId,
            },
            data: updateAnamnesisDto,
        })
    }
}
