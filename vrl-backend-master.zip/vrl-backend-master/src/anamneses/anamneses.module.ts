import { Module } from "@nestjs/common"

import { PrismaModule } from "../prisma/prisma.module"
import { AnamnesesService } from "./anamneses.service"

@Module({
    imports: [PrismaModule],
    providers: [AnamnesesService],
    exports: [AnamnesesService],
})
export class AnamnesesModule {}
