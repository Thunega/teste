import { Test, TestingModule } from "@nestjs/testing"
import { NotFoundException } from "@nestjs/common"

import { PrismaService } from "../prisma/prisma.service"
import { AnamnesesService } from "./anamneses.service"

describe("AnamnesesService", () => {
    let service: AnamnesesService
    let prisma: PrismaService

    const mockPrisma = {
        patientAnamnesis: {
            findUnique: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
        },
    }

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [AnamnesesService, { provide: PrismaService, useValue: mockPrisma }],
        }).compile()

        service = module.get<AnamnesesService>(AnamnesesService)
        prisma = module.get<PrismaService>(PrismaService)
    })

    afterEach(() => {
        jest.clearAllMocks()
    })

    it("should be defined", () => {
        expect(service).toBeDefined()
    })

    describe("create", () => {
        it("should create an anamnesis", async () => {
            const dto = { mainComplaint: "pain" }
            mockPrisma.patientAnamnesis.create.mockResolvedValue({ id: "1", ...dto })

            const result = await service.create("pid", dto as any)

            expect(result).toBeDefined()
            expect(mockPrisma.patientAnamnesis.create).toHaveBeenCalled()
        })
    })

    describe("findOne", () => {
        it("should return an anamnesis", async () => {
            mockPrisma.patientAnamnesis.findUnique.mockResolvedValue({ id: "1" })
            const result = await service.findOne("pid")
            expect(result).toEqual({ id: "1" })
        })

        it("should throw not found", async () => {
            mockPrisma.patientAnamnesis.findUnique.mockResolvedValue(null)
            await expect(service.findOne("pid")).rejects.toThrow(NotFoundException)
        })
    })
})
