# Guia de Migração: Novo Sistema de Medicamentos

Este documento explica as mudanças realizadas no sistema de medicamentos, como migrar a integração antiga servida por outras tabelas e como implementar a nova estrutura no frontend.

## 1. O que mudou?

### Implementação Anterior
*   Os medicamentos eram campos de texto (strings) ou listas internas dentro de `MedicalConsultation`, `PhysiotherapyConsultation` e `PatientClinicalInfo`.
*   Quando o remédio deixava de ser usado, o registro era simplesmente apagado ou sobrescrito.
*   Não havia um histórico de alterações (mudança de dose, horários, etc).

### Nova Implementação
*   **Entidade Própria**: Medicamentos agora têm sua própria tabela (`medications`) e são vinculados diretamente ao **Paciente**.
*   **Controle de Status**: Uso do campo `status` (`ACTIVE`/`INACTIVE`). Medicamentos não são mais deletados.
*   **Histórico de Alterações**: Toda mudança gera uma entrada na tabela `medication_history`, permitindo rastrear a evolução do tratamento.
*   **Centralização**: O gerenciamento é feito exclusivamente pelo `MedicationsModule`.

---

## 2. Como Migrar (Backend e Dados)

### Limpeza de Tabelas Antigas
Os campos `medicationsInUse` foram removidos das seguintes entidades:
*   `MedicalConsultation`
*   `PhysiotherapyConsultation`
*   `PatientClinicalInfo`

### Fluxo de Criação
Para migrar dados existentes ou criar novos:
1.  Identifique o `patientId`.
2.  Use o endpoint `POST /medications` para registrar cada medicamento individualmente.
3.  O sistema criará automaticamente o primeiro registro de histórico.

---

## 3. Integração no Frontend

### Chamadas de API
Substitua as chamadas que enviavam medicamentos dentro do objeto de consulta pelas novas rotas:

#### Listar Medicamentos do Paciente
`GET /medications/patient/{patientId}`
*Use para exibir a lista de remédios atuais e o histórico na ficha do paciente.*

#### Adicionar Novo Medicamento
`POST /medications`
```json
{
  "name": "Nome do Remédio",
  "dosage": "500mg",
  "timetables": "8h em 8h",
  "duration": "7 dias",
  "patientId": "UUID-DO-PACIENTE"
}
```

#### Atualizar Dosagem ou Prescrição
`PATCH /medications/{id}`
*Ao mudar dosagem, horários ou duração, o backend criará automaticamente uma entrada no histórico.*

#### Interromper Uso (Desativar)
`PATCH /medications/{id}/status`
```json
{
  "status": "INACTIVE",
  "discontinuedReason": "Efeito colateral",
  "observations": "Paciente relatou tontura; substituído por X."
}
```

---

## 4. Diferenças na Interface (UX)

| Recurso | Antigo | Novo |
| :--- | :--- | :--- |
| **Persistência** | Dados sumiam se apagados. | Dados são mantidos como `INACTIVE`. |
| **Linha do Tempo** | Apenas o estado atual era visível. | Possível ver todas as mudanças de dose no histórico. |
| **Motivação** | Não se sabia por que parou de usar. | Campo obrigatório para motivo da interrupção. |
| **Escopo** | Preso a uma consulta específica. | Visível em todo o prontuário do paciente. |

## 5. Próximos Passos
1.  **Refatorar Modais de Consulta**: Remova os inputs de medicamentos dos formulários de consultas médicas e fisioterapêuticas.
2.  **Nova Aba de Medicamentos**: Crie uma seção dedicada no perfil do paciente para gerenciar a farmácia pessoal.
3.  **Visualizador de Histórico**: Implementar um componente de "Timeline" para exibir os registros de `medication_history`.

---

## Apêndice: Flexibilidade na Data de Interrupção

Recentemente, adicionamos a possibilidade de definir manualmente a data em que o medicamento foi interrompido. Isso é útil para registros retroativos ou agendamento de término.

### Mudanças nos DTOs

Agora, o campo `discontinuedAt` (opcional) está disponível tanto na criação quanto na atualização de status:

#### No POST `/medications` (Criação)
Se você estiver migrando um dado que já foi interrompido no passado, pode enviar a data diretamente:
```json
{
  "name": "Nome",
  "dosage": "10mg",
  "patientId": "...",
  "status": "INACTIVE",
  "discontinuedAt": "2024-03-01T10:00:00Z"
}
```

#### No PATCH `/medications/{id}/status` (Atualização)
Ao desativar um medicamento, se o campo `discontinuedAt` não for enviado, o sistema assumirá a data e hora **atuais**. Caso queira especificar uma data diferente:
```json
{
  "status": "INACTIVE",
  "discontinuedReason": "Conclusão do ciclo",
  "discontinuedAt": "2024-03-05T08:00:00Z"
}
```

> [!TIP]
> Use o formato ISO 8601 para as datas. Se o medicamento for reativado (`status: "ACTIVE"`), o campo `discontinuedAt` será automaticamente resetado para `null` no banco de dados.
