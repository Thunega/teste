import { defineConfig } from "@prisma/config"
import * as path from "node:path"

import { env } from "./src/helpers/env.helper"

export default defineConfig({
    schema: path.join("prisma", "schema.prisma"),
    datasource: {
        url: env("DATABASE_URL")
    },
    migrations: {
        seed: "ts-node ./prisma/seed.ts",
        path: path.join("prisma", "migrations"),
    },
})