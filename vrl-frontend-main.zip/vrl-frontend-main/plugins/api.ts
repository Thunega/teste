export default defineNuxtPlugin((nuxtApp) => {
    const authStore = useAuthStore()
    let token = authStore.token
    if(!token) {
        token = localStorage.getItem('token')
    }

    const api = $fetch.create({
        baseURL: useRuntimeConfig().public.apiBaseUrl,
        onRequest({request, options, error}) {
            options.headers.set('Authorization', `Bearer ${token}`)

        },
        async onResponseError({response}) {
            if (response.status === 401) {
                await nuxtApp.runWithContext(() => navigateTo('/login'))
            }
        }
    })

    return {
        provide: {
            api
        }
    }
})
