﻿export interface UserSummary {
  id: string
  name: string
  email?: string
  role?: string
}

export interface PatientSummary {
  id: string
  name: string
  cpf?: string
}

export interface Message {
  id: string
  subject: string
  body: string
  isRead: boolean
  sender: UserSummary
  receiver: UserSummary
  patient?: PatientSummary
  createdAt: string
}

export interface PaginationMeta {
  total: number
  page: number
  perPage: number
  lastPage?: number
}

export interface ListResponse<T> {
  data: T[]
  meta: PaginationMeta
}

export interface MessageQueryParams {
  page?: number
  perPage?: number
  isRead?: boolean
  query?: string
}

export interface CreateMessageInput {
  subject: string
  body: string
  receiverId: string
  patientId?: string | null
}

export interface UpdateMessageInput {
  isRead: boolean
}
