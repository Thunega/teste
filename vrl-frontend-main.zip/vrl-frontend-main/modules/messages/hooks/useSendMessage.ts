﻿import { ref } from "vue"
import type { CreateMessageInput, Message } from "../types/message.types"
import { createMessage } from "../services/messages.api"

export function useSendMessage() {
  const loading = ref(false)
  const error = ref<unknown>(null)

  const send = async (payload: CreateMessageInput): Promise<Message> => {
    loading.value = true
    error.value = null
    try {
      return await createMessage(payload)
    } catch (err) {
      error.value = err
      throw err
    } finally {
      loading.value = false
    }
  }

  return {
    send,
    loading,
    error,
  }
}
