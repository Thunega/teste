﻿import { ref } from "vue"
import { useIntervalFn } from "@vueuse/core"
import { listMessages } from "../services/messages.api"

export function useUnreadMessagesBadge(intervalMs = 30000) {
  const count = ref(0)
  const loading = ref(false)
  const error = ref<unknown>(null)

  const fetchCount = async () => {
    if (!import.meta.client) return
    loading.value = true
    error.value = null
    try {
      const response = await listMessages({ perPage: 1 })
      count.value = response.meta?.total ?? response.data?.length ?? 0
    } catch (err) {
      error.value = err
    } finally {
      loading.value = false
    }
  }

  const { pause, resume } = useIntervalFn(fetchCount, intervalMs, {
    immediate: import.meta.client,
  })

  return {
    count,
    loading,
    error,
    refresh: fetchCount,
    pause,
    resume,
  }
}
