﻿import { ref, watch } from "vue"
import type {
  Message,
  MessageQueryParams,
  PaginationMeta,
} from "../types/message.types"
import { listMessages } from "../services/messages.api"

const defaultMeta: PaginationMeta = {
  total: 0,
  page: 1,
  perPage: 10,
}

export function useMessages(initialParams: MessageQueryParams) {
  const params = ref<MessageQueryParams>({
    perPage: defaultMeta.perPage,
    ...initialParams,
  })
  const data = ref<Message[]>([])
  const meta = ref<PaginationMeta>({
    ...defaultMeta,
    perPage: params.value.perPage || defaultMeta.perPage,
  })
  const loading = ref(false)
  const error = ref<unknown>(null)

  const fetchMessages = async () => {
    if (!import.meta.client) return
    loading.value = true
    error.value = null
    try {
      const cleanParams = { ...params.value }
      if (!cleanParams.query) delete cleanParams.query

      const response = await listMessages(cleanParams)
      data.value = response.data || []
      meta.value = response.meta || { ...defaultMeta }
    } catch (err) {
      error.value = err
    } finally {
      loading.value = false
    }
  }

  watch(params, fetchMessages, { deep: true, immediate: true })

  return {
    params,
    data,
    meta,
    loading,
    error,
    refresh: fetchMessages,
  }
}
