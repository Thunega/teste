﻿import { ref, watch, type Ref } from "vue"
import type { Message } from "../types/message.types"
import { getMessage } from "../services/messages.api"

export function useMessage(messageId: Ref<string | null>) {
  const message = ref<Message | null>(null)
  const loading = ref(false)
  const error = ref<unknown>(null)

  const fetchMessage = async () => {
    if (!messageId.value) {
      message.value = null
      return
    }
    if (!import.meta.client) return

    loading.value = true
    error.value = null
    try {
      message.value = await getMessage(messageId.value)
    } catch (err) {
      error.value = err
      message.value = null
    } finally {
      loading.value = false
    }
  }

  watch(messageId, fetchMessage, { immediate: true })

  return {
    message,
    loading,
    error,
    refresh: fetchMessage,
  }
}
