﻿import { computed, ref, watch } from "vue"
import { jwtDecode } from "jwt-decode"

interface JwtPayload {
  sub?: string
  id?: string
  userId?: string
  uid?: string
  email?: string
  name?: string
  role?: string
}

export function useCurrentUser() {
  const authStore = useAuthStore()
  const userId = ref<string | null>(null)

  const decodeToken = () => {
    if (!import.meta.client) return
    const token = authStore.token || localStorage.getItem("token")
    if (!token) return
    try {
      const payload = jwtDecode<JwtPayload>(token)
      userId.value =
        payload.sub || payload.id || payload.userId || payload.uid || null
    } catch {
      userId.value = null
    }
  }

  if (import.meta.client) {
    decodeToken()
    watch(() => authStore.token, decodeToken)
  }

  return {
    userId,
    name: computed(() => authStore.name),
    email: computed(() => authStore.email),
    role: computed(() => authStore.role),
  }
}
