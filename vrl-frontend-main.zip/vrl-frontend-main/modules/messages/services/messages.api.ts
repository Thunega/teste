﻿import type {
  CreateMessageInput,
  ListResponse,
  Message,
  MessageQueryParams,
  UpdateMessageInput,
  UserSummary,
} from "../types/message.types"

export async function listMessages(
  params: MessageQueryParams = {},
): Promise<ListResponse<Message>> {
  const { $api } = useNuxtApp()
  return await $api("/messages", { params })
}

export async function getMessage(id: string): Promise<Message> {
  const { $api } = useNuxtApp()
  return await $api(`/messages/${id}`)
}

export async function createMessage(
  payload: CreateMessageInput,
): Promise<Message> {
  const { $api } = useNuxtApp()
  return await $api("/messages", {
    method: "POST",
    body: payload,
  })
}

export async function updateMessage(
  id: string,
  payload: UpdateMessageInput,
): Promise<Message> {
  const { $api } = useNuxtApp()
  return await $api(`/messages/${id}`, {
    method: "PATCH",
    body: payload,
  })
}

export async function deleteMessage(id: string): Promise<void> {
  const { $api } = useNuxtApp()
  await $api(`/messages/${id}`, { method: "DELETE" })
}

export async function listUsers(params: {
  query?: string
  page?: number
  perPage?: number
} = {}): Promise<ListResponse<UserSummary>> {
  const { $api } = useNuxtApp()
  return await $api("/users", { params })
}
