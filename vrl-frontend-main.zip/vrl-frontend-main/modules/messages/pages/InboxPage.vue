﻿<script setup lang="ts">
import { computed, onBeforeUnmount, ref, watch } from "vue"
import { onBeforeRouteLeave } from "vue-router"
import { watchDebounced } from "@vueuse/core"
import { toast } from "vue-sonner"
import MessageList from "../components/MessageList.vue"
import MessageView from "../components/MessageView.vue"
import MessageComposeModal from "../components/MessageComposeModal.vue"
import { useMessages } from "../hooks/useMessages"
import { useMessage } from "../hooks/useMessage"
import { useCurrentUser } from "../hooks/useCurrentUser"
import { deleteMessage, updateMessage } from "../services/messages.api"

useHead({
  title: "Mensagens | VRLeao",
})

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Mensagens",
    icon: "i-lucide-mail",
    to: "/messages",
  },
])

const tabItems = [
  { label: "Inbox", value: "unread" },
  { label: "Arquivadas", value: "read" },
]

const activeTab = ref("unread")
const searchQuery = ref("")
const pagination = ref({ pageIndex: 0, pageSize: 10 })

const { params, data, meta, loading, error, refresh } = useMessages({
  page: 1,
  perPage: pagination.value.pageSize,
  isRead: false,
})

const currentPage = computed(() => pagination.value.pageIndex + 1)
const isReadFilter = computed(() => activeTab.value === "read")

const updateParams = () => {
  params.value = {
    page: currentPage.value,
    perPage: pagination.value.pageSize,
    isRead: isReadFilter.value,
    query: searchQuery.value || undefined,
  }
}

watch([currentPage, () => pagination.value.pageSize, isReadFilter], updateParams)

watchDebounced(
  searchQuery,
  () => {
    pagination.value.pageIndex = 0
    updateParams()
  },
  { debounce: 300 },
)

watch(activeTab, () => {
  pagination.value.pageIndex = 0
  updateParams()
})

const selectedId = ref<string | null>(null)

const {
  message: selectedMessage,
  loading: messageLoading,
  error: messageError,
  refresh: refreshMessage,
} = useMessage(selectedId)

watch(
  data,
  (list) => {
    if (!list || list.length === 0) {
      selectedId.value = null
      return
    }
    if (!selectedId.value || !list.find((m) => m.id === selectedId.value)) {
      selectedId.value = list[0].id
    }
  },
  { immediate: true },
)

watch(selectedId, (newId, oldId) => {
  if (oldId && newId && oldId !== newId) {
    refresh()
  }
})

onBeforeRouteLeave(() => {
  if (selectedId.value) refresh()
})

onBeforeUnmount(() => {
  if (selectedId.value) refresh()
})

const { userId, email } = useCurrentUser()

async function handleDelete() {
  if (!selectedMessage.value) return
  try {
    await deleteMessage(selectedMessage.value.id)
    toast("Mensagem deletada", {
      description: "A mensagem foi removida com sucesso.",
    })
    await refresh()
    selectedId.value = null
  } catch (err: any) {
    toast("Erro ao deletar", {
      description: err?.data?.message || "Não foi possível deletar a mensagem.",
    })
  }
}

async function handleMarkUnread() {
  if (!selectedMessage.value) return
  try {
    await updateMessage(selectedMessage.value.id, { isRead: false })
    toast("Mensagem marcada como não lida", {
      description: "A mensagem voltará para a inbox.",
    })
    await refresh()
    await refreshMessage()

    if (!data.value.find((m) => m.id === selectedMessage.value?.id)) {
      selectedId.value = null
    }
  } catch (err: any) {
    toast("Erro ao atualizar", {
      description: err?.data?.message || "Não foi possível atualizar a mensagem.",
    })
  }
}

function handleSent() {
  refresh()
}

const listError = computed(() => (error.value ? "error" : null))
const detailError = computed(() => (messageError.value ? "error" : null))
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />

    <div class="flex flex-col lg:flex-row lg:items-start justify-between mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Mensagens Internas</h1>
        <p class="text-gray-500">
          Troque mensagens seguras com outros profissionais.
        </p>
      </div>
      <MessageComposeModal @sent="handleSent" />
    </div>

    <div class="flex flex-col gap-4">
      <div class="flex flex-col lg:flex-row lg:items-center gap-4">
        <UTabs
          v-model="activeTab"
          :items="tabItems"
          :content="false"
          class="w-full lg:max-w-md"
        />
        <UInput
          v-model="searchQuery"
          icon="i-lucide-search"
          placeholder="Buscar mensagens..."
          class="w-full lg:max-w-sm"
        />
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card class="lg:col-span-1">
          <MessageList
            :messages="data"
            :selected-id="selectedId"
            :loading="loading"
            :error="listError"
            :current-user-id="userId"
            :current-user-email="email"
            @select="selectedId = $event"
            @retry="refresh"
          />

          <div
            class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
          >
            <UPagination
              v-if="meta && meta.total > meta.perPage"
              :total="meta.total"
              :page-count="pagination.pageSize"
              :model-value="currentPage"
              @update:page="(p) => (pagination.pageIndex = p - 1)"
            />
          </div>
        </Card>

        <Card class="lg:col-span-2">
          <MessageView
            :message="selectedMessage"
            :loading="messageLoading"
            :error="detailError"
            :current-user-id="userId"
            :current-user-email="email"
            @delete="handleDelete"
            @mark-unread="handleMarkUnread"
          />
        </Card>
      </div>
    </div>
  </section>
</template>
