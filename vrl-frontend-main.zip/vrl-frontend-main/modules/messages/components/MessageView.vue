﻿<script setup lang="ts">
import { computed } from "vue"
import type { Message, UserSummary } from "../types/message.types"

const props = defineProps<{
  message: Message | null
  loading?: boolean
  error?: string | null
  currentUserId?: string | null
  currentUserEmail?: string | null
}>()

const emit = defineEmits(["delete", "markUnread"])

const isCurrentUser = (user?: UserSummary) => {
  if (!user) return false
  if (props.currentUserId && user.id) return user.id === props.currentUserId
  if (props.currentUserEmail && user.email)
    return user.email === props.currentUserEmail
  return false
}

const isReceiver = computed(() =>
  props.message ? isCurrentUser(props.message.receiver) : false,
)

const createdAtLabel = computed(() => {
  if (!props.message?.createdAt) return ""
  return new Date(props.message.createdAt).toLocaleString("pt-BR")
})
</script>

<template>
  <div class="h-full">
    <div v-if="loading" class="text-sm text-gray-500">Carregando...</div>

    <div v-else-if="error" class="text-sm text-red-600">
      Não foi possível carregar a mensagem.
    </div>

    <div v-else-if="!message" class="text-sm text-gray-500">
      Selecione uma mensagem para visualizar.
    </div>

    <div v-else class="space-y-6 p-4">
      <div class="flex items-start justify-between gap-4">
        <div>
          <p class="text-xl font-semibold text-gray-900 dark:text-gray-100">
            {{ message.subject || "(Sem assunto)" }}
          </p>
          <div class="mt-2 flex flex-wrap gap-2 text-sm text-gray-500">
            <span>
              De: {{ message.sender?.name || "Remetente" }}
            </span>
            <span>·</span>
            <span>
              Para: {{ message.receiver?.name || "Destinatário" }}
            </span>
            <span v-if="message.patient">·</span>
            <span v-if="message.patient">
              Paciente: {{ message.patient.name }}
            </span>
          </div>
          <p class="mt-2 text-xs text-gray-400">
            {{ createdAtLabel }}
          </p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <UBadge
            v-if="!message.isRead"
            color="info"
            variant="subtle"
          >
            Não lida
          </UBadge>
          <UBadge
            v-else
            color="neutral"
            variant="outline"
          >
            Lida
          </UBadge>
        </div>
      </div>

      <div class="rounded-lg border border-gray-200 dark:border-gray-800 p-4 bg-white dark:bg-gray-950">
        <p class="text-sm text-gray-700 dark:text-gray-200 whitespace-pre-wrap">
          {{ message.body }}
        </p>
      </div>

      <div class="flex flex-wrap gap-2">
        <UButton
          v-if="isReceiver && message.isRead"
          size="sm"
          variant="outline"
          icon="i-lucide-mail"
          @click="emit('markUnread')"
        >
          Marcar como não lida
        </UButton>
        <UButton
          size="sm"
          color="red"
          variant="soft"
          icon="i-lucide-trash"
          @click="emit('delete')"
        >
          Deletar
        </UButton>
      </div>
    </div>
  </div>
</template>
