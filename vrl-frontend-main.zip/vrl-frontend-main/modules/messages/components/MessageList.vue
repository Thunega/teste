﻿<script setup lang="ts">
import { computed } from "vue"
import type { Message } from "../types/message.types"
import MessageItem from "./MessageItem.vue"

const props = defineProps<{
  messages: Message[]
  selectedId?: string | null
  loading?: boolean
  error?: string | null
  currentUserId?: string | null
  currentUserEmail?: string | null
}>()

const emit = defineEmits(["select", "retry"])

const isEmpty = computed(
  () => !props.loading && !props.error && props.messages.length === 0,
)
</script>

<template>
  <div class="space-y-3">
    <div v-if="loading" class="text-sm text-gray-500">Carregando...</div>

    <div v-else-if="error" class="text-sm text-red-600">
      Não foi possível carregar as mensagens.
      <div class="mt-3">
        <UButton size="sm" variant="outline" @click="emit('retry')">
          Tentar novamente
        </UButton>
      </div>
    </div>

    <div v-else-if="isEmpty" class="text-sm text-gray-500">
      Nenhuma mensagem encontrada.
    </div>

    <div v-else class="space-y-2">
      <MessageItem
        v-for="message in messages"
        :key="message.id"
        :message="message"
        :active="message.id === selectedId"
        :current-user-id="currentUserId"
        :current-user-email="currentUserEmail"
        @click="emit('select', message.id)"
      />
    </div>
  </div>
</template>
