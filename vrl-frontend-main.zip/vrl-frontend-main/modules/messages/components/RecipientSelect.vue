﻿<template>
  <USelectMenu
    v-model="selected"
    v-model:search-term="searchTerm"
    :items="users"
    :loading="status === 'pending'"
    placeholder="Buscar destinatário pelo nome..."
    option-attribute="label"
    value-attribute="value"
    ignore-filter
    by="value"
    trailing-icon="i-heroicons-magnifying-glass-20-solid"
  />
</template>

<script setup lang="ts">
import { ref, watch, useId } from "vue"
import { refDebounced } from "@vueuse/core"
import type { UserSummary } from "../types/message.types"
import { listUsers } from "../services/messages.api"
import { useCurrentUser } from "../hooks/useCurrentUser"

const emit = defineEmits(["update:receiver"])
const componentId = useId()

const selected = ref<{ value: string } | string | null>(null)
const searchTerm = ref("")
const searchTermDebounced = refDebounced(searchTerm, 300)

const { userId, email } = useCurrentUser()

watch(selected, (newValue) => {
  if (newValue && typeof newValue === "object") {
    emit("update:receiver", newValue.value)
  } else {
    emit("update:receiver", newValue)
  }
})

const { data: users, status } = await useAsyncData(
  `search-message-users-${componentId}`,
  () => {
    if (!searchTermDebounced.value) {
      return Promise.resolve({ data: [] })
    }
    return listUsers({ query: searchTermDebounced.value, perPage: 20 })
  },
  {
    transform: (response: { data: UserSummary[] }) => {
      const userList = response?.data || []
      return userList
        .filter((user) => {
          if (userId.value && user.id) return user.id !== userId.value
          if (email.value && user.email) return user.email !== email.value
          return true
        })
        .map((user) => ({
          label: `${user.name}${user.email ? ` - ${user.email}` : ""}`,
          value: user.id,
        }))
    },
    watch: [searchTermDebounced, userId, email],
    lazy: true,
    default: () => [],
  },
)
</script>
