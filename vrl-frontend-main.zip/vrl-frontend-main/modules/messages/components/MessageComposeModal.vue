﻿<script setup lang="ts">
import { reactive, ref } from "vue"
import * as z from "zod"
import type { FormSubmitEvent } from "@nuxt/ui"
import { toast } from "vue-sonner"
import { useZodForm } from "~/utils/useZodForm"
import { useSendMessage } from "../hooks/useSendMessage"
import { useCurrentUser } from "../hooks/useCurrentUser"
import RecipientSelect from "./RecipientSelect.vue"

const emit = defineEmits(["sent"])

const open = ref(false)

const { userId } = useCurrentUser()

const schema = z
  .object({
    receiverId: z
      .string({
        required_error: "Selecione um destinatário.",
        invalid_type_error: "Selecione um destinatário.",
      })
      .min(1, "Selecione um destinatário."),
    subject: z
      .string({
        required_error: "O assunto é obrigatório.",
        invalid_type_error: "O assunto é obrigatório.",
      })
      .min(3, "O assunto deve ter pelo menos 3 caracteres.")
      .max(120, "O assunto deve ter no máximo 120 caracteres."),
    body: z
      .string({
        required_error: "A mensagem é obrigatória.",
        invalid_type_error: "A mensagem é obrigatória.",
      })
      .min(3, "A mensagem deve ter pelo menos 3 caracteres.")
      .max(4000, "A mensagem deve ter no máximo 4000 caracteres."),
    patientId: z.string().optional().nullable(),
  })
  .refine(
    (data) => {
      if (!userId.value) return true
      return data.receiverId !== userId.value
    },
    {
      path: ["receiverId"],
      message: "Não é possível enviar mensagem para você mesmo.",
    },
  )

type Schema = z.output<typeof schema>

const initialState: Schema = {
  receiverId: "",
  subject: "",
  body: "",
  patientId: null,
}

const state = reactive({ ...initialState })

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state)

const { send, loading } = useSendMessage()

function resetForm() {
  Object.assign(state, initialState)
  clearErrors()
  open.value = false
}

function clearPatient() {
  state.patientId = null
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return

  try {
    await send({
      receiverId: event.data.receiverId,
      subject: event.data.subject,
      body: event.data.body,
      patientId: event.data.patientId || undefined,
    })

    toast("Mensagem enviada!", {
      description: "A mensagem foi enviada com sucesso.",
    })

    emit("sent")
    resetForm()
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors)

    toast("Erro ao enviar mensagem", {
      description: error?.data?.message || "Não foi possível enviar a mensagem.",
    })
  }
}
</script>

<template>
  <div>
    <UModal
      v-model:open="open"
      :dismissible="false"
      :overlay="false"
      title="Nova mensagem"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-pen-square" label="Nova mensagem" />

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <UFormField label="Destinatário" name="receiverId">
            <RecipientSelect @update:receiver="state.receiverId = $event" />
            <p v-if="getError('receiverId')" class="text-red-600 text-sm mt-1">
              {{ getError("receiverId") }}
            </p>
          </UFormField>

          <UFormField label="Assunto" name="subject">
            <UInput
              v-model="state.subject"
              class="w-full"
              :class="{ 'border-red-500': hasError('subject') }"
              placeholder="Ex: Dúvida sobre prontuário"
            />
            <p v-if="getError('subject')" class="text-red-600 text-sm mt-1">
              {{ getError("subject") }}
            </p>
          </UFormField>

          <UFormField label="Mensagem" name="body">
            <UTextarea
              v-model="state.body"
              class="w-full"
              rows="6"
              :class="{ 'border-red-500': hasError('body') }"
              placeholder="Escreva sua mensagem aqui..."
            />
            <p v-if="getError('body')" class="text-red-600 text-sm mt-1">
              {{ getError("body") }}
            </p>
          </UFormField>

          <UFormField label="Paciente (opcional)" name="patientId">
            <div class="flex flex-col gap-2">
              <PatientsSelectInput @update:patient="state.patientId = $event" />
              <UButton
                v-if="state.patientId"
                size="xs"
                variant="outline"
                @click="clearPatient"
              >
                Remover paciente
              </UButton>
            </div>
          </UFormField>

          <UButton type="submit" block class="mt-6" :loading="loading">
            Enviar mensagem
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
