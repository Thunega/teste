﻿<script setup lang="ts">
import { computed } from "vue"
import type { Message, UserSummary } from "../types/message.types"

const props = defineProps<{
  message: Message
  active?: boolean
  currentUserId?: string | null
  currentUserEmail?: string | null
}>()

const isCurrentUser = (user?: UserSummary) => {
  if (!user) return false
  if (props.currentUserId && user.id) return user.id === props.currentUserId
  if (props.currentUserEmail && user.email)
    return user.email === props.currentUserEmail
  return false
}

const senderLabel = computed(() =>
  isCurrentUser(props.message.sender)
    ? "Você"
    : props.message.sender?.name || "Remetente",
)

const receiverLabel = computed(() =>
  isCurrentUser(props.message.receiver)
    ? "Você"
    : props.message.receiver?.name || "Destinatário",
)

const isUnread = computed(() => !props.message.isRead)

const timeLabel = computed(() => {
  const createdAt = props.message.createdAt
  if (!createdAt) return ""

  const date = new Date(createdAt)
  const now = new Date()
  const sameDay =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear()

  if (sameDay) {
    return date.toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return date.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
  })
})
</script>

<template>
  <button
    type="button"
    class="w-full text-left px-4 py-3 rounded-lg border transition-all"
    :class="[
      active
        ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30'
        : 'border-gray-200 dark:border-gray-800',
      isUnread ? 'bg-gray-50 dark:bg-gray-900' : 'bg-white dark:bg-gray-950',
    ]"
  >
    <div class="flex items-start justify-between gap-3">
      <div class="flex items-center gap-2">
        <span
          v-if="isUnread"
          class="inline-flex size-2 rounded-full bg-blue-500"
        />
        <p
          class="text-sm"
          :class="isUnread ? 'font-semibold text-gray-900 dark:text-gray-100' : 'text-gray-700 dark:text-gray-300'"
        >
          {{ message.subject || "(Sem assunto)" }}
        </p>
      </div>
      <span class="text-xs text-gray-500 dark:text-gray-400">
        {{ timeLabel }}
      </span>
    </div>

    <p class="mt-2 text-xs text-gray-600 dark:text-gray-400">
      {{ senderLabel }} → {{ receiverLabel }}
    </p>

    <p
      v-if="message.patient"
      class="mt-1 text-xs text-gray-500 dark:text-gray-500"
    >
      Paciente: {{ message.patient.name }}
    </p>
  </button>
</template>
