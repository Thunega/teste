# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a **Nuxt 4** medical/healthcare management frontend application using **pnpm** as the package manager. The app is configured for **SPA mode** (SSR disabled) and connects to a backend API.

## Development Commands

```bash
# Install dependencies
pnpm install

# Run development server (http://localhost:3000)
pnpm dev

# Build for production
pnpm build

# Preview production build
pnpm preview
```

## Environment Configuration

- Copy `.env.example` to `.env` before starting development
- Required environment variable: `API_BASE_URL` (backend API URL)
- Default: `http://localhost:3003`

## Architecture

### Tech Stack
- **Framework**: Nuxt 4 (Vue 3)
- **UI Components**: @nuxt/ui, shadcn-nuxt (reka-ui based), Tailwind CSS 4
- **State Management**: Pinia stores
- **Form Validation**: vee-validate with Zod schemas
- **Tables**: @tanstack/vue-table
- **Charts**: Chart.js with vue-chartjs
- **Authentication**: JWT tokens (stored in localStorage)
- **Icons**: lucide-vue-next, @nuxt/icon

### Directory Structure

- **`pages/`**: File-based routing with nested routes for each module
  - Main modules: patients, exams, appointments, medical-consultations, nutritional-consultations, physiotherapy-consultations, physiotherapy-sessions, psychological-consultations, daily-food-logs, daily-performance-logs, sleep-logs, forwardings, sessions, users
  - Each module typically has `index.vue` and `[id].vue` for list/detail views

- **`components/`**: Organized by feature/module
  - `ui/`: shadcn-nuxt components (buttons, cards, forms, modals, tables, etc.)
  - Module-specific folders match page modules (e.g., `exam/`, `appointments/`, `MedicalConsultations/`)
  - Common pattern: `CreateModal.vue`, `EditModal.vue`, `Results.vue` per module
  - `AppSidebar.vue`: Main navigation sidebar
  - `NavUser.vue`: User menu component

- **`stores/`**: Pinia stores (one per module)
  - Pattern: Each store has `data`, `meta` state and `fetchData`, `createX`, `updateX`, `getById`, `delete` actions
  - `auth.ts`: Handles authentication, JWT tokens, user state
  - Uses `$api` plugin from nuxtApp for API calls
  - All stores use HMR with `acceptHMRUpdate`

- **`middleware/`**: Route protection
  - `protected.js`: Checks authentication via `authStore.checkAuth()`, redirects to `/login` if not authenticated
  - `guest.js`: For unauthenticated-only routes

- **`plugins/`**: Global plugins
  - `api.ts`: Creates `$api` fetch instance with Authorization headers and 401 error handling

- **`utils/`**: Utility functions
  - `calculateAge()`: Age calculation from date of birth
  - `getLabReference()`: Lab test reference values based on age/gender

### API Integration

- All API calls use the `$api` plugin accessed via `nuxtApp` or `useNuxtApp()`
- Base URL configured in `nuxt.config.ts` via `runtimeConfig.public.apiBaseUrl`
- Automatic JWT token injection in request headers
- Automatic redirect to `/login` on 401 responses
- Standard patterns:
  ```typescript
  const { $api } = useNuxtApp()
  await $api('/endpoint', { method: 'POST', body: data })
  ```

### Authentication Flow

1. Login sets JWT token in localStorage and auth store
2. `protected` middleware checks auth on route navigation
3. `checkAuth()` verifies token with `/auth/me` endpoint
4. Decoded JWT payload contains: `name`, `email`, `role`
5. Token stored in both localStorage and Pinia state

### Component Patterns

- **Table views**: Use @tanstack/vue-table with custom column definitions
- **Modals**: Separate Create/Edit modal components per module
- **Forms**: vee-validate with Zod schemas (though @vee-validate/nuxt is commented out in config)
- **Charts**: Chart.js components for exam results (e.g., `LiverFunctionChart.vue`, `ThyroidFunctionChart.vue`)
- **Date pickers**: Custom `UDatePicker.vue` wrapper component

### UI Framework Notes

- Primary UI library: @nuxt/ui (version 3.x)
- Secondary: shadcn-nuxt components in `components/ui/`
- All components use Tailwind CSS 4 with dark mode support
- Dark mode toggle: `DarkModeToggle.vue` component
- Color mode configured with `classSuffix: ''` (uses standard Tailwind dark: prefix)

### Role-Based Access

- User roles stored in auth store (`authStore.role`)
- Role comes from JWT payload
- Check roles in components to conditionally render UI or restrict actions

### Medical Data Domain

This app manages:
- Patient records and demographics
- Medical exams (lab results, charts)
- Various consultation types (medical, nutritional, physiotherapy, psychological)
- Daily logs (food, performance, sleep)
- Appointments and sessions
- Patient forwardings/referrals
- Clinical information and anamneses
- Lab reference values for age/gender-specific ranges

### Important Configuration

- **SSR disabled**: `ssr: false` in nuxt.config.ts
- **Package manager**: pnpm (see pnpm-lock.yaml)
- **ngrok support**: Vite server configured with allowed host for ngrok tunneling
- **Compatibility date**: Set to 2025-05-15

## CRUD Modal Pattern

This application follows a consistent pattern for Create, Edit, and Delete operations across all modules.

### Create Modal Pattern

**Location**: `components/{ModuleName}/CreateModal.vue`

**Structure**:
- Uses `UModal` component with `v-model:open` to control visibility
- Trigger button (with icon and label) inside the modal template
- `UForm` with Zod schema validation and reactive state
- Emits `@created` event after successful creation
- Shows toast notifications for success/error feedback
- Resets form state after successful submission

**Example**: `components/appointments/CreateModal.vue`

```vue
<script setup>
const emit = defineEmits(['created'])
const store = useModuleStore()
const open = ref(false)

const schema = z.object({ /* validation rules */ })
const state = reactive({ /* form fields */ })

function resetForm() {
  Object.assign(state, initialState)
  open.value = false
}

async function onSubmit(event) {
  try {
    await store.create(event.data)
    toast('Item Criado!', { description: '...' })
    emit('created')
    resetForm()
  } catch (error) {
    toast('Erro ao Criar', { description: error.data?.message })
  }
}
</script>

<template>
  <UModal v-model:open="open" title="Criar Novo Item">
    <UButton icon="i-lucide-plus-circle" label="Novo Item" />
    <template #body>
      <UForm :schema="schema" :state="state" @submit="onSubmit">
        <!-- Form fields -->
        <UButton type="submit" block>Salvar</UButton>
      </UForm>
    </template>
  </UModal>
</template>
```

### Edit Modal Pattern

**Location**: `components/{ModuleName}/EditModal.vue`

**Structure**:
- Receives `id` prop (e.g., `appointmentId`)
- Uses `defineExpose({ open, close })` for external control
- Fetches data via `store.getById(id)` when modal opens
- Watches `open` ref to trigger data loading
- Shows loading state while fetching
- Emits `@updated` event after successful update
- Pre-fills form with existing data

**Example**: `components/appointments/EditModal.vue`

```vue
<script setup>
const props = defineProps<{ appointmentId: string }>()
const emit = defineEmits(['updated'])
const store = useModuleStore()
const open = ref(false)
const isLoading = ref(false)

defineExpose({
  open: () => open.value = true,
  close: () => open.value = false
})

watch(open, (isOpen) => {
  if (isOpen) fetchData()
})

async function fetchData() {
  isLoading.value = true
  const data = await store.getById(props.appointmentId)
  Object.assign(state, data)
  isLoading.value = false
}

async function onSubmit(event) {
  await store.update(props.appointmentId, event.data)
  emit('updated')
  open.value = false
}
</script>
```

### Delete Modal Pattern

**Location**: `components/DeleteModal.vue` (shared/generic component)

**Structure**:
- Generic reusable component
- Receives `store` object and `id` as props
- Uses `defineExpose({ open, close })` for external control
- Calls `store.delete(id)` on confirmation
- Emits `@deleted` event after successful deletion
- Simple confirmation dialog with Cancel/Confirm buttons

**Example**: `components/DeleteModal.vue`

```vue
<script setup>
const props = defineProps({
  store: { type: Object, required: true },
  id: { type: [String, Number], required: true }
})
const emit = defineEmits(['deleted'])
const open = ref(false)

defineExpose({
  open: () => open.value = true,
  close: () => open.value = false
})

async function confirmDelete() {
  await props.store.delete(props.id)
  toast('Item Excluído!')
  emit('deleted')
  open.value = false
}
</script>
```

### Integration in Index Pages

**Pattern in `pages/{module}/index.vue`**:

1. **Import and setup refs**:
```vue
const editModal = ref()
const deleteModal = ref()
const selectedItemId = ref()
```

2. **Table actions dropdown**:
```vue
function getRowItems(row) {
  return [
    {
      label: 'Ver Detalhes',
      icon: 'i-lucide-eye',
      onSelect: () => router.push(`/module/${row.original.id}`)
    },
    {
      label: 'Editar',
      icon: 'i-lucide-pencil',
      onSelect: () => {
        selectedItemId.value = row.original.id
        editModal.value.open()
      }
    },
    {
      label: 'Deletar',
      icon: 'i-lucide-x-circle',
      onSelect: () => {
        selectedItemId.value = row.original.id
        deleteModal.value.open()
      }
    }
  ]
}
```

3. **Template integration**:
```vue
<template>
  <!-- Create button -->
  <ModuleCreateModal @created="fetchData()" />

  <!-- Table -->
  <UTable :data="store.data" :columns="columns" />

  <!-- Edit modal -->
  <ModuleEditModal
    ref="editModal"
    :item-id="selectedItemId"
    @updated="fetchData"
  />

  <!-- Delete modal -->
  <DeleteModal
    ref="deleteModal"
    :id="selectedItemId"
    :store="store"
    @deleted="fetchData"
  />
</template>
```

### Key Principles

1. **CreateModal**: Self-contained with trigger button, emits `@created`
2. **EditModal**: Controlled externally via `ref` and `open()` method, receives item ID as prop
3. **DeleteModal**: Generic/reusable component, receives store and ID
4. **Event handling**: All modals emit events that trigger `fetchData()` to refresh the list
5. **Toast feedback**: Success/error messages for all operations
6. **Loading states**: Edit modals show loading while fetching data
7. **Form validation**: All forms use Zod schemas for validation
