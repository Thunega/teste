<script setup lang="ts">
import { computed } from 'vue'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import { calculateMealNutrients } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

const props = defineProps<{
  log: DailyFoodLog
}>()

const mealData = computed(() => {
  if (!props.log.meals) return []

  return props.log.meals.map(meal => {
    const nutrients = calculateMealNutrients(meal)
    const time = meal.mealTime || 'N/A'
    const description = meal.description || 'Sem descrição'

    return {
      time,
      description,
      calories: nutrients.calories,
      carbs: nutrients.carbohydrates,
      proteins: nutrients.proteins,
      fats: nutrients.totalFats
    }
  }).sort((a, b) => a.time.localeCompare(b.time))
})

const chartData = computed(() => {
  const labels = mealData.value.map((meal, idx) => {
    return meal.time !== 'N/A' ? meal.time : `Refeição ${idx + 1}`
  })

  return {
    labels,
    datasets: [
      {
        label: 'Carboidratos (g)',
        data: mealData.value.map(m => m.carbs),
        backgroundColor: 'rgba(59, 130, 246, 0.8)',
        borderColor: 'rgb(59, 130, 246)',
        borderWidth: 1
      },
      {
        label: 'Proteínas (g)',
        data: mealData.value.map(m => m.proteins),
        backgroundColor: 'rgba(239, 68, 68, 0.8)',
        borderColor: 'rgb(239, 68, 68)',
        borderWidth: 1
      },
      {
        label: 'Gorduras (g)',
        data: mealData.value.map(m => m.fats),
        backgroundColor: 'rgba(245, 158, 11, 0.8)',
        borderColor: 'rgb(245, 158, 11)',
        borderWidth: 1
      }
    ]
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  indexAxis: 'y' as const,
  plugins: {
    legend: {
      position: 'top' as const,
      labels: {
        padding: 10,
        usePointStyle: true
      }
    },
    tooltip: {
      callbacks: {
        title: function(context: any) {
          const idx = context[0].dataIndex
          return `${mealData.value[idx].time} - ${mealData.value[idx].description}`
        },
        label: function(context: any) {
          return `${context.dataset.label}: ${context.parsed.x.toFixed(1)}g`
        },
        afterLabel: function(context: any) {
          if (context.datasetIndex === 0) {
            const idx = context.dataIndex
            return `Total: ${mealData.value[idx].calories.toFixed(0)} kcal`
          }
          return ''
        }
      }
    }
  },
  scales: {
    x: {
      stacked: true,
      title: {
        display: true,
        text: 'Gramas (g)'
      }
    },
    y: {
      stacked: true,
      title: {
        display: true,
        text: 'Horário da Refeição'
      }
    }
  }
}

const totalCalories = computed(() => {
  return mealData.value.reduce((sum, meal) => sum + meal.calories, 0)
})

const largestMeal = computed(() => {
  if (mealData.value.length === 0) return null
  return mealData.value.reduce((max, meal) =>
    meal.calories > max.calories ? meal : max
  )
})
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <h3 class="text-lg font-semibold">Padrão de Distribuição das Refeições</h3>
        <UIcon name="i-lucide-utensils" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div v-if="mealData.length > 0" class="h-[350px]">
      <Bar :data="chartData" :options="chartOptions" />
    </div>

    <div v-else class="h-[350px] flex items-center justify-center text-gray-500">
      <div class="text-center">
        <UIcon name="i-lucide-alert-circle" class="w-12 h-12 mx-auto mb-2" />
        <p>Nenhuma refeição registrada para este dia</p>
      </div>
    </div>

    <template #footer>
      <div class="grid grid-cols-3 gap-4 text-center text-sm">
        <div>
          <p class="text-gray-500">Total de Refeições</p>
          <p class="font-semibold">{{ mealData.length }}</p>
        </div>
        <div>
          <p class="text-gray-500">Total Calorias</p>
          <p class="font-semibold">{{ totalCalories.toFixed(0) }} kcal</p>
        </div>
        <div v-if="largestMeal">
          <p class="text-gray-500">Maior Refeição</p>
          <p class="font-semibold">{{ largestMeal.time }} ({{ largestMeal.calories.toFixed(0) }} kcal)</p>
        </div>
      </div>
    </template>
  </Card>
</template>
