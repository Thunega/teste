<script setup lang="ts">
import { computed } from 'vue'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import { calculateDailyNutrients, calculateOmegaRatio, getOmegaRatioStatus } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const sortedLogs = computed(() => {
  return [...props.logs].sort((a, b) =>
    new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime()
  )
})

const chartData = computed(() => {
  const labels = sortedLogs.value.map(log =>
    new Date(log.dateOfRegistration).toLocaleDateString('pt-BR', {
      month: 'short',
      day: 'numeric'
    })
  )

  const omega3Data = sortedLogs.value.map(log => calculateDailyNutrients(log).omega3)
  const omega6Data = sortedLogs.value.map(log => calculateDailyNutrients(log).omega6)

  return {
    labels,
    datasets: [
      {
        label: 'Ômega-3 (g)',
        data: omega3Data,
        backgroundColor: 'rgba(59, 130, 246, 0.8)',
        borderColor: 'rgb(59, 130, 246)',
        borderWidth: 1
      },
      {
        label: 'Ômega-6 (g)',
        data: omega6Data,
        backgroundColor: 'rgba(245, 158, 11, 0.8)',
        borderColor: 'rgb(245, 158, 11)',
        borderWidth: 1
      }
    ]
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top' as const,
      labels: {
        padding: 15,
        usePointStyle: true
      }
    },
    tooltip: {
      callbacks: {
        afterLabel: function(context: any) {
          const idx = context.dataIndex
          const log = sortedLogs.value[idx]
          const nutrients = calculateDailyNutrients(log)
          const ratio = calculateOmegaRatio(nutrients.omega3, nutrients.omega6)
          return `Proporção: 1:${(1/ratio).toFixed(1)}`
        }
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Gramas (g)'
      }
    },
    x: {
      title: {
        display: true,
        text: 'Data'
      }
    }
  }
}

const averageRatio = computed(() => {
  const ratios = sortedLogs.value.map(log => {
    const nutrients = calculateDailyNutrients(log)
    return calculateOmegaRatio(nutrients.omega3, nutrients.omega6)
  })
  const avg = ratios.reduce((a, b) => a + b, 0) / ratios.length
  return avg
})

const ratioStatus = computed(() => getOmegaRatioStatus(averageRatio.value))
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <div>
          <h3 class="text-lg font-semibold">Proporção Ômega-3 / Ômega-6</h3>
          <p class="text-xs text-gray-500">Ideal: 1:2 a 1:4</p>
        </div>
        <UIcon name="i-lucide-droplet" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div class="h-[300px]">
      <Bar :data="chartData" :options="chartOptions" />
    </div>

    <template #footer>
      <div class="flex items-center justify-around text-sm">
        <div class="text-center">
          <p class="text-gray-500">Proporção Média</p>
          <p class="font-semibold text-lg">1 : {{ (1/averageRatio).toFixed(1) }}</p>
        </div>
        <div class="text-center">
          <p class="text-gray-500">Status</p>
          <p class="font-semibold text-lg" :class="{
            'text-green-600': ratioStatus === 'excellent' || ratioStatus === 'good',
            'text-yellow-600': ratioStatus === 'fair',
            'text-red-600': ratioStatus === 'poor'
          }">
            {{
              ratioStatus === 'excellent' ? 'Excelente' :
              ratioStatus === 'good' ? 'Bom' :
              ratioStatus === 'fair' ? 'Razoável' : 'Ruim'
            }}
          </p>
        </div>
      </div>
    </template>
  </Card>
</template>
