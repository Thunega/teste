<script setup lang="ts">
import { computed } from 'vue'
import { Doughnut } from 'vue-chartjs'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'
import { calculateFoodDiversityScore } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

ChartJS.register(ArcElement, Tooltip, Legend)

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const diversityScore = computed(() => calculateFoodDiversityScore(props.logs))

const uniqueFoods = computed(() => {
  const foods = new Set<string>()
  props.logs.forEach(log => {
    log.meals?.forEach(meal => {
      meal.foods?.forEach(food => {
        if (food.name) {
          foods.add(food.name.toLowerCase().trim())
        }
      })
    })
  })
  return Array.from(foods).sort()
})

const chartData = computed(() => ({
  labels: ['Diversidade Alcançada', 'Potencial'],
  datasets: [
    {
      data: [diversityScore.value, 100 - diversityScore.value],
      backgroundColor: [
        diversityScore.value >= 80 ? 'rgba(34, 197, 94, 0.8)' :
        diversityScore.value >= 60 ? 'rgba(250, 204, 21, 0.8)' :
        'rgba(239, 68, 68, 0.8)',
        'rgba(229, 231, 235, 0.3)'
      ],
      borderColor: [
        diversityScore.value >= 80 ? 'rgb(34, 197, 94)' :
        diversityScore.value >= 60 ? 'rgb(250, 204, 21)' :
        'rgb(239, 68, 68)',
        'rgb(229, 231, 235)'
      ],
      borderWidth: 2
    }
  ]
}))

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  cutout: '70%',
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      enabled: false
    }
  }
}

const scoreLevel = computed(() => {
  if (diversityScore.value >= 80) return { label: 'Excelente', color: 'text-green-600' }
  if (diversityScore.value >= 60) return { label: 'Bom', color: 'text-yellow-600' }
  if (diversityScore.value >= 40) return { label: 'Regular', color: 'text-orange-600' }
  return { label: 'Baixo', color: 'text-red-600' }
})
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <div>
          <h3 class="text-lg font-semibold">Pontuação de Diversidade Alimentar</h3>
          <p class="text-xs text-gray-500">Variedade de alimentos consumidos</p>
        </div>
        <UIcon name="i-lucide-sparkles" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div class="relative h-[250px] flex items-center justify-center">
      <Doughnut :data="chartData" :options="chartOptions" />
      <div class="absolute inset-0 flex flex-col items-center justify-center">
        <p class="text-4xl font-bold" :class="scoreLevel.color">
          {{ diversityScore.toFixed(0) }}
        </p>
        <p class="text-sm text-gray-500">de 100</p>
        <p class="text-sm font-semibold mt-1" :class="scoreLevel.color">
          {{ scoreLevel.label }}
        </p>
      </div>
    </div>

    <template #footer>
      <div class="space-y-3">
        <div class="grid grid-cols-2 gap-4 text-center text-sm pb-3 border-b">
          <div>
            <p class="text-gray-500">Alimentos Únicos</p>
            <p class="font-semibold text-lg">{{ uniqueFoods.length }}</p>
          </div>
          <div>
            <p class="text-gray-500">Período Analisado</p>
            <p class="font-semibold text-lg">{{ logs.length }} dias</p>
          </div>
        </div>

        <div>
          <p class="text-xs text-gray-500 mb-2 font-medium">Alimentos Consumidos:</p>
          <div class="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
            <span
              v-for="food in uniqueFoods.slice(0, 20)"
              :key="food"
              class="text-xs px-2 py-1 bg-gray-100 dark:bg-gray-800 rounded-full"
            >
              {{ food }}
            </span>
            <span
              v-if="uniqueFoods.length > 20"
              class="text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded-full font-medium"
            >
              +{{ uniqueFoods.length - 20 }} mais
            </span>
          </div>
        </div>
      </div>
    </template>
  </Card>
</template>
