<script setup lang="ts">
import { computed } from 'vue'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const mealStats = computed(() => {
  const mealCounts: number[] = []
  const mealTimes: string[] = []

  props.logs.forEach(log => {
    mealCounts.push(log.meals?.length || 0)

    log.meals?.forEach(meal => {
      if (meal.mealTime) {
        mealTimes.push(meal.mealTime)
      }
    })
  })

  // Calculate frequency distribution
  const frequencyDist: { [key: number]: number } = {}
  mealCounts.forEach(count => {
    frequencyDist[count] = (frequencyDist[count] || 0) + 1
  })

  // Calculate average meal timing
  const timeDistribution: { [hour: string]: number } = {}
  mealTimes.forEach(time => {
    const hour = time.split(':')[0]
    timeDistribution[hour] = (timeDistribution[hour] || 0) + 1
  })

  return {
    average: mealCounts.reduce((a, b) => a + b, 0) / mealCounts.length,
    frequencyDist,
    timeDistribution,
    mostCommonCount: Object.keys(frequencyDist).reduce((a, b) =>
      frequencyDist[a] > frequencyDist[b] ? a : b
    )
  }
})

const chartData = computed(() => {
  const labels = Object.keys(mealStats.value.frequencyDist).sort((a, b) => parseInt(a) - parseInt(b))

  return {
    labels: labels.map(l => `${l} refeições`),
    datasets: [
      {
        label: 'Número de Dias',
        data: labels.map(l => mealStats.value.frequencyDist[l]),
        backgroundColor: 'rgba(59, 130, 246, 0.8)',
        borderColor: 'rgb(59, 130, 246)',
        borderWidth: 2
      }
    ]
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      callbacks: {
        label: function(context: any) {
          return `${context.parsed.y} dia(s) com ${context.label}`
        }
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: {
        stepSize: 1
      },
      title: {
        display: true,
        text: 'Número de Dias'
      }
    },
    x: {
      title: {
        display: true,
        text: 'Frequência de Refeições'
      }
    }
  }
}

const timeChartData = computed(() => {
  const hours = Object.keys(mealStats.value.timeDistribution).sort()

  return {
    labels: hours.map(h => `${h}:00`),
    datasets: [
      {
        label: 'Refeições',
        data: hours.map(h => mealStats.value.timeDistribution[h]),
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
        borderColor: 'rgb(34, 197, 94)',
        borderWidth: 2
      }
    ]
  }
})

const timeChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: {
        stepSize: 1
      },
      title: {
        display: true,
        text: 'Frequência'
      }
    },
    x: {
      title: {
        display: true,
        text: 'Horário'
      }
    }
  }
}

const consistency = computed(() => {
  const avg = mealStats.value.average
  if (avg >= 5 && avg <= 6) return { level: 'Excelente', color: 'text-green-600' }
  if (avg >= 4 && avg < 5) return { level: 'Bom', color: 'text-blue-600' }
  if (avg >= 3 && avg < 4) return { level: 'Regular', color: 'text-yellow-600' }
  return { level: 'Baixo', color: 'text-red-600' }
})
</script>

<template>
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
    <!-- Frequency Distribution -->
    <Card>
      <template #header>
        <div class="flex items-center justify-between">
          <h3 class="text-lg font-semibold">Frequência de Refeições por Dia</h3>
          <UIcon name="i-lucide-bar-chart-2" class="w-5 h-5 text-gray-500" />
        </div>
      </template>

      <div class="h-[250px]">
        <Bar :data="chartData" :options="chartOptions" />
      </div>

      <template #footer>
        <div class="grid grid-cols-3 gap-4 text-center text-sm">
          <div>
            <p class="text-gray-500">Média</p>
            <p class="font-semibold">{{ mealStats.average.toFixed(1) }}</p>
          </div>
          <div>
            <p class="text-gray-500">Mais Comum</p>
            <p class="font-semibold">{{ mealStats.mostCommonCount }} refeições</p>
          </div>
          <div>
            <p class="text-gray-500">Consistência</p>
            <p class="font-semibold" :class="consistency.color">{{ consistency.level }}</p>
          </div>
        </div>
      </template>
    </Card>

    <!-- Meal Timing Distribution -->
    <Card>
      <template #header>
        <div class="flex items-center justify-between">
          <h3 class="text-lg font-semibold">Horários Mais Comuns</h3>
          <UIcon name="i-lucide-clock" class="w-5 h-5 text-gray-500" />
        </div>
      </template>

      <div class="h-[250px]">
        <Bar :data="timeChartData" :options="timeChartOptions" />
      </div>

      <template #footer>
        <p class="text-xs text-center text-gray-500">
          Horários em que as refeições são mais frequentemente registradas
        </p>
      </template>
    </Card>
  </div>
</template>
