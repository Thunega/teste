<script setup lang="ts">
import { computed } from 'vue'
import { Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js'
import { calculateDailyNutrients, RDA } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

// Dynamic import for annotation plugin to avoid SSR issues
if (process.client) {
  import('chartjs-plugin-annotation').then(module => {
    ChartJS.register(module.default)
  })
}

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
)

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const sortedLogs = computed(() => {
  return [...props.logs].sort((a, b) =>
    new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime()
  )
})

const chartData = computed(() => {
  const labels = sortedLogs.value.map(log =>
    new Date(log.dateOfRegistration).toLocaleDateString('pt-BR', {
      month: 'short',
      day: 'numeric'
    })
  )

  const fiberData = sortedLogs.value.map(log => calculateDailyNutrients(log).fiber)
  const sugarData = sortedLogs.value.map(log => calculateDailyNutrients(log).sugar)

  return {
    labels,
    datasets: [
      {
        label: 'Fibras (g)',
        data: fiberData,
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.1)',
        tension: 0.4,
        fill: true,
        yAxisID: 'y'
      },
      {
        label: 'Açúcar (g)',
        data: sugarData,
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        tension: 0.4,
        fill: true,
        yAxisID: 'y'
      }
    ]
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    mode: 'index' as const,
    intersect: false,
  },
  plugins: {
    legend: {
      position: 'top' as const,
      labels: {
        padding: 15,
        usePointStyle: true
      }
    },
    tooltip: {
      callbacks: {
        label: function(context: any) {
          return `${context.dataset.label}: ${context.parsed.y.toFixed(1)}g`
        }
      }
    },
    annotation: {
      annotations: {
        fiberTarget: {
          type: 'line' as const,
          yMin: RDA.fiber.target,
          yMax: RDA.fiber.target,
          borderColor: 'rgba(34, 197, 94, 0.5)',
          borderWidth: 2,
          borderDash: [5, 5],
          label: {
            display: true,
            content: `Meta Fibras: ${RDA.fiber.target}g`,
            position: 'start' as const,
            backgroundColor: 'rgba(34, 197, 94, 0.8)',
            color: 'white',
            padding: 4
          }
        },
        sugarMax: {
          type: 'line' as const,
          yMin: RDA.sugar.max,
          yMax: RDA.sugar.max,
          borderColor: 'rgba(239, 68, 68, 0.5)',
          borderWidth: 2,
          borderDash: [5, 5],
          label: {
            display: true,
            content: `Limite Açúcar: ${RDA.sugar.max}g`,
            position: 'end' as const,
            backgroundColor: 'rgba(239, 68, 68, 0.8)',
            color: 'white',
            padding: 4
          }
        }
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Gramas (g)'
      }
    },
    x: {
      title: {
        display: true,
        text: 'Data'
      }
    }
  }
}

const averages = computed(() => {
  const fiber = sortedLogs.value.map(log => calculateDailyNutrients(log).fiber)
  const sugar = sortedLogs.value.map(log => calculateDailyNutrients(log).sugar)

  return {
    fiber: fiber.reduce((a, b) => a + b, 0) / fiber.length,
    sugar: sugar.reduce((a, b) => a + b, 0) / sugar.length
  }
})

const daysExceedingSugar = computed(() => {
  return sortedLogs.value.filter(log =>
    calculateDailyNutrients(log).sugar > RDA.sugar.max
  ).length
})

const daysMeetingFiber = computed(() => {
  return sortedLogs.value.filter(log =>
    calculateDailyNutrients(log).fiber >= RDA.fiber.min
  ).length
})
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <h3 class="text-lg font-semibold">Rastreamento de Fibras e Açúcar</h3>
        <UIcon name="i-lucide-candy" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div class="h-[350px]">
      <Line :data="chartData" :options="chartOptions" />
    </div>

    <template #footer>
      <div class="grid grid-cols-4 gap-4 text-center text-sm">
        <div>
          <p class="text-gray-500">Média Fibras</p>
          <p class="font-semibold text-green-600">{{ averages.fiber.toFixed(1) }}g</p>
        </div>
        <div>
          <p class="text-gray-500">Dias c/ Fibras OK</p>
          <p class="font-semibold">{{ daysMeetingFiber }} / {{ sortedLogs.length }}</p>
        </div>
        <div>
          <p class="text-gray-500">Média Açúcar</p>
          <p class="font-semibold text-red-600">{{ averages.sugar.toFixed(1) }}g</p>
        </div>
        <div>
          <p class="text-gray-500">Dias Excesso Açúcar</p>
          <p class="font-semibold" :class="{
            'text-green-600': daysExceedingSugar === 0,
            'text-yellow-600': daysExceedingSugar > 0 && daysExceedingSugar <= sortedLogs.length / 2,
            'text-red-600': daysExceedingSugar > sortedLogs.length / 2
          }">
            {{ daysExceedingSugar }} / {{ sortedLogs.length }}
          </p>
        </div>
      </div>
    </template>
  </Card>
</template>
