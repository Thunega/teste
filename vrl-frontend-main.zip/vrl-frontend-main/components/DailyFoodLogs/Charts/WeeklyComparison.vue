<script setup lang="ts">
import { computed } from 'vue'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import { groupLogsByWeek, calculateAverageNutrients } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const weeklyData = computed(() => {
  const weeks = groupLogsByWeek(props.logs)
  const weekKeys = Object.keys(weeks).sort()

  return weekKeys.map(weekKey => {
    const weekLogs = weeks[weekKey]
    const avgNutrients = calculateAverageNutrients(weekLogs)

    const weekStart = new Date(weekKey)
    const weekEnd = new Date(weekStart)
    weekEnd.setDate(weekStart.getDate() + 6)

    return {
      label: `${weekStart.toLocaleDateString('pt-BR', { month: 'short', day: 'numeric' })} - ${weekEnd.toLocaleDateString('pt-BR', { month: 'short', day: 'numeric' })}`,
      calories: avgNutrients?.calories || 0,
      proteins: avgNutrients?.proteins || 0,
      carbs: avgNutrients?.carbohydrates || 0,
      fats: avgNutrients?.totalFats || 0,
      fiber: avgNutrients?.fiber || 0,
      sodium: avgNutrients?.sodium || 0,
      daysCount: weekLogs.length
    }
  }).slice(-4) // Last 4 weeks
})

const caloriesChartData = computed(() => ({
  labels: weeklyData.value.map(w => w.label),
  datasets: [
    {
      label: 'Calorias Médias (kcal)',
      data: weeklyData.value.map(w => w.calories),
      backgroundColor: 'rgba(59, 130, 246, 0.8)',
      borderColor: 'rgb(59, 130, 246)',
      borderWidth: 2
    }
  ]
}))

const macrosChartData = computed(() => ({
  labels: weeklyData.value.map(w => w.label),
  datasets: [
    {
      label: 'Carboidratos (g)',
      data: weeklyData.value.map(w => w.carbs),
      backgroundColor: 'rgba(59, 130, 246, 0.8)',
      borderColor: 'rgb(59, 130, 246)',
      borderWidth: 1
    },
    {
      label: 'Proteínas (g)',
      data: weeklyData.value.map(w => w.proteins),
      backgroundColor: 'rgba(239, 68, 68, 0.8)',
      borderColor: 'rgb(239, 68, 68)',
      borderWidth: 1
    },
    {
      label: 'Gorduras (g)',
      data: weeklyData.value.map(w => w.fats),
      backgroundColor: 'rgba(245, 158, 11, 0.8)',
      borderColor: 'rgb(245, 158, 11)',
      borderWidth: 1
    }
  ]
}))

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    }
  },
  scales: {
    y: {
      beginAtZero: true
    }
  }
}

const macrosChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top' as const,
      labels: {
        usePointStyle: true,
        padding: 10
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Gramas (g)'
      }
    }
  }
}

const trends = computed(() => {
  if (weeklyData.value.length < 2) return null

  const current = weeklyData.value[weeklyData.value.length - 1]
  const previous = weeklyData.value[weeklyData.value.length - 2]

  return {
    calories: {
      change: current.calories - previous.calories,
      percentage: ((current.calories - previous.calories) / previous.calories) * 100
    },
    proteins: {
      change: current.proteins - previous.proteins,
      percentage: ((current.proteins - previous.proteins) / previous.proteins) * 100
    }
  }
})

function getTrendIcon(change: number) {
  if (change > 0) return 'i-lucide-trending-up'
  if (change < 0) return 'i-lucide-trending-down'
  return 'i-lucide-minus'
}

function getTrendColor(change: number) {
  if (change > 0) return 'text-green-600'
  if (change < 0) return 'text-red-600'
  return 'text-gray-600'
}
</script>

<template>
  <div class="space-y-4">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <!-- Calories Comparison -->
      <Card>
        <template #header>
          <div class="flex items-center justify-between">
            <h3 class="text-lg font-semibold">Comparação Semanal - Calorias</h3>
            <UIcon name="i-lucide-trending-up" class="w-5 h-5 text-gray-500" />
          </div>
        </template>

        <div class="h-[250px]">
          <Bar :data="caloriesChartData" :options="chartOptions" />
        </div>

        <template #footer v-if="trends">
          <div class="flex items-center justify-center gap-4 text-sm">
            <span class="text-gray-500">Tendência:</span>
            <div class="flex items-center gap-2">
              <UIcon :name="getTrendIcon(trends.calories.change)" class="w-4 h-4" :class="getTrendColor(trends.calories.change)" />
              <span class="font-semibold" :class="getTrendColor(trends.calories.change)">
                {{ trends.calories.change > 0 ? '+' : '' }}{{ trends.calories.change.toFixed(0) }} kcal
                ({{ trends.calories.percentage > 0 ? '+' : '' }}{{ trends.calories.percentage.toFixed(1) }}%)
              </span>
            </div>
          </div>
        </template>
      </Card>

      <!-- Macros Comparison -->
      <Card>
        <template #header>
          <div class="flex items-center justify-between">
            <h3 class="text-lg font-semibold">Comparação Semanal - Macros</h3>
            <UIcon name="i-lucide-bar-chart-3" class="w-5 h-5 text-gray-500" />
          </div>
        </template>

        <div class="h-[250px]">
          <Bar :data="macrosChartData" :options="macrosChartOptions" />
        </div>

        <template #footer v-if="trends">
          <div class="flex items-center justify-center gap-4 text-sm">
            <span class="text-gray-500">Proteínas:</span>
            <div class="flex items-center gap-2">
              <UIcon :name="getTrendIcon(trends.proteins.change)" class="w-4 h-4" :class="getTrendColor(trends.proteins.change)" />
              <span class="font-semibold" :class="getTrendColor(trends.proteins.change)">
                {{ trends.proteins.change > 0 ? '+' : '' }}{{ trends.proteins.change.toFixed(1) }}g
                ({{ trends.proteins.percentage > 0 ? '+' : '' }}{{ trends.proteins.percentage.toFixed(1) }}%)
              </span>
            </div>
          </div>
        </template>
      </Card>
    </div>

    <!-- Week Summary Cards -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
      <Card v-for="(week, idx) in weeklyData" :key="idx">
        <div class="text-center">
          <p class="text-xs text-gray-500 mb-2">{{ week.label }}</p>
          <p class="text-2xl font-bold">{{ week.calories.toFixed(0) }}</p>
          <p class="text-xs text-gray-500">kcal/dia</p>
          <p class="text-xs text-gray-400 mt-1">{{ week.daysCount }} dias</p>
        </div>
      </Card>
    </div>
  </div>
</template>
