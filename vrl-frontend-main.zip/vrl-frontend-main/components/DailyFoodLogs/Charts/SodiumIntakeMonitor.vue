<script setup lang="ts">
import { computed } from 'vue'
import { Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js'
import { calculateDailyNutrients, RDA } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

// Dynamic import for annotation plugin to avoid SSR issues
if (process.client) {
  import('chartjs-plugin-annotation').then(module => {
    ChartJS.register(module.default)
  })
}

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
)

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const sortedLogs = computed(() => {
  return [...props.logs].sort((a, b) =>
    new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime()
  )
})

const chartData = computed(() => {
  const labels = sortedLogs.value.map(log =>
    new Date(log.dateOfRegistration).toLocaleDateString('pt-BR', {
      month: 'short',
      day: 'numeric'
    })
  )

  const sodiumData = sortedLogs.value.map(log => calculateDailyNutrients(log).sodium)

  // Create segment colors based on safe limit
  const pointColors = sodiumData.map(sodium => {
    if (sodium <= RDA.sodium.max * 0.7) return 'rgb(34, 197, 94)' // green - safe
    if (sodium <= RDA.sodium.max) return 'rgb(250, 204, 21)' // yellow - caution
    return 'rgb(239, 68, 68)' // red - danger
  })

  return {
    labels,
    datasets: [
      {
        label: 'Sódio (mg)',
        data: sodiumData,
        borderColor: 'rgb(147, 51, 234)',
        backgroundColor: 'rgba(147, 51, 234, 0.1)',
        pointBackgroundColor: pointColors,
        pointBorderColor: pointColors,
        pointRadius: 6,
        pointHoverRadius: 8,
        tension: 0.4,
        fill: true
      }
    ]
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    mode: 'index' as const,
    intersect: false,
  },
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      callbacks: {
        label: function(context: any) {
          const value = context.parsed.y
          const percentage = (value / RDA.sodium.max) * 100
          const status = value > RDA.sodium.max ? '⚠️ EXCESSO' : '✓ OK'
          return [
            `Sódio: ${value.toFixed(0)} mg`,
            `${percentage.toFixed(0)}% do limite diário`,
            status
          ]
        }
      }
    },
    annotation: {
      annotations: {
        safeZone: {
          type: 'box' as const,
          yMin: 0,
          yMax: RDA.sodium.max * 0.7,
          backgroundColor: 'rgba(34, 197, 94, 0.1)',
          borderWidth: 0
        },
        cautionZone: {
          type: 'box' as const,
          yMin: RDA.sodium.max * 0.7,
          yMax: RDA.sodium.max,
          backgroundColor: 'rgba(250, 204, 21, 0.1)',
          borderWidth: 0
        },
        dangerZone: {
          type: 'box' as const,
          yMin: RDA.sodium.max,
          yMax: RDA.sodium.max * 1.5,
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          borderWidth: 0
        },
        maxLine: {
          type: 'line' as const,
          yMin: RDA.sodium.max,
          yMax: RDA.sodium.max,
          borderColor: 'rgb(239, 68, 68)',
          borderWidth: 2,
          borderDash: [5, 5],
          label: {
            display: true,
            content: `Limite Seguro: ${RDA.sodium.max} mg`,
            position: 'end' as const,
            backgroundColor: 'rgb(239, 68, 68)',
            color: 'white',
            padding: 4
          }
        }
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Sódio (mg)'
      }
    },
    x: {
      title: {
        display: true,
        text: 'Data'
      }
    }
  }
}

const stats = computed(() => {
  const sodium = sortedLogs.value.map(log => calculateDailyNutrients(log).sodium)
  const avg = sodium.reduce((a, b) => a + b, 0) / sodium.length
  const daysExceeding = sodium.filter(s => s > RDA.sodium.max).length
  const maxDay = Math.max(...sodium)

  return {
    average: avg,
    daysExceeding,
    maxDay,
    riskLevel: avg > RDA.sodium.max ? 'high' : avg > RDA.sodium.max * 0.7 ? 'moderate' : 'low'
  }
})
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <div>
          <h3 class="text-lg font-semibold">Monitor de Sódio</h3>
          <p class="text-xs text-gray-500">Importante para saúde cardiovascular</p>
        </div>
        <UIcon name="i-lucide-heart-pulse" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div class="h-[350px]">
      <Line :data="chartData" :options="chartOptions" />
    </div>

    <template #footer>
      <div class="grid grid-cols-4 gap-4 text-center text-sm">
        <div>
          <p class="text-gray-500">Média Diária</p>
          <p class="font-semibold">{{ stats.average.toFixed(0) }} mg</p>
        </div>
        <div>
          <p class="text-gray-500">Dias Excedendo</p>
          <p class="font-semibold" :class="{
            'text-green-600': stats.daysExceeding === 0,
            'text-yellow-600': stats.daysExceeding > 0 && stats.daysExceeding <= sortedLogs.length / 3,
            'text-red-600': stats.daysExceeding > sortedLogs.length / 3
          }">
            {{ stats.daysExceeding }} / {{ sortedLogs.length }}
          </p>
        </div>
        <div>
          <p class="text-gray-500">Pico Máximo</p>
          <p class="font-semibold" :class="{
            'text-green-600': stats.maxDay <= RDA.sodium.max * 0.7,
            'text-yellow-600': stats.maxDay > RDA.sodium.max * 0.7 && stats.maxDay <= RDA.sodium.max,
            'text-red-600': stats.maxDay > RDA.sodium.max
          }">
            {{ stats.maxDay.toFixed(0) }} mg
          </p>
        </div>
        <div>
          <p class="text-gray-500">Nível de Risco</p>
          <p class="font-semibold" :class="{
            'text-green-600': stats.riskLevel === 'low',
            'text-yellow-600': stats.riskLevel === 'moderate',
            'text-red-600': stats.riskLevel === 'high'
          }">
            {{ stats.riskLevel === 'low' ? 'Baixo' : stats.riskLevel === 'moderate' ? 'Moderado' : 'Alto' }}
          </p>
        </div>
      </div>
    </template>
  </Card>
</template>
