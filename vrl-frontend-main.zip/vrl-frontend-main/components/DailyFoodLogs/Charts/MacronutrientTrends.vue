<script setup lang="ts">
import { computed } from 'vue'
import { Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js'
import { calculateDailyNutrients, RDA } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
)

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const sortedLogs = computed(() => {
  return [...props.logs].sort((a, b) =>
    new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime()
  )
})

const chartData = computed(() => {
  const labels = sortedLogs.value.map(log =>
    new Date(log.dateOfRegistration).toLocaleDateString('pt-BR', {
      month: 'short',
      day: 'numeric'
    })
  )

  const carbsData = sortedLogs.value.map(log => calculateDailyNutrients(log).carbohydrates)
  const proteinsData = sortedLogs.value.map(log => calculateDailyNutrients(log).proteins)
  const fatsData = sortedLogs.value.map(log => calculateDailyNutrients(log).totalFats)

  return {
    labels,
    datasets: [
      {
        label: 'Carboidratos (g)',
        data: carbsData,
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Proteínas (g)',
        data: proteinsData,
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Gorduras (g)',
        data: fatsData,
        borderColor: 'rgb(245, 158, 11)',
        backgroundColor: 'rgba(245, 158, 11, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    mode: 'index' as const,
    intersect: false,
  },
  plugins: {
    legend: {
      position: 'top' as const,
      labels: {
        padding: 15,
        usePointStyle: true
      }
    },
    tooltip: {
      callbacks: {
        label: function(context: any) {
          return `${context.dataset.label}: ${context.parsed.y.toFixed(1)}g`
        }
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Gramas (g)'
      }
    },
    x: {
      title: {
        display: true,
        text: 'Data'
      }
    }
  }
}
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <h3 class="text-lg font-semibold">Tendência de Macronutrientes</h3>
        <UIcon name="i-lucide-trending-up" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div class="h-[350px]">
      <Line :data="chartData" :options="chartOptions" />
    </div>

    <template #footer>
      <div class="grid grid-cols-3 gap-4 text-center text-sm">
        <div>
          <p class="text-gray-500">Meta Carboidratos</p>
          <p class="font-semibold text-blue-600">{{ RDA.carbohydrates.target }}g</p>
        </div>
        <div>
          <p class="text-gray-500">Meta Proteínas</p>
          <p class="font-semibold text-red-600">{{ RDA.proteins.target }}g</p>
        </div>
        <div>
          <p class="text-gray-500">Meta Gorduras</p>
          <p class="font-semibold text-amber-600">{{ RDA.totalFats.target }}g</p>
        </div>
      </div>
    </template>
  </Card>
</template>
