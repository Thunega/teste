<script setup lang="ts">
import { computed } from 'vue'
import { calculateAverageNutrients, calculateMacroPercentages, RDA } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const averageNutrients = computed(() => calculateAverageNutrients(props.logs))
const macroPercentages = computed(() =>
  averageNutrients.value ? calculateMacroPercentages(averageNutrients.value) : null
)

const caloriesTrend = computed(() => {
  if (!averageNutrients.value) return 'neutral'
  const avg = averageNutrients.value.calories
  if (avg < RDA.calories.min) return 'low'
  if (avg > RDA.calories.max) return 'high'
  return 'good'
})

const proteinStatus = computed(() => {
  if (!averageNutrients.value) return 'neutral'
  const avg = averageNutrients.value.proteins
  if (avg < RDA.proteins.min) return 'low'
  if (avg > RDA.proteins.max) return 'high'
  return 'good'
})

const fiberStatus = computed(() => {
  if (!averageNutrients.value) return 'neutral'
  const avg = averageNutrients.value.fiber
  if (avg < RDA.fiber.min) return 'low'
  return 'good'
})

const sodiumStatus = computed(() => {
  if (!averageNutrients.value) return 'neutral'
  const avg = averageNutrients.value.sodium
  if (avg > RDA.sodium.max) return 'high'
  if (avg > RDA.sodium.max * 0.7) return 'moderate'
  return 'good'
})
</script>

<template>
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
    <!-- Average Calories Card -->
    <Card>
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm text-gray-500">Calorias Médias</p>
          <p class="text-2xl font-bold mt-1">
            {{ averageNutrients?.calories.toFixed(0) || 0 }}
          </p>
          <p class="text-xs text-gray-500">kcal/dia</p>
        </div>
        <div class="w-12 h-12 rounded-full flex items-center justify-center" :class="{
          'bg-green-100 dark:bg-green-900': caloriesTrend === 'good',
          'bg-yellow-100 dark:bg-yellow-900': caloriesTrend === 'neutral',
          'bg-orange-100 dark:bg-orange-900': caloriesTrend === 'low',
          'bg-red-100 dark:bg-red-900': caloriesTrend === 'high'
        }">
          <UIcon name="i-lucide-flame" class="w-6 h-6" :class="{
            'text-green-600': caloriesTrend === 'good',
            'text-yellow-600': caloriesTrend === 'neutral',
            'text-orange-600': caloriesTrend === 'low',
            'text-red-600': caloriesTrend === 'high'
          }" />
        </div>
      </div>
      <div class="mt-2 text-xs">
        <span class="text-gray-500">Meta: </span>
        <span class="font-semibold">{{ RDA.calories.target }} kcal</span>
      </div>
    </Card>

    <!-- Macronutrient Ratio Card -->
    <Card>
      <div class="flex items-center justify-between">
        <div class="flex-1">
          <p class="text-sm text-gray-500">Proporção Macros</p>
          <div class="mt-2 space-y-1">
            <div class="flex justify-between text-xs">
              <span>Carbs</span>
              <span class="font-semibold text-blue-600">{{ macroPercentages?.carbsPercent.toFixed(0) }}%</span>
            </div>
            <div class="flex justify-between text-xs">
              <span>Proteínas</span>
              <span class="font-semibold text-red-600">{{ macroPercentages?.proteinsPercent.toFixed(0) }}%</span>
            </div>
            <div class="flex justify-between text-xs">
              <span>Gorduras</span>
              <span class="font-semibold text-amber-600">{{ macroPercentages?.fatsPercent.toFixed(0) }}%</span>
            </div>
          </div>
        </div>
        <div class="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
          <UIcon name="i-lucide-pie-chart" class="w-6 h-6 text-purple-600" />
        </div>
      </div>
    </Card>

    <!-- Protein Status Card -->
    <Card>
      <div class="flex items-center justify-between">
        <div>
          <p class="text-sm text-gray-500">Proteínas Médias</p>
          <p class="text-2xl font-bold mt-1">
            {{ averageNutrients?.proteins.toFixed(1) || 0 }}
          </p>
          <p class="text-xs text-gray-500">g/dia</p>
        </div>
        <div class="w-12 h-12 rounded-full flex items-center justify-center" :class="{
          'bg-green-100 dark:bg-green-900': proteinStatus === 'good',
          'bg-orange-100 dark:bg-orange-900': proteinStatus === 'low',
          'bg-red-100 dark:bg-red-900': proteinStatus === 'high'
        }">
          <UIcon name="i-lucide-beef" class="w-6 h-6" :class="{
            'text-green-600': proteinStatus === 'good',
            'text-orange-600': proteinStatus === 'low',
            'text-red-600': proteinStatus === 'high'
          }" />
        </div>
      </div>
      <div class="mt-2 text-xs">
        <span class="text-gray-500">Meta: </span>
        <span class="font-semibold">{{ RDA.proteins.target }}g</span>
      </div>
    </Card>

    <!-- Fiber & Sodium Card -->
    <Card>
      <div class="space-y-3">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-xs text-gray-500">Fibras</p>
            <p class="text-lg font-bold">{{ averageNutrients?.fiber.toFixed(1) || 0 }}g</p>
          </div>
          <div class="w-8 h-8 rounded-full flex items-center justify-center" :class="{
            'bg-green-100 dark:bg-green-900': fiberStatus === 'good',
            'bg-orange-100 dark:bg-orange-900': fiberStatus === 'low'
          }">
            <UIcon name="i-lucide-wheat" class="w-4 h-4" :class="{
              'text-green-600': fiberStatus === 'good',
              'text-orange-600': fiberStatus === 'low'
            }" />
          </div>
        </div>
        <div class="flex items-center justify-between border-t pt-3">
          <div>
            <p class="text-xs text-gray-500">Sódio</p>
            <p class="text-lg font-bold">{{ averageNutrients?.sodium.toFixed(0) || 0 }}mg</p>
          </div>
          <div class="w-8 h-8 rounded-full flex items-center justify-center" :class="{
            'bg-green-100 dark:bg-green-900': sodiumStatus === 'good',
            'bg-yellow-100 dark:bg-yellow-900': sodiumStatus === 'moderate',
            'bg-red-100 dark:bg-red-900': sodiumStatus === 'high'
          }">
            <UIcon name="i-lucide-droplet" class="w-4 h-4" :class="{
              'text-green-600': sodiumStatus === 'good',
              'text-yellow-600': sodiumStatus === 'moderate',
              'text-red-600': sodiumStatus === 'high'
            }" />
          </div>
        </div>
      </div>
    </Card>
  </div>
</template>
