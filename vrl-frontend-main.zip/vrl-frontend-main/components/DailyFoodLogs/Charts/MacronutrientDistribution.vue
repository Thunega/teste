<script setup lang="ts">
import { computed } from 'vue'
import { Doughnut } from 'vue-chartjs'
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js'
import { calculateDailyNutrients, calculateMacroPercentages } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

ChartJS.register(ArcElement, Tooltip, Legend)

const props = defineProps<{
  log: DailyFoodLog
}>()

const nutrients = computed(() => calculateDailyNutrients(props.log))
const macroPercentages = computed(() => calculateMacroPercentages(nutrients.value))

const chartData = computed(() => ({
  labels: ['Carboidratos', 'Proteínas', 'Gorduras'],
  datasets: [
    {
      data: [
        macroPercentages.value.carbsPercent,
        macroPercentages.value.proteinsPercent,
        macroPercentages.value.fatsPercent
      ],
      backgroundColor: [
        'rgba(59, 130, 246, 0.8)', // blue-500
        'rgba(239, 68, 68, 0.8)', // red-500
        'rgba(245, 158, 11, 0.8)' // amber-500
      ],
      borderColor: [
        'rgb(59, 130, 246)',
        'rgb(239, 68, 68)',
        'rgb(245, 158, 11)'
      ],
      borderWidth: 2
    }
  ]
}))

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom' as const,
      labels: {
        padding: 15,
        font: {
          size: 12
        }
      }
    },
    tooltip: {
      callbacks: {
        label: function(context: any) {
          const label = context.label || ''
          const value = context.parsed || 0
          return `${label}: ${value.toFixed(1)}%`
        }
      }
    }
  }
}
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <h3 class="text-lg font-semibold">Distribuição de Macronutrientes</h3>
        <UIcon name="i-lucide-pie-chart" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div class="h-[300px]">
      <Doughnut :data="chartData" :options="chartOptions" />
    </div>

    <template #footer>
      <div class="grid grid-cols-3 gap-4 text-center text-sm">
        <div>
          <p class="text-gray-500">Carboidratos</p>
          <p class="font-semibold">{{ nutrients.carbohydrates.toFixed(1) }}g</p>
        </div>
        <div>
          <p class="text-gray-500">Proteínas</p>
          <p class="font-semibold">{{ nutrients.proteins.toFixed(1) }}g</p>
        </div>
        <div>
          <p class="text-gray-500">Gorduras</p>
          <p class="font-semibold">{{ nutrients.totalFats.toFixed(1) }}g</p>
        </div>
      </div>
    </template>
  </Card>
</template>
