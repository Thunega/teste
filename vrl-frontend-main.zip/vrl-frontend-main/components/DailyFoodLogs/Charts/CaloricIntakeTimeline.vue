<script setup lang="ts">
import { computed } from 'vue'
import { Bar } from 'vue-chartjs'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import { calculateDailyNutrients, RDA } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

// Dynamic import for annotation plugin to avoid SSR issues
let annotationPlugin: any = null
if (process.client) {
  import('chartjs-plugin-annotation').then(module => {
    annotationPlugin = module.default
    ChartJS.register(annotationPlugin)
  })
}

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const sortedLogs = computed(() => {
  return [...props.logs].sort((a, b) =>
    new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime()
  )
})

const chartData = computed(() => {
  const labels = sortedLogs.value.map(log =>
    new Date(log.dateOfRegistration).toLocaleDateString('pt-BR', {
      month: 'short',
      day: 'numeric'
    })
  )

  const caloriesData = sortedLogs.value.map(log => {
    const nutrients = calculateDailyNutrients(log)
    return nutrients.calories
  })

  // Color bars based on target
  const backgroundColors = caloriesData.map(cal => {
    if (cal < RDA.calories.min) return 'rgba(251, 146, 60, 0.8)' // orange - too low
    if (cal > RDA.calories.max) return 'rgba(239, 68, 68, 0.8)' // red - too high
    return 'rgba(34, 197, 94, 0.8)' // green - good
  })

  const borderColors = caloriesData.map(cal => {
    if (cal < RDA.calories.min) return 'rgb(251, 146, 60)'
    if (cal > RDA.calories.max) return 'rgb(239, 68, 68)'
    return 'rgb(34, 197, 94)'
  })

  return {
    labels,
    datasets: [
      {
        label: 'Calorias Consumidas',
        data: caloriesData,
        backgroundColor: backgroundColors,
        borderColor: borderColors,
        borderWidth: 2
      }
    ]
  }
})

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      display: false
    },
    tooltip: {
      callbacks: {
        label: function(context: any) {
          const value = context.parsed.y
          const target = RDA.calories.target
          const diff = value - target
          const status = diff > 0 ? `+${diff.toFixed(0)}` : diff.toFixed(0)
          return [
            `Calorias: ${value.toFixed(0)} kcal`,
            `Diferença da meta: ${status} kcal`
          ]
        }
      }
    },
    annotation: {
      annotations: {
        targetLine: {
          type: 'line' as const,
          yMin: RDA.calories.target,
          yMax: RDA.calories.target,
          borderColor: 'rgb(59, 130, 246)',
          borderWidth: 2,
          borderDash: [5, 5],
          label: {
            display: true,
            content: `Meta: ${RDA.calories.target} kcal`,
            position: 'end' as const,
            backgroundColor: 'rgb(59, 130, 246)',
            color: 'white',
            padding: 4
          }
        },
        minLine: {
          type: 'line' as const,
          yMin: RDA.calories.min,
          yMax: RDA.calories.min,
          borderColor: 'rgba(251, 146, 60, 0.5)',
          borderWidth: 1,
          borderDash: [3, 3]
        },
        maxLine: {
          type: 'line' as const,
          yMin: RDA.calories.max,
          yMax: RDA.calories.max,
          borderColor: 'rgba(239, 68, 68, 0.5)',
          borderWidth: 1,
          borderDash: [3, 3]
        }
      }
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Calorias (kcal)'
      }
    },
    x: {
      title: {
        display: true,
        text: 'Data'
      }
    }
  }
}

const stats = computed(() => {
  const calories = sortedLogs.value.map(log => calculateDailyNutrients(log).calories)
  const avg = calories.reduce((a, b) => a + b, 0) / calories.length
  const daysOnTarget = calories.filter(c => c >= RDA.calories.min && c <= RDA.calories.max).length
  const adherenceRate = (daysOnTarget / calories.length) * 100

  return {
    average: avg,
    daysOnTarget,
    adherenceRate
  }
})
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <h3 class="text-lg font-semibold">Linha do Tempo de Calorias</h3>
        <UIcon name="i-lucide-bar-chart-3" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div class="h-[350px]">
      <Bar :data="chartData" :options="chartOptions" />
    </div>

    <template #footer>
      <div class="grid grid-cols-3 gap-4 text-center text-sm">
        <div>
          <p class="text-gray-500">Média Diária</p>
          <p class="font-semibold">{{ stats.average.toFixed(0) }} kcal</p>
        </div>
        <div>
          <p class="text-gray-500">Dias na Meta</p>
          <p class="font-semibold">{{ stats.daysOnTarget }} / {{ sortedLogs.length }}</p>
        </div>
        <div>
          <p class="text-gray-500">Taxa de Aderência</p>
          <p class="font-semibold" :class="{
            'text-green-600': stats.adherenceRate >= 80,
            'text-yellow-600': stats.adherenceRate >= 60 && stats.adherenceRate < 80,
            'text-red-600': stats.adherenceRate < 60
          }">
            {{ stats.adherenceRate.toFixed(0) }}%
          </p>
        </div>
      </div>
    </template>
  </Card>
</template>
