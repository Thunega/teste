<script setup lang="ts">
import { computed } from 'vue'
import { calculateAverageNutrients, calculateNutrientAdequacy, getNutrientStatus, RDA } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const averageNutrients = computed(() => calculateAverageNutrients(props.logs))

const nutrients = [
  { key: 'vitaminA', label: 'Vitamina A', unit: 'μg', icon: 'i-lucide-eye' },
  { key: 'vitaminB1', label: 'Vitamina B1', unit: 'mg', icon: 'i-lucide-zap' },
  { key: 'vitaminB2', label: 'Vitamina B2', unit: 'mg', icon: 'i-lucide-zap' },
  { key: 'vitaminB3', label: 'Vitamina B3', unit: 'mg', icon: 'i-lucide-zap' },
  { key: 'vitaminB6', label: 'Vitamina B6', unit: 'mg', icon: 'i-lucide-brain' },
  { key: 'vitaminB9', label: 'Vitamina B9', unit: 'μg', icon: 'i-lucide-dna' },
  { key: 'vitaminB12', label: 'Vitamina B12', unit: 'μg', icon: 'i-lucide-activity' },
  { key: 'vitaminC', label: 'Vitamina C', unit: 'mg', icon: 'i-lucide-shield' },
  { key: 'vitaminD', label: 'Vitamina D', unit: 'μg', icon: 'i-lucide-sun' },
  { key: 'vitaminE', label: 'Vitamina E', unit: 'mg', icon: 'i-lucide-heart' },
  { key: 'vitaminK', label: 'Vitamina K', unit: 'μg', icon: 'i-lucide-droplet' },
  { key: 'calcium', label: 'Cálcio', unit: 'mg', icon: 'i-lucide-bone' },
  { key: 'iron', label: 'Ferro', unit: 'mg', icon: 'i-lucide-droplets' },
  { key: 'magnesium', label: 'Magnésio', unit: 'mg', icon: 'i-lucide-sparkles' },
  { key: 'zinc', label: 'Zinco', unit: 'mg', icon: 'i-lucide-shield-check' },
  { key: 'potassium', label: 'Potássio', unit: 'mg', icon: 'i-lucide-heart-pulse' }
]

const nutrientData = computed(() => {
  if (!averageNutrients.value) return []

  return nutrients.map(nutrient => {
    const value = averageNutrients.value[nutrient.key] || 0
    const adequacy = calculateNutrientAdequacy(nutrient.key, value)
    const status = getNutrientStatus(nutrient.key, value)
    const rda = RDA[nutrient.key]

    return {
      ...nutrient,
      value,
      adequacy,
      status,
      rda
    }
  }).sort((a, b) => a.adequacy - b.adequacy) // Sort by adequacy (worst first)
})

const criticalDeficiencies = computed(() =>
  nutrientData.value.filter(n => n.status === 'deficient')
)

const lowNutrients = computed(() =>
  nutrientData.value.filter(n => n.status === 'low')
)

const adequateNutrients = computed(() =>
  nutrientData.value.filter(n => n.status === 'adequate')
)

function getStatusColor(status: string) {
  switch (status) {
    case 'deficient': return 'bg-red-500'
    case 'low': return 'bg-orange-400'
    case 'adequate': return 'bg-green-500'
    case 'high': return 'bg-yellow-400'
    case 'excess': return 'bg-orange-400'
    default: return 'bg-gray-400'
  }
}

function getStatusTextColor(status: string) {
  switch (status) {
    case 'deficient': return 'text-red-600'
    case 'low': return 'text-orange-600'
    case 'adequate': return 'text-green-600'
    case 'high': return 'text-yellow-600'
    case 'excess': return 'text-orange-600'
    default: return 'text-gray-600'
  }
}

function getStatusLabel(status: string) {
  switch (status) {
    case 'deficient': return 'Deficiente'
    case 'low': return 'Baixo'
    case 'adequate': return 'Adequado'
    case 'high': return 'Alto'
    case 'excess': return 'Excesso'
    default: return 'Desconhecido'
  }
}
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <div>
          <h3 class="text-lg font-semibold">Alertas de Adequação Nutricional</h3>
          <p class="text-xs text-gray-500">Baseado na média dos últimos {{ logs.length }} dias</p>
        </div>
        <UIcon name="i-lucide-alert-triangle" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <!-- Critical Deficiencies -->
    <div v-if="criticalDeficiencies.length > 0" class="mb-4 p-3 bg-red-50 dark:bg-red-950 rounded-lg">
      <div class="flex items-center gap-2 mb-2">
        <UIcon name="i-lucide-alert-circle" class="w-5 h-5 text-red-600" />
        <h4 class="font-semibold text-red-600">Deficiências Críticas ({{ criticalDeficiencies.length }})</h4>
      </div>
      <div class="space-y-2">
        <div v-for="nutrient in criticalDeficiencies" :key="nutrient.key" class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <UIcon :name="nutrient.icon" class="w-4 h-4 text-red-600" />
            <span class="text-sm font-medium">{{ nutrient.label }}</span>
          </div>
          <div class="text-right">
            <span class="text-sm font-semibold text-red-600">{{ nutrient.adequacy.toFixed(0) }}%</span>
            <span class="text-xs text-gray-500 ml-2">({{ nutrient.value.toFixed(1) }} {{ nutrient.unit }})</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Low Nutrients -->
    <div v-if="lowNutrients.length > 0" class="mb-4 p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
      <div class="flex items-center gap-2 mb-2">
        <UIcon name="i-lucide-alert-triangle" class="w-5 h-5 text-orange-600" />
        <h4 class="font-semibold text-orange-600">Abaixo do Recomendado ({{ lowNutrients.length }})</h4>
      </div>
      <div class="space-y-2">
        <div v-for="nutrient in lowNutrients" :key="nutrient.key" class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <UIcon :name="nutrient.icon" class="w-4 h-4 text-orange-600" />
            <span class="text-sm">{{ nutrient.label }}</span>
          </div>
          <div class="text-right">
            <span class="text-sm font-semibold text-orange-600">{{ nutrient.adequacy.toFixed(0) }}%</span>
            <span class="text-xs text-gray-500 ml-2">({{ nutrient.value.toFixed(1) }} {{ nutrient.unit }})</span>
          </div>
        </div>
      </div>
    </div>

    <!-- All Nutrients Progress Bars -->
    <div class="space-y-3">
      <h4 class="font-semibold text-sm text-gray-700 dark:text-gray-300">Todos os Nutrientes</h4>
      <div class="space-y-3">
        <div v-for="nutrient in nutrientData" :key="nutrient.key" class="space-y-1">
          <div class="flex items-center justify-between text-xs">
            <div class="flex items-center gap-2">
              <UIcon :name="nutrient.icon" class="w-3 h-3" />
              <span class="font-medium">{{ nutrient.label }}</span>
            </div>
            <div class="flex items-center gap-2">
              <span :class="getStatusTextColor(nutrient.status)" class="font-semibold">
                {{ nutrient.adequacy.toFixed(0) }}%
              </span>
              <span class="text-gray-500">{{ nutrient.value.toFixed(1) }}/{{ nutrient.rda }} {{ nutrient.unit }}</span>
            </div>
          </div>
          <div class="relative w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              class="absolute left-0 top-0 h-full rounded-full transition-all"
              :class="getStatusColor(nutrient.status)"
              :style="{ width: `${Math.min(nutrient.adequacy, 100)}%` }"
            ></div>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <div class="grid grid-cols-3 gap-4 text-center text-sm">
        <div>
          <p class="text-gray-500">Adequados</p>
          <p class="font-semibold text-green-600">{{ adequateNutrients.length }}</p>
        </div>
        <div>
          <p class="text-gray-500">Baixos</p>
          <p class="font-semibold text-orange-600">{{ lowNutrients.length }}</p>
        </div>
        <div>
          <p class="text-gray-500">Críticos</p>
          <p class="font-semibold text-red-600">{{ criticalDeficiencies.length }}</p>
        </div>
      </div>
    </template>
  </Card>
</template>
