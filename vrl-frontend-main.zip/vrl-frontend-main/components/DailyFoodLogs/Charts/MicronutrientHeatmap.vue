<script setup lang="ts">
import { computed } from 'vue'
import { calculateDailyNutrients, calculateNutrientAdequacy, getAdequacyColor, RDA } from '~/utils/nutritionCalculations'
import type { DailyFoodLog } from '~/utils/nutritionCalculations'

const props = defineProps<{
  logs: DailyFoodLog[]
}>()

const micronutrients = [
  { key: 'vitaminA', label: 'Vit A' },
  { key: 'vitaminB1', label: 'Vit B1' },
  { key: 'vitaminB2', label: 'Vit B2' },
  { key: 'vitaminB3', label: 'Vit B3' },
  { key: 'vitaminB6', label: 'Vit B6' },
  { key: 'vitaminB9', label: 'Vit B9' },
  { key: 'vitaminB12', label: 'Vit B12' },
  { key: 'vitaminC', label: 'Vit C' },
  { key: 'vitaminD', label: 'Vit D' },
  { key: 'vitaminE', label: 'Vit E' },
  { key: 'vitaminK', label: 'Vit K' },
  { key: 'calcium', label: 'Cálcio' },
  { key: 'iron', label: 'Ferro' },
  { key: 'magnesium', label: 'Magnésio' },
  { key: 'potassium', label: 'Potássio' },
  { key: 'zinc', label: 'Zinco' }
]

const sortedLogs = computed(() => {
  return [...props.logs].sort((a, b) =>
    new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime()
  ).slice(-7) // Last 7 days
})

const heatmapData = computed(() => {
  return sortedLogs.value.map(log => {
    const nutrients = calculateDailyNutrients(log)
    const date = new Date(log.dateOfRegistration).toLocaleDateString('pt-BR', {
      month: 'short',
      day: 'numeric'
    })

    return {
      date,
      nutrients: micronutrients.map(micro => ({
        key: micro.key,
        label: micro.label,
        value: nutrients[micro.key] || 0,
        adequacy: calculateNutrientAdequacy(micro.key, nutrients[micro.key] || 0),
        color: getAdequacyColor(calculateNutrientAdequacy(micro.key, nutrients[micro.key] || 0))
      }))
    }
  })
})
</script>

<template>
  <Card>
    <template #header>
      <div class="flex items-center justify-between">
        <div>
          <h3 class="text-lg font-semibold">Mapa de Calor de Micronutrientes</h3>
          <p class="text-sm text-gray-500">% da Ingestão Diária Recomendada</p>
        </div>
        <UIcon name="i-lucide-grid-3x3" class="w-5 h-5 text-gray-500" />
      </div>
    </template>

    <div class="overflow-x-auto">
      <table class="w-full text-xs">
        <thead>
          <tr class="border-b">
            <th class="py-2 px-2 text-left sticky left-0 bg-white dark:bg-gray-900">Nutriente</th>
            <th v-for="day in heatmapData" :key="day.date" class="py-2 px-2 text-center">
              {{ day.date }}
            </th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="micro in micronutrients" :key="micro.key" class="border-b hover:bg-gray-50 dark:hover:bg-gray-800">
            <td class="py-2 px-2 font-medium sticky left-0 bg-white dark:bg-gray-900">
              {{ micro.label }}
            </td>
            <td v-for="day in heatmapData" :key="`${day.date}-${micro.key}`" class="py-2 px-2">
              <div
                class="w-full h-8 rounded flex items-center justify-center font-semibold text-white"
                :style="{
                  backgroundColor: day.nutrients.find(n => n.key === micro.key)?.color
                }"
                :title="`${day.nutrients.find(n => n.key === micro.key)?.value.toFixed(1)} (${day.nutrients.find(n => n.key === micro.key)?.adequacy.toFixed(0)}% RDA)`"
              >
                {{ day.nutrients.find(n => n.key === micro.key)?.adequacy.toFixed(0) }}%
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <template #footer>
      <div class="flex items-center justify-center gap-6 text-xs">
        <div class="flex items-center gap-2">
          <div class="w-4 h-4 rounded bg-red-500"></div>
          <span>&lt; 50%</span>
        </div>
        <div class="flex items-center gap-2">
          <div class="w-4 h-4 rounded bg-orange-400"></div>
          <span>50-79%</span>
        </div>
        <div class="flex items-center gap-2">
          <div class="w-4 h-4 rounded bg-yellow-400"></div>
          <span>80-99%</span>
        </div>
        <div class="flex items-center gap-2">
          <div class="w-4 h-4 rounded bg-green-500"></div>
          <span>100-120%</span>
        </div>
        <div class="flex items-center gap-2">
          <div class="w-4 h-4 rounded bg-orange-400"></div>
          <span>&gt; 120%</span>
        </div>
      </div>
    </template>
  </Card>
</template>
