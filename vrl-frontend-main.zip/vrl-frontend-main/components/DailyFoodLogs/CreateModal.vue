<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const dailyFoodLogsStore = useDailyFoodLogsStore();
const open = ref(false);

// Expose method to auto-fill form from JSON
defineExpose({
  openWithData,
});

const numericField = z.coerce.number().optional();

const foodItemSchema = z.object({
  name: z
    .string({
      required_error: "O nome do alimento é obrigatório.",
      invalid_type_error: "O nome do alimento é obrigatório.",
    })
    .min(1, "Nome do alimento é obrigatório."),
  brand: z.string().optional(),
  quantity: z.coerce
    .number({
      invalid_type_error: "A quantidade deve ser um número.",
      required_error: "A quantidade é obrigatória.",
    })
    .positive("A quantidade deve ser positiva."),
  unit: z
    .string({
      required_error: "A unidade é obrigatória.",
      invalid_type_error: "A unidade é obrigatória.",
    })
    .min(1, "Unidade é obrigatória."),

  // Macronutrientes
  calories: numericField,
  carbohydrates: numericField,
  proteins: numericField,
  totalFats: numericField,
  saturatedFats: numericField,
  transFats: numericField,
  monounsaturatedFats: numericField,
  polyunsaturatedFats: numericField,
  cholesterol: numericField,
  fiber: numericField,
  sugar: numericField,
  sodium: numericField,

  // Vitaminas
  vitaminA: numericField,
  vitaminB1: numericField,
  vitaminB2: numericField,
  vitaminB3: numericField,
  vitaminB5: numericField,
  vitaminB6: numericField,
  vitaminB7: numericField,
  vitaminB9: numericField,
  vitaminB12: numericField,
  vitaminC: numericField,
  vitaminD: numericField,
  vitaminE: numericField,
  vitaminK: numericField,

  // Minerais
  calcium: numericField,
  iron: numericField,
  magnesium: numericField,
  phosphorus: numericField,
  potassium: numericField,
  zinc: numericField,
  copper: numericField,
  manganese: numericField,
  selenium: numericField,
  iodine: numericField,

  // Outros
  omega3: numericField,
  omega6: numericField,
  caffeine: numericField,
  notes: z.string().optional(),
});

const mealRecordSchema = z.object({
  mealTime: z
    .string({
      required_error: "O horário da refeição é obrigatório.",
      invalid_type_error: "O horário da refeição é obrigatório.",
    })
    .min(1, "Horário da refeição é obrigatório."),
  description: z.string().optional(),
  foods: z.array(foodItemSchema).optional(),
});

const schema = z.object({
  dateOfRegistration: z.string({
    required_error: "A data de registro é obrigatória.",
    invalid_type_error: "A data de registro é obrigatória.",
  }),
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  meals: z.array(mealRecordSchema).optional(),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  dateOfRegistration: "",
  patientId: "",
  meals: [],
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

// Track JSON input for auto-filling foods
const foodsJsonInput = ref<{ [mealIndex: number]: string }>({});

const mealTypeOptions = [
  { value: "BREAKFAST", label: "Café da Manhã" },
  { value: "MORNING_SNACK", label: "Lanche da Manhã" },
  { value: "LUNCH", label: "Almoço" },
  { value: "AFTERNOON_SNACK", label: "Lanche da Tarde" },
  { value: "DINNER", label: "Jantar" },
  { value: "EVENING_SNACK", label: "Ceia" },
  { value: "OTHER", label: "Outro" },
];

function resetForm() {
  Object.assign(state, initialState);
  foodsJsonInput.value = {};
  open.value = false;
}

function openWithData(jsonData?: Partial<Schema>) {
  resetForm();
  if (jsonData) {
    // Auto-fill meals if provided
    if (jsonData.meals && Array.isArray(jsonData.meals)) {
      state.meals = jsonData.meals.map((meal) => {
        return {
          mealTime: meal.mealTime || "",
          description: meal.description || "",
          foods:
            meal.foods && Array.isArray(meal.foods)
              ? meal.foods.map((food) => ({
                  name: food.name || "",
                  brand: food.brand || "",
                  quantity: food.quantity || 0,
                  unit: food.unit || "",

                  // Macronutrientes
                  calories: food.calories,
                  carbohydrates: food.carbohydrates,
                  proteins: food.proteins,
                  totalFats: food.totalFats,
                  saturatedFats: food.saturatedFats,
                  transFats: food.transFats,
                  monounsaturatedFats: food.monounsaturatedFats,
                  polyunsaturatedFats: food.polyunsaturatedFats,
                  cholesterol: food.cholesterol,
                  fiber: food.fiber,
                  sugar: food.sugar,
                  sodium: food.sodium,

                  // Vitaminas
                  vitaminA: food.vitaminA,
                  vitaminB1: food.vitaminB1,
                  vitaminB2: food.vitaminB2,
                  vitaminB3: food.vitaminB3,
                  vitaminB5: food.vitaminB5,
                  vitaminB6: food.vitaminB6,
                  vitaminB7: food.vitaminB7,
                  vitaminB9: food.vitaminB9,
                  vitaminB12: food.vitaminB12,
                  vitaminC: food.vitaminC,
                  vitaminD: food.vitaminD,
                  vitaminE: food.vitaminE,
                  vitaminK: food.vitaminK,

                  // Minerais
                  calcium: food.calcium,
                  iron: food.iron,
                  magnesium: food.magnesium,
                  phosphorus: food.phosphorus,
                  potassium: food.potassium,
                  zinc: food.zinc,
                  copper: food.copper,
                  manganese: food.manganese,
                  selenium: food.selenium,
                  iodine: food.iodine,

                  // Outros
                  omega3: food.omega3,
                  omega6: food.omega6,
                  caffeine: food.caffeine,
                  notes: food.notes || "",
                }))
              : [],
        };
      });
    }
  }
  open.value = true;
}

function addMeal() {
  if (!state.meals) state.meals = [];
  const newMealIndex = state.meals.length;
  state.meals.push({
    mealTime: "",
    description: "",
    foods: [],
  });
  foodsJsonInput.value[newMealIndex] = "";
}

function removeMeal(index: number) {
  if (state.meals) {
    state.meals.splice(index, 1);
    // Remove JSON input for this meal and reindex remaining meals
    delete foodsJsonInput.value[index];
    const newFoodsJsonInput: { [mealIndex: number]: string } = {};
    Object.keys(foodsJsonInput.value).forEach((key) => {
      const idx = parseInt(key);
      if (idx > index) {
        newFoodsJsonInput[idx - 1] = foodsJsonInput.value[idx];
      } else if (idx < index) {
        newFoodsJsonInput[idx] = foodsJsonInput.value[idx];
      }
    });
    foodsJsonInput.value = newFoodsJsonInput;
  }
}

function addFoodToMeal(mealIndex: number) {
  if (state.meals && state.meals[mealIndex]) {
    if (!state.meals[mealIndex].foods) state.meals[mealIndex].foods = [];
    state.meals[mealIndex].foods!.push({
      name: "",
      brand: "",
      quantity: 0,
      unit: "",

      // Macronutrientes
      calories: undefined,
      carbohydrates: undefined,
      proteins: undefined,
      totalFats: undefined,
      saturatedFats: undefined,
      transFats: undefined,
      monounsaturatedFats: undefined,
      polyunsaturatedFats: undefined,
      cholesterol: undefined,
      fiber: undefined,
      sugar: undefined,
      sodium: undefined,

      // Vitaminas
      vitaminA: undefined,
      vitaminB1: undefined,
      vitaminB2: undefined,
      vitaminB3: undefined,
      vitaminB5: undefined,
      vitaminB6: undefined,
      vitaminB7: undefined,
      vitaminB9: undefined,
      vitaminB12: undefined,
      vitaminC: undefined,
      vitaminD: undefined,
      vitaminE: undefined,
      vitaminK: undefined,

      // Minerais
      calcium: undefined,
      iron: undefined,
      magnesium: undefined,
      phosphorus: undefined,
      potassium: undefined,
      zinc: undefined,
      copper: undefined,
      manganese: undefined,
      selenium: undefined,
      iodine: undefined,

      // Outros
      omega3: undefined,
      omega6: undefined,
      caffeine: undefined,
      notes: "",
    });
  }
}

function removeFoodFromMeal(mealIndex: number, foodIndex: number) {
  if (state.meals && state.meals[mealIndex] && state.meals[mealIndex].foods) {
    state.meals[mealIndex].foods!.splice(foodIndex, 1);
  }
}

function loadFoodsFromJson(mealIndex: number) {
  try {
    const jsonText = foodsJsonInput.value[mealIndex];
    if (!jsonText || !jsonText.trim()) {
      toast("JSON Vazio", {
        description: "Por favor, insira o JSON dos alimentos.",
      });
      return;
    }

    const foodsArray = JSON.parse(jsonText);

    if (!Array.isArray(foodsArray)) {
      toast("Formato Inválido", {
        description: "O JSON deve ser um array de alimentos.",
      });
      return;
    }

    // Replace the foods array for this meal
    if (state.meals && state.meals[mealIndex]) {
      state.meals[mealIndex].foods = foodsArray.map((food) => ({
        name: food.name || "",
        brand: food.brand || "",
        quantity: food.quantity || 0,
        unit: food.unit || "",

        // Macronutrientes
        calories: food.calories ?? 0,
        carbohydrates: food.carbohydrates ?? 0,
        proteins: food.proteins ?? 0,
        totalFats: food.totalFats ?? 0,
        saturatedFats: food.saturatedFats ?? 0,
        transFats: food.transFats ?? 0,
        monounsaturatedFats: food.monounsaturatedFats ?? 0,
        polyunsaturatedFats: food.polyunsaturatedFats ?? 0,
        cholesterol: food.cholesterol ?? 0,
        fiber: food.fiber ?? 0,
        sugar: food.sugar ?? 0,
        sodium: food.sodium ?? 0,

        // Vitaminas
        vitaminA: food.vitaminA ?? 0,
        vitaminB1: food.vitaminB1 ?? 0,
        vitaminB2: food.vitaminB2 ?? 0,
        vitaminB3: food.vitaminB3 ?? 0,
        vitaminB5: food.vitaminB5 ?? 0,
        vitaminB6: food.vitaminB6 ?? 0,
        vitaminB7: food.vitaminB7 ?? 0,
        vitaminB9: food.vitaminB9 ?? 0,
        vitaminB12: food.vitaminB12 ?? 0,
        vitaminC: food.vitaminC ?? 0,
        vitaminD: food.vitaminD ?? 0,
        vitaminE: food.vitaminE ?? 0,
        vitaminK: food.vitaminK ?? 0,

        // Minerais
        calcium: food.calcium ?? 0,
        iron: food.iron ?? 0,
        magnesium: food.magnesium ?? 0,
        phosphorus: food.phosphorus ?? 0,
        potassium: food.potassium ?? 0,
        zinc: food.zinc ?? 0,
        copper: food.copper ?? 0,
        manganese: food.manganese ?? 0,
        selenium: food.selenium ?? 0,
        iodine: food.iodine ?? 0,

        // Outros
        omega3: food.omega3 ?? 0,
        omega6: food.omega6 ?? 0,
        caffeine: food.caffeine ?? 0,
        notes: food.notes || "",
      }));

      toast("Alimentos Carregados!", {
        description: `${foodsArray.length} alimento(s) carregado(s) com sucesso.`,
      });

      // Clear the JSON input after successful load
      foodsJsonInput.value[mealIndex] = "";
    }
  } catch (error: any) {
    toast("Erro ao Processar JSON", {
      description: "Verifique se o JSON está no formato correto.",
    });
  }
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    // const formData = new FormData()

    // // Append basic fields
    // formData.append('dateOfRegistration', event.data.dateOfRegistration)
    // formData.append('patientId', event.data.patientId)
    // if (event.data.observations) {
    //   formData.append('observations', event.data.observations)
    // }
    // if (event.data.totalWaterIntake !== undefined) {
    //   formData.append('totalWaterIntake', String(event.data.totalWaterIntake))
    // }

    // // Append meals as JSON with photos as multipart files
    // if (event.data.meals && event.data.meals.length > 0) {
    //   event.data.meals.forEach((meal, mealIndex) => {
    //     // Append meal data as JSON
    //     formData.append(`meals[${mealIndex}][mealType]`, meal.mealType)
    //     formData.append(`meals[${mealIndex}][mealTime]`, meal.mealTime)
    //     if (meal.description) formData.append(`meals[${mealIndex}][description]`, meal.description)
    //     if (meal.location) formData.append(`meals[${mealIndex}][location]`, meal.location)
    //     if (meal.observations) formData.append(`meals[${mealIndex}][observations]`, meal.observations)

    //     // Append foods for this meal
    //     if (meal.foods && meal.foods.length > 0) {
    //       meal.foods.forEach((food, foodIndex) => {
    //         formData.append(`meals[${mealIndex}][foods][${foodIndex}][name]`, food.name)
    //         formData.append(`meals[${mealIndex}][foods][${foodIndex}][quantity]`, String(food.quantity))
    //         formData.append(`meals[${mealIndex}][foods][${foodIndex}][unit]`, food.unit)

    //         if (food.brand) formData.append(`meals[${mealIndex}][foods][${foodIndex}][brand]`, food.brand)

    //         // Append all nutritional fields if they exist
    //         const numericFields = [
    //           'calories', 'carbohydrates', 'proteins', 'totalFats', 'saturatedFats',
    //           'transFats', 'monounsaturatedFats', 'polyunsaturatedFats', 'cholesterol',
    //           'fiber', 'sugar', 'sodium', 'vitaminA', 'vitaminB1', 'vitaminB2',
    //           'vitaminB3', 'vitaminB5', 'vitaminB6', 'vitaminB7', 'vitaminB9',
    //           'vitaminB12', 'vitaminC', 'vitaminD', 'vitaminE', 'vitaminK',
    //           'calcium', 'iron', 'magnesium', 'phosphorus', 'potassium',
    //           'zinc', 'copper', 'manganese', 'selenium', 'iodine',
    //           'omega3', 'omega6', 'caffeine'
    //         ]

    //         numericFields.forEach(field => {
    //           if (food[field] !== undefined && food[field] !== null && food[field] !== '') {
    //             formData.append(`meals[${mealIndex}][foods][${foodIndex}][${field}]`, String(food[field]))
    //           }
    //         })

    //         if (food.notes) {
    //           formData.append(`meals[${mealIndex}][foods][${foodIndex}][notes]`, food.notes)
    //         }
    //       })
    //     }
    //   })
    // }

    await dailyFoodLogsStore.create(event.data);
    toast("Registro Alimentar Criado!", {
      description: "O registro alimentar diário foi salvo com sucesso.",
    });
    emit("created");
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Registro", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :ui="{ content: 'lg:max-w-4xl' }"
      :overlay="false"
      title="Novo Registro Alimentar"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-plus-circle" label="Novo Registro" />
      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-6"
          @submit="onSubmit"
        >
          <div class="flex items-start gap-4">
            <UFormField label="Paciente" name="patientId" class="flex-1">
              <PatientsSelectInput
                @update:patient="state.patientId = $event"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField
              label="Data de Registro"
              name="dateOfRegistration"
              class="flex-1"
            >
              <UInput
                v-model="state.dateOfRegistration"
                type="date"
                :class="{ 'border-red-500': hasError('dateOfRegistration') }"
              />
              <p
                v-if="getError('dateOfRegistration')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("dateOfRegistration") }}
              </p>
            </UFormField>
          </div>

          <!-- <UFormField label="Observações Gerais" name="observations">
            <UTextarea v-model="state.observations" class="w-full" rows="3"/>
          </UFormField> -->

          <USeparator label="Refeições" />

          <UAccordion
            v-if="state.meals && state.meals.length > 0"
            :items="
              state.meals.map((meal, idx) => ({
                label: `Refeição ${idx + 1} - ${meal.mealTime || 'Sem horário'}`,
                icon: 'i-lucide-utensils',
                slot: `meal-${idx}`,
                defaultOpen: idx === 0,
              }))
            "
            :ui="{ item: { base: 'mb-2' } }"
          >
            <template
              v-for="(meal, mealIndex) in state.meals"
              :key="mealIndex"
              #[`meal-${mealIndex}`]
            >
              <div class="p-4 space-y-4">
                <div class="flex justify-end">
                  <UButton
                    icon="i-lucide-trash-2"
                    color="red"
                    variant="ghost"
                    size="sm"
                    @click="removeMeal(mealIndex)"
                  >
                    Remover Refeição
                  </UButton>
                </div>

                <div class="grid grid-cols-2 gap-4">
                  <UFormField
                    :label="`Horário`"
                    :name="`meals.${mealIndex}.mealTime`"
                  >
                    <UInput v-model="meal.mealTime" type="time" />
                  </UFormField>
                  <UFormField
                    :label="`Descrição`"
                    :name="`meals.${mealIndex}.description`"
                  >
                    <UInput v-model="meal.description" />
                  </UFormField>
                </div>

                <!-- Auto-fill from JSON -->
                <div class="border-t pt-4 space-y-3">
                  <h4 class="font-medium">Importar Alimentos de JSON</h4>
                  <UFormField
                    label="Cole o JSON dos alimentos aqui"
                    hint="Array de alimentos no formato especificado"
                  >
                    <UTextarea
                      class="w-full"
                      v-model="foodsJsonInput[mealIndex]"
                      rows="4"
                      placeholder='[{"name": "Arroz", "quantity": 100, "unit": "g", ...}]'
                    />
                  </UFormField>
                  <UButton
                    icon="i-lucide-upload"
                    size="sm"
                    variant="outline"
                    @click="loadFoodsFromJson(mealIndex)"
                  >
                    Carregar Alimentos do JSON
                  </UButton>
                </div>

                <!-- Alimentos -->
                <div class="border-t pt-4">
                  <div class="flex justify-between items-center mb-4">
                    <h4 class="font-medium">Alimentos</h4>
                    <UButton
                      icon="i-lucide-plus"
                      size="sm"
                      variant="outline"
                      @click="addFoodToMeal(mealIndex)"
                    >
                      Adicionar Alimento
                    </UButton>
                  </div>

                  <UAccordion
                    v-if="meal.foods && meal.foods.length > 0"
                    :items="
                      meal.foods.map((food, idx) => ({
                        label: food.name || `Alimento ${idx + 1}`,
                        icon: 'i-lucide-apple',
                        slot: `food-${mealIndex}-${idx}`,
                        defaultOpen: false,
                      }))
                    "
                    :ui="{ item: { base: 'mb-2' } }"
                  >
                    <template
                      v-for="(food, foodIndex) in meal.foods"
                      :key="foodIndex"
                      #[`food-${mealIndex}-${foodIndex}`]
                    >
                      <div class="p-3 space-y-3">
                        <div class="flex justify-end">
                          <UButton
                            icon="i-lucide-trash-2"
                            color="red"
                            variant="ghost"
                            size="xs"
                            @click="removeFoodFromMeal(mealIndex, foodIndex)"
                          >
                            Remover
                          </UButton>
                        </div>

                        <div class="grid grid-cols-4 gap-3">
                          <UFormField
                            :label="`Nome`"
                            :name="`meals.${mealIndex}.foods.${foodIndex}.name`"
                          >
                            <UInput v-model="food.name" />
                          </UFormField>
                          <UFormField
                            :label="`Marca`"
                            :name="`meals.${mealIndex}.foods.${foodIndex}.brand`"
                          >
                            <UInput v-model="food.brand" />
                          </UFormField>
                          <UFormField
                            :label="`Quantidade`"
                            :name="`meals.${mealIndex}.foods.${foodIndex}.quantity`"
                          >
                            <UInput
                              v-model.number="food.quantity"
                              type="number"
                              step="0.1"
                            />
                          </UFormField>
                          <UFormField
                            :label="`Unidade`"
                            :name="`meals.${mealIndex}.foods.${foodIndex}.unit`"
                          >
                            <UInput
                              v-model="food.unit"
                              placeholder="g, ml, xícara"
                            />
                          </UFormField>
                        </div>

                        <!-- Macronutrientes -->
                        <div class="space-y-4">
                          <h6
                            class="text-sm font-medium text-gray-700 border-b pb-1"
                          >
                            Macronutrientes
                          </h6>
                          <div class="grid grid-cols-4 gap-3">
                            <UFormField
                              :label="`Calorias`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.calories`"
                            >
                              <UInput
                                v-model.number="food.calories"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Carboidratos (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.carbohydrates`"
                            >
                              <UInput
                                v-model.number="food.carbohydrates"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Proteínas (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.proteins`"
                            >
                              <UInput
                                v-model.number="food.proteins"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Gorduras Totais (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.totalFats`"
                            >
                              <UInput
                                v-model.number="food.totalFats"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                          <div class="grid grid-cols-4 gap-3">
                            <UFormField
                              :label="`Gorduras Saturadas (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.saturatedFats`"
                            >
                              <UInput
                                v-model.number="food.saturatedFats"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Gorduras Trans (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.transFats`"
                            >
                              <UInput
                                v-model.number="food.transFats"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Gorduras Monoinsaturadas (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.monounsaturatedFats`"
                            >
                              <UInput
                                v-model.number="food.monounsaturatedFats"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Gorduras Poli-insaturadas (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.polyunsaturatedFats`"
                            >
                              <UInput
                                v-model.number="food.polyunsaturatedFats"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                          <div class="grid grid-cols-4 gap-3">
                            <UFormField
                              :label="`Colesterol (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.cholesterol`"
                            >
                              <UInput
                                v-model.number="food.cholesterol"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Fibras (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.fiber`"
                            >
                              <UInput
                                v-model.number="food.fiber"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Açúcar (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.sugar`"
                            >
                              <UInput
                                v-model.number="food.sugar"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Sódio (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.sodium`"
                            >
                              <UInput
                                v-model.number="food.sodium"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                        </div>

                        <!-- Vitaminas -->
                        <div class="space-y-4">
                          <h6
                            class="text-sm font-medium text-gray-700 border-b pb-1"
                          >
                            Vitaminas
                          </h6>
                          <div class="grid grid-cols-4 gap-3">
                            <UFormField
                              :label="`Vitamina A (μg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminA`"
                            >
                              <UInput
                                v-model.number="food.vitaminA"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina B1 (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminB1`"
                            >
                              <UInput
                                v-model.number="food.vitaminB1"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina B2 (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminB2`"
                            >
                              <UInput
                                v-model.number="food.vitaminB2"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina B3 (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminB3`"
                            >
                              <UInput
                                v-model.number="food.vitaminB3"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                          <div class="grid grid-cols-4 gap-3">
                            <UFormField
                              :label="`Vitamina B5 (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminB5`"
                            >
                              <UInput
                                v-model.number="food.vitaminB5"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina B6 (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminB6`"
                            >
                              <UInput
                                v-model.number="food.vitaminB6"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina B7 (μg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminB7`"
                            >
                              <UInput
                                v-model.number="food.vitaminB7"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina B9 (μg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminB9`"
                            >
                              <UInput
                                v-model.number="food.vitaminB9"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                          <div class="grid grid-cols-4 gap-3">
                            <UFormField
                              :label="`Vitamina B12 (μg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminB12`"
                            >
                              <UInput
                                v-model.number="food.vitaminB12"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina C (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminC`"
                            >
                              <UInput
                                v-model.number="food.vitaminC"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina D (μg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminD`"
                            >
                              <UInput
                                v-model.number="food.vitaminD"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Vitamina E (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminE`"
                            >
                              <UInput
                                v-model.number="food.vitaminE"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                          <div class="grid grid-cols-1 gap-3">
                            <UFormField
                              :label="`Vitamina K (μg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.vitaminK`"
                            >
                              <UInput
                                v-model.number="food.vitaminK"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                        </div>

                        <!-- Minerais -->
                        <div class="space-y-4">
                          <h6
                            class="text-sm font-medium text-gray-700 border-b pb-1"
                          >
                            Minerais
                          </h6>
                          <div class="grid grid-cols-4 gap-3">
                            <UFormField
                              :label="`Cálcio (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.calcium`"
                            >
                              <UInput
                                v-model.number="food.calcium"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Ferro (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.iron`"
                            >
                              <UInput
                                v-model.number="food.iron"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Magnésio (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.magnesium`"
                            >
                              <UInput
                                v-model.number="food.magnesium"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Fósforo (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.phosphorus`"
                            >
                              <UInput
                                v-model.number="food.phosphorus"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                          <div class="grid grid-cols-4 gap-3">
                            <UFormField
                              :label="`Potássio (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.potassium`"
                            >
                              <UInput
                                v-model.number="food.potassium"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Zinco (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.zinc`"
                            >
                              <UInput
                                v-model.number="food.zinc"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Cobre (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.copper`"
                            >
                              <UInput
                                v-model.number="food.copper"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Manganês (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.manganese`"
                            >
                              <UInput
                                v-model.number="food.manganese"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                          <div class="grid grid-cols-2 gap-3">
                            <UFormField
                              :label="`Selênio (μg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.selenium`"
                            >
                              <UInput
                                v-model.number="food.selenium"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Iodo (μg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.iodine`"
                            >
                              <UInput
                                v-model.number="food.iodine"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                        </div>

                        <!-- Outros Compostos -->
                        <div class="space-y-4">
                          <h6
                            class="text-sm font-medium text-gray-700 border-b pb-1"
                          >
                            Outros Compostos
                          </h6>
                          <div class="grid grid-cols-3 gap-3">
                            <UFormField
                              :label="`Ômega 3 (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.omega3`"
                            >
                              <UInput
                                v-model.number="food.omega3"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Ômega 6 (g)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.omega6`"
                            >
                              <UInput
                                v-model.number="food.omega6"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                            <UFormField
                              :label="`Cafeína (mg)`"
                              :name="`meals.${mealIndex}.foods.${foodIndex}.caffeine`"
                            >
                              <UInput
                                v-model.number="food.caffeine"
                                type="number"
                                step="0.1"
                              />
                            </UFormField>
                          </div>
                        </div>

                        <UFormField
                          :label="`Observações`"
                          :name="`meals.${mealIndex}.foods.${foodIndex}.notes`"
                        >
                          <UTextarea v-model="food.notes" rows="2" />
                        </UFormField>
                      </div>
                    </template>
                  </UAccordion>
                </div>
              </div>
            </template>
          </UAccordion>

          <div class="flex justify-center">
            <UButton icon="i-lucide-plus" variant="outline" @click="addMeal">
              Adicionar Refeição
            </UButton>
          </div>

          <UButton type="submit" block class="mt-8">
            Salvar Registro Alimentar
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
