<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'

const route = useRoute()
const patientId = route.params.id as string

const dailyFoodLogsStore = useDailyFoodLogsStore()
const patientStore = usePatientStore()

const dateRange = ref({
  start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Last 30 days
  end: new Date().toISOString().split('T')[0]
})

const selectedLogId = ref<string>()
const loading = ref(false)

const logs = computed(() => dailyFoodLogsStore.data || [])
const patient = computed(() => patientStore.data.find(p => p.id === patientId))

const selectedLog = computed(() => {
  return logs.value.find(log => log.id === selectedLogId.value)
})

async function fetchData() {
  loading.value = true
  try {
    await Promise.all([
      dailyFoodLogsStore.fetchData({
        patientId,
        startDate: dateRange.value.start,
        endDate: dateRange.value.end,
        perPage: 50
      }),
      patientStore.fetchData({ perPage: 50 })
    ])

    // Auto-select the most recent log
    if (logs.value.length > 0 && !selectedLogId.value) {
      const sortedLogs = [...logs.value].sort((a, b) =>
        new Date(b.dateOfRegistration).getTime() - new Date(a.dateOfRegistration).getTime()
      )
      selectedLogId.value = sortedLogs[0].id
    }
  } finally {
    loading.value = false
  }
}

watch(dateRange, fetchData, { deep: true })

onMounted(fetchData)


const activeTab = ref('overview')

const tabs = [
  { key: 'overview', label: 'Visão Geral', icon: 'i-lucide-layout-grid' },
  { key: 'trends', label: 'Tendências', icon: 'i-lucide-trending-up' },
  { key: 'nutrients', label: 'Micronutrientes', icon: 'i-lucide-sparkles' },
  { key: 'daily', label: 'Análise Diária', icon: 'i-lucide-calendar-days' }
]
</script>

<template>
  <section class="space-y-6">

    <!-- Header -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
      <div>
        <h1 class="text-3xl font-bold">Análises Nutricionais</h1>
        <p class="text-gray-500 mt-1">
          <span v-if="patient">{{ patient.name }}</span>
          <span class="mx-2">•</span>
          <span>{{ logs.length }} registros</span>
        </p>
      </div>

      <div class="flex items-center gap-3">
        <UFormField label="Data Inicial">
          <UInput v-model="dateRange.start" type="date" />
        </UFormField>
        <UFormField label="Data Final">
          <UInput v-model="dateRange.end" type="date" />
        </UFormField>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="loading" class="flex items-center justify-center py-12">
      <div class="text-center">
        <UIcon name="i-lucide-loader-2" class="w-8 h-8 animate-spin text-primary-500 mx-auto mb-2" />
        <p class="text-gray-500">Carregando análises...</p>
      </div>
    </div>

    <!-- No Data State -->
    <div v-else-if="logs.length === 0" class="text-center py-12">
      <UIcon name="i-lucide-inbox" class="w-16 h-16 text-gray-400 mx-auto mb-4" />
      <h3 class="text-lg font-semibold text-gray-700 mb-2">Nenhum registro encontrado</h3>
      <p class="text-gray-500 mb-4">Não há registros alimentares para o período selecionado.</p>
      <UButton to="/daily-food-logs" icon="i-lucide-plus">
        Criar Novo Registro
      </UButton>
    </div>

    <!-- Content -->
    <div v-else class="space-y-6">
      <!-- Tabs -->
      <div class="border-b border-gray-200 dark:border-gray-800">
        <div class="flex gap-4 overflow-x-auto">
          <button
            v-for="tab in tabs"
            :key="tab.key"
            @click="activeTab = tab.key"
            class="flex items-center gap-2 px-4 py-3 border-b-2 font-medium text-sm transition-colors whitespace-nowrap"
            :class="{
              'border-primary-500 text-primary-600': activeTab === tab.key,
              'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300': activeTab !== tab.key
            }"
          >
            <UIcon :name="tab.icon" class="w-4 h-4" />
            {{ tab.label }}
          </button>
        </div>
      </div>

      <!-- Overview Tab -->
      <div v-show="activeTab === 'overview'" class="space-y-6">
        <DailyFoodLogsChartsNutritionalSummaryCards :logs="logs" />

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DailyFoodLogsChartsCaloricIntakeTimeline :logs="logs" />
          <DailyFoodLogsChartsFoodDiversityScore :logs="logs" />
        </div>

        <DailyFoodLogsChartsMealFrequencyAnalysis :logs="logs" />
      </div>

      <!-- Trends Tab -->
      <div v-show="activeTab === 'trends'" class="space-y-6">
        <DailyFoodLogsChartsWeeklyComparison :logs="logs" />

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DailyFoodLogsChartsMacronutrientTrends :logs="logs" />
          <DailyFoodLogsChartsFiberSugarTracking :logs="logs" />
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DailyFoodLogsChartsSodiumIntakeMonitor :logs="logs" />
          <DailyFoodLogsChartsOmegaRatioChart :logs="logs" />
        </div>
      </div>

      <!-- Micronutrients Tab -->
      <div v-show="activeTab === 'nutrients'" class="space-y-6">
        <DailyFoodLogsChartsVitaminDeficiencyAlerts :logs="logs" />
        <DailyFoodLogsChartsMicronutrientHeatmap :logs="logs" />
      </div>

      <!-- Daily Analysis Tab -->
      <div v-show="activeTab === 'daily'" class="space-y-6">
        <Card>
          <template #header>
            <div class="flex items-center justify-between">
              <h3 class="text-lg font-semibold">Selecione um Dia para Análise Detalhada</h3>
              <UIcon name="i-lucide-calendar" class="w-5 h-5 text-gray-500" />
            </div>
          </template>

          <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
            <button
              v-for="log in logs.slice().reverse()"
              :key="log.id"
              @click="selectedLogId = log.id"
              class="p-3 rounded-lg border-2 transition-all text-center"
              :class="{
                'border-primary-500 bg-primary-50 dark:bg-primary-950': selectedLogId === log.id,
                'border-gray-200 dark:border-gray-800 hover:border-primary-300': selectedLogId !== log.id
              }"
            >
              <p class="text-xs text-gray-500 mb-1">
                {{ new Date(log.dateOfRegistration).toLocaleDateString('pt-BR', { weekday: 'short' }) }}
              </p>
              <p class="text-sm font-semibold">
                {{ new Date(log.dateOfRegistration).toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' }) }}
              </p>
              <p class="text-xs text-gray-500 mt-1">{{ log.meals?.length || 0 }} refeições</p>
            </button>
          </div>
        </Card>

        <div v-if="selectedLog" class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DailyFoodLogsChartsMacronutrientDistribution :log="selectedLog" />
          <DailyFoodLogsChartsMealDistributionPattern :log="selectedLog" />
        </div>
      </div>
    </div>
  </section>
</template>
