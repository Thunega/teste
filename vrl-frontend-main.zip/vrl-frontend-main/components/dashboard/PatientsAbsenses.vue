<script setup lang="ts">
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'

defineProps({
  patients: Array
})

function getInitials(nome: string): string {
  const names = nome.split(' ')
  if (names.length === 0) return ''
  const firstName = names[0]
  const lastName = names[1] || ''
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}
</script>

<template>
  <Card class="p-6">
    <h3 class="mb-4 text-lg font-semibold">
      Pacientes com Faltas Consecutivas
    </h3>

    <Table>
      <TableCaption>
        Pacientes que faltaram em várias consultas seguidas.
      </TableCaption>

      <TableHeader>
        <TableRow>
          <TableHead class="w-[350px]">
            Paciente
          </TableHead>

          <TableHead>
            Faltas Consecutivas
          </TableHead>

          <TableHead class="text-right">
            Ação
          </TableHead>
        </TableRow>
      </TableHeader>

      <TableBody>
        <TableRow
          v-for="patient in patients"
          :key="patient.id"
        >
          <TableCell class="font-medium">
            <div class="flex items-center gap-3">
              <Avatar>
                <AvatarFallback>
                  {{ getInitials(patient.name) }}
                </AvatarFallback>
              </Avatar>

              <span>{{ patient.name }}</span>
            </div>
          </TableCell>

          <TableCell>
            {{ patient.consecutiveAbsences }}
          </TableCell>

          <TableCell class="text-right">
            <Button
              variant="outline"
              size="sm"
              @click="useRouter().push(`/patients/${patient.id}`)"
            >
              Ver Ficha
            </Button>
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>
  </Card>
</template>