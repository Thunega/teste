<script setup lang="ts">
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'

// Dados de exemplo para os pacientes
defineProps({
  patients: Array
})

/**
 * Pega as iniciais do primeiro e último nome.
 * @param {string} nome - O nome completo do paciente.
 * @returns {string} As iniciais.
 */
function getInitials(nome: string): string {
  const names = nome.split(' ')
  if (names.length === 0) return ''
  const firstName = names[0]
  const lastName = names[1] 
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}

const formatDate = (dateString) => {
  const options = { year: "numeric", month: "long", day: "numeric" , hour: 'numeric', minute: 'numeric'}
  return new Date(dateString).toLocaleDateString(undefined, options)
}

/**
 * Função de exemplo para o clique do botão.
 * @param {string} pacienteId - O ID do paciente.
 */
function verFicha(pacienteId: string) {
  alert(`Exibindo a ficha do paciente: ${pacienteId}`)
}
</script>

<template>
  <Card class="p-6">
    <h3 class="mb-4 text-lg font-semibold">
      Pacintes Recentes
    </h3>
    <Table>
      <TableCaption>Uma lista de seus pacientes recentes.</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead class="w-[350px]">
            Paciente
          </TableHead>
          <TableHead>Atualizado Em</TableHead>
          <TableHead class="text-right">
            Ação
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow v-for="patient in patients" :key="patient.id">
          <TableCell class="font-medium">
            <div class="flex items-center gap-3">
              <Avatar>
                <AvatarFallback>{{ getInitials(patient.name) }}</AvatarFallback>
              </Avatar>
              <span>{{ patient.name }}</span>
            </div>
          </TableCell>
          <TableCell>{{ formatDate(patient.updatedAt) }}</TableCell>
          <TableCell class="text-right">
            <Button variant="outline" size="sm" @click="useRouter().push(`/patients/${patient.id}`)">
              Ver Ficha
            </Button>
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>
  </Card>
</template>
