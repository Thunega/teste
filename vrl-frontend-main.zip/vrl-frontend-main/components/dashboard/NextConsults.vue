<script setup lang="ts">
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'

type Status = 'Confirmado' | 'Pendente' | 'Cancelado'


defineProps({
  appoitments: Array
})

// function getStatusClasses(status: Status): string {
//   const baseClasses = 'border-transparent rounded-full px-2.5 py-0.5'

//   switch (status) {
//     case 'Confirmado':
//       return `${baseClasses} bg-green-100 text-green-900 dark:bg-green-900/80 dark:text-green-50`
//     case 'Pendente':
//       return `${baseClasses} bg-yellow-100 text-yellow-900 dark:bg-yellow-900/80 dark:text-yellow-50`
//     case 'Cancelado':
//       return `${baseClasses} bg-red-100 text-red-900 dark:bg-red-900/80 dark:text-red-50`
//     default:
//       return baseClasses
//   }
// }

/**
 * Pega as iniciais do nome para o Avatar.
 */
function getInitials(nome: string): string {
  const names = nome.split(' ')
  return names.map(n => n[0]).join('').substring(0, 2).toUpperCase()
}

const formatDate = (dateString) => {
  const options = { year: "numeric", month: "long", day: "numeric", hour: 'numeric', minute: 'numeric'}
  return new Date(dateString).toLocaleDateString(undefined, options)
}
</script>

<template>
  <Card class="p-6">
    <h3 class="mb-4 text-lg font-semibold">
      Próximos Agendamentos
    </h3>
    <Table>
      <TableCaption>Uma lista das suas próximas consultas agendadas.</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead class="w-[250px]">
            Paciente
          </TableHead>
          <TableHead>Hora</TableHead>
          <TableHead>Descrição</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow v-for="consulta in appoitments" :key="consulta.id">
          <TableCell class="font-medium">
            <div class="flex items-center gap-3">
              <Avatar class="h-8 w-8">
                <AvatarFallback>{{ getInitials(consulta.patient.name) }}</AvatarFallback>
              </Avatar>
              <span>{{ consulta.patient.name }}</span>
            </div>
          </TableCell>
          <TableCell>{{ formatDate(consulta.scheduledAt) }}</TableCell>
          <TableCell>{{ consulta.description }}</TableCell>
        </TableRow>
      </TableBody>
    </Table>
  </Card>
</template>