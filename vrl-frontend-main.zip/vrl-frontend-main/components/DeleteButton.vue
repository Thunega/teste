<script setup lang="ts">
import { ref, defineProps, defineEmits } from "vue";
import { toast } from "vue-sonner";

const props = defineProps({
  store: {
    type: Object,
    required: true,
  },
  id: {
    type: [String, Number],
    required: true,
  },
});

const emit = defineEmits(["deleted"]);

const isOpen = ref(false);

async function confirmDelete() {
  try {
    await props.store.delete(props.id);
    toast("Item Excluído!", {
      description: "O item foi removido do sistema com sucesso.",
    });
    isOpen.value = false;
    emit("deleted");
  } catch (error: any) {
    toast("Erro ao Excluir", {
      description: error.data?.message || "Não foi possível remover o item.",
    });
  }
}
</script>

<template>
  <div>
    <UButton
      variant="subtle"
      color="error"
      icon="i-lucide-trash"
      label="Excluir"
      @click="isOpen = true"
    />

    <UModal
      :dismissible="false"
      v-model:open="isOpen"
      title="Confirmar Exclusão"
    >
      <template #body>
        <p>
          Você tem certeza que deseja excluir este item? Esta ação não pode ser
          desfeita.
        </p>
        <div class="flex justify-end space-x-4 mt-4">
          <UButton variant="solid" @click="isOpen = false"> Cancelar </UButton>
          <UButton
            variant="subtle"
            color="error"
            icon="i-lucide-trash"
            @click="confirmDelete"
          >
            Confirmar
          </UButton>
        </div>
      </template>
    </UModal>
  </div>
</template>
