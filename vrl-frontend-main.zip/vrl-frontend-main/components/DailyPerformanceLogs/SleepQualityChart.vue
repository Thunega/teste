<script setup lang="ts">
import { computed } from 'vue';
import { Doughnut } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  type ChartOptions,
  type ChartData
} from 'chart.js';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    ArcElement
);

const props = defineProps<{
  logs: any[];
}>();

const chartData = computed<ChartData<'doughnut'>>(() => {
  const sleepCounts = {
    GOOD: 0,
    AVERAGE: 0,
    BAD: 0,
  };

  props.logs.forEach(log => {
    if (log.sleepQuality === 'GOOD') sleepCounts.GOOD++;
    else if (log.sleepQuality === 'AVERAGE') sleepCounts.AVERAGE++;
    else if (log.sleepQuality === 'BAD') sleepCounts.BAD++;
  });

  return {
    labels: ['Bom', 'Regular', 'Ruim'],
    datasets: [
      {
        label: 'Noites',
        data: [sleepCounts.GOOD, sleepCounts.AVERAGE, sleepCounts.BAD],
        backgroundColor: [
          'rgb(34, 197, 94)',
          'rgb(245, 158, 11)',
          'rgb(239, 68, 68)',
        ],
        hoverOffset: 4,
      },
    ],
  };
});

const chartOptions = computed<ChartOptions<'doughnut'>>(() => ({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    title: {
      display: true,
      text: 'Resumo da Qualidade do Sono',
      font: { size: 18 }
    },
    legend: {
      position: 'top',
    }
  },
}));

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Doughnut v-if="props.logs && props.logs.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Sem dados para exibir.
      </p>
    </div>
  </div>
</template>