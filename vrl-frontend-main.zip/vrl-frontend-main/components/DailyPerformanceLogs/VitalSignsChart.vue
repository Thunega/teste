<script setup lang="ts">
import { computed } from 'vue';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  type ChartOptions,
  type ChartData
} from 'chart.js';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement
);

const props = defineProps<{
  logs: any[];
}>();

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit', year: '2-digit' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const chartData = computed<ChartData<'line'>>(() => {
  const sortedLogs = [...props.logs].sort((a, b) => new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime());

  const labels = sortedLogs.map(log => formatDate(log.dateOfRegistration));
  const systolicData = sortedLogs.map(log => parseInt(log.bloodPressure.split('/')[0], 10));
  const diastolicData = sortedLogs.map(log => parseInt(log.bloodPressure.split('/')[1], 10));
  const bpmData = sortedLogs.map(log => log.beatsPerMinute);

  return {
    labels,
    datasets: [
      {
        label: 'Pressão Sistólica (mmHg)',
        borderColor: 'rgb(239, 68, 68)',
        data: systolicData,
        tension: 0.2,
      },
      {
        label: 'Pressão Diastólica (mmHg)',
        borderColor: 'rgb(59, 130, 246)',
        data: diastolicData,
        tension: 0.2,
      },
      {
        label: 'Batimentos (BPM)',
        borderColor: 'rgb(34, 197, 94)',
        data: bpmData,
        tension: 0.2,
      },
    ],
  };
});

const chartOptions = computed<ChartOptions<'line'>>(() => ({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    title: {
      display: true,
      text: 'Histórico de Sinais Vitais',
      font: { size: 18 }
    },
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Valores'
      }
    }
  }
}));

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Line v-if="props.logs && props.logs.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Sem dados para exibir.
      </p>
    </div>
  </div>
</template>