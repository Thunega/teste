<script setup lang="ts">
import { computed } from 'vue';
import { Bar } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
  type ChartOptions,
  type ChartData
} from 'chart.js';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    BarElement,
    CategoryScale,
    LinearScale
);

const props = defineProps<{
  logs: any[];
}>();

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const getIntensityColor = (intensity: 'MILD' | 'MODERATE' | 'INTENSIVE') => {
  if (intensity === 'INTENSIVE') return 'rgb(239, 68, 68)';
  if (intensity === 'MODERATE') return 'rgb(245, 158, 11)';
  return 'rgb(34, 197, 94)'; // MILD
};

const chartData = computed<ChartData<'bar'>>(() => {
  const sortedLogs = [...props.logs].sort((a, b) => new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime());

  return {
    labels: sortedLogs.map(log => formatDate(log.dateOfRegistration)),
    datasets: [
      {
        label: 'Duração da Atividade (min)',
        data: sortedLogs.map(log => log.physicalActivity?.duration || 0),
        backgroundColor: sortedLogs.map(log => getIntensityColor(log.physicalActivity?.intensity)),
      },
    ],
  };
});

const chartOptions = computed<ChartOptions<'bar'>>(() => ({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    title: {
      display: true,
      text: 'Duração e Intensidade das Atividades Físicas',
      font: { size: 18 }
    },
    legend: {
      display: false,
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      title: {
        display: true,
        text: 'Duração (minutos)'
      }
    }
  }
}));

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Bar v-if="props.logs && props.logs.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Sem dados para exibir.
      </p>
    </div>
  </div>
</template>