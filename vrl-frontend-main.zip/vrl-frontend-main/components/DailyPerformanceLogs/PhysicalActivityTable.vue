<script setup lang="ts">
import { computed } from 'vue';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

const props = defineProps<{
  logs: any[];
}>();

// Mapeia os valores de intensidade para traduções em português.
const intensityMap = {
  MILD: 'Leve',
  MODERATE: 'Moderada',
  INTENSIVE: 'Intensa',
};

// Ordena os logs pela data de registro.
const sortedLogs = computed(() => {
  if (!props.logs) return [];
  return [...props.logs].sort((a, b) => new Date(b.dateOfRegistration).getTime() - new Date(a.dateOfRegistration).getTime());
});

// Formata a data.
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit', year: 'numeric' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};
</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <Table v-if="sortedLogs.length > 0">
      <TableCaption>Um registro das suas atividades físicas.</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead class="w-[150px]">Data</TableHead>
          <TableHead>Atividade</TableHead>
          <TableHead>Intensidade</TableHead>
          <TableHead class="text-right">Duração (min)</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow v-for="log in sortedLogs" :key="log.id">
          <TableCell class="font-medium">{{ formatDate(log.dateOfRegistration) }}</TableCell>
          <TableCell>{{ log.physicalActivity?.name || 'N/A' }}</TableCell>
          <TableCell>{{ intensityMap[log.physicalActivity?.intensity] || 'N/A' }}</TableCell>
          <TableCell class="text-right">{{ log.physicalActivity?.duration || 0 }}</TableCell>
        </TableRow>
      </TableBody>
    </Table>
    <p v-else class="text-center text-gray-500 py-4">
      Sem registros de atividades físicas para exibir.
    </p>
  </div>
</template>