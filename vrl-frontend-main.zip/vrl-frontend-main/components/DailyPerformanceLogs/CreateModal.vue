<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const dailyPerformanceLogStore = useDailyPerformanceLogsStore();
const open = ref(false);
const showPhysicalActivity = ref(false);

const sleepQualityEnum = ["GOOD", "AVERAGE", "BAD"];
const intensityEnum = ["MILD", "MODERATE", "INTENSIVE"];

const sleepQualityOptions = [
  { label: "Boa", value: "GOOD" },
  { label: "Média", value: "AVERAGE" },
  { label: "Ruim", value: "BAD" },
];

const intensityOptions = [
  { label: "Leve", value: "MILD" },
  { label: "Moderada", value: "MODERATE" },
  { label: "Intensa", value: "INTENSIVE" },
];

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  dateOfRegistration: z.string({
    required_error: "A data do registro é obrigatória.",
    invalid_type_error: "A data do registro é obrigatória.",
  }),
  bloodPressure: z.string().optional(),
  oxygenSaturation: z.coerce
    .number({ invalid_type_error: "A saturação deve ser um número." })
    .min(0, "A saturação deve ser no mínimo 0%.")
    .max(100, "A saturação deve ser no máximo 100%.")
    .optional(),
  beatsPerMinute: z.coerce
    .number({ invalid_type_error: "A frequência cardíaca deve ser um número." })
    .positive("A frequência cardíaca deve ser um número positivo.")
    .optional(),
  sleepQuality: z.enum(sleepQualityEnum, {
    required_error: "Selecione a qualidade do sono.",
    invalid_type_error: "Selecione a qualidade do sono.",
  }),
  physicalActivity: z
    .object({
      name: z.string().optional(),
      duration: z.coerce
        .number({ invalid_type_error: "A duração deve ser um número." })
        .positive("A duração deve ser um número positivo.")
        .optional(),
      intensity: z.enum(intensityEnum).optional(),
    })
    .optional(),
  observations: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  patientId: "",
  dateOfRegistration: "",
  bloodPressure: "",
  oxygenSaturation: undefined,
  beatsPerMinute: undefined,
  sleepQuality: "",
  physicalActivity: {
    name: undefined,
    duration: undefined,
    intensity: undefined,
  },
  observations: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, {
    ...initialState,
    physicalActivity: { ...initialState.physicalActivity },
  });
  showPhysicalActivity.value = false;
  open.value = false;
}

function removePhysicalActivity() {
  state.physicalActivity = { ...initialState.physicalActivity };
  showPhysicalActivity.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    const data = JSON.parse(JSON.stringify(event.data));
    if (
      !data.physicalActivity?.name &&
      !data.physicalActivity?.duration &&
      !data.physicalActivity?.intensity
    ) {
      delete data.physicalActivity;
    }
    await dailyPerformanceLogStore.create(data);
    toast("Registro Criado!", {
      description: "O registro de performance diária foi salvo com sucesso.",
    });
    emit("created");
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Registro", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="false"
      title="Criar Novo Registro"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-plus-circle" label="Novo Registro" />

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-6"
          @submit="onSubmit"
        >
          <div class="flex items-start gap-4">
            <UFormField label="Paciente" name="patientId" class="flex-1">
              <PatientsSelectInput
                @update:patient="state.patientId = $event"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField
              label="Data do Registro"
              name="dateOfRegistration"
              class="flex-1"
            >
              <UInput
                v-model="state.dateOfRegistration"
                type="date"
                :class="{ 'border-red-500': hasError('dateOfRegistration') }"
              />
              <p
                v-if="getError('dateOfRegistration')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("dateOfRegistration") }}
              </p>
            </UFormField>
          </div>

          <USeparator label="Sinais Vitais e Sono" />
          <div class="grid grid-cols-2 md:grid-cols-4 items-end gap-4">
            <UFormField label="Pressão Arterial" name="bloodPressure"
              ><UInput
                v-model="state.bloodPressure"
                placeholder="Ex: 120/80"
                :class="{ 'border-red-500': hasError('bloodPressure') }"
              />
              <p
                v-if="getError('bloodPressure')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("bloodPressure") }}
              </p>
            </UFormField>
            <UFormField label="O₂ Saturation (%)" name="oxygenSaturation"
              ><UInput
                v-model.number="state.oxygenSaturation"
                type="number"
                :class="{ 'border-red-500': hasError('oxygenSaturation') }"
              />
              <p
                v-if="getError('oxygenSaturation')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("oxygenSaturation") }}
              </p>
            </UFormField>
            <UFormField label="BPM" name="beatsPerMinute"
              ><UInput
                v-model.number="state.beatsPerMinute"
                type="number"
                :class="{ 'border-red-500': hasError('beatsPerMinute') }"
              />
              <p
                v-if="getError('beatsPerMinute')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("beatsPerMinute") }}
              </p>
            </UFormField>
            <UFormField label="Qualidade do Sono" name="sleepQuality">
              <USelect
                v-model="state.sleepQuality"
                :items="sleepQualityOptions"
                class="w-full"
                option-attribute="label"
                value-attribute="value"
              />
              <p
                v-if="getError('sleepQuality')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("sleepQuality") }}
              </p>
            </UFormField>
          </div>

          <USeparator label="Atividade Física" />
          <div v-if="!showPhysicalActivity" class="flex justify-center">
            <UButton
              icon="i-lucide-plus-circle"
              label="Adicionar Atividade Física"
              @click="showPhysicalActivity = true"
            />
          </div>
          <div v-else class="space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <UFormField
                label="Nome da Atividade"
                name="physicalActivity.name"
                class="sm:col-span-1"
              >
                <UInput
                  v-model="state.physicalActivity.name"
                  placeholder="Ex: Musculação"
                />
              </UFormField>
              <UFormField
                label="Duração (min)"
                name="physicalActivity.duration"
              >
                <UInput
                  v-model.number="state.physicalActivity.duration"
                  type="number"
                />
              </UFormField>
              <UFormField label="Intensidade" name="physicalActivity.intensity">
                <USelect
                  v-model="state.physicalActivity.intensity"
                  :items="intensityOptions"
                  class="w-full"
                  option-attribute="label"
                  value-attribute="value"
                />
              </UFormField>
            </div>
            <div class="flex justify-end">
              <UButton
                icon="i-lucide-trash-2"
                label="Remover Atividade Física"
                color="red"
                variant="soft"
                @click="removePhysicalActivity"
              />
            </div>
          </div>

          <USeparator />
          <UFormField label="Observações" name="observations">
            <UTextarea
              v-model="state.observations"
              placeholder="Observações sobre o dia, bem-estar, etc."
              class="w-full"
            />
          </UFormField>

          <UButton type="submit" block class="mt-8"> Salvar Registro </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
