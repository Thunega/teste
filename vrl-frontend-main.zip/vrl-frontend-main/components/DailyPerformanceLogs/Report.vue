<script setup lang="ts">

const props = defineProps<{
  patientId: string;
}>()

const dailyPerformanceLogsStore = useDailyPerformanceLogsStore();
const limit = ref(10);

const fetchData = async () => {
  await dailyPerformanceLogsStore.fetchData(
      {
        patientId: props.patientId,
        orderBy: 'dateOfRegistration',
        sort: 'desc',
        perPage: limit.value
      }
  )
}
const authStore = useAuthStore()
const userRole = computed(() => authStore.role )

onMounted(fetchData);
</script>

<template>
  <main class="flex flex-wrap flex-col gap-6 mt-6">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <DailyPerformanceLogsDailyPerformanceTable :logs="dailyPerformanceLogsStore.data" v-if="['ADMIN', 'EDUCATOR_VR'].includes(userRole)" />
      <DailyPerformanceLogsVitalSignsChart :logs="dailyPerformanceLogsStore.data" />
      <DailyPerformanceLogsPhysicalActivityChart :logs="dailyPerformanceLogsStore.data" />
      <DailyPerformanceLogsSleepQualityChart :logs="dailyPerformanceLogsStore.data" />
    </div>
  </main>
</template>