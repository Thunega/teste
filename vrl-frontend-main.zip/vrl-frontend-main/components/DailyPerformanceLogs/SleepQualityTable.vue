<script setup lang="ts">
import { computed } from 'vue';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

const props = defineProps<{
  logs: any[];
}>();

// Mapeia os valores de qualidade do sono para traduções.
const sleepQualityMap = {
  GOOD: 'Bom',
  REGULAR: 'Regular',
  POOR: 'Ruim',
};

// Ordena os logs pela data.
const sortedLogs = computed(() => {
  if (!props.logs) return [];
  return [...props.logs].sort((a, b) => new Date(b.dateOfRegistration).getTime() - new Date(a.dateOfRegistration).getTime());
});

// Formata a data.
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit', year: 'numeric' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};
</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <Table v-if="sortedLogs.length > 0">
      <TableCaption>Um registro da sua qualidade de sono.</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead class="w-[150px]">Data</TableHead>
          <TableHead>Qualidade do Sono</TableHead>
          <TableHead>Observações</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow v-for="log in sortedLogs" :key="log.id">
          <TableCell class="font-medium">{{ formatDate(log.dateOfRegistration) }}</TableCell>
          <TableCell>{{ sleepQualityMap[log.sleepQuality] || 'N/A' }}</TableCell>
          <TableCell>{{ log.observations }}</TableCell>
        </TableRow>
      </TableBody>
    </Table>
    <p v-else class="text-center text-gray-500 py-4">
      Sem registros de sono para exibir.
    </p>
  </div>
</template>
