<script setup lang="ts">
import { computed } from 'vue';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

const props = defineProps<{
  logs: any[];
}>();

// Ordena os logs pela data de registro, do mais recente para o mais antigo.
const sortedLogs = computed(() => {
  if (!props.logs) return [];
  return [...props.logs].sort((a, b) => new Date(b.dateOfRegistration).getTime() - new Date(a.dateOfRegistration).getTime());
});

// Formata a data para um formato legível.
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};
</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <Table v-if="sortedLogs.length > 0">
      <TableCaption>Um registro dos seus sinais vitais diários.</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead class="w-[200px]">Data do Registro</TableHead>
          <TableHead>Pressão Arterial</TableHead>
          <TableHead class="text-right">Batimentos (BPM)</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow v-for="log in sortedLogs" :key="log.id">
          <TableCell class="font-medium">{{ formatDate(log.dateOfRegistration) }}</TableCell>
          <TableCell>{{ log.bloodPressure }}</TableCell>
          <TableCell class="text-right">{{ log.beatsPerMinute }}</TableCell>
        </TableRow>
      </TableBody>
    </Table>
    <p v-else class="text-center text-gray-500 py-4">
      Sem registros de sinais vitais para exibir.
    </p>
  </div>
</template>