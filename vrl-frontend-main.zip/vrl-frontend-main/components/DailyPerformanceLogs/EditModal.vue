<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps({
  logId: {
    type: String,
    required: true,
  },
});

const emit = defineEmits(["updated"]);
const dailyPerformanceLogStore = useDailyPerformanceLogsStore();
const open = ref(false);
const showPhysicalActivity = ref(false);

const sleepQualityEnum = ["GOOD", "AVERAGE", "BAD"];
const intensityEnum = ["MILD", "MODERATE", "INTENSIVE"];

const sleepQualityOptions = [
  { label: "Boa", value: "GOOD" },
  { label: "Média", value: "AVERAGE" },
  { label: "Ruim", value: "BAD" },
];

const intensityOptions = [
  { label: "Leve", value: "MILD" },
  { label: "Moderada", value: "MODERATE" },
  { label: "Intensa", value: "INTENSIVE" },
];

const schema = z.object({
  bloodPressure: z.string().optional(),
  oxygenSaturation: z.coerce.number().optional(),
  beatsPerMinute: z.coerce.number().optional(),
  dateOfRegistration: z.string({
    required_error: "A data do registro é obrigatória.",
    invalid_type_error: "A data do registro é obrigatória.",
  }),
  sleepQuality: z.enum(sleepQualityEnum, {
    required_error: "Selecione a qualidade do sono.",
    invalid_type_error: "Selecione a qualidade do sono.",
  }),
  physicalActivity: z
    .object({
      name: z.string().optional(),
      duration: z.coerce.number().optional(),
      intensity: z.enum(intensityEnum).optional(),
    })
    .optional(),
  observations: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  dateOfRegistration: "",
  bloodPressure: "",
  oxygenSaturation: undefined,
  beatsPerMinute: undefined,
  sleepQuality: "GOOD",
  physicalActivity: {
    name: "",
    duration: undefined,
    intensity: "",
  },
  observations: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, initialState);
  showPhysicalActivity.value = false;
}

async function fetchData() {
  try {
    const logData = await dailyPerformanceLogStore.getById(props.logId);
    if (logData) {
      for (const key of Object.keys(initialState)) {
        if (logData[key] !== undefined) {
          state[key as keyof Schema] = logData[key];
        }
      }
      state.dateOfRegistration = new Date(logData.dateOfRegistration)
        .toISOString()
        .split("T")[0];

      if (logData.physicalActivity) {
        state.physicalActivity = logData.physicalActivity;
        showPhysicalActivity.value = true;
      } else {
        state.physicalActivity = {
          name: undefined,
          duration: undefined,
          intensity: undefined,
        };
        showPhysicalActivity.value = false;
      }
    }
  } catch (error) {
    toast.error("Erro ao carregar dados do registro.");
  }
}

watch(open, (isOpen) => {
  if (isOpen) {
    fetchData();
  } else {
    resetForm();
  }
});

function removePhysicalActivity() {
  state.physicalActivity = { name: "", duration: undefined, intensity: "MILD" };
  showPhysicalActivity.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    const dataToSubmit = { ...event.data };
    if (
      !dataToSubmit.physicalActivity?.name &&
      !dataToSubmit.physicalActivity?.duration &&
      !dataToSubmit.physicalActivity?.intensity
    ) {
      dataToSubmit.physicalActivity = null;
    }
    await dailyPerformanceLogStore.update(props.logId, dataToSubmit);
    toast.success("Registro atualizado com sucesso!");
    open.value = false;
    emit("updated");
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast.error("Erro ao atualizar registro", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      title="Editar Registro de Performance Diária"
    >
      <UButton icon="i-lucide-edit" color="primary" @click="open = true"
        >Editar</UButton
      >

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-6 p-4"
          @submit="onSubmit"
        >
          <UFormField label="Data do Registro" name="dateOfRegistration">
            <UInput
              v-model="state.dateOfRegistration"
              type="date"
              :class="{ 'border-red-500': hasError('dateOfRegistration') }"
            />
            <p
              v-if="getError('dateOfRegistration')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("dateOfRegistration") }}
            </p>
          </UFormField>

          <USeparator label="Sinais Vitais e Sono" />
          <div class="grid grid-cols-2 md:grid-cols-4 items-end gap-4">
            <UFormField label="Pressão Arterial" name="bloodPressure"
              ><UInput v-model="state.bloodPressure" placeholder="Ex: 120/80"
            /></UFormField>
            <UFormField label="O₂ Saturation (%)" name="oxygenSaturation"
              ><UInput v-model.number="state.oxygenSaturation" type="number"
            /></UFormField>
            <UFormField label="BPM" name="beatsPerMinute"
              ><UInput v-model.number="state.beatsPerMinute" type="number"
            /></UFormField>
            <UFormField label="Qualidade do Sono" name="sleepQuality">
              <USelect
                v-model="state.sleepQuality"
                :items="sleepQualityOptions"
                class="w-full"
                option-attribute="label"
                value-attribute="value"
              />
            </UFormField>
          </div>

          <USeparator label="Atividade Física" />
          <div v-if="!showPhysicalActivity" class="flex justify-center">
            <UButton
              icon="i-lucide-plus-circle"
              label="Adicionar Atividade Física"
              @click="showPhysicalActivity = true"
            />
          </div>
          <div v-else class="space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <UFormField
                label="Nome da Atividade"
                name="physicalActivity.name"
                class="sm:col-span-1"
              >
                <UInput
                  v-model="state.physicalActivity.name"
                  placeholder="Ex: Musculação"
                />
              </UFormField>
              <UFormField
                label="Duração (min)"
                name="physicalActivity.duration"
              >
                <UInput
                  v-model.number="state.physicalActivity.duration"
                  type="number"
                />
              </UFormField>
              <UFormField label="Intensidade" name="physicalActivity.intensity">
                <USelect
                  v-model="state.physicalActivity.intensity"
                  :items="intensityOptions"
                  class="w-full"
                  option-attribute="label"
                  value-attribute="value"
                />
              </UFormField>
            </div>
            <div class="flex justify-end">
              <UButton
                icon="i-lucide-trash-2"
                label="Remover Atividade Física"
                color="red"
                variant="soft"
                @click="removePhysicalActivity"
              />
            </div>
          </div>

          <USeparator />
          <UFormField label="Observações" name="observations">
            <UTextarea
              v-model="state.observations"
              placeholder="Observações sobre o dia, bem-estar, etc."
              class="w-full"
            />
          </UFormField>

          <UButton type="submit" block class="mt-8">
            Salvar Alterações
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
