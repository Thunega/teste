<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const psychologicalConsultationStore = usePsychologicalConsultationsStore();
const open = ref(false);

const humorOptions = ["muito ruim", "ruim", "moderado", "bom", "muito bom"];
const anxietyOptions = [
  "muito baixa",
  "baixa",
  "moderada",
  "alta",
  "muito alta",
];

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  consultationDate: z.string({
    required_error: "A data da consulta é obrigatória.",
    invalid_type_error: "A data da consulta é obrigatória.",
  }),
  humor: z.enum(humorOptions, {
    required_error: "Selecione o nível de humor.",
    invalid_type_error: "Selecione o nível de humor.",
  }),
  anxietyLevel: z.enum(anxietyOptions, {
    required_error: "Selecione o nível de ansiedade.",
    invalid_type_error: "Selecione o nível de ansiedade.",
  }),
  observations: z
    .string({
      required_error: "As observações são obrigatórias.",
      invalid_type_error: "As observações são obrigatórias.",
    })
    .min(5, "As observações devem ter pelo menos 5 caracteres."),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  patientId: "",
  consultationDate: "",
  humor: "moderado",
  anxietyLevel: "moderada",
  observations: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, initialState);
  open.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await psychologicalConsultationStore.create(event.data);
    toast("Consulta Criada!", {
      description: "A consulta psicológica foi salva com sucesso.",
    });
    emit("created");
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Consulta", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="false"
      title="Criar Nova Consulta"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-plus-circle" label="Nova Consulta" />

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <div class="flex items-start gap-4">
            <UFormField label="Paciente" name="patientId">
              <PatientsSelectInput
                @update:patient="state.patientId = $event"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField label="Data da Consulta" name="consultationDate">
              <UInput
                v-model="state.consultationDate"
                type="date"
                :class="{ 'border-red-500': hasError('consultationDate') }"
              />
              <p
                v-if="getError('consultationDate')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("consultationDate") }}
              </p>
            </UFormField>
          </div>

          <div class="flex gap-4">
            <UFormField label="Humor" name="humor">
              <USelectMenu
                v-model="state.humor"
                :items="humorOptions"
                :class="{ 'border-red-500': hasError('humor') }"
              />
              <p v-if="getError('humor')" class="text-red-600 text-sm mt-1">
                {{ getError("humor") }}
              </p>
            </UFormField>
            <UFormField label="Nível de Ansiedade" name="anxietyLevel">
              <USelectMenu
                v-model="state.anxietyLevel"
                :items="anxietyOptions"
                :class="{ 'border-red-500': hasError('anxietyLevel') }"
              />
              <p
                v-if="getError('anxietyLevel')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("anxietyLevel") }}
              </p>
            </UFormField>
          </div>

          <UFormField
            label="Observações / Anotações da Sessão"
            name="observations"
          >
            <UTextarea
              v-model="state.observations"
              :rows="6"
              placeholder="Descreva os pontos principais da sessão, evolução do paciente, etc."
              class="w-full"
              :class="{ 'border-red-500': hasError('observations') }"
            />
            <p
              v-if="getError('observations')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("observations") }}
            </p>
          </UFormField>

          <UButton type="submit" block class="mt-6"> Salvar Consulta </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
