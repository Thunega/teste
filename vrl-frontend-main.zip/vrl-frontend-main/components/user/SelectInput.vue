<template>

    <USelectMenu
      v-model="selectedUser"
      v-model:search-term="searchTerm"
      :items="users"
      :loading="status === 'pending'"
      placeholder="Buscar usuário pelo nome..."
      option-attribute="label"
      value-attribute="value"
      ignore-filter
      by="value"
      trailing-icon="i-heroicons-magnifying-glass-20-solid"
    />
</template>

<script setup lang="ts">
import { ref, watch, useId } from 'vue'
import { refDebounced } from '@vueuse/core'

const emit = defineEmits(['update:user'])
const componentId = useId()
// This v-model might receive the full object, so its type is adjusted.
const selectedUser = ref<{ value: string } | string | null>(null)
const searchTerm = ref('')
const searchTermDebounced = refDebounced(searchTerm, 300)

watch(selectedUser, (newValue) => {
  // FIX: Check if the new value is an object. If so, emit its 'value' property (the ID).
  // This guarantees we only emit the user ID string.
  if (newValue && typeof newValue === 'object') {
    emit('update:user', newValue.value)
  } else {
    emit('update:user', newValue)
  }
})

const { $api } = useNuxtApp()

const { data: users, status } = await useAsyncData(
  `search-users-${componentId}`,
  () => {
    if (!searchTermDebounced.value) {
      return Promise.resolve({ data: [] })
    }
    return $api('/users', {
      params: { query: searchTermDebounced.value }
    })
  }, {
    transform: (response: { data: { id: string, name: string, cpf: string }[] }) => {
      const userList = response.data || []
      return userList.map(user => ({
        label: `${user.name} - email: ${user.email}`,
        value: user.id
      }))
    },
    watch: [searchTermDebounced],
    lazy: true,
    default: () => []
  }
)
</script>