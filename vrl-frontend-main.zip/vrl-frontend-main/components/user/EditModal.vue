<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps<{
  userId: string;
}>();

const emit = defineEmits(["updated"]);
const userStore = useUsersStore();

const open = ref(false);
const isLoading = ref(false);

const roleOptions = [
  { value: "ADMIN", label: "Admin" },
  { value: "DOCTOR", label: "Médico" },
  { value: "PHYSIOTHERAPIST", label: "Fisioterapeuta" },
  { value: "PSYCHOLOGIST", label: "Psicólogo" },
  { value: "NUTRITIONIST", label: "Nutricionista" },
  { value: "EDUCATOR_VR", label: "Educador VR" },
  { value: "DATA_COLLECTOR", label: "Coletor de Dados" },
];

const userRoles = [
  "EDUCATOR_VR",
  "DOCTOR",
  "PHYSIOTHERAPIST",
  "PSYCHOLOGIST",
  "NUTRITIONIST",
  "ADMIN",
  "DATA_COLLECTOR",
];

const schema = z.object({
  name: z
    .string({
      required_error: "O nome é obrigatório.",
      invalid_type_error: "O nome é obrigatório.",
    })
    .min(3, "O nome deve ter pelo menos 3 caracteres."),
  email: z
    .string({
      required_error: "O email é obrigatório.",
      invalid_type_error: "O email é obrigatório.",
    })
    .email("Email inválido."),
  role: z.enum(userRoles, {
    required_error: "Selecione uma função.",
    invalid_type_error: "Selecione uma função.",
  }),
  password: z
    .string()
    .regex(
      /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$ %^&*-]).{8,64}$/,
      "A senha deve conter: letra maiúscula, letra minúscula, número e caractere especial (#?!@$ %^&*-).",
    )
    .min(8, "A nova senha deve ter no mínimo 8 caracteres.")
    .max(64, "A senha deve ter no máximo 64 caracteres.")
    .optional()
    .or(z.literal("")),
});

type Schema = z.output<typeof schema>;

const state = reactive<Partial<Schema>>({
  name: "",
  email: "",
  role: undefined,
  password: "",
});

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

async function fetchUserData() {
  if (!props.userId) return;
  try {
    isLoading.value = true;
    const userData = await userStore.getById(props.userId);
    if (userData) {
      state.name = userData.name;
      state.email = userData.email;
      state.role = userData.role;
      state.password = "";
    }
  } catch (error) {
    toast("Erro ao carregar dados", {
      description: "Não foi possível buscar os dados do usuário.",
    });
  } finally {
    isLoading.value = false;
  }
}

watch(open, (isOpen) => {
  if (isOpen) {
    fetchUserData();
  }
});

function openModal() {
  open.value = true;
}

defineExpose({
  openModal,
});

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    const payload = { ...event.data };
    if (!payload.password) {
      delete payload.password;
    }
    await userStore.update(props.userId, payload);
    toast("Usuário Atualizado!", {
      description: "Os dados do usuário foram atualizados com sucesso.",
    });
    emit("updated-user");
    open.value = false;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar Usuário", {
      description:
        error.data?.message || "Não foi possível salvar as alterações.",
    });
  }
}
</script>

<template>
  <UModal
    :dismissible="false"
    v-model:open="open"
    :overlay="false"
    title="Editar Usuário"
    :close="{
      color: 'primary',
      variant: 'outline',
      class: 'rounded-full',
    }"
  >
    <UButton icon="i-lucide-pen-line" label="Editar" />

    <template #body>
      <UForm
        :schema="schema"
        :state="state"
        class="space-y-4"
        @submit="onSubmit"
      >
        <UFormField label="Nome Completo" name="name">
          <UInput
            v-model="state.name"
            class="w-full"
            :class="{ 'border-red-500': hasError('name') }"
          />
          <p v-if="getError('name')" class="text-red-600 text-sm mt-1">
            {{ getError("name") }}
          </p>
        </UFormField>

        <UFormField label="Email" name="email">
          <UInput
            v-model="state.email"
            type="email"
            class="w-full"
            :class="{ 'border-red-500': hasError('email') }"
          />
          <p v-if="getError('email')" class="text-red-600 text-sm mt-1">
            {{ getError("email") }}
          </p>
        </UFormField>

        <UFormField label="Nova Senha" name="password">
          <UInput
            v-model="state.password"
            type="password"
            class="w-full"
            placeholder="Deixe em branco para não alterar"
            :class="{ 'border-red-500': hasError('password') }"
          />
          <p v-if="getError('password')" class="text-red-600 text-sm mt-1">
            {{ getError("password") }}
          </p>
        </UFormField>

        <UFormField label="Função (Role)" name="role">
          <USelect
            v-model="state.role"
            :items="roleOptions"
            class="w-full"
            option-attribute="label"
            value-attribute="value"
            placeholder="Selecione um cargo"
            :class="{ 'border-red-500': hasError('role') }"
          />
          <p v-if="getError('role')" class="text-red-600 text-sm mt-1">
            {{ getError("role") }}
          </p>
        </UFormField>

        <UButton type="submit" block class="mt-6"> Salvar Alterações </UButton>
      </UForm>
    </template>
  </UModal>
</template>
