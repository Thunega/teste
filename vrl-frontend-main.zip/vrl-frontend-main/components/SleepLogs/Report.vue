<script setup lang="ts">

const props = defineProps<{
  patientId: string;
}>()

const sleepLogsStore = useSleepLogsStore();
const limit = ref(10);

const fetchData = async () => {
  await sleepLogsStore.fetchData(
      {
        patientId: props.patientId,
        orderBy: 'createdAt',
        sort: 'desc',
        perPage: limit.value
      }
  )
}

onMounted(fetchData);
</script>

<template>
  <main class="flex flex-wrap flex-col gap-6 mt-6">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <SleepLogsSleepQualityChart :sleep-logs="sleepLogsStore.data" />
      <SleepLogsSleepComposition :sleep-logs="sleepLogsStore.data" />
      <SleepLogsSleepIndicatorsTable :sleep-logs="sleepLogsStore.data" class="col-span-1 lg:col-span-2"/>
    </div>
  </main>
</template>