<script setup lang="ts">
import { computed } from 'vue';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  type ChartOptions,
  type ChartData
} from 'chart.js';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement
);

const props = defineProps<{
  sleepLogs: any[];
}>();

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit' };
  return new Date(dateString).toLocaleDateString('pt-BR', { timeZone: 'UTC', ...options });
};

const chartData = computed<ChartData<'line'>>(() => {
  const sortedLogs = [...props.sleepLogs].sort((a, b) => new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime());

  const labels = sortedLogs.map(log => formatDate(log.dateOfRegistration));

  return {
    labels,
    datasets: [
      {
        label: 'Score do Sono',
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        fill: true,
        data: sortedLogs.map(log => log.score),
        tension: 0.2,
        yAxisID: 'y',
      },
      {
        label: 'Saturação O₂ (%)',
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.2)',
        fill: false,
        data: sortedLogs.map(log => log.avgOxygenSaturation),
        tension: 0.2,
        yAxisID: 'y1',
      },
      {
        label: 'Freq. Cardíaca (bpm)',
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.2)',
        fill: false,
        data: sortedLogs.map(log => log.avgHeartRate),
        tension: 0.2,
        yAxisID: 'y2',
      },
    ],
  };
});

const chartOptions: ChartOptions<'line'> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    title: {
      display: true,
      text: 'Evolução das Métricas de Sono',
      font: { size: 18 }
    },
  },
  scales: {
    y: {
      type: 'linear',
      position: 'left',
      min: 0,
      max: 100,
      title: {
        display: true,
        text: 'Score'
      }
    },
    y1: {
      type: 'linear',
      position: 'right',
      min: 90,
      max: 100,
      title: {
        display: true,
        text: 'Saturação O₂ (%)'
      },
      grid: {
        drawOnChartArea: false,
      },
    },
    y2: {
      type: 'linear',
      position: 'right',
      min: 40,
      max: 100,
      title: {
        display: true,
        text: 'Freq. Cardíaca (bpm)'
      },
      grid: {
        drawOnChartArea: false,
      },
    },
  }
};

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Line v-if="props.sleepLogs && props.sleepLogs.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Sem dados de sono para exibir.
      </p>
    </div>
  </div>
</template>