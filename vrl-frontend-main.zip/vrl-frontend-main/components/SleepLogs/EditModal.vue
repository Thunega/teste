<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";
import { timeToMinutes, minutesToTime } from "@/utils";

const props = defineProps<{
  sleepLogId: string;
}>();

const emit = defineEmits(["updated"]);
const sleepLogStore = useSleepLogsStore();
const open = ref(false);
const isLoading = ref(false);

defineExpose({
  open: () => (open.value = true),
  close: () => (open.value = false),
});

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  dateOfRegistration: z.string({
    required_error: "A data do registro é obrigatória.",
    invalid_type_error: "A data do registro é obrigatória.",
  }),
  score: z.coerce
    .number({
      required_error: "O score é obrigatório.",
      invalid_type_error: "O score deve ser um número.",
    })
    .int("O score deve ser um número inteiro.")
    .min(0, "O score deve ser no mínimo 0.")
    .max(100, "O score deve ser no máximo 100."),
  sleepTime: z
    .string({
      required_error: "O tempo dormindo é obrigatório.",
      invalid_type_error: "O tempo dormindo é obrigatório.",
    })
    .regex(/^\d{1,2}:\d{2}$/, "Formato inválido. Use HH:MM"),
  agreedTime: z
    .string({
      required_error: "O tempo acordado é obrigatório.",
      invalid_type_error: "O tempo acordado é obrigatório.",
    })
    .regex(/^\d{1,2}:\d{2}$/, "Formato inválido. Use HH:MM"),
  remTime: z
    .string({
      required_error: "O sono REM é obrigatório.",
      invalid_type_error: "O sono REM é obrigatório.",
    })
    .regex(/^\d{1,2}:\d{2}$/, "Formato inválido. Use HH:MM"),
  lightSleep: z
    .string({
      required_error: "O sono leve é obrigatório.",
      invalid_type_error: "O sono leve é obrigatório.",
    })
    .regex(/^\d{1,2}:\d{2}$/, "Formato inválido. Use HH:MM"),
  deepSleep: z
    .string({
      required_error: "O sono profundo é obrigatório.",
      invalid_type_error: "O sono profundo é obrigatório.",
    })
    .regex(/^\d{1,2}:\d{2}$/, "Formato inválido. Use HH:MM"),
  avgOxygenSaturation: z.coerce
    .number({
      required_error: "A saturação média de oxigênio é obrigatória.",
      invalid_type_error: "A saturação deve ser um número.",
    })
    .min(0, "A saturação deve ser no mínimo 0%.")
    .max(100, "A saturação deve ser no máximo 100%."),
  avgHeartRate: z.coerce
    .number({
      required_error: "A frequência cardíaca média é obrigatória.",
      invalid_type_error: "A frequência cardíaca deve ser um número.",
    })
    .positive("A frequência cardíaca deve ser um número positivo."),
  observations: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const initialState: Partial<Schema> = {
  patientId: undefined,
  dateOfRegistration: undefined,
  score: undefined,
  sleepTime: "00:00",
  agreedTime: "00:00",
  remTime: "00:00",
  lightSleep: "00:00",
  deepSleep: "00:00",
  avgOxygenSaturation: undefined,
  avgHeartRate: undefined,
  observations: undefined,
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

watch(open, (isOpen) => {
  if (isOpen) {
    fetchData();
  }
});

async function fetchData() {
  try {
    isLoading.value = true;
    const sleepLogData = await sleepLogStore.getById(props.sleepLogId);
    if (sleepLogData) {
      state.patientId = sleepLogData.patientId;
      state.dateOfRegistration = sleepLogData.dateOfRegistration;
      state.score = sleepLogData.score;
      state.sleepTime = minutesToTime(sleepLogData.sleepTime);
      state.agreedTime = minutesToTime(sleepLogData.agreedTime);
      state.remTime = minutesToTime(sleepLogData.remTime);
      state.lightSleep = minutesToTime(sleepLogData.lightSleep);
      state.deepSleep = minutesToTime(sleepLogData.deepSleep);
      state.avgOxygenSaturation = sleepLogData.avgOxygenSaturation;
      state.avgHeartRate = sleepLogData.avgHeartRate;
      state.observations = sleepLogData.observations;
    }
  } catch (error) {
    toast.error("Erro ao carregar dados do registro de sono.");
  } finally {
    isLoading.value = false;
  }
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    const dataToSubmit = {
      ...event.data,
      sleepTime: timeToMinutes(event.data.sleepTime),
      agreedTime: timeToMinutes(event.data.agreedTime),
      remTime: timeToMinutes(event.data.remTime),
      lightSleep: timeToMinutes(event.data.lightSleep),
      deepSleep: timeToMinutes(event.data.deepSleep),
    };

    await sleepLogStore.update(props.sleepLogId, dataToSubmit);

    toast("Registro de Sono Atualizado!", {
      description:
        "Os dados do registro de sono foram atualizados com sucesso.",
    });

    emit("updated");
    open.value = false;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar Registro", {
      description:
        error.data?.message || "Não foi possível salvar as alterações.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="true"
      title="Editar Registro de Sono"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <template #body>
        <div v-if="isLoading" class="p-8 text-center">
          <p>Carregando dados do registro de sono...</p>
        </div>

        <UForm
          v-else
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <UFormField label="ID do Paciente" name="patientId">
              <UInput
                type="text"
                v-model="state.patientId"
                class="w-full"
                readonly
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField label="Selecionar Novo Paciente">
              <PatientsSelectInput @update:patient="state.patientId = $event" />
            </UFormField>
          </div>

          <UFormField label="Data do Registro" name="dateOfRegistration">
            <UInput
              v-model="state.dateOfRegistration"
              type="date"
              class="w-full"
              :class="{ 'border-red-500': hasError('dateOfRegistration') }"
            />
            <p
              v-if="getError('dateOfRegistration')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("dateOfRegistration") }}
            </p>
          </UFormField>

          <USeparator
            label="Métricas do Sono (Score 0-100, tempos no formato HH:MM)"
          />

          <div class="grid grid-cols-2 md:grid-cols-4 gap-4 items-end">
            <UFormField label="Score (0-100)" name="score">
              <UInput
                v-model.number="state.score"
                type="number"
                :class="{ 'border-red-500': hasError('score') }"
              />
              <p v-if="getError('score')" class="text-red-600 text-sm mt-1">
                {{ getError("score") }}
              </p>
            </UFormField>
            <UFormField label="Tempo Dormindo" name="sleepTime"
              ><UInput
                v-model="state.sleepTime"
                type="time"
                placeholder="HH:MM"
            /></UFormField>
            <UFormField label="Tempo Acordado" name="agreedTime"
              ><UInput
                v-model="state.agreedTime"
                type="time"
                placeholder="HH:MM"
            /></UFormField>
            <UFormField label="Sono REM" name="remTime"
              ><UInput v-model="state.remTime" type="time" placeholder="HH:MM"
            /></UFormField>
            <UFormField label="Sono Leve" name="lightSleep"
              ><UInput
                v-model="state.lightSleep"
                type="time"
                placeholder="HH:MM"
            /></UFormField>
            <UFormField label="Sono Profundo" name="deepSleep"
              ><UInput
                v-model="state.deepSleep"
                type="time"
                placeholder="HH:MM"
            /></UFormField>
          </div>

          <USeparator label="Métricas de Saúde" />

          <div class="grid grid-cols-2 gap-4 items-end">
            <UFormField
              label="Saturação Média de Oxigênio (%)"
              name="avgOxygenSaturation"
              ><UInput
                v-model.number="state.avgOxygenSaturation"
                type="number"
                step="0.1"
            /></UFormField>
            <UFormField
              label="Frequência Cardíaca Média (bpm)"
              name="avgHeartRate"
              ><UInput v-model.number="state.avgHeartRate" type="number"
            /></UFormField>
          </div>

          <UFormField label="Observações" name="observations">
            <UTextarea
              v-model="state.observations"
              class="w-full"
              placeholder="Qualquer observação relevante sobre a noite de sono..."
            />
          </UFormField>

          <UButton type="submit" block class="mt-6">
            Salvar Alterações
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
