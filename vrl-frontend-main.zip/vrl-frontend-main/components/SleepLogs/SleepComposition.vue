<script setup lang="ts">
import { computed } from 'vue';
import { Bar } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
  type ChartOptions,
  type ChartData
} from 'chart.js';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    BarElement,
    CategoryScale,
    LinearScale
);

const props = defineProps<{
  sleepLogs: any[];
}>();

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit' };
  return new Date(dateString).toLocaleDateString('pt-BR', { timeZone: 'UTC', ...options });
};

const chartData = computed<ChartData<'bar'>>(() => {
  const sortedLogs = [...props.sleepLogs].sort((a, b) => new Date(a.dateOfRegistration).getTime() - new Date(b.dateOfRegistration).getTime());

  return {
    labels: sortedLogs.map(log => formatDate(log.dateOfRegistration)),
    datasets: [
      {
        label: 'Sono Leve',
        data: sortedLogs.map(log => log.lightSleep),
        backgroundColor: 'rgb(107, 114, 128)',
      },
      {
        label: 'Sono Profundo',
        data: sortedLogs.map(log => log.deepSleep),
        backgroundColor: 'rgb(59, 130, 246)',
      },
      {
        label: 'Sono REM',
        data: sortedLogs.map(log => log.remTime),
        backgroundColor: 'rgb(139, 92, 246)',
      },
    ],
  };
});

const chartOptions: ChartOptions<'bar'> = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    title: {
      display: true,
      text: 'Composição das Fases do Sono (min)',
      font: { size: 18 }
    },
  },
  scales: {
    x: {
      stacked: true,
    },
    y: {
      stacked: true,
      title: {
        display: true,
        text: 'Minutos'
      }
    }
  }
};

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Bar v-if="props.sleepLogs && props.sleepLogs.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Sem dados de sono para exibir.
      </p>
    </div>
  </div>
</template>