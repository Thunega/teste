<script setup lang="ts">
import { computed } from 'vue';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

const props = defineProps<{
  sleepLogs: any[];
}>();

const sortedLogs = computed(() => {
  if (!props.sleepLogs) return [];
  return [...props.sleepLogs].sort((a, b) => new Date(b.dateOfRegistration).getTime() - new Date(a.dateOfRegistration).getTime());
});

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit', year: 'numeric' };
  return new Date(dateString).toLocaleDateString('pt-BR', { timeZone: 'UTC', ...options });
};
</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <Table v-if="sortedLogs.length > 0">
      <TableCaption>Indicadores de qualidade do sono.</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead class="w-[120px]">Data</TableHead>
          <TableHead>Pontuação</TableHead>
          <TableHead>Saturação O₂ (%)</TableHead>
          <TableHead class="text-right">Freq. Cardíaca (bpm)</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow v-for="log in sortedLogs" :key="log.id">
          <TableCell class="font-medium">{{ formatDate(log.dateOfRegistration) }}</TableCell>
          <TableCell>{{ log.score }} / 100</TableCell>
          <TableCell>{{ log.avgOxygenSaturation }}%</TableCell>
          <TableCell class="text-right">{{ log.avgHeartRate }}</TableCell>
        </TableRow>
      </TableBody>
    </Table>
    <p v-else class="py-4 text-center text-gray-500">
      Sem dados de sono para exibir.
    </p>
  </div>
</template>