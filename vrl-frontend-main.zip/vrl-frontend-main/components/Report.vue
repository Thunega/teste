<script setup lang="ts">
import { computed, ref } from 'vue'
import { Line } from 'vue-chartjs'
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement
} from 'chart.js'

ChartJS.register(Title, Tooltip, Legend, LineElement, CategoryScale, LinearScale, PointElement)

const props = defineProps<{
  reportData: Record<string, any>;
}>()

const timelineEvents = computed(() => {
  const events = [];
  const { exams, nutritionalConsultations, medicalConsultations, psychologicalConsultations } = props.reportData;

  if (exams) {
    exams.forEach(exam => events.push({
      date: new Date(exam.createdAt),
      type: 'Exame Laboratorial',
      icon: 'i-lucide-beaker',
      color: 'blue',
      data: exam
    }))
  }
  if (nutritionalConsultations) {
    nutritionalConsultations.forEach(consult => events.push({
      date: new Date(consult.createdAt),
      type: 'Consulta Nutricional',
      icon: 'i-lucide-apple',
      color: 'green',
      data: consult
    }))
  }
  if (medicalConsultations) {
    medicalConsultations.forEach(consult => events.push({
      date: new Date(consult.createdAt),
      type: 'Consulta Médica',
      icon: 'i-lucide-stethoscope',
      color: 'red',
      data: consult
    }))
  }
  if (psychologicalConsultations) {
    psychologicalConsultations.forEach(consult => events.push({
      date: new Date(consult.createdAt),
      type: 'Consulta Psicológica',
      icon: 'i-lucide-brain-circuit',
      color: 'purple',
      data: consult
    }))
  }

  return events.sort((a, b) => b.date.getTime() - a.date.getTime());
})

const getChartData = (label: string, dataKey: string, sourceArray: any[], dateKey: string = 'consultationDate') => {
  const sortedData = [...sourceArray].sort((a, b) => new Date(a[dateKey]).getTime() - new Date(b[dateKey]).getTime());
  return {
    labels: sortedData.map(item => new Date(item[dateKey]).toLocaleDateString('pt-BR')),
    datasets: [{
      label: label,
      backgroundColor: '#18a36b',
      borderColor: '#18a36b',
      data: sortedData.map(item => item[dataKey]),
      tension: 0.1
    }]
  }
}

const weightChartData = computed(() => getChartData('Peso (kg)', 'weightKg', props.reportData.nutritionalConsultations))
const cholesterolChartData = computed(() => getChartData('Colesterol Total (mg/dL)', 'totalCholesterol', props.reportData.exams, 'createdAt'))

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false
}
</script>

<template>
  <div class="space-y-8">
    <UCard>
      <template #header>
        <h3 class="text-lg font-semibold">Gráficos de Evolução</h3>
      </template>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8 h-72">
        <div v-if="weightChartData.datasets[0].data.length > 1">
          <h4 class="font-medium text-center mb-2">Evolução do Peso</h4>
          <Line :data="weightChartData" :options="chartOptions" />
        </div>
        <div v-if="cholesterolChartData.datasets[0].data.length > 1">
          <h4 class="font-medium text-center mb-2">Evolução do Colesterol</h4>
          <Line :data="cholesterolChartData" :options="chartOptions" />
        </div>
      </div>
      <div v-if="weightChartData.datasets[0].data.length <= 1 && cholesterolChartData.datasets[0].data.length <= 1" class="text-center py-8 text-gray-500">
        <p>Não há dados suficientes para gerar gráficos de evolução.</p>
        <p class="text-sm">É necessário pelo menos dois registros de peso ou colesterol.</p>
      </div>
    </UCard>

    <UCard>
      <template #header>
        <h3 class="text-lg font-semibold">Linha do Tempo de Atendimentos</h3>
      </template>
      <div class="relative pl-8">
        <div class="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200 dark:bg-gray-700"></div>

        <div v-for="(event, index) in timelineEvents" :key="event.data.id" class="relative mb-8">
          <div :class="`absolute -left-[38px] top-1 flex items-center justify-center size-8 rounded-full bg-${event.color}-500 text-white`">
            <UIcon :name="event.icon" class="size-5" />
          </div>
          <div class="p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-800">
            <div class="flex justify-between items-center mb-2">
              <h4 class="font-semibold text-gray-800 dark:text-gray-200">{{ event.type }}</h4>
              <time class="text-sm text-gray-500 dark:text-gray-400">{{ new Date(event.date).toLocaleDateString('pt-BR') }}</time>
            </div>

            <div v-if="event.type === 'Exame Laboratorial'" class="text-sm">
              <p>Colesterol: {{ event.data.totalCholesterol }} mg/dL, Glicemia: {{ event.data.fastingGlucose }} mg/dL</p>
            </div>
            <div v-if="event.type === 'Consulta Nutricional'" class="text-sm">
              <p><b>Motivo:</b> {{ event.data.reason }}</p>
              <p><b>Peso:</b> {{ event.data.weightKg }} kg</p>
            </div>
            <div v-if="event.type === 'Consulta Médica'" class="text-sm">
              <p class="line-clamp-2"><b>Observações:</b> {{ event.data.observations }}</p>
            </div>
            <div v-if="event.type === 'Consulta Psicológica'" class="text-sm">
              <p><b>Humor:</b> {{ event.data.humor }} | <b>Ansiedade:</b> {{ event.data.anxietyLevel }}</p>
            </div>
          </div>
        </div>
      </div>
    </UCard>
  </div>
</template>