<script setup lang="ts">
import { ref } from "vue";
import { toast } from "vue-sonner";

const props = defineProps({
  id: {
    type: String,
    required: true,
  },
});

const emit = defineEmits(["deleted"]);
const weeklyWeightsStore = useWeeklyWeightsStore();
const open = ref(false);
const loading = ref(false);

defineExpose({
  open: () => (open.value = true),
  close: () => (open.value = false),
});

async function handleDelete() {
  loading.value = true;
  try {
    await weeklyWeightsStore.delete(props.id);
    toast("Registro Excluído!", {
      description: "O registro de peso semanal foi excluído com sucesso.",
    });
    emit("deleted");
    open.value = false;
  } catch (error: any) {
    toast("Erro ao Excluir", {
      description:
        error.data?.message || "Não foi possível excluir o registro.",
    });
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <UModal
    :dismissible="false"
    v-model:open="open"
    title="Confirmar Exclusão"
    :close="{
      color: 'primary',
      variant: 'outline',
      class: 'rounded-full',
    }"
  >
    <template #body>
      <div class="space-y-4">
        <p class="text-gray-700 dark:text-gray-300">
          Tem certeza que deseja excluir este registro de peso semanal? Esta
          ação não pode ser desfeita.
        </p>

        <div class="flex gap-2 justify-end">
          <UButton variant="outline" @click="open = false"> Cancelar </UButton>
          <UButton color="red" :loading="loading" @click="handleDelete">
            Excluir
          </UButton>
        </div>
      </div>
    </template>
  </UModal>
</template>
