<script setup lang="ts">
import { computed } from 'vue';

const props = defineProps<{
  weeklyWeights: any[];
}>();

const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('pt-BR', { timeZone: 'UTC' });
};

const sortedWeights = computed(() => {
  return [...props.weeklyWeights].sort((a, b) =>
    new Date(b.weekStartDate).getTime() - new Date(a.weekStartDate).getTime()
  );
});

const weightStats = computed(() => {
  if (!props.weeklyWeights || props.weeklyWeights.length === 0) return null;

  const weights = props.weeklyWeights.map(w => w.weightKg);
  const min = Math.min(...weights);
  const max = Math.max(...weights);
  const avg = weights.reduce((a, b) => a + b, 0) / weights.length;

  // Calculate weight change (most recent - oldest)
  const sorted = [...props.weeklyWeights].sort((a, b) =>
    new Date(a.weekStartDate).getTime() - new Date(b.weekStartDate).getTime()
  );
  const oldest = sorted[0]?.weightKg;
  const newest = sorted[sorted.length - 1]?.weightKg;
  const change = newest - oldest;

  return {
    min: min.toFixed(1),
    max: max.toFixed(1),
    avg: avg.toFixed(1),
    change: change.toFixed(1),
    changePercent: ((change / oldest) * 100).toFixed(1)
  };
});
</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <h3 class="text-lg font-semibold mb-4">Resumo de Peso Semanal</h3>

    <div v-if="weightStats" class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
      <div class="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <p class="text-sm text-gray-500 dark:text-gray-400">Peso Mínimo</p>
        <p class="text-xl font-bold text-green-600">{{ weightStats.min }} kg</p>
      </div>
      <div class="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <p class="text-sm text-gray-500 dark:text-gray-400">Peso Máximo</p>
        <p class="text-xl font-bold text-red-600">{{ weightStats.max }} kg</p>
      </div>
      <div class="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <p class="text-sm text-gray-500 dark:text-gray-400">Peso Médio</p>
        <p class="text-xl font-bold text-blue-600">{{ weightStats.avg }} kg</p>
      </div>
      <div class="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <p class="text-sm text-gray-500 dark:text-gray-400">Variação Total</p>
        <p class="text-xl font-bold" :class="parseFloat(weightStats.change) >= 0 ? 'text-red-600' : 'text-green-600'">
          {{ weightStats.change > 0 ? '+' : '' }}{{ weightStats.change }} kg
        </p>
      </div>
      <div class="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <p class="text-sm text-gray-500 dark:text-gray-400">Variação (%)</p>
        <p class="text-xl font-bold" :class="parseFloat(weightStats.changePercent) >= 0 ? 'text-red-600' : 'text-green-600'">
          {{ weightStats.changePercent > 0 ? '+' : '' }}{{ weightStats.changePercent }}%
        </p>
      </div>
    </div>

    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead class="bg-gray-50 dark:bg-gray-800">
          <tr>
            <th class="px-4 py-2 text-left font-semibold">Data</th>
            <th class="px-4 py-2 text-left font-semibold">Peso (kg)</th>
            <th class="px-4 py-2 text-left font-semibold">Variação</th>
            <th class="px-4 py-2 text-left font-semibold">Observações</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(weight, index) in sortedWeights" :key="weight.id" class="border-t border-gray-200 dark:border-gray-700">
            <td class="px-4 py-2">{{ formatDate(weight.weekStartDate) }}</td>
            <td class="px-4 py-2 font-semibold">{{ weight.weightKg }} kg</td>
            <td class="px-4 py-2">
              <span v-if="index < sortedWeights.length - 1" :class="{
                'text-green-600': sortedWeights[index + 1].weightKg > weight.weightKg,
                'text-red-600': sortedWeights[index + 1].weightKg < weight.weightKg,
                'text-gray-500': sortedWeights[index + 1].weightKg === weight.weightKg
              }">
                {{ (weight.weightKg - sortedWeights[index + 1].weightKg).toFixed(1) }} kg
              </span>
              <span v-else class="text-gray-400">-</span>
            </td>
            <td class="px-4 py-2 text-gray-600 dark:text-gray-400">{{ weight.observations || 'N/A' }}</td>
          </tr>
        </tbody>
      </table>
      <p v-if="!weeklyWeights || weeklyWeights.length === 0" class="text-center py-8 text-gray-500">
        Nenhum registro de peso encontrado.
      </p>
    </div>
  </div>
</template>
