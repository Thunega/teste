<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const weeklyWeightsStore = useWeeklyWeightsStore();
const open = ref(false);

const schema = z.object({
  weekStartDate: z.string({
    required_error: "A data de início da semana é obrigatória.",
    invalid_type_error: "A data de início da semana é obrigatória.",
  }),
  weightKg: z.coerce
    .number({
      invalid_type_error: "O peso deve ser um número.",
      required_error: "O peso é obrigatório.",
    })
    .positive("O peso deve ser positivo."),
  observations: z.string().optional(),
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  weekStartDate: "",
  weightKg: 0,
  observations: "",
  patientId: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, initialState);
  open.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await weeklyWeightsStore.create(event.data);
    toast("Peso Semanal Registrado!", {
      description: "O registro de peso semanal foi salvo com sucesso.",
    });
    emit("created");
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Registro", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      title="Novo Registro de Peso Semanal"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-plus-circle" label="Novo Registro" />
      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <UFormField label="Paciente" name="patientId">
            <PatientsSelectInput
              @update:patient="state.patientId = $event"
              :class="{ 'border-red-500': hasError('patientId') }"
            />
            <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
              {{ getError("patientId") }}
            </p>
          </UFormField>

          <div class="grid grid-cols-2 gap-4">
            <UFormField label="Início da Semana" name="weekStartDate">
              <UInput
                v-model="state.weekStartDate"
                type="date"
                :class="{ 'border-red-500': hasError('weekStartDate') }"
              />
              <p
                v-if="getError('weekStartDate')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("weekStartDate") }}
              </p>
            </UFormField>

            <UFormField label="Peso (kg)" name="weightKg">
              <UInput
                v-model.number="state.weightKg"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('weightKg') }"
              />
              <p v-if="getError('weightKg')" class="text-red-600 text-sm mt-1">
                {{ getError("weightKg") }}
              </p>
            </UFormField>
          </div>

          <UFormField label="Observações" name="observations">
            <UTextarea
              v-model="state.observations"
              class="w-full"
              rows="3"
              :class="{ 'border-red-500': hasError('observations') }"
            />
            <p
              v-if="getError('observations')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("observations") }}
            </p>
          </UFormField>

          <UButton type="submit" block class="mt-4"> Salvar Registro </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
