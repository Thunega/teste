<script setup lang="ts">

const props = defineProps<{
  patientId: string;
}>()

const weeklyWeightsStore = useWeeklyWeightsStore();
const limit = ref(20);

const fetchData = async () => {
  await weeklyWeightsStore.fetchData(
      {
        patientId: props.patientId,
        orderBy: 'weekStartDate',
        sort: 'desc',
        perPage: limit.value
      }
  )
}

onMounted(fetchData);
</script>

<template>
  <main class="flex flex-wrap flex-col gap-6 mt-6">
    <div class="grid grid-cols-1 gap-6">
      <WeeklyWeightsWeightProgressionChart :weekly-weights="weeklyWeightsStore.data" />
      <WeeklyWeightsWeightSummaryTable :weekly-weights="weeklyWeightsStore.data" />
    </div>
  </main>
</template>
