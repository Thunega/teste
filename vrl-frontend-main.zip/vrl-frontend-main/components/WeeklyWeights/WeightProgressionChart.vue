<script setup lang="ts">
import { computed } from 'vue';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Filler,
  type ChartOptions,
  type ChartData
} from 'chart.js';
import annotationPlugin from 'chartjs-plugin-annotation';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement,
    Filler,
    annotationPlugin
);

const props = defineProps<{
  weeklyWeights: any[];
}>();

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: '2-digit', month: '2-digit', day: '2-digit', timeZone: 'UTC' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const chartData = computed<ChartData<'line'>>(() => {
  const sortedWeights = [...props.weeklyWeights].sort((a, b) =>
    new Date(a.weekStartDate).getTime() - new Date(b.weekStartDate).getTime()
  );
  const labels = sortedWeights.map(weight => formatDate(weight.weekStartDate));

  return {
    labels,
    datasets: [
      {
        label: 'Peso (kg)',
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.2)',
        fill: true,
        data: sortedWeights.map(weight => weight.weightKg),
        tension: 0.3,
      },
    ],
  };
});

const chartOptions = computed<ChartOptions<'line'>>(() => {
  const weights = props.weeklyWeights.map(w => w.weightKg);
  const minWeight = Math.min(...weights);
  const maxWeight = Math.max(...weights);
  const avgWeight = weights.reduce((a, b) => a + b, 0) / weights.length;

  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Progressão de Peso Semanal',
        font: {
          size: 18,
        },
        padding: {
          bottom: 20,
        }
      },
      annotation: {
        annotations: {
          avgWeightLine: {
            type: 'line',
            yMin: avgWeight,
            yMax: avgWeight,
            borderColor: 'rgba(59, 130, 246, 0.6)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `Média: ${avgWeight.toFixed(1)} kg`,
              position: 'start',
              enabled: true,
              font: { size: 10, weight: 'bold' },
              color: 'rgba(59, 130, 246, 0.8)',
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }
          },
        }
      }
    },
    scales: {
      y: {
        suggestedMin: minWeight - 5,
        suggestedMax: maxWeight + 5,
        title: {
          display: true,
          text: 'Peso (kg)'
        }
      },
      x: {
        title: {
          display: false,
        }
      }
    }
  };
});

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Line v-if="props.weeklyWeights && props.weeklyWeights.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Dados insuficientes para gerar o gráfico de progressão de peso.
      </p>
    </div>
  </div>
</template>
