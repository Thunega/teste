<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps({
  weeklyWeight: {
    type: Object,
    required: true,
  },
});

const emit = defineEmits(["updated"]);
const weeklyWeightsStore = useWeeklyWeightsStore();
const open = ref(false);

defineExpose({
  open: () => (open.value = true),
  close: () => (open.value = false),
});

const schema = z.object({
  weekStartDate: z.string({
    required_error: "A data de início da semana é obrigatória.",
    invalid_type_error: "A data de início da semana é obrigatória.",
  }),
  weightKg: z.coerce
    .number({
      invalid_type_error: "O peso deve ser um número.",
      required_error: "O peso é obrigatório.",
    })
    .positive("O peso deve ser positivo."),
  observations: z.string().optional(),
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
});

type Schema = z.output<typeof schema>;

const state = reactive<Schema>({
  weekStartDate: "",
  weightKg: 0,
  observations: "",
  patientId: "",
});

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

watch(
  () => props.weeklyWeight,
  (newVal) => {
    if (newVal) {
      state.weekStartDate = newVal.weekStartDate || "";
      state.weightKg = newVal.weightKg || 0;
      state.observations = newVal.observations || "";
      state.patientId = newVal.patientId || "";
    }
  },
  { immediate: true },
);

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    const updated = await weeklyWeightsStore.update(
      props.weeklyWeight.id,
      event.data,
    );
    toast("Peso Semanal Atualizado!", {
      description: "O registro de peso semanal foi atualizado com sucesso.",
    });
    emit("updated", updated);
    open.value = false;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar Registro", {
      description:
        error.data?.message || "Não foi possível atualizar os dados.",
    });
  }
}
</script>

<template>
  <UModal
    :dismissible="false"
    v-model:open="open"
    title="Editar Registro de Peso Semanal"
    :close="{
      color: 'primary',
      variant: 'outline',
      class: 'rounded-full',
    }"
  >
    <template #body>
      <UForm
        :schema="schema"
        :state="state"
        class="space-y-4"
        @submit="onSubmit"
      >
        <UFormField label="Paciente ID" name="patientId">
          <UInput v-model="state.patientId" readonly disabled />
        </UFormField>

        <div class="grid grid-cols-2 gap-4">
          <UFormField label="Início da Semana" name="weekStartDate">
            <UInput v-model="state.weekStartDate" type="date" />
          </UFormField>

          <UFormField label="Peso (kg)" name="weightKg">
            <UInput v-model.number="state.weightKg" type="number" step="0.1" />
          </UFormField>
        </div>

        <UFormField label="Observações" name="observations">
          <UTextarea v-model="state.observations" class="w-full" rows="3" />
        </UFormField>

        <UButton type="submit" block class="mt-4"> Salvar Alterações </UButton>
      </UForm>
    </template>
  </UModal>
</template>
