<script setup lang="ts">
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps<{
  medication: any;
}>();

const emit = defineEmits(["medicationUpdated"]);

const open = ref(false);

const schema = z.object({
  name: z
    .string({
      required_error: "O nome do medicamento é obrigatório.",
      invalid_type_error: "O nome do medicamento é obrigatório.",
    })
    .min(2, "O nome deve ter pelo menos 2 caracteres."),
  dosage: z
    .string({
      required_error: "A dosagem é obrigatória.",
      invalid_type_error: "A dosagem é obrigatória.",
    })
    .min(1, "A dosagem é obrigatória."),
  timetables: z.string().optional(),
  duration: z.string().optional(),
  status: z.enum(["ACTIVE", "INACTIVE"], {
    required_error: "Selecione o status.",
    invalid_type_error: "Selecione o status.",
  }),
  discontinuedReason: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const state = reactive<Partial<Schema>>({
  name: "",
  dosage: "",
  timetables: "",
  duration: "",
  status: "ACTIVE",
  discontinuedReason: "",
});

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

watch(
  () => props.medication,
  (med) => {
    if (!med) return;

    state.name = med.title;
    state.dosage = med.dose;
    state.timetables = med.timetables;
    state.duration = med.duration;

    state.status =
      med.description === "Ativo"
        ? "ACTIVE"
        : med.description === "Interrompido"
          ? "INACTIVE"
          : "ACTIVE";

    state.discontinuedReason = med.discontinuedReason ?? "";
  },
  { immediate: true },
);

const statusOptions = [
  { label: "Ativo", value: "ACTIVE" },
  { label: "Interrompido", value: "INACTIVE" },
];

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    const { $api } = useNuxtApp();

    // 1️⃣ Atualiza dados do medicamento
    await $api(`/medications/${props.medication.id}`, {
      method: "PATCH",
      body: {
        name: state.name,
        dosage: state.dosage,
        timetables: state.timetables,
        duration: state.duration,
      },
    });

    // 2️⃣ Atualiza status do medicamento
    await $api(`/medications/${props.medication.id}/status`, {
      method: "PATCH",
      body: {
        status: state.status,
        discontinuedReason:
          state.status === "INACTIVE" ? state.discontinuedReason : null,
      },
    });

    toast("Medicamento atualizado");

    emit("medicationUpdated");
    open.value = false;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    console.error(error);

    toast("Erro ao atualizar medicamento", {
      description: error?.data?.message ?? "Erro inesperado",
    });
  }
}
</script>

<template>
  <div>
    <UButton
      icon="i-heroicons-pencil-square"
      size="xs"
      variant="ghost"
      @click="open = true"
    />

    <UModal v-model:open="open" title="Editar Medicamento" :dismissible="false">
      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <UFormField label="Nome">
            <UInput v-model="state.name" />
          </UFormField>

          <UFormField label="Dosagem">
            <UInput v-model="state.dosage" />
          </UFormField>

          <UFormField label="Horários">
            <UInput v-model="state.timetables" />
          </UFormField>

          <UFormField label="Duração">
            <UInput v-model="state.duration" />
          </UFormField>

          <UFormField label="Status" name="status">
            <USelect
              v-model="state.status"
              :items="statusOptions"
              option-attribute="label"
              value-attribute="value"
            />
          </UFormField>

          <UFormField
            v-if="state.status === 'INACTIVE'"
            label="Motivo da interrupção"
          >
            <UTextarea
              v-model="state.discontinuedReason"
              placeholder="Opcional"
            />
          </UFormField>

          <UButton type="submit" block class="mt-6">
            Salvar Alterações
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
