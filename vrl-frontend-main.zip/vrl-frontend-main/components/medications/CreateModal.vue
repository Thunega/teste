<script setup lang="ts">
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps<{
  patientId: string;
}>();

const open = ref(false);
const emit = defineEmits(["medicationCreated"]);

const medicationSchema = z.object({
  name: z
    .string({
      required_error: "O nome do medicamento é obrigatório.",
      invalid_type_error: "O nome do medicamento é obrigatório.",
    })
    .min(2, "O nome deve ter pelo menos 2 caracteres."),
  dosage: z
    .string({
      required_error: "A dosagem é obrigatória.",
      invalid_type_error: "A dosagem é obrigatória.",
    })
    .min(1, "A dosagem é obrigatória."),
  timetables: z.string().optional(),
  duration: z.string().optional(),
});

type MedicationSchema = z.output<typeof medicationSchema>;

const state = reactive<Partial<MedicationSchema>>({
  name: "",
  dosage: "",
  timetables: "",
  duration: "",
});

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(medicationSchema, state);

async function onSubmit(event: FormSubmitEvent<MedicationSchema>) {
  if (!validate()) return;

  try {
    const { $api } = useNuxtApp();

    await $api("/medications", {
      method: "POST",
      body: {
        ...event.data,
        patientId: props.patientId,
      },
    });

    toast("Medicamento criado!", {
      description: "Medicamento adicionado ao paciente.",
    });

    emit("medicationCreated");
    open.value = false;

    // limpa formulário
    Object.assign(state, {
      name: "",
      dosage: "",
      timetables: "",
      duration: "",
    });
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    console.error(error);

    toast("Erro ao criar medicamento", {
      description: error?.data?.message ?? "Erro inesperado",
    });
  }
}
</script>

<template>
  <UModal v-model:open="open" :dismissible="false" title="Novo Medicamento">
    <UButton icon="i-heroicons-plus-circle"> Novo Medicamento </UButton>

    <template #body>
      <UForm
        :schema="medicationSchema"
        :state="state"
        class="space-y-4"
        @submit="onSubmit"
      >
        <UFormField label="Nome" name="name">
          <UInput
            v-model="state.name"
            :class="{ 'border-red-500': hasError('name') }"
          />
          <p v-if="getError('name')" class="text-red-600 text-sm mt-1">
            {{ getError("name") }}
          </p>
        </UFormField>

        <UFormField label="Dosagem" name="dosage">
          <UInput
            v-model="state.dosage"
            :class="{ 'border-red-500': hasError('dosage') }"
          />
          <p v-if="getError('dosage')" class="text-red-600 text-sm mt-1">
            {{ getError("dosage") }}
          </p>
        </UFormField>

        <UFormField label="Horários" name="timetables">
          <UInput
            v-model="state.timetables"
            :class="{ 'border-red-500': hasError('timetables') }"
          />
          <p v-if="getError('timetables')" class="text-red-600 text-sm mt-1">
            {{ getError("timetables") }}
          </p>
        </UFormField>

        <UFormField label="Duração" name="duration">
          <UInput
            v-model="state.duration"
            :class="{ 'border-red-500': hasError('duration') }"
          />
          <p v-if="getError('duration')" class="text-red-600 text-sm mt-1">
            {{ getError("duration") }}
          </p>
        </UFormField>

        <UButton type="submit" block> Criar Medicamento </UButton>
      </UForm>
    </template>
  </UModal>
</template>
