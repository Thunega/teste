<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  type ChartOptions,
  type ChartData
} from 'chart.js';
import annotationPlugin from 'chartjs-plugin-annotation';

// Assumindo que getLabReferenceObjects é auto-importado de seus utils
// import { getLabReferenceObjects } from '@/utils/lab-references';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement,
    annotationPlugin
);

const props = defineProps<{
  exams: any;
}>();

const labRef = computed(() => {
  const patient = props.exams[0]?.patient;
  return getLabReference(patient.dateOfBirth, patient.gender);
});

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: '2-digit', month: '2-digit', day: '2-digit', timeZone: 'UTC' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const chartData = computed<ChartData<'line'>>(() => {
  const sortedExams = [...props.exams].sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());
  const labels = sortedExams.map(exam => formatDate(exam.examDate));

  return {
    labels,
    datasets: [
      {
        label: 'TGO (U/L)',
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.2)',
        data: sortedExams.map(exam => exam.sgot),
        tension: 0.2,
      },
      {
        label: 'TGP (U/L)',
        borderColor: 'rgb(245, 158, 11)',
        backgroundColor: 'rgba(245, 158, 11, 0.2)',
        data: sortedExams.map(exam => exam.sgpt),
        tension: 0.2,
      },
    ],
  };
});

const chartOptions = computed<ChartOptions<'line'>>(() => {
  if (!labRef.value.sgot) {
    return { responsive: true, maintainAspectRatio: false };
  }

  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Evolução da Função Hepática (Fígado)',
        font: { size: 18 },
        padding: { bottom: 20 }
      },
      annotation: {
        annotations: {
          sgotLine: {
            type: 'line',
            yMin: labRef.value.sgot.value,
            yMax: labRef.value.sgot.value,
            borderColor: 'rgba(239, 68, 68, 0.5)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `TGO Ideal: ${labRef.value.sgot.ref}`,
              position: 'start',
              enabled: true,
              font: { size: 10 },
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }
          },
          sgptLine: {
            type: 'line',
            yMin: labRef.value.sgpt.value,
            yMax: labRef.value.sgpt.value,
            borderColor: 'rgba(245, 158, 11, 0.5)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `TGP Ideal: ${labRef.value.sgpt.ref}`,
              position: 'end',
              enabled: true,
              font: { size: 10 },
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }
          },
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Valores (U/L)'
        }
      },
      x: {
        title: {
          display: false,
        }
      }
    }
  };
});

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Line v-if="props.exams && props.exams.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Dados insuficientes para gerar o gráfico.
      </p>
    </div>
  </div>
</template>