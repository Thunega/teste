<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  type ChartOptions,
  type ChartData
} from 'chart.js';
import annotationPlugin from 'chartjs-plugin-annotation';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement,
    annotationPlugin
);

const props = defineProps<{
  exams: any;
}>();

const labRef = computed(() => {
  const patient = props.exams[0]?.patient;
  return getLabReference(patient.dateOfBirth, patient.gender);
});

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'UTC' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const chartData = computed<ChartData<'line'>>(() => {
  const sortedExams = [...props.exams].sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());
  const labels = sortedExams.map(exam => formatDate(exam.examDate));

  return {
    labels,
    datasets: [
      {
        label: 'Colesterol Total (mg/dL)',
        borderColor: 'rgb(217, 38, 70)',
        backgroundColor: 'rgba(217, 38, 70, 0.2)',
        data: sortedExams.map(exam => exam.totalCholesterol),
        tension: 0.2,
      },
      {
        label: 'HDL (mg/dL)',
        borderColor: 'rgb(22, 163, 74)',
        backgroundColor: 'rgba(22, 163, 74, 0.2)',
        data: sortedExams.map(exam => exam.hdl),
        tension: 0.2,
      },
      {
        label: 'LDL (mg/dL)',
        borderColor: 'rgb(234, 179, 8)',
        backgroundColor: 'rgba(234, 179, 8, 0.2)',
        data: sortedExams.map(exam => exam.ldl),
        tension: 0.2,
      },
      {
        label: 'Triglicerídeos (mg/dL)',
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        data: sortedExams.map(exam => exam.triglycerides),
        tension: 0.2,
      },
    ],
  };
});

const chartOptions = computed<ChartOptions<'line'>>(() => {
  if (!labRef.value.totalCholesterol) {
    return { responsive: true, maintainAspectRatio: false };
  }

  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Evolução do Perfil Lipídico',
        font: { size: 18 },
        padding: { bottom: 20 }
      },
      annotation: {
        annotations: {
          totalCholesterolLine: {
            type: 'line',
            yMin: labRef.value.totalCholesterol.value,
            yMax: labRef.value.totalCholesterol.value,
            borderColor: 'rgba(217, 38, 70, 0.5)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `Ideal: ${labRef.value.totalCholesterol.ref}`,
              position: 'start',
              enabled: true,
              font: { size: 10 },
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }
          },
          hdlLine: {
            type: 'line',
            yMin: labRef.value.hdl.value,
            yMax: labRef.value.hdl.value,
            borderColor: 'rgba(22, 163, 74, 0.5)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `Ideal: ${labRef.value.hdl.ref}`,
              position: 'end',
              enabled: true,
              font: { size: 10 },
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }
          },
          ldlLine: {
            type: 'line',
            yMin: labRef.value.ldl.value,
            yMax: labRef.value.ldl.value,
            borderColor: 'rgba(234, 179, 8, 0.5)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `Ideal: ${labRef.value.ldl.ref}`,
              position: 'start',
              enabled: true,
              font: { size: 10 },
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }
          },
          triglyceridesLine: {
            type: 'line',
            yMin: labRef.value.triglycerides.value,
            yMax: labRef.value.triglycerides.value,
            borderColor: 'rgba(59, 130, 246, 0.5)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `Ideal: ${labRef.value.triglycerides.ref}`,
              position: 'end',
              enabled: true,
              font: { size: 10 },
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Valores (mg/dL)'
        }
      },
      x: {
        title: {
          display: false,
          text: 'Data do Exame'
        }
      }
    }
  };
});

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Line v-if="props.exams && props.exams.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Dados insuficientes para gerar o gráfico.
      </p>
    </div>
  </div>
</template>