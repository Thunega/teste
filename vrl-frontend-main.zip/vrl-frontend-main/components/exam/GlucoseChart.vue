<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  Filler,
  type ChartOptions,
  type ChartData
} from 'chart.js';
import annotationPlugin from 'chartjs-plugin-annotation';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement,
    Filler,
    annotationPlugin
);

const props = defineProps<{
  exams: any;
}>();

const labRef = computed(() => {
  const patient = props.exams[0]?.patient;
  return getLabReference(patient.dateOfBirth, patient.gender);
});

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: '2-digit', month: '2-digit', day: '2-digit', timeZone: 'UTC' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const chartData = computed<ChartData<'line'>>(() => {
  const sortedExams = [...props.exams].sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());
  const labels = sortedExams.map(exam => formatDate(exam.examDate));

  return {
    labels,
    datasets: [
      {
        label: 'Glicemia de Jejum (mg/dL)',
        borderColor: 'rgb(139, 92, 246)',
        backgroundColor: 'rgba(139, 92, 246, 0.2)',
        fill: true,
        data: sortedExams.map(exam => exam.fastingGlucose),
        tension: 0.3,
      },
    ],
  };
});

const chartOptions = computed<ChartOptions<'line'>>(() => {
  if (!labRef.value.fastingGlucose) {
    return { responsive: true, maintainAspectRatio: false };
  }

  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: 'Acompanhamento da Glicemia de Jejum',
        font: {
          size: 18,
        },
        padding: {
          bottom: 20,
        }
      },
      annotation: {
        annotations: {
          idealGlucoseLine: {
            type: 'line',
            yMin: labRef.value.fastingGlucose.value,
            yMax: labRef.value.fastingGlucose.value,
            borderColor: 'rgba(22, 163, 74, 0.6)',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `Ideal: ${labRef.value.fastingGlucose.ref}`,
              position: 'start',
              enabled: true,
              font: { size: 10, weight: 'bold' },
              color: 'rgba(22, 163, 74, 0.8)',
              backgroundColor: 'rgba(255, 255, 255, 0.8)'
            }
          },
        }
      }
    },
    scales: {
      y: {
        suggestedMin: 50,
        title: {
          display: true,
          text: 'Valores (mg/dL)'
        }
      },
      x: {
        title: {
          display: false,
        }
      }
    }
  };
});

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Line v-if="props.exams && props.exams.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Dados insuficientes para gerar o gráfico de glicemia.
      </p>
    </div>
  </div>
</template>
