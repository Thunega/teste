<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { Bar } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  BarElement,
  CategoryScale,
  LinearScale,
  type ChartOptions,
  type ChartData
} from 'chart.js';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    BarElement,
    CategoryScale,
    LinearScale
);

const props = defineProps<{
  exams: any;
}>();

const labRef = computed(() => {
  const patient = props.exams[0]?.patient;
  return getLabReference(patient.dateOfBirth, patient.gender);
});

const  mostRecentExam = computed(() => [...props.exams].sort((a, b) => new Date(b.examDate).getTime() - new Date(a.examDate).getTime())[0]);

const getStatusColor = (key: string, value: number, reference: { value: number; ref: string; }) => {
  if (!reference) return 'rgb(156, 163, 175)'; // Cor cinza para N/A

  const { value: refValue, ref: refString } = reference;
  const borderlineFactor = 1.20; // 20% de margem para "atenção"

  if (refString.includes('<')) {
    if (value <= refValue) return 'rgb(34, 197, 94)'; // Verde (Bom)
    if (value <= refValue * borderlineFactor) return 'rgb(234, 179, 8)'; // Amarelo (Atenção)
    return 'rgb(239, 68, 68)'; // Vermelho (Alto)
  }

  if (refString.includes('>')) {
    if (value >= refValue) return 'rgb(34, 197, 94)'; // Verde (Bom)
    if (value >= refValue / borderlineFactor) return 'rgb(234, 179, 8)'; // Amarelo (Atenção)
    return 'rgb(239, 68, 68)'; // Vermelho (Baixo)
  }

  return 'rgb(156, 163, 175)'; // Cor padrão
};

const chartData = computed<ChartData<'bar'>>(() => {
  if (!mostRecentExam.value || Object.keys(labRef.value).length === 0) {
    return { labels: [], datasets: [] };
  }

  const examKeys = ['totalCholesterol', 'hdl', 'ldl', 'triglycerides', 'fastingGlucose', 'sgot', 'sgpt', 'tsh'];
  const labels = examKeys.map(key => `${key}: ${labRef.value[key]?.ref}`);
  const data = examKeys.map(key => mostRecentExam.value[key]);
  const backgroundColors = examKeys.map(key => getStatusColor(key, mostRecentExam.value[key], labRef.value[key]));

  return {
    labels,
    datasets: [
      {
        label: 'Resultado do Último Exame',
        backgroundColor: backgroundColors,
        borderColor: backgroundColors,
        borderWidth: 1,
        data: data,
      },
    ],
  };
});

const chartOptions = computed<ChartOptions<'bar'>>(() => {
  if (!mostRecentExam.value) return {};

  const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('pt-BR', { timeZone: 'UTC' });

  return {
    indexAxis: 'y', // Transforma em gráfico de barras horizontais
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false, // Legenda não é necessária para este tipo de gráfico
      },
      title: {
        display: true,
        text: `Painel de Controle - Exame de ${formatDate(mostRecentExam.value.examDate)}`,
        font: { size: 18 },
        padding: { bottom: 20 }
      },
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Valor Medido'
        }
      },
      y: {
        ticks: {
          font: {
            size: 10
          }
        }
      }
    }
  };
});

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 500px">
      <Bar v-if="mostRecentExam" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Não há dados de exames para exibir o painel.
      </p>
    </div>
  </div>
</template>
