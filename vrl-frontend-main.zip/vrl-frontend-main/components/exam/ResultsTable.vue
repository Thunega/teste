<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

const props = defineProps<{
  exams: any;
}>();


const examDefinitions = {
  totalCholesterol: { label: 'COLESTEROL TOTAL', unit: 'mg/dL' },
  hdl: { label: 'HDL', unit: 'mg/dL' },
  ldl: { label: 'LDL', unit: 'mg/dL' },
  fastingGlucose: { label: 'GLICEMIA JEJUM', unit: 'mg/dL' },
  triglycerides: { label: 'TRIGLICERIDES', unit: 'mg/dL' },
  sgot: { label: 'TGO', unit: 'U/L' },
  sgpt: { label: 'TGP', unit: 'U/L' },
  creatinine: { label: 'CREATINA', unit: 'mg/dL' },
  t4: { label: 'T4 Livre', unit: 'ug/dL' },
  tsh: { label: 'TSH', unit: 'mU/L' }
};

const labRef = computed(() => {
  const patient = props.exams[0]?.patient;
  return getLabReference(patient.dateOfBirth, patient.gender);
})

const examDates = computed(() => {
  if (!props.exams || props.exams.length === 0) return [];
  return [...props.exams].map((exam: any) => exam.examDate).reverse();
});

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'UTC' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const getResult = (date: string, examKey: keyof typeof examDefinitions) => {
  const examSet = props.exams.find((e: any) => e.examDate === date);
  const value = examSet?.[examKey];
  const unit = examDefinitions[examKey]?.unit || '';

  if (value === undefined || value === null) {
    return 'N/A';
  }
  return `${value} ${unit}`.trim();
};

</script>

<template>
  <div v-if="props.exams && props.exams.length > 0" class="border rounded-lg overflow-x-auto w-full">
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead class="sticky left-0 bg-gray-50 dark:bg-gray-800 w-[200px] text-left">
            Exame
          </TableHead>
          <TableHead
              v-for="date in examDates"
              :key="date"
              class="text-center"
          >
            {{ formatDate(date) }}
          </TableHead>
          <TableHead class="sticky right-0 bg-gray-50 dark:bg-gray-800 text-center">
            Referência
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow v-for="(exam, key) in examDefinitions" :key="key">
          <TableCell class="font-medium sticky left-0 bg-white dark:bg-gray-900">
            {{ exam.label }}
          </TableCell>
          <TableCell
              v-for="date in examDates"
              :key="`${date}-${key}`"
              class="text-center"
          >
            {{ getResult(date, key) }}
          </TableCell>
          <TableCell class="font-medium sticky right-0 bg-white dark:bg-gray-900 text-center">
            {{ labRef[key]?.ref || 'N/A' }}
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>
  </div>
</template>