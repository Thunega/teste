<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  examData: Record<string, any>;
}>()

function getClassification(key: string, value: number) {
  if (value === null || value === undefined) return { text: 'N/A', color: 'gray' };

  switch (key) {
    case 'totalCholesterol':
      if (value < 200) return { text: 'Normal', color: 'success' };
      if (value <= 239) return { text: 'Alerta', color: 'warning' };
      return { text: 'Alto', color: 'error' };
    case 'hdl':
      if (value >= 40) return { text: 'Normal', color: 'success' };
      return { text: 'Baixo', color: 'error' };
    case 'ldl':
      if (value < 130) return { text: 'Normal', color: 'success' };
      return { text: 'Alto', color: 'error' };
    case 'fastingGlucose':
      if (value < 100) return { text: 'Normal', color: 'success' };
      if (value <= 125) return { text: 'Alerta', color: 'warning' };
      return { text: 'Alto', color: 'error' };
    case 'triglycerides':
      if (value < 150) return { text: 'Normal', color: 'success' };
      if (value <= 199) return { text: 'Alerta', color: 'warning' };
      return { text: 'Alto', color: 'error' };
    case 'tsh':
      if (value >= 0.4 && value <= 4.5) return { text: 'Normal', color: 'success' };
      if (value < 0.4) return { text: 'Baixo', color: 'warning' };
      return { text: 'Alto', color: 'warning' };
    case 't4':
      if (value >= 4.5 && value <= 12.0) return { text: 'Normal', color: 'success' };
      if (value < 4.5) return { text: 'Baixo', color: 'warning' };
      return { text: 'Alto', color: 'warning' };
    case 'creatinine':
      if (value >= 0.6 && value <= 1.3) return { text: 'Normal', color: 'success' };
      return { text: 'Alto', color: 'error' };
    case 'sgot':
      if (value <= 40) return { text: 'Normal', color: 'success' };
      return { text: 'Alto', color: 'error' };
    case 'sgpt':
      if (value <= 40) return { text: 'Normal', color: 'success' };
      return { text: 'Alto', color: 'error' };

      // --- NOVOS CAMPOS ADICIONADOS AQUI ---
    case 'hemoglobinaGlicada':
      if (value < 5.7) return { text: 'Normal', color: 'success' };
      if (value <= 6.4) return { text: 'Alerta', color: 'warning' };
      return { text: 'Alto', color: 'error' };
    case 'vitaminaD_25_OH':
      if (value < 20) return { text: 'Baixo', color: 'error' };
      if (value <= 30) return { text: 'Alerta', color: 'warning' };
      if (value <= 100) return { text: 'Normal', color: 'success' };
      return { text: 'Alto', color: 'warning' };
    case 'potassio':
      if (value >= 3.5 && value <= 5.1) return { text: 'Normal', color: 'success' };
      if (value < 3.5) return { text: 'Baixo', color: 'warning' };
      return { text: 'Alto', color: 'warning' };
    case 'microalbuminuria':
      if (value < 30) return { text: 'Normal', color: 'success' };
      if (value <= 300) return { text: 'Alerta', color: 'warning' };
      return { text: 'Alto', color: 'error' };
    case 'vitaminaB12':
      if (value < 200) return { text: 'Baixo', color: 'warning' };
      if (value <= 900) return { text: 'Normal', color: 'success' };
      return { text: 'Alto', color: 'warning' };
    case 'acidoUrico':
      // Valores podem variar entre sexos, usando uma média geral.
      if (value >= 2.5 && value <= 7.0) return { text: 'Normal', color: 'success' };
      if (value < 2.5) return { text: 'Baixo', color: 'warning' };
      return { text: 'Alto', color: 'error' };
      // ------------------------------------

    default:
      return { text: 'N/A', color: 'gray' };
  }
}

const results = computed(() => {
  if (!props.examData) return [];
  const exam = props.examData;
  const allResults = [
    { name: 'Colesterol Total', key: 'totalCholesterol', value: exam.totalCholesterol, unit: 'mg/dL' },
    { name: 'HDL', key: 'hdl', value: exam.hdl, unit: 'mg/dL' },
    { name: 'LDL', key: 'ldl', value: exam.ldl, unit: 'mg/dL' },
    { name: 'Triglicerídeos', key: 'triglycerides', value: exam.triglycerides, unit: 'mg/dL' },
    { name: 'Glicemia de Jejum', key: 'fastingGlucose', value: exam.fastingGlucose, unit: 'mg/dL' },
    { name: 'TGO (AST)', key: 'sgot', value: exam.sgot, unit: 'U/L' },
    { name: 'TGP (ALT)', key: 'sgpt', value: exam.sgpt, unit: 'U/L' },
    { name: 'Creatinina', key: 'creatinine', value: exam.creatinine, unit: 'mg/dL' },
    { name: 'TSH', key: 'tsh', value: exam.tsh, unit: 'µU/mL' },
    { name: 'T4 Livre', key: 't4', value: exam.t4, unit: 'µg/dL' },

    // --- NOVOS CAMPOS ADICIONADOS AQUI ---
    { name: 'Hemoglobina Glicada', key: 'hemoglobinaGlicada', value: exam.hemoglobinaGlicada, unit: '%' },
    { name: 'Vitamina D (25-OH)', key: 'vitaminaD_25_OH', value: exam.vitaminaD_25_OH, unit: 'ng/mL' },
    { name: 'Potássio', key: 'potassio', value: exam.potassio, unit: 'mEq/L' },
    { name: 'Microalbuminúria', key: 'microalbuminuria', value: exam.microalbuminuria, unit: 'mg/g' },
    { name: 'Vitamina B12', key: 'vitaminaB12', value: exam.vitaminaB12, unit: 'pg/mL' },
    { name: 'Ácido Úrico', key: 'acidoUrico', value: exam.acidoUrico, unit: 'mg/dL' },
    // ------------------------------------
  ];
  return allResults
      .filter(r => typeof r.value === 'number')
      .map(r => ({ ...r, classification: getClassification(r.key, r.value) }));
});
</script>

<template>
  <div v-if="results.length > 0" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-7 gap-4">
    <div
        v-for="result in results"
        :key="result.key"
        class="p-4 rounded-lg bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-800"
    >
      <div class="flex justify-between items-center mb-1">
        <h4 class="font-semibold text-gray-700 dark:text-gray-300">{{ result.name }}</h4>
        <UBadge :color="result.classification.color" variant="soft" size="md">
          {{ result.classification.text }}
        </UBadge>
      </div>
      <p class="text-xl font-bold text-gray-900 dark:text-white">
        {{ result.value }}
        <span class="text-sm font-normal text-gray-500 dark:text-gray-400">{{ result.unit }}</span>
      </p>
    </div>
  </div>
  <div v-else>
    <p class="text-center text-gray-500">Nenhum resultado laboratorial para exibir.</p>
  </div>
</template>