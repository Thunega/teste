<script setup lang="ts">

const props = defineProps<{
  patientId: string;
}>()

const examStore = useExamStore();
const limit = ref(10);

const fetchData = async () => {
  await examStore.fetchData(
      {
        patientId: props.patientId,
        orderBy: 'examDate',
        sort: 'desc',
        perPage: limit.value
      }
  )
}

onMounted(fetchData);
</script>
<template>
  <main class="flex flex-wrap flex-col gap-6 mt-6">
    <ExamRecentExamPanel :exams="examStore.data"/>
    <div class="grid grid-rows-1 lg:grid-cols-2 gap-6">
      <ExamLipidProfile :exams="examStore.data" />
      <ExamGlucoseChart :exams="examStore.data" />
      <ExamLiverFunctionChart :exams="examStore.data" />
      <ExamThyroidFunctionChart :exams="examStore.data" />
    </div>

    <div class="flex-1">
      <ExamResultsTable :exams="examStore.data"/>
    </div>

  </main>
</template>