<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const examStore = useExamStore();
const open = ref(false);

const numericField = z.coerce.number().optional();

const schema = z.object({
  examDate: z.string({
    required_error: "A data do exame é obrigatória.",
    invalid_type_error: "A data do exame é obrigatória.",
  }),
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  totalCholesterol: numericField,
  hdl: numericField,
  ldl: numericField,
  fastingGlucose: numericField,
  triglycerides: numericField,
  sgot: numericField,
  sgpt: numericField,
  creatinine: numericField,
  t4: numericField,
  tsh: numericField,
  hemoglobinaGlicada: numericField,
  vitaminaD_25_OH: numericField,
  potassio: numericField,
  microalbuminuria: numericField,
  vitaminaB12: numericField,
  acidoUrico: numericField,
  others: z.string().optional(),
  observations: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  examDate: undefined,
  patientId: "",
  totalCholesterol: undefined,
  hdl: undefined,
  ldl: undefined,
  fastingGlucose: undefined,
  triglycerides: undefined,
  sgot: undefined,
  sgpt: undefined,
  creatinine: undefined,
  t4: undefined,
  tsh: undefined,
  hemoglobinaGlicada: undefined,
  vitaminaD_25_OH: undefined,
  potassio: undefined,
  microalbuminuria: undefined,
  vitaminaB12: undefined,
  acidoUrico: undefined,
  others: "",
  observations: "",
};

const state = useState("exam-create-modal", () =>
  reactive({ ...initialState }),
);

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state.value);

function resetForm() {
  Object.assign(state.value, initialState);
  open.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  // validação local via Zod
  if (!validate()) return;

  try {
    await examStore.create(event.data);
    toast("Exame Criado!", {
      description: "Os resultados do exame foram salvos com sucesso.",
    });
    resetForm();
    emit("created");
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Exame", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      v-model:open="open"
      :overlay="false"
      :dismissible="false"
      title="Criar Novo Exame"
      :ui="{ content: 'lg:max-w-xl' }"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-plus-circle" label="Novo Exame" />

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-6"
          @submit="onSubmit"
        >
          <div class="flex w-full gap-4">
            <UFormField label="Paciente" name="patientId">
              <PatientsSelectInput
                class="w-full"
                @update:patient="state.patientId = $event"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField label="Data do exame" name="examDate">
              <UDatePicker
                mo
                @update:model-value="state.examDate = $event.toString()"
                :class="{ 'border-red-500': hasError('examDate') }"
              />
              <p v-if="getError('examDate')" class="text-red-600 text-sm mt-1">
                {{ getError("examDate") }}
              </p>
            </UFormField>
          </div>

          <USeparator />
          <div
            class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 items-end"
          >
            <UFormField label="Hemoglobina Glicada" name="hemoglobinaGlicada">
              <UInput
                v-model.number="state.hemoglobinaGlicada"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('hemoglobinaGlicada') }"
              />
              <p
                v-if="getError('hemoglobinaGlicada')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("hemoglobinaGlicada") }}
              </p>
            </UFormField>
            <UFormField label="Colesterol Total" name="totalCholesterol">
              <UInput
                v-model.number="state.totalCholesterol"
                type="number"
                :class="{ 'border-red-500': hasError('totalCholesterol') }"
              />
              <p
                v-if="getError('totalCholesterol')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("totalCholesterol") }}
              </p>
            </UFormField>
            <UFormField label="HDL" name="hdl">
              <UInput
                v-model.number="state.hdl"
                type="number"
                :class="{ 'border-red-500': hasError('hdl') }"
              />
              <p v-if="getError('hdl')" class="text-red-600 text-sm mt-1">
                {{ getError("hdl") }}
              </p>
            </UFormField>
            <UFormField label="LDL" name="ldl">
              <UInput
                v-model.number="state.ldl"
                type="number"
                :class="{ 'border-red-500': hasError('ldl') }"
              />
              <p v-if="getError('ldl')" class="text-red-600 text-sm mt-1">
                {{ getError("ldl") }}
              </p>
            </UFormField>
            <UFormField label="Glicemia" name="fastingGlucose">
              <UInput
                v-model.number="state.fastingGlucose"
                type="number"
                :class="{ 'border-red-500': hasError('fastingGlucose') }"
              />
              <p
                v-if="getError('fastingGlucose')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("fastingGlucose") }}
              </p>
            </UFormField>
            <UFormField label="Triglicerídeos" name="triglycerides">
              <UInput
                v-model.number="state.triglycerides"
                type="number"
                :class="{ 'border-red-500': hasError('triglycerides') }"
              />
              <p
                v-if="getError('triglycerides')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("triglycerides") }}
              </p>
            </UFormField>
            <UFormField label="TGO (AST)" name="sgot">
              <UInput
                v-model.number="state.sgot"
                type="number"
                :class="{ 'border-red-500': hasError('sgot') }"
              />
              <p v-if="getError('sgot')" class="text-red-600 text-sm mt-1">
                {{ getError("sgot") }}
              </p>
            </UFormField>
            <UFormField label="TGP (ALT)" name="sgpt">
              <UInput
                v-model.number="state.sgpt"
                type="number"
                :class="{ 'border-red-500': hasError('sgpt') }"
              />
              <p v-if="getError('sgpt')" class="text-red-600 text-sm mt-1">
                {{ getError("sgpt") }}
              </p>
            </UFormField>
            <UFormField label="Creatinina" name="creatinine">
              <UInput
                v-model.number="state.creatinine"
                type="number"
                :class="{ 'border-red-500': hasError('creatinine') }"
              />
              <p
                v-if="getError('creatinine')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("creatinine") }}
              </p>
            </UFormField>
            <UFormField label="TSH" name="tsh">
              <UInput
                v-model.number="state.tsh"
                type="number"
                step="0.01"
                :class="{ 'border-red-500': hasError('tsh') }"
              />
              <p v-if="getError('tsh')" class="text-red-600 text-sm mt-1">
                {{ getError("tsh") }}
              </p>
            </UFormField>
            <UFormField label="T4 Livre" name="t4">
              <UInput
                v-model.number="state.t4"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('t4') }"
              />
              <p v-if="getError('t4')" class="text-red-600 text-sm mt-1">
                {{ getError("t4") }}
              </p>
            </UFormField>
            <UFormField label="Vitamina D" name="vitaminaD_25_OH">
              <UInput
                v-model.number="state.vitaminaD_25_OH"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('vitaminaD_25_OH') }"
              />
              <p
                v-if="getError('vitaminaD_25_OH')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("vitaminaD_25_OH") }}
              </p>
            </UFormField>
            <UFormField label="Potássio" name="potassio">
              <UInput
                v-model.number="state.potassio"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('potassio') }"
              />
              <p v-if="getError('potassio')" class="text-red-600 text-sm mt-1">
                {{ getError("potassio") }}
              </p>
            </UFormField>
            <UFormField label="Vitamina B12" name="vitaminaB12">
              <UInput
                v-model.number="state.vitaminaB12"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('vitaminaB12') }"
              />
              <p
                v-if="getError('vitaminaB12')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("vitaminaB12") }}
              </p>
            </UFormField>
            <UFormField label="Ácido úrico" name="acidoUrico">
              <UInput
                v-model.number="state.acidoUrico"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('acidoUrico') }"
              />
              <p
                v-if="getError('acidoUrico')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("acidoUrico") }}
              </p>
            </UFormField>
            <UFormField label="Microalbuminúria" name="microalbuminuria">
              <UInput
                v-model.number="state.microalbuminuria"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('microalbuminuria') }"
              />
              <p
                v-if="getError('microalbuminuria')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("microalbuminuria") }}
              </p>
            </UFormField>
          </div>

          <UFormField label="Outros Exames" name="others">
            <UTextarea
              class="w-full"
              v-model="state.others"
              placeholder="Resultados de outros exames não listados acima..."
              :class="{ 'border-red-500': hasError('others') }"
            />
            <p v-if="getError('others')" class="text-red-600 text-sm mt-1">
              {{ getError("others") }}
            </p>
          </UFormField>
          <UFormField label="Observações" name="observations">
            <UTextarea
              class="w-full"
              v-model="state.observations"
              placeholder="Observações gerais sobre os resultados ou condições do paciente..."
              :class="{ 'border-red-500': hasError('observations') }"
            />
            <p
              v-if="getError('observations')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("observations") }}
            </p>
          </UFormField>

          <UButton type="submit" block class="mt-8"> Salvar Exame </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
