<script setup lang="ts">
import { computed, ref, onMounted } from 'vue';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  type ChartOptions,
  type ChartData
} from 'chart.js';
import annotationPlugin from 'chartjs-plugin-annotation';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement,
    annotationPlugin
);

const props = defineProps<{
  exams: any;
}>();

const labRef = computed(() => {
  const patient = props.exams[0]?.patient;
  return getLabReference(patient.dateOfBirth, patient.gender);
});


const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: '2-digit', month: '2-digit', day: '2-digit', timeZone: 'UTC' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const chartData = computed<ChartData<'line'>>(() => {
  const sortedExams = [...props.exams].sort((a, b) => new Date(a.examDate).getTime() - new Date(b.examDate).getTime());
  const labels = sortedExams.map(exam => formatDate(exam.examDate));

  return {
    labels,
    datasets: [
      {
        label: 'TSH (mU/L)',
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.2)',
        data: sortedExams.map(exam => exam.tsh),
        tension: 0.2,
        yAxisID: 'y'
      },
      {
        label: 'T4 Livre (ug/dL)',
        borderColor: 'rgb(217, 119, 6)',
        backgroundColor: 'rgba(217, 119, 6, 0.2)',
        data: sortedExams.map(exam => exam.t4),
        tension: 0.2,
        yAxisID: 'y'
      }
    ],
  };
});

const chartOptions = computed<ChartOptions<'line'>>(() => {
  const annotations: any = {};

  // Preenche dinamicamente as anotações se os dados de referência estiverem disponíveis
  if (labRef.value.tsh) {
    annotations.tshLine = {
      type: 'line',
      yMin: labRef.value.tsh.value,
      yMax: labRef.value.tsh.value,
      borderColor: 'rgba(34, 197, 94, 0.5)',
      borderWidth: 2,
      borderDash: [6, 6],
      scaleID: 'y',
      label: {
        content: `TSH Ideal: ${labRef.value.tsh.ref}`,
        position: 'start',
        enabled: true,
        font: { size: 10 },
        backgroundColor: 'rgba(255, 255, 255, 0.8)'
      }
    };
    annotations.t4Line = {
      type: 'line',
      yMin: labRef.value.t4.value,
      yMax: labRef.value.t4.value,
      borderColor: 'rgba(217, 119, 6, 0.5)',
      borderWidth: 2,
      borderDash: [6, 6],
      scaleID: 'y',
      label: {
        content: `T4 Ideal: ${labRef.value.t4.ref}`,
        position: 'end',
        enabled: true,
        font: { size: 10 },
        backgroundColor: 'rgba(255, 255, 255, 0.8)'
      }
    };
  }

  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Evolução da Função Tireoidiana',
        font: { size: 18 },
        padding: { bottom: 20 }
      },
      annotation: {
        annotations
      }
    },
    scales: {
      y: {
        type: 'linear',
        display: true,
        position: 'left',
        beginAtZero: true,
        title: {
          display: true,
          text: 'TSH (mU/L) / T4 (ug/dL)'
        }
      },
    }
  };
});

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <div style="height: 400px">
      <Line v-if="props.exams && props.exams.length > 0" :data="chartData" :options="chartOptions" />
      <p v-else class="flex items-center justify-center h-full text-gray-500">
        Dados insuficientes para gerar o gráfico.
      </p>
    </div>
  </div>
</template>