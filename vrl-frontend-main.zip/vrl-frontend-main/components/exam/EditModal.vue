<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { CalendarDate, parseDate } from "@internationalized/date";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps<{
  examId: string;
}>();

const emit = defineEmits(["updated"]);
const examStore = useExamStore();
const open = ref(false);
const isLoading = ref(false);

defineExpose({
  open: () => (open.value = true),
  close: () => (open.value = false),
});

const numericField = z.coerce.number().optional();

const examDate = ref();

const schema = z.object({
  examDate: z.string({
    required_error: "A data do exame é obrigatória.",
    invalid_type_error: "A data do exame é obrigatória.",
  }),
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  totalCholesterol: numericField,
  hdl: numericField,
  ldl: numericField,
  fastingGlucose: numericField,
  triglycerides: numericField,
  sgot: numericField,
  sgpt: numericField,
  creatinine: numericField,
  t4: numericField,
  tsh: numericField,
  hemoglobinaGlicada: numericField,
  vitaminaD_25_OH: numericField,
  potassio: numericField,
  microalbuminuria: numericField,
  vitaminaB12: numericField,
  acidoUrico: numericField,
  others: z.string().optional(),
  observations: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const initialState: Partial<Schema> = {
  examDate: undefined,
  patientId: undefined,
  totalCholesterol: undefined,
  hdl: undefined,
  ldl: undefined,
  fastingGlucose: undefined,
  triglycerides: undefined,
  sgot: undefined,
  sgpt: undefined,
  creatinine: undefined,
  t4: undefined,
  tsh: undefined,
  hemoglobinaGlicada: undefined,
  vitaminaD_25_OH: undefined,
  potassio: undefined,
  microalbuminuria: undefined,
  vitaminaB12: undefined,
  acidoUrico: undefined,
  others: "",
  observations: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

watch(open, (isOpen) => {
  if (isOpen) {
    fetchData();
  }
});

async function fetchData() {
  try {
    isLoading.value = true;
    const examData = await examStore.getById(props.examId);
    if (examData) {
      for (const key of Object.keys(initialState)) {
        if (examData[key] !== undefined) {
          state[key as keyof Schema] = examData[key];
        }
      }

      if (examData.examDate) {
        examDate.value = parseDate(examData.examDate);
        state.examDate = examData.examDate;
      }
    }
  } catch (error) {
    toast.error("Erro ao carregar dados do exame.");
  } finally {
    isLoading.value = false;
  }
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await examStore.update(props.examId, event.data);
    toast("Exame Atualizado!", {
      description: "Os resultados do exame foram atualizados com sucesso.",
    });
    emit("updated");
    open.value = false;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar Exame", {
      description:
        error.data?.message || "Não foi possível salvar as alterações.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="true"
      title="Editar Exame"
      :ui="{ content: 'lg:max-w-2xl' }"
    >
      <!-- <UButton
          icon="i-lucide-pencil"
          label="Editar Exame"
      /> -->

      <template #body>
        <div v-if="isLoading" class="p-8 text-center">
          <p>Carregando dados do exame...</p>
        </div>
        <UForm
          v-else
          :schema="schema"
          :state="state"
          class="space-y-6"
          @submit="onSubmit"
        >
          <div class="flex w-full gap-4">
            <UFormField label="ID do Paciente" name="patientId">
              <Input type="text" v-model="state.patientId" class="w-full" />
            </UFormField>
            <UFormField label="Selecionar Novo Paciente">
              <PatientsSelectInput @update:patient="state.patientId = $event" />
            </UFormField>
          </div>
          <UFormField label="Data do exame" name="examDate">
            <UDatePicker
              v-model="examDate"
              @update:model-value="state.examDate = $event.toString()"
            />
          </UFormField>
          <USeparator />
          <div
            class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 items-end"
          >
            <UFormField label="Hemoglobina Glicada" name="hemoglobinaGlicada">
              <UInput
                v-model.number="state.hemoglobinaGlicada"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Colesterol Total" name="totalCholesterol">
              <UInput v-model.number="state.totalCholesterol" type="number" />
            </UFormField>
            <UFormField label="HDL" name="hdl">
              <UInput v-model.number="state.hdl" type="number" />
            </UFormField>
            <UFormField label="LDL" name="ldl">
              <UInput v-model.number="state.ldl" type="number" />
            </UFormField>
            <UFormField label="Glicemia" name="fastingGlucose">
              <UInput v-model.number="state.fastingGlucose" type="number" />
            </UFormField>
            <UFormField label="Triglicerídeos" name="triglycerides">
              <UInput v-model.number="state.triglycerides" type="number" />
            </UFormField>
            <UFormField label="TGO (AST)" name="sgot">
              <UInput v-model.number="state.sgot" type="number" />
            </UFormField>
            <UFormField label="TGP (ALT)" name="sgpt">
              <UInput v-model.number="state.sgpt" type="number" />
            </UFormField>
            <UFormField label="Creatinina" name="creatinine">
              <UInput v-model.number="state.creatinine" type="number" />
            </UFormField>
            <UFormField label="TSH" name="tsh">
              <UInput v-model.number="state.tsh" type="number" step="0.01" />
            </UFormField>
            <UFormField label="T4 livre" name="t4">
              <UInput v-model.number="state.t4" type="number" step="0.1" />
            </UFormField>
            <UFormField label="Vitamina D" name="vitaminaD_25_OH">
              <UInput
                v-model.number="state.vitaminaD_25_OH"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Potássio" name="potassio">
              <UInput
                v-model.number="state.potassio"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Vitamina B12" name="vitaminaB12">
              <UInput
                v-model.number="state.vitaminaB12"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Ácido úrico" name="acidoUrico">
              <UInput
                v-model.number="state.acidoUrico"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Microalbuminúria" name="microalbuminuria">
              <UInput
                v-model.number="state.microalbuminuria"
                type="number"
                step="0.1"
              />
            </UFormField>
          </div>
          <USeparator />

          <UFormField label="Outros Exames" name="others">
            <UTextarea
              class="w-full"
              v-model="state.others"
              placeholder="Resultados de outros exames não listados acima..."
            />
          </UFormField>
          <UFormField label="Observações" name="observations">
            <UTextarea
              class="w-full"
              v-model="state.observations"
              placeholder="Observações gerais sobre os resultados ou condições do paciente..."
            />
          </UFormField>

          <UButton type="submit" block class="mt-8">
            Salvar Alterações
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
