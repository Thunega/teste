<script setup lang="ts">
import { onMounted, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps({
  patientId: {
    type: String,
    required: true,
  },
});

const emit = defineEmits(["updated"]);
const open = ref(false);
const anamnesisToEditId = ref<string | null>(null);

const schema = z.object({
  chiefComplaint: z
    .string({ required_error: "A queixa principal é obrigatória." })
    .min(5, "A queixa principal deve ter pelo menos 5 caracteres."),
  historyOfCurrentIllness: z
    .string({ required_error: "O histórico da doença atual é obrigatório." })
    .min(10, "O histórico deve ter pelo menos 10 caracteres."),
  personalAndFamilyHistory: z
    .string({ required_error: "O histórico pessoal e familiar é obrigatório." })
    .min(10, "O histórico deve ter pelo menos 10 caracteres."),
  lifestyleHabits: z
    .string({ required_error: "Os hábitos de vida são obrigatórios." })
    .min(10, "Os hábitos de vida devem ter pelo menos 10 caracteres."),
});

type Schema = z.output<typeof schema>;

const state = reactive<Partial<Schema>>({
  chiefComplaint: undefined,
  historyOfCurrentIllness: undefined,
  personalAndFamilyHistory: undefined,
  lifestyleHabits: undefined,
});

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

const anamnesisStore = useAnamnesisStore();

onMounted(async () => {
  try {
    const anamneses = await anamnesisStore.getByPatientId(props.patientId);

    if (anamneses) {
      for (const key of Object.keys(state)) {
        if (anamneses[key] !== undefined) {
          state[key as keyof Schema] = anamneses[key];
        }
      }
    } else {
      toast("Nenhuma Anamnese Encontrada", {
        description: "Não há um histórico de anamnese para este paciente.",
      });
    }
  } catch (error) {
    toast("Erro ao Carregar Histórico", {
      description: "Não foi possível carregar o histórico de anamneses.",
    });
    console.error("Error fetching anamnesis history:", error);
  }
});

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!props.patientId) {
    toast.error("Erro de Referência", {
      description: "Não foi possível identificar a anamnese a ser atualizada.",
    });
    return;
  }

  if (!validate()) return;

  try {
    await anamnesisStore.update(props.patientId, event.data);

    toast("Anamnese Atualizada!", {
      description: "Os dados da anamnese foram atualizados com sucesso.",
    });

    emit("updated");
    open.value = false;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar Anamnese", {
      description: `Não foi possível atualizar os dados. Verifique e tente novamente. \n ${error.data?.message}`,
    });
    console.error("Error updating anamnesis:", error);
  }
}
</script>

<template>
  <div>
    <UModal
      v-model:open="open"
      :overlay="false"
      :dismissible="false"
      title="Editar Anamnese"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton color="primary" variant="solid" @click="open = true">
        <UIcon name="i-heroicons-pencil-square" class="size-6" /> Editar
        Anamnese
      </UButton>

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <UFormField label="Queixa Principal" name="chiefComplaint">
            <UTextarea
              size="xl"
              variant="soft"
              class="w-full"
              v-model="state.chiefComplaint"
              placeholder="Ex: Dor de cabeça constante há 3 dias..."
              :class="{ 'border-red-500': hasError('chiefComplaint') }"
            />
            <p
              v-if="getError('chiefComplaint')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("chiefComplaint") }}
            </p>
          </UFormField>

          <UFormField
            label="História da Doença Atual"
            name="historyOfCurrentIllness"
          >
            <UTextarea
              size="xl"
              variant="soft"
              class="w-full"
              v-model="state.historyOfCurrentIllness"
              placeholder="Detalhes sobre o início, localização, intensidade, etc."
              :class="{ 'border-red-500': hasError('historyOfCurrentIllness') }"
            />
            <p
              v-if="getError('historyOfCurrentIllness')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("historyOfCurrentIllness") }}
            </p>
          </UFormField>

          <UFormField
            label="Histórico Pessoal e Familiar"
            name="personalAndFamilyHistory"
          >
            <UTextarea
              size="xl"
              variant="soft"
              class="w-full"
              v-model="state.personalAndFamilyHistory"
              placeholder="Doenças prévias, cirurgias, histórico de doenças na família..."
              :class="{
                'border-red-500': hasError('personalAndFamilyHistory'),
              }"
            />
            <p
              v-if="getError('personalAndFamilyHistory')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("personalAndFamilyHistory") }}
            </p>
          </UFormField>

          <UFormField label="Hábitos de Vida" name="lifestyleHabits">
            <UTextarea
              size="xl"
              variant="soft"
              class="w-full"
              v-model="state.lifestyleHabits"
              placeholder="Alimentação, prática de exercícios, tabagismo, etilismo..."
              :class="{ 'border-red-500': hasError('lifestyleHabits') }"
            />
            <p
              v-if="getError('lifestyleHabits')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("lifestyleHabits") }}
            </p>
          </UFormField>

          <UButton
            type="submit"
            block
            class="mt-6"
            :disabled="!props.patientId"
          >
            Salvar Alterações
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
