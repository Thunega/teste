<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps<{
  consultationId: string;
}>();

const emit = defineEmits(["updated"]);
const medicalConsultationStore = useMedicalConsultationsStore();
const open = ref(false);
const isLoading = ref(false);
const numericField = z.coerce.number().optional();

defineExpose({
  open: () => (open.value = true),
  close: () => (open.value = false),
});

const medicationSchema = z.object({
  name: z
    .string({
      required_error: "O nome do medicamento é obrigatório.",
      invalid_type_error: "O nome do medicamento é obrigatório.",
    })
    .min(2, "O nome deve ter pelo menos 2 caracteres."),
  dosage: z
    .string({
      required_error: "A dosagem é obrigatória.",
      invalid_type_error: "A dosagem é obrigatória.",
    })
    .min(1, "A dosagem é obrigatória."),
  timetables: z.string().optional(),
  duration: z.string().optional(),
});

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  consultationDate: z.string({
    required_error: "A data da consulta é obrigatória.",
    invalid_type_error: "A data da consulta é obrigatória.",
  }),
  // Medidas principais
  weightKg: numericField,
  heightCm: numericField,
  bmi: numericField,
  vitalSigns: z
    .object({
      bloodPressure: z.string().optional(),
      heartRate: z.coerce.number().optional(),
    })
    .optional(),
  examIds: z.array(z.string()).optional(),
  medicationsInUse: z.array(medicationSchema).optional(),
  observations: z.string().optional(),
});

type Schema = z.output<typeof schema>;
type MedicationSchema = z.output<typeof medicationSchema>;

const initialState = {
  patientId: "",
  consultationDate: "",
  weightKg: undefined,
  heightCm: undefined,
  bmi: undefined,
  vitalSigns: {
    bloodPressure: "",
    heartRate: undefined,
  },
  examIds: [],
  medicationsInUse: [{} as Partial<MedicationSchema>],
  observations: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

watch(open, (isOpen) => {
  if (isOpen) {
    fetchData();
  }
});

async function fetchData() {
  try {
    isLoading.value = true;
    const consultationData = await medicalConsultationStore.getById(
      props.consultationId,
    );
    if (consultationData) {
      state.patientId = consultationData.patientId || "";
      state.consultationDate = consultationData.consultationDate || "";
      state.weightKg = consultationData.weightKg;
      state.heightCm = consultationData.heightCm;
      state.bmi = consultationData.bmi;
      state.vitalSigns = consultationData.vitalSigns || {
        bloodPressure: "",
        heartRate: undefined,
      };
      state.examIds = consultationData.examIds || [];
      state.medicationsInUse =
        consultationData.medicationsInUse &&
        consultationData.medicationsInUse.length > 0
          ? consultationData.medicationsInUse
          : [{}];
      state.observations = consultationData.observations || "";
    }
  } catch (error) {
    toast.error("Erro ao carregar dados da consulta.");
  } finally {
    isLoading.value = false;
  }
}

function addMedication() {
  state.medicationsInUse.push({});
}

function removeMedication(index: number) {
  state.medicationsInUse.splice(index, 1);
}

function resetForm() {
  Object.assign(state, {
    ...initialState,
    medicationsInUse: [{}],
    vitalSigns: { ...initialState.vitalSigns },
    examIds: [],
  });
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await medicalConsultationStore.update(props.consultationId, event.data);
    toast("Consulta Atualizada!", {
      description: "A consulta médica foi atualizada com sucesso.",
    });
    emit("updated");
    open.value = false;
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar Consulta", {
      description:
        error.data?.message || "Não foi possível salvar as alterações.",
    });
  }
}

async function searchExams(query: string) {
  // Mock: Substitua pela busca real de exames
  const allExams = [
    { label: "Hemograma Completo", value: "exam-123" },
    { label: "Perfil Lipídico", value: "exam-456" },
  ];
  return allExams.filter((exam) =>
    exam.label.toLowerCase().includes(query.toLowerCase()),
  );
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="true"
      title="Editar Consulta Médica"
      :ui="{ content: 'lg:max-w-2xl' }"
    >
      <template #body>
        <div v-if="isLoading" class="p-8 text-center">
          <p>Carregando dados da consulta...</p>
        </div>
        <UForm
          v-else
          :schema="schema"
          :state="state"
          class="space-y-6"
          @submit="onSubmit"
        >
          <div class="flex items-start gap-4">
            <UFormField label="Paciente" name="patientId" class="flex-1">
              <PatientsSelectInput
                @update:patient="state.patientId = $event"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField
              label="Data da Consulta"
              name="consultationDate"
              class="flex-1"
            >
              <UInput
                v-model="state.consultationDate"
                type="date"
                :class="{ 'border-red-500': hasError('consultationDate') }"
              />
              <p
                v-if="getError('consultationDate')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("consultationDate") }}
              </p>
            </UFormField>
          </div>

          <USeparator label="Medidas e Sinais Vitais" />
          <div class="grid grid-cols-3 gap-4 items-end">
            <UFormField label="Peso (kg)" name="weightKg">
              <UInput
                v-model.number="state.weightKg"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Altura (cm)" name="heightCm">
              <UInput v-model.number="state.heightCm" type="number" />
            </UFormField>
            <UFormField label="IMC" name="bmi">
              <UInput v-model.number="state.bmi" type="number" step="0.1" />
            </UFormField>
            <UFormField
              label="Pressão Arterial"
              name="vitalSigns.bloodPressure"
            >
              <UInput
                v-model="state.vitalSigns.bloodPressure"
                placeholder="Ex: 120/80"
              />
            </UFormField>
            <UFormField
              label="Frequência Cardíaca (bpm)"
              name="vitalSigns.heartRate"
            >
              <UInput
                v-model.number="state.vitalSigns.heartRate"
                type="number"
              />
            </UFormField>
          </div>

          <USeparator label="Medicamentos em Uso" />
          <div class="space-y-4">
            <div
              v-for="(med, index) in state.medicationsInUse"
              :key="index"
              class="p-4 rounded-md bg-gray-50 dark:bg-gray-800/50"
            >
              <UForm
                :state="med"
                :schema="medicationSchema"
                class="grid grid-cols-1 sm:grid-cols-4 gap-3"
              >
                <UFormField
                  label="Nome"
                  name="name"
                  class="col-span-1 sm:col-span-2"
                >
                  <UInput v-model="med.name" />
                </UFormField>
                <UFormField label="Dosagem" name="dosage">
                  <UInput v-model="med.dosage" />
                </UFormField>
                <UFormField label="Horários" name="timetables">
                  <UInput v-model="med.timetables" />
                </UFormField>
                <UFormField label="Duração" name="duration">
                  <UInput v-model="med.duration" />
                </UFormField>
              </UForm>
              <div
                v-if="state.medicationsInUse.length > 1"
                class="text-right mt-2"
              >
                <UButton
                  @click="removeMedication(index)"
                  color="red"
                  variant="link"
                  icon="i-heroicons-x-circle"
                  size="xs"
                  >Remover
                </UButton>
              </div>
            </div>
            <div>
              <UButton
                @click="addMedication"
                icon="i-heroicons-plus-circle"
                size="sm"
                >Adicionar Medicamento</UButton
              >
            </div>
          </div>

          <UDivider />
          <UFormField
            label="Observações e Evolução Clínica"
            name="observations"
          >
            <UTextarea
              v-model="state.observations"
              :rows="6"
              placeholder="Descreva a evolução do paciente, queixas, observações do exame físico, etc."
              class="w-full"
            />
          </UFormField>

          <UButton type="submit" block class="mt-8">
            Salvar Alterações
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
