<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const medicalConsultationStore = useMedicalConsultationsStore();
const open = ref(false);
const numericField = z.coerce.number().optional();

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  consultationDate: z.string({
    required_error: "A data da consulta é obrigatória.",
    invalid_type_error: "A data da consulta é obrigatória.",
  }),
  // Medidas principais
  weightKg: numericField,
  heightCm: numericField,
  bmi: numericField,
  vitalSigns: z
    .object({
      bloodPressure: z.string().optional(),
      heartRate: z.coerce.number().optional(),
    })
    .optional(),
  examIds: z.array(z.string()).optional(),
  observations: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const initialState = {
  patientId: "",
  consultationDate: "",
  // Medidas principais
  weightKg: undefined,
  heightCm: undefined,
  bmi: undefined,
  vitalSigns: {
    bloodPressure: "",
    heartRate: undefined,
  },
  examIds: [],
  observations: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, {
    ...initialState,
    vitalSigns: { ...initialState.vitalSigns },
    examIds: [],
  });
  open.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await medicalConsultationStore.create(event.data);
    toast("Consulta Criada!", {
      description: "A consulta médica foi salva com sucesso.",
    });
    emit("created");
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Consulta", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}

async function searchExams(query: string) {
  // Mock: Substitua pela busca real de exames
  const allExams = [
    { label: "Hemograma Completo", value: "exam-123" },
    { label: "Perfil Lipídico", value: "exam-456" },
  ];
  return allExams.filter((exam) =>
    exam.label.toLowerCase().includes(query.toLowerCase()),
  );
}
</script>

<template>
  <UModal
    :dismissible="false"
    v-model:open="open"
    :overlay="false"
    title="Registrar Nova Consulta"
    :close="{
      color: 'primary',
      variant: 'outline',
      class: 'rounded-full',
    }"
  >
    <UButton icon="i-lucide-plus-circle" label="Nova Consulta" />

    <template #body>
      <UForm
        :schema="schema"
        :state="state"
        class="space-y-6"
        @submit="onSubmit"
      >
        <div class="flex items-start gap-4">
          <UFormField label="Paciente" name="patientId" class="flex-1">
            <PatientsSelectInput
              @update:patient="state.patientId = $event"
              :class="{ 'border-red-500': hasError('patientId') }"
            />
            <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
              {{ getError("patientId") }}
            </p>
          </UFormField>
          <UFormField
            label="Data da Consulta"
            name="consultationDate"
            class="flex-1"
          >
            <UInput
              v-model="state.consultationDate"
              type="date"
              :class="{ 'border-red-500': hasError('consultationDate') }"
            />
            <p
              v-if="getError('consultationDate')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("consultationDate") }}
            </p>
          </UFormField>
        </div>

        <USeparator label="Medidas e Sinais Vitais" />
        <div class="grid grid-cols-3 gap-4 items-end">
          <UFormField label="Peso (kg)" name="weightKg">
            <UInput
              v-model.number="state.weightKg"
              type="number"
              step="0.1"
              :class="{ 'border-red-500': hasError('weightKg') }"
            />
            <p v-if="getError('weightKg')" class="text-red-600 text-sm mt-1">
              {{ getError("weightKg") }}
            </p>
          </UFormField>
          <UFormField label="Altura (cm)" name="heightCm">
            <UInput
              v-model.number="state.heightCm"
              type="number"
              :class="{ 'border-red-500': hasError('heightCm') }"
            />
            <p v-if="getError('heightCm')" class="text-red-600 text-sm mt-1">
              {{ getError("heightCm") }}
            </p>
          </UFormField>
          <UFormField label="IMC" name="bmi">
            <UInput
              v-model.number="state.bmi"
              type="number"
              step="0.1"
              :class="{ 'border-red-500': hasError('bmi') }"
            />
            <p v-if="getError('bmi')" class="text-red-600 text-sm mt-1">
              {{ getError("bmi") }}
            </p>
          </UFormField>
          <UFormField label="Pressão Arterial" name="vitalSigns.bloodPressure">
            <UInput
              v-model="state.vitalSigns.bloodPressure"
              placeholder="Ex: 120/80"
              :class="{
                'border-red-500': hasError('vitalSigns.bloodPressure'),
              }"
            />
            <p
              v-if="getError('vitalSigns.bloodPressure')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("vitalSigns.bloodPressure") }}
            </p>
          </UFormField>
          <UFormField
            label="Frequência Cardíaca (bpm)"
            name="vitalSigns.heartRate"
          >
            <UInput
              v-model.number="state.vitalSigns.heartRate"
              type="number"
              :class="{ 'border-red-500': hasError('vitalSigns.heartRate') }"
            />
            <p
              v-if="getError('vitalSigns.heartRate')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("vitalSigns.heartRate") }}
            </p>
          </UFormField>
        </div>
        <!--        <UDivider label="Exames Associados"/>-->
        <!--        <UFormField label="Vincular exames a esta consulta" name="examIds">-->
        <!--          <USelectMenu v-model="state.examIds" :searchable="searchExams" multiple placeholder="Busque exames..."-->
        <!--                       option-attribute="label" value-attribute="value"/>-->
        <!--        </UFormField>-->

        <UDivider />
        <UFormField label="Observações e Evolução Clínica" name="observations">
          <UTextarea
            v-model="state.observations"
            :rows="6"
            placeholder="Descreva a evolução do paciente, queixas, observações do exame físico, etc."
            class="w-full"
          />
        </UFormField>

        <UButton type="submit" block class="mt-8"> Salvar Consulta </UButton>
      </UForm>
    </template>
  </UModal>
</template>
