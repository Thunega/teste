<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const physiotherapyConsultationStore = usePhysiotherapyConsultationsStore();
const open = ref(false);

const functionalLevelEnum = ["INDEPENDENT", "SEMI_INDEPENDENT", "DEPENDENT"];
const functionalLevelOptions = [
  { label: "Independente", id: "INDEPENDENT" },
  { label: "Semi-independente", id: "SEMI_INDEPENDENT" },
  { label: "Dependente", id: "DEPENDENT" },
];

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
  }),
  consultationDate: z.string({
    required_error: "A data da consulta é obrigatória.",
  }),
  mainComplaint: z.string().min(5, "A queixa principal é obrigatória."),
  painLevel: z
    .number({
      required_error: "O nível de dor é obrigatório.",
      invalid_type_error: "O nível de dor deve ser um número.",
    })
    .min(0, "O nível de dor deve ser no mínimo 0.")
    .max(10, "O nível de dor deve ser no máximo 10."),
  functionalLevel: z.enum(functionalLevelEnum, {
    required_error: "Selecione o nível funcional.",
    invalid_type_error: "Selecione o nível funcional.",
  }),
  shortTermGoals: z
    .string({
      required_error: "Defina ao menos um objetivo de curto prazo.",
      invalid_type_error: "Defina ao menos um objetivo de curto prazo.",
    })
    .min(5, "Defina ao menos um objetivo de curto prazo."),
  longTermGoals: z
    .string({
      required_error: "Defina ao menos um objetivo de longo prazo.",
      invalid_type_error: "Defina ao menos um objetivo de longo prazo.",
    })
    .min(5, "Defina ao menos um objetivo de longo prazo."),
  treatmentPlan: z
    .string({
      required_error: "O plano de tratamento é obrigatório.",
      invalid_type_error: "O plano de tratamento é obrigatório.",
    })
    .min(10, "O plano de tratamento deve ter pelo menos 10 caracteres."),
  sessionFrequency: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  patientId: "",
  consultationDate: "",
  mainComplaint: "",

  painLevel: 0,
  functionalLevel: "INDEPENDENT",
  shortTermGoals: "",
  longTermGoals: "",
  treatmentPlan: "",
  sessionFrequency: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, {
    ...initialState,
    medicationsInUse: [],
  });
  open.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await physiotherapyConsultationStore.create(event.data);
    toast("Consulta Criada!", {
      description: "A consulta de fisioterapia foi salva com sucesso.",
    });
    emit("created");
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Consulta", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="false"
      title="Criar Nova Consulta"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-plus-circle" label="Nova Consulta" />

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-6"
          @submit="onSubmit"
        >
          <div class="flex items-start gap-4">
            <UFormField label="Paciente" name="patientId" class="">
              <PatientsSelectInput
                @update:patient="state.patientId = $event"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField
              label="Data da Consulta"
              name="consultationDate"
              class=""
            >
              <UInput
                v-model="state.consultationDate"
                type="date"
                :class="{ 'border-red-500': hasError('consultationDate') }"
              />
              <p
                v-if="getError('consultationDate')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("consultationDate") }}
              </p>
            </UFormField>
          </div>

          <USeparator label="Avaliação Inicial" />

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <UFormField label="Queixa Principal" name="mainComplaint">
              <UTextarea
                v-model="state.mainComplaint"
                :class="{ 'border-red-500': hasError('mainComplaint') }"
              />
              <p
                v-if="getError('mainComplaint')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("mainComplaint") }}
              </p>
            </UFormField>
            <UFormField
              label="Histórico Médico Relevante"
              name="medicalHistory"
            >
              <UTextarea
                v-model="state.medicalHistory"
                :class="{ 'border-red-500': hasError('medicalHistory') }"
              />
              <p
                v-if="getError('medicalHistory')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("medicalHistory") }}
              </p>
            </UFormField>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-8 items-center">
            <UFormField
              :label="`Nível de Dor: ${state.painLevel}`"
              name="painLevel"
            >
              <UInputNumber
                v-model="state.painLevel"
                :max="10"
                :class="{ 'border-red-500': hasError('painLevel') }"
              />
              <p v-if="getError('painLevel')" class="text-red-600 text-sm mt-1">
                {{ getError("painLevel") }}
              </p>
            </UFormField>
            <UFormField label="Nível Funcional" name="functionalLevel">
              <USelectMenu
                v-model="state.functionalLevel"
                :items="functionalLevelOptions"
                value-key="id"
                :class="{ 'border-red-500': hasError('functionalLevel') }"
              />
              <p
                v-if="getError('functionalLevel')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("functionalLevel") }}
              </p>
            </UFormField>
          </div>
          <USeparator label="Plano de Tratamento" />
          <div class="grid grid-cols-1 gap-4">
            <UFormField label="Objetivos de Curto Prazo" name="shortTermGoals">
              <UTextarea
                v-model="state.shortTermGoals"
                class="w-full"
                :class="{ 'border-red-500': hasError('shortTermGoals') }"
              />
              <p
                v-if="getError('shortTermGoals')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("shortTermGoals") }}
              </p>
            </UFormField>
            <UFormField label="Objetivos de Longo Prazo" name="longTermGoals">
              <UTextarea
                v-model="state.longTermGoals"
                class="w-full"
                :class="{ 'border-red-500': hasError('longTermGoals') }"
              />
              <p
                v-if="getError('longTermGoals')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("longTermGoals") }}
              </p>
            </UFormField>
            <UFormField
              label="Plano de Tratamento Detalhado"
              name="treatmentPlan"
              class="col-span-full"
            >
              <UTextarea
                v-model="state.treatmentPlan"
                :rows="5"
                class="w-full"
                :class="{ 'border-red-500': hasError('treatmentPlan') }"
              />
              <p
                v-if="getError('treatmentPlan')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("treatmentPlan") }}
              </p>
            </UFormField>
            <UFormField label="Frequência das Sessões" name="sessionFrequency">
              <UInput
                v-model="state.sessionFrequency"
                placeholder="Ex: 2x por semana"
                class="w-full"
                :class="{ 'border-red-500': hasError('sessionFrequency') }"
              />
              <p
                v-if="getError('sessionFrequency')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("sessionFrequency") }}
              </p>
            </UFormField>
          </div>

          <UButton type="submit" block class="mt-8"> Salvar Consulta </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
