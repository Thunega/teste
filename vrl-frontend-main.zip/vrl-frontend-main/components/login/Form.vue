<script setup lang="ts">
import { BriefcaseMedical } from 'lucide-vue-next'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

const authStore = useAuthStore()
const router = useRouter()

const email = ref('')
const password = ref('')
const loading = ref(false)
const error = ref('')

async function handleSubmit() {
  loading.value = true
  error.value = ''

  try {
    const success = await authStore.login(email.value, password.value)
    if (success) {
      window.location.href = '/';
    } else {
      error.value = 'Invalid credentials'
    }
  } catch (e) {
    error.value = 'An error occurred'
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <div class="flex flex-col gap-6">
    <form @submit.prevent="handleSubmit">
      <div class="flex flex-col gap-6">
        <div class="flex flex-col items-center gap-2">
          <a
            href="#"
            class="flex flex-col items-center gap-2 font-medium"
          >
            <div class="flex h-8 w-8 items-center justify-center rounded-md">
              <BriefcaseMedical class="size-8" />
            </div>
            <span class="sr-only">VR LEÃO</span>
          </a>
          <h1 class="text-xl font-bold">
            Bem vindo a VR Leão médica.
          </h1>
        </div>
        <div class="flex flex-col gap-6">
          <div class="grid gap-2">
            <Label html-for="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="m@example.com"
              v-model="email"
              required
            />
          </div>

          <div class="grid gap-2">
            <Label html-for="password">Password</Label>
            <Input
            v-model="password"
              id="password"
              type="password"
              placeholder="password"
              required
            />
          </div>

          <Button type="submit" class="w-full" :disabled="loading">
            {{ loading ? 'Loading...' : 'Login' }}
          </Button>
        </div>
      </div>
    </form>
  </div>
</template>
