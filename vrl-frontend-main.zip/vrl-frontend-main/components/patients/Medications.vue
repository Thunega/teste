<script setup lang="ts">
import { ref, onMounted, computed } from "vue";
import type { TimelineItem } from "@nuxt/ui/dist/runtime/types";

const props = defineProps<{
  patientId: string;
}>();

const { $api } = useNuxtApp();

const loading = ref(true);
const medications = ref<any[]>([]);

const pagination = ref({
  pageIndex: 0,
  pageSize: 10,
});

async function fetchData() {
  try {
    loading.value = true;

    const data = await $api(`/medications/patient/${props.patientId}`);

    medications.value = data?.data ?? [];
  } catch (error) {
    console.error("Erro ao buscar medicamentos", error);
  } finally {
    loading.value = false;
  }
}

onMounted(fetchData);



const formatDateTime = (isoString: string) => {
  return new Date(isoString).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

const translateStatus = (description?: string) => {
  switch (description) {
    case "ACTIVE":
      return "Ativo";
    case "INACTIVE":
      return "Interrompido";
    default:
      return description;
  }
};

const timelineItems = computed<TimelineItem[]>(() => {
  if (!medications.value?.length) return [];

  const events: TimelineItem[] = [];

  medications.value.forEach((medication) => {
    medication.history?.forEach((h: any) => {
      events.push({
        id: medication.id,
        date: formatDateTime(h.createdAt),
        title: medication.name,
        dose: h.dosage,
        timetables: h.timetables,
        duration: h.duration,
        description: translateStatus(h.status) ,
        discontinuedReason: medication.discontinuedReason,
        icon: "i-lucide-pill",
      });
    });
  });

  return events.sort(
    (a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime(),
  );
});

const paginatedTimelineItems = computed(() => {
  const start = pagination.value.pageIndex * pagination.value.pageSize;
  const end = start + pagination.value.pageSize;
  return timelineItems.value.slice(start, end);
});

const currentPage = computed(() => pagination.value.pageIndex + 1);
</script>

<template>
  <div v-if="loading" class="text-center p-8">
    <p>Carregando histórico...</p>
  </div>

  <div v-else-if="!timelineItems.length" class="text-center p-8">
    <p>Nenhum histórico encontrado para este paciente.</p>
  </div>

  <div v-else>
    <div class="flex justify-between items-center w-full gap-32">
      <PatientsMedicationTable :events="paginatedTimelineItems" class="mr-16" />

      <UTimeline
        :items="paginatedTimelineItems"
        :default-value="pagination.pageSize"
        :ui="{
          item: 'even:flex-row-reverse even:-translate-x-[calc(100%-2rem)] even:text-right',
        }"
        class="translate-x-[calc(50%-1rem)]"
      >
        <template #title="{ item }">
          <ULink v-bind:to="item.link">{{ item.title }}</ULink>
        </template>
        <template #description="{ item }">
    <div class="space-y-1 text-sm">
      <p><strong>{{ item.description }}</strong></p>
    </div>
  </template>
      </UTimeline>
    </div>

    <div class="flex justify-center items-center mt-6">
      <UPagination
        v-if="timelineItems.length > pagination.pageSize"
        :total="timelineItems.length"
        :page-count="pagination.pageSize"
        :model-value="currentPage"
        @update:page="(p) => (pagination.pageIndex = p - 1)"
      />
    </div>
  </div>
</template>
