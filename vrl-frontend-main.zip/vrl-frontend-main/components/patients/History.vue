<script setup lang="ts">
import {ref, onMounted, computed, watch} from 'vue'
import type {TimelineItem} from '@nuxt/ui/dist/runtime/types'
import {useTimeAgo} from "@vueuse/core";

const props = defineProps<{
  patientId: string;
}>()

const historyStore = useHistoryStore()
const pagination = ref({pageIndex: 0, pageSize: 7});

const fetchData = () => {
  historyStore.fetchData(props.patientId, {
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
  })
}

watch(() => pagination.value.pageIndex, fetchData);
onMounted(fetchData);

const getEventTypeDetails = (type: string) => {
  switch (type) {
    case 'EXAM':
      return {title: 'Exame Laboratorial', icon: 'i-lucide-beaker', linkPrefix: '/exams'};
    case 'MEDICAL_CONSULTATION':
      return {title: 'Consulta Médica', icon: 'i-lucide-stethoscope', linkPrefix: '/medical-consultations'};
    case 'NUTRITIONAL_CONSULTATION':
      return {title: 'Consulta Nutricional', icon: 'i-lucide-apple', linkPrefix: '/nutritional-consultations'};
    case 'PSYCHOLOGICAL_CONSULTATION':
      return {
        title: 'Consulta Psicológica',
        icon: 'i-lucide-brain-circuit',
        linkPrefix: '/psychological-consultations'
      };
    case 'PHYSIOTHERAPY_CONSULTATION':
      return {
        title: 'Consulta Fisioterapêutica',
        icon: 'i-lucide-user-cog',
        linkPrefix: '/physiotherapy-consultations'
      };
    default:
      return {title: type, icon: 'i-lucide-file-text', linkPrefix: '/'};
  }
}

const formatDateTime = (isoString: string) => {
  return new Date(isoString).toLocaleString('pt-BR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

const timelineItems = computed<TimelineItem[]>(() => {
  if (!historyStore.data) return []
  return historyStore.data.map((event: any) => {
    const details = getEventTypeDetails(event.type)
    return {
      date: formatDateTime(event.date),
      title: details.title,
      description: `Responsável: ${event.responsibleUserName}`,
      icon: details.icon,
      link: `${details.linkPrefix}/${event.id}`,
    }
  })
})

const currentPage = computed(() => pagination.value.pageIndex + 1)
</script>

<template>
  <div v-if="historyStore.loading && !historyStore.data?.length" class="text-center p-8">
    <p>Carregando histórico...</p>
  </div>
  <div v-else-if="!historyStore.data?.length" class="text-center p-8">
    <p>Nenhum histórico encontrado para este paciente.</p>
  </div>
  <div v-else>
    <div class="flex justify-between items-center w-full gap-32">
      <PatientsHistoryTable :events="timelineItems" class="mr-24"/>

        <UTimeline
            :items="timelineItems"
            :default-value="pagination.pageSize"
            :ui="{ item: 'even:flex-row-reverse even:-translate-x-[calc(100%-2rem)] even:text-right' }"
            class="translate-x-[calc(50%-1rem)]"
        >
          <template #title="{ item }">
            <ULink v-bind:to="item.link">{{ item.title }}</ULink>
          </template>
        </UTimeline>

    </div>
    <div class="flex justify-center items-center mt-6">
      <UPagination
          v-if="historyStore.meta && historyStore.meta.total > historyStore.meta.perPage"
          :total="historyStore.meta.total"
          :page-count="historyStore.meta.perPage"
          :model-value="currentPage"
          @update:page="p => pagination.pageIndex = p - 1"
      />
    </div>
  </div>
</template>