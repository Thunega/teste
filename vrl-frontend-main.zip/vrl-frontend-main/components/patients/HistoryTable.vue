<script setup lang="ts">
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { computed } from 'vue';

const router = useRouter()

// --- Tipagem para os dados formatados que o componente espera ---
interface EventItem {
  date: string;
  title: string;
  description: string;
  icon: any; // Pode ser um componente Vue ou um nome de ícone
  link: string;
}

const props = defineProps<{
  events: EventItem[];
}>();

// --- Ordena os eventos pela data, do mais recente para o mais antigo ---
const sortedEvents = computed(() => {
  if (!props.events) return [];
  // A data já vem formatada, então a ordenação precisa ser feita antes da formatação.
  // Se a data original estiver disponível, seria ideal usá-la aqui.
  // Por enquanto, vamos assumir que a ordem recebida está correta ou não precisa de reordenação.
  return props.events;
});

// --- Função para navegar para o link do evento ---
// Em uma aplicação real, você usaria o router do Vue (ex: router.push(link))
const navigateTo = (link: string) => {
  router.push(link);
 
};
</script>

<template>
  <div class="h-min p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <Table v-if="sortedEvents.length > 0">
      <TableHeader>
        <TableRow>
          <TableHead>Tipo de Evento</TableHead>
          <TableHead>Descrição</TableHead>
          <TableHead class="text-right">Data</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow
            v-for="(event, index) in sortedEvents"
            :key="index"
            class="cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800"
            @click="navigateTo(event.link)"
        >
          <TableCell class="font-medium">
            <div class="flex items-center gap-3">
              <!-- Renderiza o componente do ícone se for um objeto, ou o nome se for string -->
              <component v-if="typeof event.icon === 'object'" :is="event.icon" class="h-5 w-5 text-gray-500" />
              <UIcon v-bind:name="event.icon" v-else/>
              <span>{{ event.title }}</span>
            </div>
          </TableCell>
          <TableCell>{{ event.description }}</TableCell>
          <TableCell class="text-right">{{ event.date }}</TableCell>
        </TableRow>
      </TableBody>
    </Table>
    <p v-else class="py-4 text-center text-gray-500">
      Sem eventos para exibir.
    </p>
  </div>
</template>