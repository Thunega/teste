<template>
  <USelectMenu
    v-model="selected"
    v-model:search-term="searchTerm"
    :items="patients"
    :loading="status === 'pending'"
    placeholder="Buscar paciente pelo nome..."
    option-attribute="label"
    value-attribute="value"
    ignore-filter
    by="value"
  >
   <template #trailing>
    <UButton
      v-if="searchTerm || selected"
      icon="i-heroicons-x-mark-20-solid"
      variant="ghost"
      size="xs"
      @click.stop="clearInput"
    />
    <UIcon
      v-else
      name="i-heroicons-magnifying-glass-20-solid"
      class="text-gray-400"
    />
  </template>
  </USelectMenu>
</template>

<script setup lang="ts">
import { ref, useId, watch } from "vue";
import { refDebounced } from "@vueuse/core";

const emit = defineEmits(["update:patient"]);
const componentId = useId();

const selected = ref<any>(null);
const searchTerm = ref("");

const clearInput =  () => {
  selected.value = null;
  searchTerm.value = "";
};

const searchTermDebounced = refDebounced(searchTerm, 300);

watch(selected, (value) => {
  if (!value) return;
  emit("update:patient", value.value);
});

const { $api } = useNuxtApp();

const { data: patients, status } = await useAsyncData(
  `search-patients-${componentId}`,
  () => {
    return $api("/patients", {
      params: searchTermDebounced.value
        ? { query: searchTermDebounced.value }
        : {}
    });
  },
  {
    transform: (response: {
      data: { id: string; name: string; cpf: string }[];
    }) => {
      return (response.data || []).map((patient) => ({
        label: `${patient.name} - CPF: ${patient.cpf}`,
        value: patient.id,
      }));
    },
    watch: [searchTermDebounced],
    lazy: true,
    default: () => [],
  }
);
</script>
