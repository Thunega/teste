<script setup lang="ts">
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { computed } from "vue";

const router = useRouter();

// --- Tipagem para os dados formatados que o componente espera ---
interface EventItem {
  id: string;
  date: string;
  title: string;
  dose?: string;
  timetables?: string;
  duration?: string;
  description?: string;
  icon: any;
  link?: string;
  discontinuedReason?: string
}

const props = defineProps<{
  events: EventItem[];
}>();

// --- Ordena os eventos pela data, do mais recente para o mais antigo ---
const sortedEvents = computed(() => {
  if (!props.events) return [];
  // A data já vem formatada, então a ordenação precisa ser feita antes da formatação.
  // Se a data original estiver disponível, seria ideal usá-la aqui.
  // Por enquanto, vamos assumir que a ordem recebida está correta ou não precisa de reordenação.
  return props.events;
});

// --- Função para navegar para o link do evento ---
// Em uma aplicação real, você usaria o router do Vue (ex: router.push(link))
const navigateTo = (link: string) => {
  router.push(link);
  // window.location.href = link; // Descomente para navegação real
};
</script>

<template>
  <div class="h-min p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <Table v-if="sortedEvents.length > 0">
      <TableHeader>
        <TableRow>
          <TableHead>Medicamento</TableHead>
          <TableHead>Dose</TableHead>
          <TableHead>Horários</TableHead>
          <TableHead>Duração</TableHead>
          <TableHead>Status</TableHead>
          <TableHead class="text-right">Data</TableHead>
        </TableRow>
      </TableHeader>

      <TableBody>
        <TableRow
          v-for="(event, index) in sortedEvents"
          :key="index"
          class="cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800"
          @click="event.link && navigateTo(event.link)"
        >
          <TableCell class="font-medium">
            <div class="flex items-center gap-3">
              <component
                v-if="typeof event.icon === 'object'"
                :is="event.icon"
                class="h-5 w-5 text-gray-500"
              />
              <UIcon v-bind:name="event.icon" v-else />
              <span>{{ event.title }}</span>
            </div>
          </TableCell>

          <TableCell>
            {{ event.dose || "-" }}
          </TableCell>

          <TableCell>
            {{ event.timetables || "-" }}
          </TableCell>

          <TableCell>
            {{ event.duration || "-" }}
          </TableCell>

          <TableCell>
            <TooltipProvider v-if="event.description === 'Interrompido'">
              <Tooltip>
                <TooltipTrigger as-child>
                  <UBadge class="bg-red-500 text-white cursor-help">
                    {{ event.description }}
                  </UBadge>
                </TooltipTrigger>

                <TooltipContent>
                  {{ event.discontinuedReason || "Medicamento interrompido" }}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <UBadge
              v-else-if="event.description === 'Ativo'"
              class="bg-green-500 text-white"
            >
              {{ event.description }}
            </UBadge>

            <span v-else>-</span>
          </TableCell>

          <TableCell class="text-right">
            {{ event.date }}
          </TableCell>
          <TableCell class="text-right">
            <MedicationsEditModal
              :medication="event"
              @medicationUpdated="fetchData"
            />
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>
    <p v-else class="py-4 text-center text-gray-500">
      Sem eventos para exibir.
    </p>
  </div>
</template>
