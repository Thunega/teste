<script setup lang="ts">
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

// New schema based on your JSON structure
const open = ref(false);
const emit = defineEmits(["patientCreated"]);

const medicationSchema = z.object({
  name: z
    .string({
      required_error: "O nome do medicamento é obrigatório.",
      invalid_type_error: "O nome do medicamento é obrigatório.",
    })
    .min(2, "O nome deve ter pelo menos 2 caracteres."),
  dosage: z
    .string({
      required_error: "A dosagem é obrigatória.",
      invalid_type_error: "A dosagem é obrigatória.",
    })
    .min(1, "A dosagem é obrigatória."),
  timetables: z.string().optional(),
  duration: z.string().optional(),
});

const schema = z.object({
  name: z
    .string({
      required_error: "O nome é obrigatório.",
      invalid_type_error: "O nome é obrigatório.",
    })
    .min(3, "O nome deve ter pelo menos 3 caracteres."),
  cpf: z
    .string({
      required_error: "O CPF é obrigatório.",
      invalid_type_error: "O CPF é obrigatório.",
    })
    .regex(/^\d{11}$/, "O CPF deve conter exatamente 11 dígitos numéricos."),
  dateOfBirth: z
    .string({
      required_error: "A data de nascimento é obrigatória.",
      invalid_type_error: "A data de nascimento é obrigatória.",
    })
    .nonempty("A data de nascimento é obrigatória."),
  gender: z.enum(["MALE", "FEMALE", "OTHER"], {
    required_error: "Selecione o gênero.",
    invalid_type_error: "Selecione o gênero.",
  }),
  bloodType: z
    .enum([
      "A_POSITIVE",
      "A_NEGATIVE",
      "B_POSITIVE",
      "B_NEGATIVE",
      "AB_POSITIVE",
      "AB_NEGATIVE",
      "O_POSITIVE",
      "O_NEGATIVE",
    ])
    .optional(),
  email: z.string().email("Email inválido.").optional(),
  phone: z
    .string()
    .regex(
      /^\+55[1-9]{2}[0-9]{8,9}$/,
      "Formato inválido. Use o formato: +5531999998888",
    )
    .optional(),
  address: z.string().optional(),
  zipCode: z
    .string()
    .regex(/^\d{8}$/, "O CEP deve conter exatamente 8 números.")
    .optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  emergencyContact: z
    .string()
    .regex(
      /^\+55[1-9]{2}[0-9]{8,9}$/,
      "Formato inválido. Use o formato: +5531999998888",
    )
    .optional(),
  status: z
  .enum(["ACTIVE", "TREATMENT_INTERRUPTED", "TREATMENT_COMPLETED"])
  .optional(),
  exerciseAlert: z.string().optional(),
  clinicalInfo: z
    .object({
      healthInsurance: z.string().optional(),
      weightKg: z
        .number({
          required_error: "O peso é obrigatório.",
          invalid_type_error: "O peso deve ser um número.",
        })
        .positive("O peso deve ser positivo."),
      heightCm: z
        .number({
          required_error: "A altura é obrigatória.",
          invalid_type_error: "A altura deve ser um número.",
        })
        .positive("A altura deve ser positiva."),
      allergies: z.string().optional(),
      comorbidities: z.string().optional(),
      medicationsInUse: z.string().optional(),
      mainTreatmentGoal: z.string().optional(),
    })
    .optional(),
  medicalHistory: z.string().optional(),
  medicationsInUse: z.array(medicationSchema).optional(),
  anamnesis: z
    .object({
      chiefComplaint: z.string().optional(),
      historyOfCurrentIllness: z.string().optional(),
      personalAndFamilyHistory: z.string().optional(),
      lifestyleHabits: z.string().optional(),
    })
    .optional(),
});

type Schema = z.output<typeof schema>;
type MedicationSchema = z.output<typeof medicationSchema>;

const state = reactive<Partial<Schema>>({
  name: undefined,
  cpf: undefined,
  dateOfBirth: undefined,
  gender: undefined,
  bloodType: undefined,
  email: undefined,
  phone: undefined,
  address: undefined,
  zipCode: undefined,
  city: undefined,
  state: undefined,
  emergencyContact: undefined,
  status: "ACTIVE",
  exerciseAlert: undefined,
  clinicalInfo: {
    healthInsurance: undefined,
    weightKg: undefined,
    heightCm: undefined,
    allergies: undefined,
    comorbidities: undefined,
    medicationsInUse: undefined,
    mainTreatmentGoal: undefined,
  },
  medicalHistory: "",
  medicationsInUse: [{} as Partial<MedicationSchema>],
  anamnesis: {
    chiefComplaint: undefined,
    historyOfCurrentIllness: undefined,
    personalAndFamilyHistory: undefined,
    lifestyleHabits: undefined,
  },
});

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

// Options for the gender select dropdown
const genderItems = ref([
  {
    label: "Masculino",
    id: "MALE",
  },
  {
    label: "Feminino",
    id: "FEMALE",
  },
  {
    label: "Outro",
    id: "OTHER",
  },
]);

const statusItems = ref([
  {
    label: "Ativo",
    id: "ACTIVE",
  },
  {
    label: "Interrompido",
    id: "TREATMENT_INTERRUPTED",
  },
  {
    label: "Finalizado",
    id: "TREATMENT_COMPLETED",
  },
]);

// Options for blood type select dropdown
const bloodTypeItems = ref([
  { label: "A+", id: "A_POSITIVE" },
  { label: "A-", id: "A_NEGATIVE" },
  { label: "B+", id: "B_POSITIVE" },
  { label: "B-", id: "B_NEGATIVE" },
  { label: "AB+", id: "AB_POSITIVE" },
  { label: "AB-", id: "AB_NEGATIVE" },
  { label: "O+", id: "O_POSITIVE" },
  { label: "O-", id: "O_NEGATIVE" },
]);

async function onSubmit(event: FormSubmitEvent<Schema>) {
  // validação local via Zod
  if (!validate()) return;

  try {
    const { $api } = useNuxtApp();

    // separa medicamentos
    const medications = event.data.medicationsInUse ?? [];

    // remove do payload do paciente
    const { medicationsInUse, medicalHistory, ...patientData } = event.data;

    // cria paciente
    const newPatient = await usePatientStore().createPatient(patientData);

    const patientId = newPatient.id;

    // cria medicamentos
    for (const med of medications) {
      if (!med.name) continue;

      await $api("/medications", {
        method: "POST",
        body: {
          ...med,
          patientId,
        },
      });
    }

    toast("Paciente Cadastrado!", {
      description: "Paciente e medicamentos salvos.",
    });

    emit("patientCreated");
    open.value = false;
  } catch (error: any) {
    // aplica erros do servidor aos campos, quando disponíveis
    if (error?.data?.errors) {
      setErrorsFromServer(error.data.errors);
    }

    console.log(error);
    toast("Erro ao Cadastrar", {
      description: `Não foi possível criar o paciente. Verifique os dados e tente novamente.\n ${error?.data?.message || ""}`,
    });
    console.error("Error creating patient:", error);
  }
}

function addMedication() {
  state.medicationsInUse.push({});
}

function removeMedication(index: number) {
  state.medicationsInUse.splice(index, 1);
}
</script>

<template>
  <UModal
    v-model:open="open"
    :overlay="false"
    :dismissible="false"
    title="Criar Novo Paciente"
    :close="{
      color: 'primary',
      variant: 'outline',
      class: 'rounded-full',
    }"
  >
    <UButton color="primary" variant="solid">
      <UIcon name="i-heroicons-plus-circle" class="size-6" /> Criar Novo
      Paciente
    </UButton>

    <template #body>
      <UForm
        :schema="schema"
        :state="state"
        class="space-y-4 space-x4 h-full w-full"
        @submit="onSubmit"
      >
        <!-- Dados Pessoais -->
        <div class="flex gap-4 flex-wrap">
          <UFormField label="Nome Completo" name="name">
            <UInput
              v-model="state.name"
              placeholder="João da Silva"
              :class="{ 'border-red-500': hasError('name') }"
            />
            <p v-if="getError('name')" class="text-red-600 text-sm mt-1">
              {{ getError("name") }}
            </p>
          </UFormField>

          <UFormField label="Gênero" name="gender">
            <USelect
              v-model="state.gender"
              value-key="id"
              placeholder="Selecione..."
              :items="genderItems"
              :class="{ 'border-red-500': hasError('gender') }"
            />
            <p v-if="getError('gender')" class="text-red-600 text-sm mt-1">
              {{ getError("gender") }}
            </p>
          </UFormField>

          <UFormField label="CPF" name="cpf">
            <UInput
              v-model="state.cpf"
              placeholder="00011122233"
              :class="{ 'border-red-500': hasError('cpf') }"
            />
            <p v-if="getError('cpf')" class="text-red-600 text-sm mt-1">
              {{ getError("cpf") }}
            </p>
          </UFormField>

          <UFormField label="Data de Nascimento" name="dateOfBirth">
            <UInput
              v-model="state.dateOfBirth"
              type="date"
              :class="{ 'border-red-500': hasError('dateOfBirth') }"
            />
            <p v-if="getError('dateOfBirth')" class="text-red-600 text-sm mt-1">
              {{ getError("dateOfBirth") }}
            </p>
          </UFormField>

          <UFormField label="Tipo Sanguíneo" name="bloodType">
            <USelect
              v-model="state.bloodType"
              value-key="id"
              placeholder="Selecione..."
              :items="bloodTypeItems"
              :class="{ 'border-red-500': hasError('bloodType') }"
            />
            <p v-if="getError('bloodType')" class="text-red-600 text-sm mt-1">
              {{ getError("bloodType") }}
            </p>
          </UFormField>
          <UFormField label="Status do Paciente" name="status">
            <USelect
              v-model="state.status"
              value-key="id"
              placeholder="Selecione..."
              :items="statusItems"
            />
          </UFormField>
          <UFormField
            label="Restrição Fisica"
            name="exerciseAlert"
            class="w-full"
          >
            <UTextarea
              v-model="state.exerciseAlert"
              placeholder="Evitar exercícios de alto impacto. Restrição: joelho direito com lesão de menisco."
              rows="3"
              class="w-full"
            />
            <p
              v-if="getError('exerciseAlert')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("exerciseAlert") }}
            </p>
          </UFormField>
        </div>

        <!-- Contato -->
        <div class="flex gap-4 items-end">
          <UFormField label="Email" name="email">
            <UInput
              v-model="state.email"
              type="email"
              placeholder="joao.silva@email.com"
              class="flex-1"
              :class="{ 'border-red-500': hasError('email') }"
            />
            <p v-if="getError('email')" class="text-red-600 text-sm mt-1">
              {{ getError("email") }}
            </p>
          </UFormField>

          <UFormField label="Telefone" name="phone">
            <UInput
              v-model="state.phone"
              type="tel"
              placeholder="+5527988887777"
              class="flex-1"
              :class="{ 'border-red-500': hasError('phone') }"
            />
            <p v-if="getError('phone')" class="text-red-600 text-sm mt-1">
              {{ getError("phone") }}
            </p>
          </UFormField>

          <UFormField label="Contato de Emergência" name="emergencyContact">
            <UInput
              v-model="state.emergencyContact"
              placeholder="+5527988887777"
              class="flex-1"
              :class="{ 'border-red-500': hasError('emergencyContact') }"
            />
            <p
              v-if="getError('emergencyContact')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("emergencyContact") }}
            </p>
          </UFormField>
        </div>

        <!-- Endereço -->
        <div class="grid grid-cols-2 gap-6">
          <UFormField label="Endereço" name="address">
            <UInput
              v-model="state.address"
              placeholder="Rua das Flores, 123"
              :class="{ 'border-red-500': hasError('address') }"
            />
            <p v-if="getError('address')" class="text-red-600 text-sm mt-1">
              {{ getError("address") }}
            </p>
          </UFormField>

          <UFormField label="CEP" name="zipCode">
            <UInput
              v-model="state.zipCode"
              placeholder="01001000"
              :class="{ 'border-red-500': hasError('zipCode') }"
            />
            <p v-if="getError('zipCode')" class="text-red-600 text-sm mt-1">
              {{ getError("zipCode") }}
            </p>
          </UFormField>

          <UFormField label="Cidade" name="city">
            <UInput
              v-model="state.city"
              placeholder="São Paulo"
              :class="{ 'border-red-500': hasError('city') }"
            />
            <p v-if="getError('city')" class="text-red-600 text-sm mt-1">
              {{ getError("city") }}
            </p>
          </UFormField>

          <UFormField label="Estado" name="state">
            <UInput
              v-model="state.state"
              placeholder="SP"
              :class="{ 'border-red-500': hasError('state') }"
            />
            <p v-if="getError('state')" class="text-red-600 text-sm mt-1">
              {{ getError("state") }}
            </p>
          </UFormField>
        </div>

        <!-- Informações Clínicas -->
        <div class="space-y-2 border-t pt-4">
          <h3 class="font-semibold">Informações Clínicas</h3>
          <div class="grid grid-cols-2 gap-6">
            <UFormField label="Convênio" name="clinicalInfo.healthInsurance">
              <UInput
                v-model="state.clinicalInfo.healthInsurance"
                placeholder="Unimed"
              />
            </UFormField>

            <UFormField label="Peso (kg)" name="clinicalInfo.weightKg">
              <UInput
                v-model.number="state.clinicalInfo.weightKg"
                type="number"
                step="0.1"
                placeholder="68.5"
                :class="{ 'border-red-500': hasError('clinicalInfo.weightKg') }"
              />
              <p
                v-if="getError('clinicalInfo.weightKg')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("clinicalInfo.weightKg") }}
              </p>
            </UFormField>

            <UFormField label="Altura (cm)" name="clinicalInfo.heightCm">
              <UInput
                v-model.number="state.clinicalInfo.heightCm"
                type="number"
                step="0.1"
                placeholder="165"
                :class="{ 'border-red-500': hasError('clinicalInfo.heightCm') }"
              />
              <p
                v-if="getError('clinicalInfo.heightCm')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("clinicalInfo.heightCm") }}
              </p>
            </UFormField>

            <UFormField label="Alergias" name="clinicalInfo.allergies">
              <UInput
                v-model="state.clinicalInfo.allergies"
                placeholder="Penicilina, Dipirona"
              />
            </UFormField>

            <UFormField label="Comorbidades" name="clinicalInfo.comorbidities">
              <UInput
                v-model="state.clinicalInfo.comorbidities"
                placeholder="Hipertensão, Diabetes"
              />
            </UFormField>

            <UFormField
              label="Objetivo do Tratamento"
              name="clinicalInfo.mainTreatmentGoal"
            >
              <UInput
                v-model="state.clinicalInfo.mainTreatmentGoal"
                placeholder="Controle de peso e glicemia"
              />
            </UFormField>
          </div>
        </div>
        <!---Medicamentos em uso-->
        <USeparator label="Medicamentos em Uso" />
        <div class="space-y-4">
          <div
            v-for="(med, index) in state.medicationsInUse"
            :key="index"
            class="p-4 rounded-md bg-gray-50 dark:bg-gray-800/50"
          >
            <UForm
              :state="med"
              :schema="medicationSchema"
              class="grid grid-cols-1 sm:grid-cols-4 gap-3"
            >
              <UFormField
                label="Nome"
                name="name"
                class="col-span-1 sm:col-span-2"
              >
                <UInput v-model="med.name" />
              </UFormField>
              <UFormField label="Dosagem" name="dosage">
                <UInput v-model="med.dosage" />
              </UFormField>
              <UFormField label="Horários" name="timetables">
                <UInput v-model="med.timetables" />
              </UFormField>
              <UFormField label="Duração" name="duration">
                <UInput v-model="med.duration" />
              </UFormField>
            </UForm>
            <div
              v-if="state.medicationsInUse.length > 1"
              class="text-right mt-2"
            >
              <UButton
                @click="removeMedication(index)"
                color="red"
                variant="link"
                icon="i-heroicons-x-circle"
                size="xs"
                >Remover
              </UButton>
            </div>
          </div>
          <div>
            <UButton
              @click="addMedication"
              icon="i-heroicons-plus-circle"
              size="sm"
              >Adicionar Medicamento</UButton
            >
          </div>
        </div>

        <!-- Anamnese -->
        <div class="space-y-2 border-t pt-4">
          <h3 class="font-semibold">Anamnese</h3>
          <div class="flex gap-4 flex-wrap">
            <UFormField
              label="Queixa Principal"
              name="anamnesis.chiefComplaint"
              class="w-full"
            >
              <UTextarea
                v-model="state.anamnesis.chiefComplaint"
                placeholder="Dores nas articulações e fadiga constante"
                rows="3"
                class="w-full"
              />
              <p
                v-if="getError('anamnesis.chiefComplaint')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("anamnesis.chiefComplaint") }}
              </p>
            </UFormField>

            <UFormField
              label="História da Doença Atual"
              name="anamnesis.historyOfCurrentIllness"
              class="w-full"
            >
              <UTextarea
                v-model="state.anamnesis.historyOfCurrentIllness"
                placeholder="Início dos sintomas há 6 meses..."
                rows="3"
                class="w-full"
              />
              <p
                v-if="getError('anamnesis.historyOfCurrentIllness')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("anamnesis.historyOfCurrentIllness") }}
              </p>
            </UFormField>

            <UFormField
              label="História Pessoal e Familiar"
              name="anamnesis.personalAndFamilyHistory"
              class="w-full"
            >
              <UTextarea
                v-model="state.anamnesis.personalAndFamilyHistory"
                placeholder="Mãe com histórico de diabetes..."
                rows="3"
                class="w-full"
              />
              <p
                v-if="getError('anamnesis.personalAndFamilyHistory')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("anamnesis.personalAndFamilyHistory") }}
              </p>
            </UFormField>

            <UFormField
              label="Hábitos de Vida"
              name="anamnesis.lifestyleHabits"
              class="w-full"
            >
              <UTextarea
                v-model="state.anamnesis.lifestyleHabits"
                placeholder="Sedentária, alimentação irregular..."
                rows="3"
                class="w-full"
              />
              <p
                v-if="getError('anamnesis.lifestyleHabits')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("anamnesis.lifestyleHabits") }}
              </p>
            </UFormField>
          </div>
        </div>

        <UButton type="submit" block> Cadastrar Paciente </UButton>
      </UForm>
    </template>
  </UModal>
</template>
