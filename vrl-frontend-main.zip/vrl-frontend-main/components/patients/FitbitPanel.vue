<template>
  <div class="p-4 border rounded-md">
    <h3 class="text-lg font-medium mb-4">Integração com Fitbit</h3>

    <div v-if="fitbitStore.isLoading" class="flex items-center space-x-2">
      <div class="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-gray-900"></div>
      <span>Carregando informações...</span>
    </div>

    <div v-else-if="fitbitStore.authInfo">
      <div class="space-y-4">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-green-600 font-semibold">Conta Fitbit Vinculada</p>
            <p class="text-sm text-gray-500">ID de Usuário Fitbit: {{ fitbitStore.authInfo.userId }}</p>
          </div>
          <Badge variant="success">Ativo</Badge>
        </div>

        <div class="flex space-x-2">
          <div class="flex gap-4">
            <UPopover>
            <UButton color="neutral" variant="subtle" icon="i-lucide-calendar">
              <template v-if="modelValue.start">
                <template v-if="modelValue.end">
                  {{ df.format(modelValue.start.toDate(getLocalTimeZone())) }} - {{ df.format(modelValue.end.toDate(getLocalTimeZone())) }}
                </template>

                <template v-else>
                  {{ df.format(modelValue.start.toDate(getLocalTimeZone())) }}
                </template>
              </template>
              <template v-else>
                Pick a date
              </template>
            </UButton>

            <template #content>
              <UCalendar v-model="modelValue" class="p-4" size="md" :number-of-months="1" range />
            </template>
          </UPopover>
          
          <Button @click="handleSyncSleepLogs">
            <Icon name="material-symbols:sync" class="mr-2" />
            Sincronizar Registros de Sono
          </Button>
          </div>
          

    
          <Button v-if="authStore.role === 'ADMIN'" variant="destructive" @click="handleDeleteAuth">
            <Icon name="material-symbols:link-off" class="mr-2" />
            Revogar Acesso
          </Button>
        </div>
      </div>
    </div>

    <div v-else>
      <div class="space-y-4">
        <div>
          <p class="text-yellow-600 font-semibold">Nenhuma conta Fitbit vinculada.</p>
          <p class="text-sm text-gray-500">Gere um link para autorizar o acesso aos dados do Fitbit.</p>
        </div>
        <div class="flex flex-col gap-4">
          <Button @click="handleGenerateLink" size="sm">
            <Icon name="material-symbols:link" class="mr-2" />
            Gerar Link de Autorização
          </Button>

          <UInput
         v-if="authUrl"
    v-model="authUrl"
    :ui="{ trailing: 'pr-0.5' }"
  >
    <template v-if="authUrl?.length" #trailing>
      <UTooltip text="Copiar para área de transferência" :content="{ side: 'right' }">
        <UButton
          :color=" 'neutral' "
          variant="link"
          size="md"
          :icon="'i-lucide-copy'"
          aria-label="Copiar para área de transferência"
          @click="copy(authUrl)"
        />
      </UTooltip>
    </template>
  </UInput>
        </div> 
      </div>
    </div>

    <div v-if="fitbitStore.error" class="mt-4 p-3 bg-red-100 text-red-700 border border-red-200 rounded-md">
      <p>Ocorreu um erro: {{ fitbitStore.error.data?.message || 'Erro desconhecido' }}</p>
    </div>
  </div>
</template>


<script setup lang="ts">
import { onMounted, watch } from 'vue';
import { useFitbitStore } from '@/stores/fitbit';
import { useAuthStore } from '@/stores/auth';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'vue-sonner';
import { useClipboard } from '@vueuse/core';
import { CalendarDate, DateFormatter, getLocalTimeZone } from '@internationalized/date'

const df = new DateFormatter('en-US', {
  dateStyle: 'medium'
})

const modelValue = shallowRef({
  start: new CalendarDate(2025, 8, 9),
  end: new CalendarDate(2025, 8, 9)
})

watch(modelValue, (newValue, oldValue) => {
  if (newValue.start && newValue.end) {
    const start = newValue.start.toDate(getLocalTimeZone())
    const end = newValue.end.toDate(getLocalTimeZone())
    const diffInMs = end.getTime() - start.getTime()
    const diffInDays = diffInMs / (1000 * 60 * 60 * 24)

    if (diffInDays > 100) {
      toast.error('O intervalo entre as datas não pode ser maior que 100 dias.')
      modelValue.value = oldValue
    }
  }
})

const { copy, copied } = useClipboard()

const props = defineProps({
  patientId: {
    type: String,
    required: true,
  },
});

const fitbitStore = useFitbitStore();
const authStore = useAuthStore();
const authUrl= ref();

onMounted(() => {
  fitbitStore.fetchAuthInfo(props.patientId);
});

async function handleGenerateLink() {
  authUrl.value = await fitbitStore.generateAuthLink(props.patientId);
}

async function handleSyncSleepLogs() {
  if (modelValue.value.start && modelValue.value.end) {
    const startDate = modelValue.value.start.toDate(getLocalTimeZone()).toISOString().split('T')[0]
    const endDate = modelValue.value.end.toDate(getLocalTimeZone()).toISOString().split('T')[0]
    await fitbitStore.syncSleepLogs(props.patientId, { startDate, endDate })
  } else {
    toast.error('Por favor, selecione um intervalo de datas.')
  }
}

async function handleDeleteAuth() {
  if (confirm('Tem certeza que deseja revogar o acesso do Fitbit para este paciente?')) {
    await fitbitStore.deleteAuth(props.patientId);
  }
}
</script>

<style scoped>
/* You can add additional styles here if needed */
</style>
