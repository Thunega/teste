<script setup lang="ts">
import type { TabsItem } from '@nuxt/ui'

const props = defineProps<{
  patientId: string,
}>();

const examsStore = useExamStore();

const fetchData = async () => {
  await examsStore.fetchData({
    patientId: props.patientId,
    sort: 'desc',
    orderBy: 'createdAt',
  });
}



onMounted(fetchData)
</script>

<template>
  <UTabs :items="items" class="w-full">
    <template #exams>
      <ExamReport :exams="examsStore.data"/>
    </template>
  </UTabs>
</template>

