<script setup lang="ts">
import { onMounted } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["patientUpdated"]);

const props = defineProps({
  patientId: {
    type: String,
    required: true,
  },
});

const open = ref(false);

const statusItems = ref([
  {
    label: "Ativo",
    id: "ACTIVE",
  },
  {
    label: "Interrompido",
    id: "TREATMENT_INTERRUPTED",
  },
  {
    label: "Finalizado",
    id: "TREATMENT_COMPLETED",
  },
]);

const schema = z.object({
  name: z
    .string({
      required_error: "O nome é obrigatório.",
      invalid_type_error: "O nome é obrigatório.",
    })
    .min(3, "O nome deve ter pelo menos 3 caracteres."),
  cpf: z
    .string({
      required_error: "O CPF é obrigatório.",
      invalid_type_error: "O CPF é obrigatório.",
    })
    .regex(/^\d{11}$/, "O CPF deve conter exatamente 11 dígitos numéricos."),
  dateOfBirth: z
    .string({
      required_error: "A data de nascimento é obrigatória.",
      invalid_type_error: "A data de nascimento é obrigatória.",
    })
    .nonempty("A data de nascimento é obrigatória."),
  gender: z.enum(["MALE", "FEMALE", "OTHER"], {
    required_error: "Selecione o gênero.",
    invalid_type_error: "Selecione o gênero.",
  }),
  email: z.string().email("Email inválido.").optional(),
  phone: z
    .string()
    .regex(
      /^\+55[1-9]{2}[0-9]{8,9}$/,
      "Formato inválido. Use o formato: +5531999998888",
    )
    .optional(),
  address: z
    .string({
      required_error: "O endereço é obrigatório.",
      invalid_type_error: "O endereço é obrigatório.",
    })
    .nonempty("O endereço é obrigatório."),
  zipCode: z
    .string({
      required_error: "O CEP é obrigatório.",
      invalid_type_error: "O CEP é obrigatório.",
    })
    .regex(/^\d{8}$/, "O CEP deve conter exatamente 8 números."),
  city: z
    .string({
      required_error: "A cidade é obrigatória.",
      invalid_type_error: "A cidade é obrigatória.",
    })
    .nonempty("A cidade é obrigatória."),
  state: z
    .string({
      required_error: "O estado é obrigatório.",
      invalid_type_error: "O estado é obrigatório.",
    })
    .nonempty("O estado é obrigatório."),
  emergencyContact: z
    .string()
    .regex(
      /^\+55[1-9]{2}[0-9]{8,9}$/,
      "Formato inválido. Use o formato: +5531999998888",
    )
    .optional(),
    status: z
  .enum(["ACTIVE", "TREATMENT_INTERRUPTED", "TREATMENT_COMPLETED"])
  .optional(),
  exerciseAlert: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const state = reactive<Partial<Schema>>({
  name: undefined,
  cpf: undefined,
  dateOfBirth: undefined,
  gender: undefined,
  email: undefined,
  phone: undefined,
  address: undefined,
  zipCode: undefined,
  city: undefined,
  state: undefined,
  emergencyContact: undefined,
  status: "ACTIVE",
  exerciseAlert: undefined,
});

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

const genderItems = ref([
  { label: "Masculino", id: "MALE" },
  { label: "Feminino", id: "FEMALE" },
  { label: "Outro", id: "OTHER" },
]);

onMounted(async () => {
  try {
    const patientStore = usePatientStore();
    const patientData = await patientStore.getById(props.patientId);

    if (patientData) {
      // **FIX**: Instead of Object.assign, we selectively populate the state
      // This prevents fields like 'createdAt' from being added to the state.
      for (const key of Object.keys(state)) {
        if (patientData[key] !== undefined && patientData[key] !== null) {
          state[key as keyof Schema] = patientData[key];
        }
      }
      // Still handle date formatting separately
      if (patientData.dateOfBirth) {
        state.dateOfBirth = new Date(patientData.dateOfBirth)
          .toISOString()
          .split("T")[0];
      }
    }
  } catch (error) {
    toast("Erro ao Carregar Dados", {
      description: "Não foi possível carregar os dados do paciente.",
    });
    console.error("Error fetching patient data:", error);
  }
});

async function onSubmit(event: FormSubmitEvent<Schema>) {
  // validação local
  if (!validate()) return;

  try {
    const patientStore = usePatientStore();
    const updatedPatient = await patientStore.updatePatient(
      props.patientId,
      event.data,
    );

    toast("Paciente Atualizado!", {
      description: "Os dados do paciente foram atualizados com sucesso.",
    });
    console.log("Patient updated successfully:", updatedPatient);
    emit("patientUpdated");
    open.value = !open.value;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar", {
      description: `Não foi possível atualizar o paciente. Verifique os dados e tente novamente.\n ${error?.data?.message || ""}`,
    });
    console.error("Error updating patient:", error);
  }
}
</script>

<template>
  <UModal
    :dismissible="false"
    v-model:open="open"
    :overlay="false"
    title="Editar Paciente"
    :close="{
      color: 'primary',
      variant: 'outline',
      class: 'rounded-full',
    }"
  >
    <UButton color="primary" variant="solid">
      <UIcon name="i-heroicons-pencil-square" class="size-5" /> Editar Paciente
    </UButton>

    <template #body>
      <UForm
        :schema="schema"
        :state="state"
        class="space-y-4 space-x4 h-full w-full"
        @submit="onSubmit"
      >
        <div class="flex flex-wrap gap-4">
          <UFormField label="Nome Completo" name="name">
            <UInput
              v-model="state.name"
              placeholder="João da Silva"
              :class="{ 'border-red-500': hasError('name') }"
            />
            <p v-if="getError('name')" class="text-red-600 text-sm mt-1">
              {{ getError("name") }}
            </p>
          </UFormField>

          <UFormField label="Gênero" name="gender">
            <USelect
              v-model="state.gender"
              value-key="id"
              placeholder="Selecione..."
              :items="genderItems"
              :class="{ 'border-red-500': hasError('gender') }"
            />
            <p v-if="getError('gender')" class="text-red-600 text-sm mt-1">
              {{ getError("gender") }}
            </p>
          </UFormField>

          <UFormField label="CPF" name="cpf">
            <UInput
              v-model="state.cpf"
              placeholder="00011122233"
              :class="{ 'border-red-500': hasError('cpf') }"
            />
            <p v-if="getError('cpf')" class="text-red-600 text-sm mt-1">
              {{ getError("cpf") }}
            </p>
          </UFormField>

          <UFormField label="Data de Nascimento" name="dateOfBirth">
            <UInput
              v-model="state.dateOfBirth"
              type="date"
              :class="{ 'border-red-500': hasError('dateOfBirth') }"
            />
            <p v-if="getError('dateOfBirth')" class="text-red-600 text-sm mt-1">
              {{ getError("dateOfBirth") }}
            </p>
          </UFormField>
        </div>
        <div class="flex flex-wrap gap-4">
          <UFormField label="Email" name="email">
            <UInput
              v-model="state.email"
              type="email"
              placeholder="joao.silva@email.com"
              :class="{ 'border-red-500': hasError('email') }"
            />
            <p v-if="getError('email')" class="text-red-600 text-sm mt-1">
              {{ getError("email") }}
            </p>
          </UFormField>

          <UFormField label="Telefone" name="phone">
            <UInput
              v-model="state.phone"
              type="tel"
              placeholder="+5527988887777"
              :class="{ 'border-red-500': hasError('phone') }"
            />
            <p v-if="getError('phone')" class="text-red-600 text-sm mt-1">
              {{ getError("phone") }}
            </p>
          </UFormField>

          <UFormField label="Contato de Emergência" name="emergencyContact">
            <UInput
              v-model="state.emergencyContact"
              placeholder="+5527988887777"
              :class="{ 'border-red-500': hasError('emergencyContact') }"
            />
            <p
              v-if="getError('emergencyContact')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("emergencyContact") }}
            </p>
          </UFormField>
          <UFormField label="Status do Paciente" name="status">
            <USelect
              v-model="state.status"
              value-key="id"
              placeholder="Selecione..."
              :items="statusItems"
            />
          </UFormField>
          <UFormField
            label="Restrição Fisica"
            name="exerciseAlert"
            class="w-full"
          >
            <UTextarea
              v-model="state.exerciseAlert"
              placeholder="Evitar exercícios de alto impacto. Restrição: joelho direito com lesão de menisco."
              rows="3"
              class="w-full"
            />
            <p
              v-if="getError('exerciseAlert')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("exerciseAlert") }}
            </p>
          </UFormField>
        </div>
        <div class="flex flex-wrap gap-4">
          <UFormField label="Endereço" name="address">
            <UInput
              v-model="state.address"
              placeholder="Rua das Flores, 123"
              :class="{ 'border-red-500': hasError('address') }"
            />
            <p v-if="getError('address')" class="text-red-600 text-sm mt-1">
              {{ getError("address") }}
            </p>
          </UFormField>

          <UFormField label="CEP" name="zipCode">
            <UInput
              v-model="state.zipCode"
              placeholder="01001000"
              :class="{ 'border-red-500': hasError('zipCode') }"
            />
            <p v-if="getError('zipCode')" class="text-red-600 text-sm mt-1">
              {{ getError("zipCode") }}
            </p>
          </UFormField>

          <UFormField label="Cidade" name="city">
            <UInput
              v-model="state.city"
              placeholder="São Paulo"
              :class="{ 'border-red-500': hasError('city') }"
            />
            <p v-if="getError('city')" class="text-red-600 text-sm mt-1">
              {{ getError("city") }}
            </p>
          </UFormField>

          <UFormField label="Estado" name="state">
            <UInput
              v-model="state.state"
              placeholder="SP"
              :class="{ 'border-red-500': hasError('state') }"
            />
            <p v-if="getError('state')" class="text-red-600 text-sm mt-1">
              {{ getError("state") }}
            </p>
          </UFormField>
        </div>

        <UButton type="submit" block> Salvar Alterações </UButton>
      </UForm>
    </template>
  </UModal>
</template>
