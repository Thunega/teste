<script setup lang="ts">
import {CalendarDate, DateFormatter, getLocalTimeZone} from '@internationalized/date'

const df = new DateFormatter('pt-BR', {
  dateStyle: 'medium'
})

const model = defineModel<CalendarDate>()
// onMounted(() => {
//   const today = new Date();
//   model.value = new CalendarDate(today.getFullYear(), today.getMonth() + 1, today.getDate())
// })

</script>

<template>
  <UPopover>
    <UButton color="neutral" variant="subtle" icon="i-lucide-calendar">
      {{ model ? df.format(model.toDate(getLocalTimeZone())) : 'Selecione Uma Data' }}
    </UButton>

    <template #content>
      <UCalendar v-model="model" class="p-2"/>
    </template>
  </UPopover>
</template>

