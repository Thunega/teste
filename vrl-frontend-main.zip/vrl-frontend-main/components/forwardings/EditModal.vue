<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps<{
  forwardingId: string;
}>();

const emit = defineEmits(["updated"]);
const forwardingStore = useForwardingStore();

const open = ref(false);
const isLoading = ref(false);

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  toUserId: z.string({
    required_error: "É obrigatório selecionar um destinatário.",
    invalid_type_error: "É obrigatório selecionar um destinatário.",
  }),
  medicalNotes: z
    .string({
      required_error: "As notas médicas são obrigatórias.",
      invalid_type_error: "As notas médicas são obrigatórias.",
    })
    .min(10, "As notas médicas devem ter pelo menos 10 caracteres."),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  patientId: "",
  toUserId: "",
  medicalNotes: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

async function fetchData() {
  try {
    isLoading.value = true;
    const forwardingData = await forwardingStore.getById(props.forwardingId);
    if (forwardingData) {
      state.patientId = forwardingData.patientId;
      state.toUserId = forwardingData.toUserId;
      state.medicalNotes = forwardingData.medicalNotes;
    }
  } catch (error) {
    toast.error("Erro ao carregar dados", {
      description: "Não foi possível buscar os dados do encaminhamento.",
    });
  } finally {
    isLoading.value = false;
  }
}

watch(open, (isOpen) => {
  if (isOpen) {
    fetchData();
  }
});

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await forwardingStore.update(props.forwardingId, event.data);
    toast("Encaminhamento Atualizado!", {
      description: "O encaminhamento foi atualizado com sucesso.",
    });
    open.value = false;
    emit("updated");
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="false"
      title="Editar Encaminhamento"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton color="primary" variant="solid">
        <UIcon name="i-heroicons-plus-circle" class="size-6" />
        Editar Encaminhamento
      </UButton>

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <UFormField label="Paciente" name="patientId">
            <div class="space-y-4">
              <PatientsSelectInput
                @update:patient="state.patientId = $event"
                class="w-full"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <Input
                v-model="state.patientId"
                type="text"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </div>
          </UFormField>

          <UFormField label="Encaminhar para" name="toUserId">
            <div class="space-y-4">
              <UserSelectInput
                @update:user="state.toUserId = $event"
                class="w-full"
                :class="{ 'border-red-500': hasError('toUserId') }"
              />
              <Input
                v-model="state.toUserId"
                type="text"
                :class="{ 'border-red-500': hasError('toUserId') }"
              />
              <p v-if="getError('toUserId')" class="text-red-600 text-sm mt-1">
                {{ getError("toUserId") }}
              </p>
            </div>
          </UFormField>

          <UFormField label="Notas Médicas / Justificativa" name="medicalNotes">
            <UTextarea
              v-model="state.medicalNotes"
              placeholder="Descreva o motivo do encaminhamento, observações clínicas relevantes, etc."
              :rows="5"
              class="w-full"
              :class="{ 'border-red-500': hasError('medicalNotes') }"
            />
            <p
              v-if="getError('medicalNotes')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("medicalNotes") }}
            </p>
          </UFormField>

          <UButton type="submit" block class="mt-6">
            Salvar Alterações
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
