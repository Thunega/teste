<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const forwardingStore = useForwardingStore();

const open = ref(false);

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  toUserId: z.string({
    required_error: "É obrigatório selecionar um destinatário.",
    invalid_type_error: "É obrigatório selecionar um destinatário.",
  }),
  medicalNotes: z
    .string({
      required_error: "As notas médicas são obrigatórias.",
      invalid_type_error: "As notas médicas são obrigatórias.",
    })
    .min(10, "As notas médicas devem ter pelo menos 10 caracteres."),
});

type Schema = z.output<typeof schema>;

const initialState = {
  patientId: null,
  toUserId: null,
  medicalNotes: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, initialState);
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await forwardingStore.create(event.data);
    toast("Encaminhamento Criado!", {
      description: "O encaminhamento foi registrado com sucesso.",
    });
    resetForm();
    open.value = false;
    emit("created");
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Encaminhamento", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <UModal
    :dismissible="false"
    v-model:open="open"
    :overlay="false"
    title="Criar Novo Encaminhamento"
    :close="{
      color: 'primary',
      variant: 'outline',
      class: 'rounded-full',
    }"
  >
    <UButton color="primary" variant="solid">
      <UIcon name="i-heroicons-plus-circle" class="size-6" /> Novo
      Encaminhamento
    </UButton>

    <template #body>
      <UForm
        :schema="schema"
        :state="state"
        class="space-y-4"
        @submit="onSubmit"
      >
        <UFormField label="Paciente" name="patientId">
          <PatientsSelectInput
            class="w-full"
            @update:patient="state.patientId = $event"
            :class="{ 'border-red-500': hasError('patientId') }"
          />
          <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
            {{ getError("patientId") }}
          </p>
        </UFormField>

        <UFormField label="Encaminhar para" name="patientId">
          <UserSelectInput
            class="w-full"
            @update:user="state.toUserId = $event"
            :class="{ 'border-red-500': hasError('toUserId') }"
          />
          <p v-if="getError('toUserId')" class="text-red-600 text-sm mt-1">
            {{ getError("toUserId") }}
          </p>
        </UFormField>

        <UFormField label="Notas Médicas / Justificativa" name="medicalNotes">
          <UTextarea
            v-model="state.medicalNotes"
            placeholder="Descreva o motivo do encaminhamento, observações clínicas relevantes, etc."
            :rows="5"
            class="w-full"
            :class="{ 'border-red-500': hasError('medicalNotes') }"
          />
          <p v-if="getError('medicalNotes')" class="text-red-600 text-sm mt-1">
            {{ getError("medicalNotes") }}
          </p>
        </UFormField>

        <UButton type="submit" block class="mt-6">
          Salvar Encaminhamento
        </UButton>
      </UForm>
    </template>
  </UModal>
</template>
