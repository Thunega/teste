<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps<{
  appointmentId: string;
}>();

const emit = defineEmits(["updated"]);
const appointmentStore = useAppointmentStore();
const open = ref(false);
const isLoading = ref(false);

// Expõe métodos para controle externo
defineExpose({
  open: () => (open.value = true),
  close: () => (open.value = false),
});

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  scheduledAt: z
    .string({
      required_error: "A data e hora são obrigatórias.",
      invalid_type_error: "A data e hora são obrigatórias.",
    })
    .refine((val) => !isNaN(Date.parse(val)), {
      message: "Data e hora inválidas.",
    }),
  description: z
    .string()
    .min(5, "A descrição deve ter pelo menos 5 caracteres."),
});

type Schema = z.output<typeof schema>;

const initialState: Partial<Schema> = {
  patientId: undefined,
  scheduledAt: undefined,
  description: undefined,
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

watch(open, (isOpen) => {
  if (isOpen) {
    fetchData();
  }
});

async function fetchData() {
  try {
    isLoading.value = true;
    const appointmentData = await appointmentStore.getById(props.appointmentId);
    if (appointmentData) {
      // Preenche os campos com os dados existentes
      state.patientId = appointmentData.patientId;
      state.description = appointmentData.description;

      // Converte a data ISO para o formato datetime-local
      if (appointmentData.scheduledAt) {
        const date = new Date(appointmentData.scheduledAt);
        // Formato datetime-local: YYYY-MM-DDTHH:mm
        const localDateTime = new Date(
          date.getTime() - date.getTimezoneOffset() * 60000,
        )
          .toISOString()
          .slice(0, 16);
        state.scheduledAt = localDateTime;
      }
    }
  } catch (error) {
    toast.error("Erro ao carregar dados do agendamento.");
  } finally {
    isLoading.value = false;
  }
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await appointmentStore.update(props.appointmentId, {
      ...event.data,
      scheduledAt: new Date(event.data.scheduledAt).toISOString(),
    });

    toast("Agendamento Atualizado!", {
      description: "Os dados do agendamento foram atualizados com sucesso.",
    });

    emit("updated");
    open.value = false;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Atualizar Agendamento", {
      description:
        error.data?.message || "Não foi possível salvar as alterações.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="true"
      title="Editar Agendamento"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <template #body>
        <div v-if="isLoading" class="p-8 text-center">
          <p>Carregando dados do agendamento...</p>
        </div>

        <UForm
          v-else
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <div class="flex w-full gap-4">
            <UFormField label="ID do Paciente" name="patientId">
              <UInput
                type="text"
                v-model="state.patientId"
                class="w-full"
                readonly
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField label="Selecionar Novo Paciente">
              <PatientsSelectInput
                @update:patient="state.patientId = $event"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
          </div>

          <UFormField label="Data e Hora do Agendamento" name="scheduledAt">
            <UInput
              v-model="state.scheduledAt"
              type="datetime-local"
              :class="{ 'border-red-500': hasError('scheduledAt') }"
            />
            <p v-if="getError('scheduledAt')" class="text-red-600 text-sm mt-1">
              {{ getError("scheduledAt") }}
            </p>
          </UFormField>

          <UFormField label="Descrição / Motivo" name="description">
            <UTextarea
              v-model="state.description"
              :rows="4"
              placeholder="Ex: Consulta de retorno, avaliação inicial..."
              class="w-full"
              :class="{ 'border-red-500': hasError('description') }"
            />
            <p v-if="getError('description')" class="text-red-600 text-sm mt-1">
              {{ getError("description") }}
            </p>
          </UFormField>

          <UButton type="submit" block class="mt-6">
            Salvar Alterações
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
