<script setup lang="ts">
import { reactive, ref, watch } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const appointmentStore = useAppointmentStore();
const open = ref(false);

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
  }),
  scheduledAt: z
    .string({ required_error: "A data e hora são obrigatórias." })
    .refine((val) => !isNaN(Date.parse(val)), {
      message: "Data e hora inválidas.",
    }),
  description: z
    .string()
    .min(5, "A descrição deve ter pelo menos 5 caracteres."),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  patientId: "",
  scheduledAt: "",
  description: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, initialState);
  open.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  // validação local
  if (!validate()) return;

  try {
    await appointmentStore.create({
      ...event.data,
      scheduledAt: new Date(event.data.scheduledAt).toISOString(),
    });

    toast("Agendamento Criado!", {
      description: "O agendamento foi salvo com sucesso.",
    });

    emit("created");
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Agendamento", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      v-model:open="open"
      :overlay="false"
      :dismissible="false"
      title="Criar Novo Agendamento"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-plus-circle" label="Novo Agendamento" />

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <UFormField label="Paciente" name="patientId">
            <PatientsSelectInput
              @update:patient="state.patientId = $event"
              class="w-full"
              :class="{ 'border-red-500': hasError('patientId') }"
            />
            <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
              {{ getError("patientId") }}
            </p>
          </UFormField>

          <UFormField label="Data e Hora do Agendamento" name="scheduledAt">
            <UInput
              v-model="state.scheduledAt"
              type="datetime-local"
              :class="{ 'border-red-500': hasError('scheduledAt') }"
            />
            <p v-if="getError('scheduledAt')" class="text-red-600 text-sm mt-1">
              {{ getError("scheduledAt") }}
            </p>
          </UFormField>

          <UFormField label="Descrição / Motivo" name="description">
            <UTextarea
              v-model="state.description"
              :rows="4"
              placeholder="Ex: Consulta de retorno, avaliação inicial..."
              class="w-full"
              :class="{ 'border-red-500': hasError('description') }"
            />
            <p v-if="getError('description')" class="text-red-600 text-sm mt-1">
              {{ getError("description") }}
            </p>
          </UFormField>

          <UButton type="submit" block class="mt-6">
            Salvar Agendamento
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
