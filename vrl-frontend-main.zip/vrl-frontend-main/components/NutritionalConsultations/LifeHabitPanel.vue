<script setup lang="ts">
import { computed } from 'vue';

const props = defineProps<{
  consultations: any;
}>();

// --- Pega a consulta mais recente do array ---
const mostRecentConsultation = computed(() => {
  if (!props.consultations || props.consultations.length === 0) {
    return null;
  }
  return [...props.consultations].sort((a: any, b: any) => new Date(b.consultationDate).getTime() - new Date(a.consultationDate).getTime())[0];
});

// --- Define e processa a lista de hábitos a serem exibidos ---
const habits = computed(() => {
  if (!mostRecentConsultation.value) return [];

  const consult = mostRecentConsultation.value;

  return [
    {
      label: 'Pratica atividade física',
      value: consult.practicesPhysicalActivity,
    },
    {
      label: 'Duração do sono adequada',
      value: consult.sleepDurationAdequate,
    },
    {
      label: 'Dieta balanceada',
      value: consult.balancedDiet,
    },
    {
      label: 'Ingestão frequente de líquidos',
      value: consult.frequentLiquidIntake,
    },
    {
      label: 'Cozinha as próprias refeições',
      value: consult.cooksOwnMeals,
    },
    {
      label: 'Hábito sedentário',
      value: !consult.sedentaryHabits, // Invertido: o hábito positivo é NÃO ser sedentário
    },
  ];
});

// --- Componentes de Ícone (SVG inline para simplicidade) ---
const IconCheck = {
  template: `<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" /></svg>`
};

const IconX = {
  template: `<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>`
};

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <h3 class="text-lg font-semibold mb-4 text-gray-800 dark:text-gray-200">Painel de Hábitos e Estilo de Vida</h3>
    <div v-if="mostRecentConsultation" class="space-y-3">
      <div v-for="(habit, index) in habits" :key="index" class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-md">
        <span class="text-gray-700 dark:text-gray-300">{{ habit.label }}</span>
        <component :is="habit.value ? IconCheck : IconX" />
      </div>
    </div>
    <p v-else class="py-4 text-center text-gray-500">
      Sem dados de consulta para exibir o painel de hábitos.
    </p>
  </div>
</template>