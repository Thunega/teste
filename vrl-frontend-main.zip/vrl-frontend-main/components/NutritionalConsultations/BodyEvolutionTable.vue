<script setup lang="ts">
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { computed } from 'vue';

const props = defineProps<{
  consultations: any;
}>();

// --- Ordena as consultas da mais antiga para a mais recente para a ordem das colunas ---
const sortedConsultations = computed(() => {
  if (!props.consultations) return [];
  return [...props.consultations].sort((a: any, b: any) => new Date(a.consultationDate).getTime() - new Date(b.consultationDate).getTime());
});

// --- Define as métricas que serão as linhas da tabela ---
const metrics = {
  weightKg: { label: 'Peso (kg)' },
  bmi: { label: 'IMC' },
  fatPercentage: { label: '% Gordura' },
  leanMassPercentage: { label: '% Massa Magra' },
  visceralFatLevel: { label: 'Gordura Visceral' },
  metabolicAge: { label: 'Idade Metabólica' },
  restingMetabolismKcal: { label: 'Metabolismo (kcal)' },
  upperWaistCm: { label: 'Cintura Superior (cm)' },
  midlineWaistCm: { label: 'Cintura Média (cm)' },
  lowerWaistCm: { label: 'Cintura Inferior (cm)' },
  hipCm: { label: 'Quadril (cm)' },
  bustCm: { label: 'Busto (cm)' },
  gluteCm: { label: 'Glúteo (cm)' },
  neckCm: { label: 'Pescoço (cm)' },
  stomachCm: { label: 'Abdômen (cm)' },
};

// --- Funções de formatação e cálculo ---

const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'UTC' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

const formatNumber = (num: number) => {
  return num ? num.toFixed(2) : '0.00';
};

// --- Função para buscar o valor correto para cada célula ---
const getValueForMetric = (consultation: any, metricKey: string) => {
  const value = consultation[metricKey];

  if (value === null || value === undefined) return 'N/A';

  switch (metricKey) {
    case 'bmi':
      return formatNumber(value);
    case 'fatPercentage':
    case 'leanMassPercentage':
      return `${value}%`;
    case 'metabolicAge':
      return `${value} anos`;
    case 'restingMetabolismKcal':
      return `${value} kcal`;
    default:
      return value;
  }
};

</script>

<template>
  <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
    <Table v-if="sortedConsultations.length > 0">
      <TableCaption>Tabela comparativa da sua evolução corporal.</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead class="w-[150px] ">Métrica</TableHead>
          <!-- As colunas agora são as datas das consultas -->
          <TableHead v-for="consultation in sortedConsultations" :key="consultation.id" class="text-center">
            {{ formatDate(consultation.consultationDate) }}
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <!-- As linhas agora são as métricas definidas -->
        <TableRow v-for="(metric, key) in metrics" :key="key">
          <TableCell class="font-semibold text-gray-800 dark:text-gray-200">{{ metric.label }}</TableCell>
          <!-- Para cada métrica, percorre as consultas para preencher as células -->
          <TableCell v-for="consultation in sortedConsultations" :key="consultation.id" class="text-center">
            {{ getValueForMetric(consultation, key) }}
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>
    <p v-else class="py-4 text-center text-gray-500">
      Sem dados de consulta para exibir.
    </p>
  </div>
</template>