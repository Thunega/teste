<script setup lang="ts">
import { reactive, ref } from "vue";
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const emit = defineEmits(["created"]);
const nutritionalConsultationStore = useNutritionalConsultationsStore();
const open = ref(false);

const numericField = z.coerce.number().optional();
const booleanField = z.boolean().default(false);

const schema = z.object({
  patientId: z.string({
    required_error: "É obrigatório selecionar um paciente.",
    invalid_type_error: "É obrigatório selecionar um paciente.",
  }),
  consultationDate: z.string({
    required_error: "A data da consulta é obrigatória.",
    invalid_type_error: "A data da consulta é obrigatória.",
  }),
  reason: z
    .string({
      required_error: "O motivo é obrigatório.",
      invalid_type_error: "O motivo é obrigatório.",
    })
    .min(5, "O motivo deve ter pelo menos 5 caracteres."),
  mainObjective: z
    .string({
      required_error: "O objetivo principal é obrigatório.",
      invalid_type_error: "O objetivo principal é obrigatório.",
    })
    .min(5, "O objetivo deve ter pelo menos 5 caracteres."),

  // Medidas principais
  weightKg: numericField,
  heightCm: numericField,
  bmi: numericField,
  fatPercentage: numericField,
  leanMassPercentage: numericField,
  visceralFatLevel: z.coerce.number().int().optional(),
  restingMetabolismKcal: z.coerce.number().int().optional(),
  metabolicAge: z.coerce.number().int().optional(),

  // Circunferências
  neckCm: numericField,
  bustCm: numericField,
  rightArmCm: numericField,
  leftArmCm: numericField,
  upperWaistCm: numericField,
  midlineWaistCm: numericField,
  lowerWaistCm: numericField,
  stomachCm: numericField,
  hipCm: numericField,
  gluteCm: numericField,
  rightThighCm: numericField,
  leftThighCm: numericField,
  rightCalfCm: numericField,
  leftCalfCm: numericField,

  // Hábitos e preferências
  dietaryRestrictions: z.string().optional(),
  dietaryPreferences: z.string().optional(),
  mealFrequency: z.string().optional(),
  mealTimes: z.string().optional(),
  sedentaryHabits: booleanField,
  sleepDurationAdequate: booleanField,
  hasBeenOnDiet: booleanField,
  cooksOwnMeals: booleanField,
  regularBowelFunction: booleanField,
  practicesPhysicalActivity: booleanField,
  usesLicitDrugs: booleanField,
  balancedDiet: booleanField,
  frequentLiquidIntake: booleanField,
  isPregnant: booleanField,
  nutritionalGuidance: z.string().optional(),
});

type Schema = z.output<typeof schema>;

const initialState: Schema = {
  patientId: "",
  consultationDate: "",
  reason: "",
  mainObjective: "",

  // Medidas principais
  weightKg: undefined,
  heightCm: undefined,
  bmi: undefined,
  fatPercentage: undefined,
  leanMassPercentage: undefined,
  visceralFatLevel: undefined,
  restingMetabolismKcal: undefined,
  metabolicAge: undefined,

  // Circunferências
  neckCm: undefined,
  bustCm: undefined,
  rightArmCm: undefined,
  leftArmCm: undefined,
  upperWaistCm: undefined,
  midlineWaistCm: undefined,
  lowerWaistCm: undefined,
  stomachCm: undefined,
  hipCm: undefined,
  gluteCm: undefined,
  rightThighCm: undefined,
  leftThighCm: undefined,
  rightCalfCm: undefined,
  leftCalfCm: undefined,

  // Hábitos e preferências
  dietaryRestrictions: "",
  dietaryPreferences: "",
  mealFrequency: "",
  mealTimes: "",
  sedentaryHabits: false,
  sleepDurationAdequate: false,
  hasBeenOnDiet: false,
  cooksOwnMeals: false,
  regularBowelFunction: false,
  practicesPhysicalActivity: false,
  usesLicitDrugs: false,
  balancedDiet: false,
  frequentLiquidIntake: false,
  isPregnant: false,
  nutritionalGuidance: "",
};

const state = reactive({ ...initialState });

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

function resetForm() {
  Object.assign(state, initialState);
  open.value = false;
}

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await nutritionalConsultationStore.create(event.data);
    toast("Consulta Criada!", {
      description: "A consulta nutricional foi salva com sucesso.",
    });
    emit("created");
    resetForm();
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Consulta", {
      description: error.data?.message || "Não foi possível salvar os dados.",
    });
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :ui="{ content: 'lg:max-w-xl' }"
      :overlay="false"
      title="Nova Consulta"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton icon="i-lucide-plus-circle" label="Nova Consulta" />
      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-6"
          @submit="onSubmit"
        >
          <div class="flex items-start gap-4">
            <UFormField label="Paciente" name="patientId" class="flex-1">
              <PatientsSelectInput
                @update:patient="state.patientId = $event"
                :class="{ 'border-red-500': hasError('patientId') }"
              />
              <p v-if="getError('patientId')" class="text-red-600 text-sm mt-1">
                {{ getError("patientId") }}
              </p>
            </UFormField>
            <UFormField
              label="Data da Consulta"
              name="consultationDate"
              class="flex-1"
            >
              <UInput
                v-model="state.consultationDate"
                type="date"
                :class="{ 'border-red-500': hasError('consultationDate') }"
              />
              <p
                v-if="getError('consultationDate')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("consultationDate") }}
              </p>
            </UFormField>
          </div>

          <USeparator label="Objetivos" />
          <div>
            <UFormField class="mb-4" label="Motivo da Consulta" name="reason">
              <UTextarea
                class="w-full"
                rows="4"
                v-model="state.reason"
                :class="{ 'border-red-500': hasError('reason') }"
              />
              <p v-if="getError('reason')" class="text-red-600 text-sm mt-1">
                {{ getError("reason") }}
              </p>
            </UFormField>
            <UFormField label="Objetivo Principal" name="mainObjective">
              <UTextarea
                class="w-full"
                rows="4"
                v-model="state.mainObjective"
                :class="{ 'border-red-500': hasError('mainObjective') }"
              />
              <p
                v-if="getError('mainObjective')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("mainObjective") }}
              </p>
            </UFormField>
          </div>

          <USeparator label="Hábitos de Vida" />
          <div class="grid grid-cols-2 gap-x-4 gap-y-4">
            <UFormField
              label="Pratica atividade física"
              name="practicesPhysicalActivity"
            >
              <USwitch v-model="state.practicesPhysicalActivity" />
            </UFormField>
            <UFormField label="Hábitos sedentários" name="sedentaryHabits">
              <USwitch v-model="state.sedentaryHabits" />
            </UFormField>
            <UFormField label="Sono adequado" name="sleepDurationAdequate">
              <USwitch v-model="state.sleepDurationAdequate" />
            </UFormField>
            <UFormField label="Já fez dieta antes" name="hasBeenOnDiet">
              <USwitch v-model="state.hasBeenOnDiet" />
            </UFormField>
            <UFormField label="Cozinha as refeições" name="cooksOwnMeals">
              <USwitch v-model="state.cooksOwnMeals" />
            </UFormField>
            <UFormField
              label="Função intestinal regular"
              name="regularBowelFunction"
            >
              <USwitch v-model="state.regularBowelFunction" />
            </UFormField>
            <UFormField label="Usa drogas lícitas" name="usesLicitDrugs">
              <USwitch v-model="state.usesLicitDrugs" />
            </UFormField>
            <UFormField
              label="Considera a dieta balanceada"
              name="balancedDiet"
            >
              <USwitch v-model="state.balancedDiet" />
            </UFormField>
            <UFormField
              label="Ingere líquidos com frequência"
              name="frequentLiquidIntake"
            >
              <USwitch v-model="state.frequentLiquidIntake" />
            </UFormField>
            <UFormField label="É gestante" name="isPregnant">
              <USwitch v-model="state.isPregnant" />
            </UFormField>
          </div>

          <USeparator label="Medidas Principais" />
          <div class="grid grid-cols-3 gap-4 items-end">
            <UFormField label="Peso (kg)" name="weightKg">
              <UInput
                v-model.number="state.weightKg"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('weightKg') }"
              />
              <p v-if="getError('weightKg')" class="text-red-600 text-sm mt-1">
                {{ getError("weightKg") }}
              </p>
            </UFormField>
            <UFormField label="Altura (cm)" name="heightCm">
              <UInput
                v-model.number="state.heightCm"
                type="number"
                :class="{ 'border-red-500': hasError('heightCm') }"
              />
              <p v-if="getError('heightCm')" class="text-red-600 text-sm mt-1">
                {{ getError("heightCm") }}
              </p>
            </UFormField>
            <UFormField label="IMC" name="bmi">
              <UInput
                v-model.number="state.bmi"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('bmi') }"
              />
              <p v-if="getError('bmi')" class="text-red-600 text-sm mt-1">
                {{ getError("bmi") }}
              </p>
            </UFormField>
            <UFormField label="% Gordura" name="fatPercentage">
              <UInput
                v-model.number="state.fatPercentage"
                type="number"
                step="0.1"
                :class="{ 'border-red-500': hasError('fatPercentage') }"
              />
              <p
                v-if="getError('fatPercentage')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("fatPercentage") }}
              </p>
            </UFormField>
            <UFormField label="% Massa Magra" name="leanMassPercentage">
              <UInput
                v-model.number="state.leanMassPercentage"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Gordura Visceral" name="visceralFatLevel">
              <UInput v-model.number="state.visceralFatLevel" type="number" />
            </UFormField>
            <UFormField label="Metabolismo (kcal)" name="restingMetabolismKcal">
              <UInput
                v-model.number="state.restingMetabolismKcal"
                type="number"
              />
            </UFormField>
            <UFormField label="Idade Metabólica" name="metabolicAge">
              <UInput v-model.number="state.metabolicAge" type="number" />
            </UFormField>
          </div>

          <USeparator label="Circunferências (cm)" />
          <div class="grid grid-cols-3 gap-4 items-end">
            <UFormField label="Pescoço" name="neckCm">
              <UInput v-model.number="state.neckCm" type="number" step="0.1" />
            </UFormField>
            <UFormField label="Busto" name="bustCm">
              <UInput v-model.number="state.bustCm" type="number" step="0.1" />
            </UFormField>
            <UFormField label="Braço Direito" name="rightArmCm">
              <UInput
                v-model.number="state.rightArmCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Braço Esquerdo" name="leftArmCm">
              <UInput
                v-model.number="state.leftArmCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Cintura Superior" name="upperWaistCm">
              <UInput
                v-model.number="state.upperWaistCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Cintura Média" name="midlineWaistCm">
              <UInput
                v-model.number="state.midlineWaistCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Cintura Inferior" name="lowerWaistCm">
              <UInput
                v-model.number="state.lowerWaistCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Estômago" name="stomachCm">
              <UInput
                v-model.number="state.stomachCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Quadril" name="hipCm">
              <UInput v-model.number="state.hipCm" type="number" step="0.1" />
            </UFormField>
            <UFormField label="Glúteo" name="gluteCm">
              <UInput v-model.number="state.gluteCm" type="number" step="0.1" />
            </UFormField>
            <UFormField label="Coxa Direita" name="rightThighCm">
              <UInput
                v-model.number="state.rightThighCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Coxa Esquerda" name="leftThighCm">
              <UInput
                v-model.number="state.leftThighCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Panturrilha Direita" name="rightCalfCm">
              <UInput
                v-model.number="state.rightCalfCm"
                type="number"
                step="0.1"
              />
            </UFormField>
            <UFormField label="Panturrilha Esquerda" name="leftCalfCm">
              <UInput
                v-model.number="state.leftCalfCm"
                type="number"
                step="0.1"
              />
            </UFormField>
          </div>

          <USeparator label="Hábitos Alimentares" />
          <div class="flex flex-col gap-4">
            <UFormField
              label="Restrições Alimentares"
              name="dietaryRestrictions"
            >
              <UTextarea class="w-full" v-model="state.dietaryRestrictions" />
            </UFormField>
            <UFormField
              label="Preferências Alimentares"
              name="dietaryPreferences"
            >
              <UTextarea class="w-full" v-model="state.dietaryPreferences" />
            </UFormField>
            <UFormField label="Frequência de Refeições" name="mealFrequency">
              <UTextarea class="w-full" v-model="state.mealFrequency" />
            </UFormField>
            <UFormField label="Horários das Refeições" name="mealTimes">
              <UTextarea class="w-full" v-model="state.mealTimes" />
            </UFormField>
          </div>

          <USeparator label="Plano e Orientações" />
          <UFormField
            label="Orientações Nutricionais"
            name="nutritionalGuidance"
          >
            <UTextarea
              v-model="state.nutritionalGuidance"
              class="w-full"
              :rows="6"
              placeholder="Descreva as orientações e o plano alimentar para o paciente..."
              :class="{ 'border-red-500': hasError('nutritionalGuidance') }"
            />
            <p
              v-if="getError('nutritionalGuidance')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("nutritionalGuidance") }}
            </p>
          </UFormField>

          <UButton type="submit" block class="mt-8"> Salvar Consulta </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
```
