<script setup lang="ts">
import { computed } from 'vue';
import { Line } from 'vue-chartjs';
import {
  Chart as ChartJS,
  Title,
  Tooltip,
  Legend,
  LineElement,
  CategoryScale,
  LinearScale,
  PointElement,
  type ChartOptions,
  type ChartData
} from 'chart.js';

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    LineElement,
    CategoryScale,
    LinearScale,
    PointElement
);

const props = defineProps<{
  consultations: any;
}>();

// --- Ordena as consultas da mais antiga para a mais recente ---
const sortedConsultations = computed(() => {
  if (!props.consultations) return [];
  return [...props.consultations].sort((a: any, b: any) => new Date(a.consultationDate).getTime() - new Date(b.consultationDate).getTime());
});

// --- Formata a data para o eixo X ---
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { day: '2-digit', month: '2-digit', year: 'numeric', timeZone: 'UTC' };
  return new Date(dateString).toLocaleDateString('pt-BR', options);
};

// --- Prepara os dados para o gráfico de composição corporal ---
const chartData = computed<ChartData<'line'>>(() => {
  const labels = sortedConsultations.value.map((c: any) => formatDate(c.consultationDate));

  return {
    labels,
    datasets: [
      {
        label: 'Peso (kg)',
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.weightKg),
        tension: 0.2,
        yAxisID: 'y',
      },
      {
        label: 'IMC',
        borderColor: 'rgb(234, 179, 8)',
        backgroundColor: 'rgba(234, 179, 8, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.bmi),
        tension: 0.2,
        yAxisID: 'y1',
      },
      {
        label: '% Gordura',
        borderColor: 'rgb(239, 68, 68)',
        backgroundColor: 'rgba(239, 68, 68, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.fatPercentage),
        tension: 0.2,
        yAxisID: 'y1',
      },
      {
        label: '% Massa Magra',
        borderColor: 'rgb(34, 197, 94)',
        backgroundColor: 'rgba(34, 197, 94, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.leanMassPercentage),
        tension: 0.2,
        yAxisID: 'y1',
      },
    ],
  };
});

// --- Prepara os dados para o gráfico de circunferências ---
const circumferencesData = computed<ChartData<'line'>>(() => {
  const labels = sortedConsultations.value.map((c: any) => formatDate(c.consultationDate));

  return {
    labels,
    datasets: [
      {
        label: 'Cintura Média (cm)',
        borderColor: 'rgb(147, 51, 234)',
        backgroundColor: 'rgba(147, 51, 234, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.midlineWaistCm),
        tension: 0.2,
      },
      {
        label: 'Quadril (cm)',
        borderColor: 'rgb(236, 72, 153)',
        backgroundColor: 'rgba(236, 72, 153, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.hipCm),
        tension: 0.2,
      },
      {
        label: 'Abdômen (cm)',
        borderColor: 'rgb(249, 115, 22)',
        backgroundColor: 'rgba(249, 115, 22, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.stomachCm),
        tension: 0.2,
      },
      {
        label: 'Busto (cm)',
        borderColor: 'rgb(14, 165, 233)',
        backgroundColor: 'rgba(14, 165, 233, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.bustCm),
        tension: 0.2,
      },
    ],
  };
});

// --- Prepara os dados para o gráfico de metabolismo ---
const metabolismData = computed<ChartData<'line'>>(() => {
  const labels = sortedConsultations.value.map((c: any) => formatDate(c.consultationDate));

  return {
    labels,
    datasets: [
      {
        label: 'Metabolismo (kcal)',
        borderColor: 'rgb(5, 150, 105)',
        backgroundColor: 'rgba(5, 150, 105, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.restingMetabolismKcal),
        tension: 0.2,
        yAxisID: 'y',
      },
      {
        label: 'Idade Metabólica',
        borderColor: 'rgb(220, 38, 38)',
        backgroundColor: 'rgba(220, 38, 38, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.metabolicAge),
        tension: 0.2,
        yAxisID: 'y1',
      },
      {
        label: 'Gordura Visceral',
        borderColor: 'rgb(234, 88, 12)',
        backgroundColor: 'rgba(234, 88, 12, 0.2)',
        data: sortedConsultations.value.map((c: any) => c.visceralFatLevel),
        tension: 0.2,
        yAxisID: 'y1',
      },
    ],
  };
});

// --- Configurações dos gráficos ---
const chartOptions = computed<ChartOptions<'line'>>(() => ({
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    mode: 'index',
    intersect: false,
  },
  plugins: {
    title: {
      display: true,
      text: 'Evolução da Composição Corporal',
      font: { size: 18 },
      padding: { bottom: 20 }
    },
    legend: {
      position: 'top',
    },
  },
  scales: {
    y: {
      type: 'linear',
      display: true,
      position: 'left',
      title: {
        display: true,
        text: 'Peso (kg)'
      }
    },
    y1: {
      type: 'linear',
      display: true,
      position: 'right',
      title: {
        display: true,
        text: 'IMC / % Composição'
      },
      grid: {
        drawOnChartArea: false,
      },
    },
    x: {
      title: {
        display: true,
        text: 'Data da Consulta'
      }
    }
  }
}));

const circumferencesOptions = computed<ChartOptions<'line'>>(() => ({
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    mode: 'index',
    intersect: false,
  },
  plugins: {
    title: {
      display: true,
      text: 'Evolução das Circunferências',
      font: { size: 18 },
      padding: { bottom: 20 }
    },
    legend: {
      position: 'top',
    },
  },
  scales: {
    y: {
      type: 'linear',
      display: true,
      position: 'left',
      title: {
        display: true,
        text: 'Centímetros (cm)'
      }
    },
    x: {
      title: {
        display: true,
        text: 'Data da Consulta'
      }
    }
  }
}));

const metabolismOptions = computed<ChartOptions<'line'>>(() => ({
  responsive: true,
  maintainAspectRatio: false,
  interaction: {
    mode: 'index',
    intersect: false,
  },
  plugins: {
    title: {
      display: true,
      text: 'Evolução Metabólica',
      font: { size: 18 },
      padding: { bottom: 20 }
    },
    legend: {
      position: 'top',
    },
  },
  scales: {
    y: {
      type: 'linear',
      display: true,
      position: 'left',
      title: {
        display: true,
        text: 'Metabolismo (kcal)'
      }
    },
    y1: {
      type: 'linear',
      display: true,
      position: 'right',
      title: {
        display: true,
        text: 'Idade / Gordura Visceral'
      },
      grid: {
        drawOnChartArea: false,
      },
    },
    x: {
      title: {
        display: true,
        text: 'Data da Consulta'
      }
    }
  }
}));

</script>

<template>
  <div class="space-y-6">
    <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
      <div style="height: 400px">
        <Line v-if="sortedConsultations.length > 0" :data="chartData" :options="chartOptions" />
        <p v-else class="py-4 text-center text-gray-500">
          Sem dados de consulta para exibir o gráfico.
        </p>
      </div>
    </div>

    <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
      <div style="height: 400px">
        <Line v-if="sortedConsultations.length > 0" :data="circumferencesData" :options="circumferencesOptions" />
        <p v-else class="py-4 text-center text-gray-500">
          Sem dados de consulta para exibir o gráfico.
        </p>
      </div>
    </div>

    <div class="p-4 border rounded-lg bg-white dark:bg-gray-900 shadow-md">
      <div style="height: 400px">
        <Line v-if="sortedConsultations.length > 0" :data="metabolismData" :options="metabolismOptions" />
        <p v-else class="py-4 text-center text-gray-500">
          Sem dados de consulta para exibir o gráfico.
        </p>
      </div>
    </div>
  </div>
</template>
