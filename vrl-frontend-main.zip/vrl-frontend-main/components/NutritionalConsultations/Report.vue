<script setup lang="ts">

const props = defineProps<{
  patientId: string;
}>()

const nutritionalConsultationsStore = useNutritionalConsultationsStore();
const limit = ref(10);

const fetchData = async () => {
  await nutritionalConsultationsStore.fetchData(
      {
        patientId: props.patientId,
        orderBy: 'createdAt',
        sort: 'desc',
        perPage: limit.value
      }
  )
}

onMounted(fetchData);
</script>

<template>
  <main class="flex flex-wrap flex-col gap-6 mt-6">
    <NutritionalConsultationsBodyEvolutionTable :consultations="nutritionalConsultationsStore.data" />
    <NutritionalConsultationsBodyEvolutionChart :consultations="nutritionalConsultationsStore.data" />
  </main>
</template>