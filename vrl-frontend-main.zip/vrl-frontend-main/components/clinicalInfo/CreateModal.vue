<script setup lang="ts">
import * as z from "zod";
import type { FormSubmitEvent } from "@nuxt/ui";
import { toast } from "vue-sonner";
import { useZodForm } from "~/utils/useZodForm";

const props = defineProps({
  patientId: {
    type: String,
    required: true,
  },
});
const emit = defineEmits(["created"]);
const open = ref(false);

const schema = z.object({
  healthInsurance: z.string().optional(),
  weightKg: z
    .number({ invalid_type_error: "O peso deve ser um número." })
    .positive("O peso deve ser positivo.")
    .optional(),
  heightCm: z
    .number({ invalid_type_error: "A altura deve ser um número." })
    .positive("A altura deve ser positiva.")
    .optional(),
  allergies: z.string().optional(),
  comorbidities: z.string().optional(),
  medicationsInUse: z.string().optional(),
  mainTreatmentGoal: z
    .string()
    .min(5, "O objetivo deve ter pelo menos 5 caracteres.")
    .optional(),
});

type Schema = z.output<typeof schema>;

const state = reactive<Partial<Schema>>({
  healthInsurance: undefined,
  weightKg: undefined,
  heightCm: undefined,
  allergies: undefined,
  comorbidities: undefined,
  mainTreatmentGoal: undefined,
});

const { validate, getError, hasError, setErrorsFromServer, clearErrors } =
  useZodForm(schema, state);

const clinicalInfoStore = useClinicalInfoStore();

async function onSubmit(event: FormSubmitEvent<Schema>) {
  if (!validate()) return;

  try {
    await clinicalInfoStore.create(props.patientId, event.data);

    toast("Informações Clínicas Criadas!", {
      description: "Os dados clínicos foram salvos com sucesso.",
    });

    emit("created");
    open.value = false;
  } catch (error: any) {
    if (error?.data?.errors) setErrorsFromServer(error.data.errors);

    toast("Erro ao Criar Informações Clínicas", {
      description: `Não foi possível salvar os dados. Verifique e tente novamente. \n ${error.data?.message || ""}`,
    });
    console.error("Error creating clinical info:", error);
  }
}
</script>

<template>
  <div>
    <UModal
      :dismissible="false"
      v-model:open="open"
      :overlay="false"
      :ui="{ content: 'lg:max-w-xl' }"
      title="Criar Novas Informações Clínicas"
      :close="{
        color: 'primary',
        variant: 'outline',
        class: 'rounded-full',
      }"
    >
      <UButton color="primary" variant="solid">
        <UIcon name="i-heroicons-plus-circle" class="size-6" /> Criar Info.
        Clínicas
      </UButton>

      <template #body>
        <UForm
          :schema="schema"
          :state="state"
          class="space-y-4"
          @submit="onSubmit"
        >
          <div class="flex gap-4">
            <UFormField
              label="Plano de Saúde"
              name="healthInsurance"
              class="flex-1"
            >
              <UInput
                v-model="state.healthInsurance"
                placeholder="Ex: Unimed"
                :class="{ 'border-red-500': hasError('healthInsurance') }"
              />
              <p
                v-if="getError('healthInsurance')"
                class="text-red-600 text-sm mt-1"
              >
                {{ getError("healthInsurance") }}
              </p>
            </UFormField>
            <UFormField label="Peso (kg)" name="weightKg" class="flex-1">
              <UInput
                v-model.number="state.weightKg"
                type="number"
                step="0.1"
                placeholder="Ex: 75.5"
                :class="{ 'border-red-500': hasError('weightKg') }"
              />
              <p v-if="getError('weightKg')" class="text-red-600 text-sm mt-1">
                {{ getError("weightKg") }}
              </p>
            </UFormField>
            <UFormField label="Altura (cm)" name="heightCm" class="flex-1">
              <UInput
                v-model.number="state.heightCm"
                type="number"
                placeholder="Ex: 180"
                :class="{ 'border-red-500': hasError('heightCm') }"
              />
              <p v-if="getError('heightCm')" class="text-red-600 text-sm mt-1">
                {{ getError("heightCm") }}
              </p>
            </UFormField>
          </div>

          <UFormField label="Alergias" name="allergies">
            <UTextarea
              size="xl"
              variant="soft"
              class="w-full"
              v-model="state.allergies"
              placeholder="Descreva as alergias do paciente..."
            />
            <p v-if="getError('allergies')" class="text-red-600 text-sm mt-1">
              {{ getError("allergies") }}
            </p>
          </UFormField>

          <UFormField label="Comorbidades" name="comorbidities">
            <UTextarea
              size="xl"
              variant="soft"
              class="w-full"
              v-model="state.comorbidities"
              placeholder="Descreva as comorbidades existentes..."
            />
            <p
              v-if="getError('comorbidities')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("comorbidities") }}
            </p>
          </UFormField>


          <UFormField
            label="Objetivo Principal do Tratamento"
            name="mainTreatmentGoal"
          >
            <UTextarea
              size="xl"
              variant="soft"
              class="w-full"
              v-model="state.mainTreatmentGoal"
              placeholder="Qual o principal foco ou objetivo do tratamento?"
              :class="{ 'border-red-500': hasError('mainTreatmentGoal') }"
            />
            <p
              v-if="getError('mainTreatmentGoal')"
              class="text-red-600 text-sm mt-1"
            >
              {{ getError("mainTreatmentGoal") }}
            </p>
          </UFormField>

          <UButton type="submit" block class="mt-6">
            Salvar Informações Clínicas
          </UButton>
        </UForm>
      </template>
    </UModal>
  </div>
</template>
