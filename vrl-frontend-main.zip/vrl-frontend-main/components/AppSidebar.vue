<script setup lang="ts">
import { Calendar,UtensilsCrossed, LayoutDashboard, Activity, TestTubeDiagonal,ChartLine,BedDouble, Users, CircleArrowRight,Search, Settings, HeartPulse, FileUser, Brain, Timer, ShieldUser, Weight, Utensils, Mail } from "lucide-vue-next"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { Title } from "#components";

const authStore = useAuthStore()

const userRole = computed(() => authStore.role )

const educadorVR = [
  {
    title: "Registro de performace diária",
    url: "/daily-performance-logs",
    icon: ChartLine,
  },
  {
    title: "Peso Semanal",
    url: "/weekly-weights",
    icon: Weight,
  },
]

const sleepAndFood = [
  {
    title: "Registro de sono",
    url: "/sleep-logs",
    icon: BedDouble,
  },
  {
    title: "Registros Alimentares",
    url: "/daily-food-logs",
    icon: Utensils,
  },
]



const acompanhamentoMedico = [
  {
    title: "Exames",
    url: "/exams",
    icon: TestTubeDiagonal,
  },
  {
    title: "Ficha Nutricional",
    url: "/nutritional-consultations",
    icon: UtensilsCrossed,
  },
  {
    title: "Consultas Médicas",
    url: "/medical-consultations",
    icon: Search,
  },
  {
    title: "Consultas de Fisioterapia",
    url: "/physiotherapy-consultations",
    icon: FileUser,
  },
  {
    title: "Acompanhamento Psicológico",
    url: "/psychological-consultations",
    icon: Brain,
  }
]

const items = [
  {
    title: "Painel",
    url: "/",
    icon: LayoutDashboard,
  },
  {
    title: "Pacientes",
    url: "/patients",
    icon: Users,
  },
  {
    title: "Encaminhamento médico",
    url: "/forwardings",
    icon: CircleArrowRight,
  },
  {
    title: "Agendamentos",
    url: "/appointments",
    icon: Calendar,
  },
  {
    title: "Lembretes",
    url: "/reminders",
    icon: Timer,
  },
  {
    title: "Mensagens",
    url: "/messages",
    icon: Mail,
  },
  
];

const admin = [
  {
    title: 'Usuários do Sistema',
    url: '/users',
    icon: ShieldUser
  },
  {
    title: 'Sessões',
    url: '/sessions',
    icon: ShieldUser
  }
]
onMounted(authStore.checkAuth)
</script>

<template>
  <Sidebar collapsible="icon">
    <SidebarHeader>
      <SidebarMenu>
        <SidebarMenuItem>
          <SidebarMenuButton size="lg" as-child>
            <a href="#">
              <div class="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
                <HeartPulse class="size-5" />
              </div>
              <div class="grid flex-1 text-left text-sm leading-tight">
                <span class="truncate font-semibold text-xl">VR LEÃO</span>
              </div>
            </a>
          </SidebarMenuButton>
        </SidebarMenuItem>
      </SidebarMenu>
    </SidebarHeader>
    <SidebarContent>
      <SidebarGroup>
        <SidebarGroupLabel>GERENCIAMENTO</SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu>
              <SidebarMenuItem v-for="item in items" :key="item.title">
                <SidebarMenuButton asChild>
                    <NuxtLink :href="item.url">
                      <component :is="item.icon" />
                      <span>{{item.title}}</span>
                    </NuxtLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>

      <SidebarGroup>
        <SidebarGroupLabel>ACOMPANHAMENTO</SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu>
              <SidebarMenuItem v-for="item in acompanhamentoMedico" :key="item.title">
                <SidebarMenuButton asChild>
                    <NuxtLink :href="item.url">
                      <component :is="item.icon" />
                      <span>{{item.title}}</span>
                    </NuxtLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>

      <SidebarGroup v-if="['ADMIN', 'EDUCATOR_VR', 'DOCTOR'].includes(userRole)">
        <SidebarGroupLabel>EDUCADOR VR</SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu>
              <SidebarMenuItem v-for="item in educadorVR" :key="item.title">
                <SidebarMenuButton asChild>
                    <NuxtLink :href="item.url">
                      <component :is="item.icon" />
                      <span>{{item.title}}</span>
                    </NuxtLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>

      <SidebarGroup v-if="['ADMIN', 'EDUCATOR_VR', 'DOCTOR', 'DATA_COLLECTOR'].includes(userRole)">
        <SidebarGroupLabel>SONO E ALIMENTAÇÃO</SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu>
              <SidebarMenuItem v-for="item in sleepAndFood" :key="item.title">
                <SidebarMenuButton asChild>
                    <NuxtLink :href="item.url">
                      <component :is="item.icon" />
                      <span>{{item.title}}</span>
                    </NuxtLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>

      <SidebarGroup v-if="userRole=== 'ADMIN'">
        <SidebarGroupLabel>ADMINISTRAÇÃO</SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu>
              <SidebarMenuItem v-for="item in admin" :key="item.title">
                <SidebarMenuButton asChild>
                    <NuxtLink :href="item.url">
                      <component :is="item.icon" />
                      <span>{{item.title}}</span>
                    </NuxtLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>
    </SidebarContent>
    <SidebarFooter>
      <NavUser />
    </SidebarFooter>
  </Sidebar>
</template>
