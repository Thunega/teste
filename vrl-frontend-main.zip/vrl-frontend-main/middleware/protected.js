export default defineNuxtRouteMiddleware(async (to) => {
    const authStore =  useAuthStore()
    await authStore.checkAuth()

    if (!authStore.name) {
      return navigateTo('/login')
    }
  })