import { defineStore } from 'pinia';

export const useClinicalInfoStore = defineStore('clinicalInfo', {
  actions: {
    /**
     * Busca as informações clínicas de um paciente específico.
     * Corresponde a: GET /patients/{id}/clinical-info
     */
    async getByPatientId(patientId) {
      const { $api } = useNuxtApp();
       try {
        const clinicalInfo = await $api(`/patients/${patientId}/clinical-info/last`, {
          method: 'GET'
        });
        return clinicalInfo;
      } catch (error) {
        if (error.response && error.response.status === 404) {
          return null;
        }
        throw error;
      }
    },

    async create(patientId, data) {
      const { $api } = useNuxtApp();
      const newClinicalInfo = await $api(`/patients/${patientId}/clinical-info`, {
        method: 'POST',
        body: data
      });
      return newClinicalInfo;
    },

    /**
     * Atualiza as informações clínicas existentes de um paciente.
     * Corresponde a: PATCH /patients/{id}/clinical-info
     */
    async update(patientId, data) {
      const { $api } = useNuxtApp();
      const updatedClinicalInfo = await $api(`/patients/${patientId}/clinical-info`, {
        method: 'PATCH',
        body: data
      });
      return updatedClinicalInfo;
    }
  }
});

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useClinicalInfoStore, import.meta.hot))
}