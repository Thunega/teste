import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const useDailyPerformanceLogsStore = defineStore('DailyPerformanceLogs', {
    state: () => ({
        data: [],
        meta: {},
    }),

    actions: {
        setData(response) {
            this.data = response.data
            this.meta = response.meta
        },

        async fetchData(params) {
            const { $api } = nuxtApp;
            const response = await $api('/daily-performance-logs',{params:params})

            this.setData(response)
        },

        async create(data) {
            const { $api } = nuxtApp;
            const newPatient = await $api('/daily-performance-logs', {
                method: 'POST',
                body: data
            });

            return newPatient;
        },


        async update(id: string, data) {
            const { $api } = nuxtApp;
            return await $api(`/daily-performance-logs/${id}`, {
                method: 'PATCH',
                body: data
            });
        },

        async getById(id: string) {
            const { $api } = nuxtApp;
            try {
                const url = `/daily-performance-logs/${id}`;
                return await $api(url);

            } catch (error: any) {
                console.error(`Failed to fetch patient with ID ${id}:`, error);
                return null;
            }
        }
    }
})


if (import.meta.hot) {
    import.meta.hot.accept(acceptHMRUpdate(useDailyPerformanceLogsStore, import.meta.hot))
}