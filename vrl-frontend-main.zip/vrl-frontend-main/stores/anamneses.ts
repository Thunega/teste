import { defineStore } from 'pinia';

export const useAnamnesisStore = defineStore('anamnesis', {
  actions: {
    async getByPatientId(patientId) {
      const { $api } = useNuxtApp();
      try {
        const anamnesis = await $api(`/patients/${patientId}/anamneses`, {
          method: 'GET'
        });
        return anamnesis;
      } catch (error) {
        if (error.response && error.response.status === 404) {
          return null; 
        }
        throw error;
      }
    },

    async create(patientId, data) {
      const { $api } = useNuxtApp();
      const newAnamnesis = await $api(`/patients/${patientId}/anamneses`, {
        method: 'POST',
        body: data
      });
      return newAnamnesis;
    },

    async update(patientId, data) {
      const { $api } = useNuxtApp();
      const updatedAnamnesis = await $api(`/patients/${patientId}/anamneses`, {
        method: 'PATCH',
        body: data
      });
      return updatedAnamnesis;
    }
  }
});

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useAnamnesisStore, import.meta.hot))
}