import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const useExamStore = defineStore('Exam', {
  state: () => ({
    data: [],
    meta: {},
  }),

  actions: {
    setData(response) {
        this.data = response.data
        this.meta = response.meta
    },

    async fetchData(params) {
        const { $api } = nuxtApp;
        const response = await $api('/exams',{params:params})

        this.setData(response)
    },

    async create(data) {
        const { $api } = nuxtApp;
        const newPatient = await $api('/exams', {
            method: 'POST',
            body: data
        });

        return newPatient;
    },


    async update(id: string, data) {
        const { $api } = nuxtApp;
        return await $api(`/exams/${id}`, {
            method: 'PATCH',
            body: data
        });
    },

      async delete(id: string) {
          const { $api } = nuxtApp;
          return await $api(`/exams/${id}`, {
              method: 'DELETE'
          });
      },

    async getById(id: string) {
        const { $api } = nuxtApp;
        try {
            const url = `/exams/${id}`;
            return await $api(url);

        } catch (error: any) {
            console.error(`Failed to fetch patient with ID ${id}:`, error);
            return null;
        }
    }
  }
})


if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useExamStore, import.meta.hot))
}