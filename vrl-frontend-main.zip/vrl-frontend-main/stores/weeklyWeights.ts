import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const useWeeklyWeightsStore = defineStore('WeeklyWeights', {
  state: () => ({
    data: [],
    meta: {},
    loading: false,
  }),

  actions: {
    setData(response) {
        this.data = response.data
        this.meta = response.meta
    },

    setLoading(loading: boolean) {
        this.loading = loading
    },

    async fetchData(params) {
        this.setLoading(true)
        try {
            const { $api } = nuxtApp;
            const response = await $api('/weekly-weight', {params: params})
            this.setData(response)
        } finally {
            this.setLoading(false)
        }
    },

    async create(data) {
        const { $api } = nuxtApp;
        const newWeeklyWeight = await $api('/weekly-weight', {
            method: 'POST',
            body: data
        });

        return newWeeklyWeight;
    },

    async update(id: string, data) {
        const { $api } = nuxtApp;
        return await $api(`/weekly-weight/${id}`, {
            method: 'PATCH',
            body: data
        });
    },

    async delete(id: string) {
        const { $api } = nuxtApp;
        return await $api(`/weekly-weight/${id}`, {
            method: 'DELETE'
        });
    },

    async getById(id: string) {
        const { $api } = nuxtApp;
        try {
            const url = `/weekly-weight/${id}`;
            return await $api(url);

        } catch (error: any) {
            console.error(`Failed to fetch weekly weight with ID ${id}:`, error);
            return null;
        }
    }
  }
})

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useWeeklyWeightsStore, import.meta.hot))
}
