import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const useMedicalConsultationsStore = defineStore('MedicalConsultations', {
  state: () => ({
    data: [],
    meta: {},
  }),

  actions: {
    setData(response) {
        this.data = response.data
        this.meta = response.meta
    },

    async fetchData(params) {
        const { $api } = nuxtApp;
        const response = await $api('/medical-consultations',{params:params})

        this.setData(response)
    },

    async create(data) {
        const { $api } = nuxtApp;
        const newPatient = await $api('/medical-consultations', {
            method: 'POST',
            body: data
        });

        return newPatient;
    },


    async updatePatient(id: string, data) {
        const { $api } = nuxtApp;
        return await $api(`/medical-consultations/${id}`, {
            method: 'PATCH',
            body: data
        });
    },

    async getById(id: string) {
        const { $api } = nuxtApp;
        try {
            const url = `/medical-consultations/${id}`;
            return await $api(url);

        } catch (error: any) {
            console.error(`Failed to fetch patient with ID ${id}:`, error);
            return null;
        }
    }
  }
})


if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useMedicalConsultationsStore, import.meta.hot))
}