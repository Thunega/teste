import { defineStore } from 'pinia';
import { toast } from 'vue-sonner';

const nuxtApp = useNuxtApp();

export const useFitbitStore = defineStore('fitbit', {
  state: () => ({
    authInfo: null as any,
    isLoading: false,
    error: null as any,
  }),

  actions: {
    async fetchAuthInfo(patientId: string) {
      const { $api } = nuxtApp;
      this.isLoading = true;
      this.error = null;
      try {
        this.authInfo = await $api(`/fitbit/auth-info/${patientId}`);
      } catch (error) {
        this.error = error;
        this.authInfo = null; // Reset on error
      }
      this.isLoading = false;
    },

    async syncSleepLogs(patientId: string, params: any) {
      const { $api } = nuxtApp;
      try {
        const response = await $api(`/fitbit/sync-sleep-logs/${patientId}`, {params: params});
        toast.success(response.message || 'Sincronização concluída!', {
          description: 'Os registros de sono do Fitbit foram importados.',
        });
      } catch (error: any) {
        console.error('Failed to sync sleep logs:', error);
        toast.error('Falha na Sincronização', {
          description: error.data?.message || 'Não foi possível sincronizar os registros de sono.',
        });
      }
    },

    async deleteAuth(patientId: string) {
      const { $api } = nuxtApp;
      try {
        await $api(`/fitbit/auth-info/${patientId}`, { method: 'DELETE' });
        this.authInfo = null;
        toast.success('Acesso Revogado', {
          description: 'A autorização do Fitbit foi removida com sucesso.',
        });
      } catch (error: any) {
        console.error('Failed to delete Fitbit auth:', error);
        toast.error('Falha ao Revogar', {
          description: error.data?.message || 'Não foi possível remover a autorização do Fitbit.',
        });
      }
    },

    async generateAuthLink(patientId: string) {
      const { $api } = nuxtApp;
      try {
        const response = await $api(`/fitbit/auth/${patientId}`);
        return response.url; // The API returns an object with a 'url' property
      } catch (error: any) {
        console.error('Failed to generate auth link:', error);
        toast.error('Falha ao Gerar Link', {
          description: error.data?.message || 'Não foi possível gerar o link de autorização.',
        });
        return null;
      }
    },
  },
});
