import {defineStore} from 'pinia';

const nuxtApp = useNuxtApp();

export const useAppointmentStore = defineStore('appointments', {
    state: () => ({
        data: [],
        meta: {},
    }),

    actions: {
        setData(response) {
            this.data = response.data
            this.meta = response.meta
        },

        async fetchData(params) {
            const {$api} = nuxtApp;
            const response = await $api('/appointments', {params: params})

            this.setData(response)
        },

        async create(data) {
            const {$api} = nuxtApp;
            const newPatient = await $api('/appointments', {
                method: 'POST',
                body: data
            });

            return newPatient;
        },


        async update(id: string, data) {
            const {$api} = nuxtApp;
            return await $api(`/appointments/${id}`, {
                method: 'PATCH',
                body: data
            });
        },

        async delete(id: string) {
            const {$api} = nuxtApp;
            return await $api(`/appointments/${id}`, {
                method: 'DELETE'
            });
        },

        async getById(id: string) {
            const {$api} = nuxtApp;
            try {
                const url = `/appointments/${id}`;
                return await $api(url);

            } catch (error: any) {
                console.error(`Failed to fetch appointment with ID ${id}:`, error);
                return null;
            }
        }
    }
})


if (import.meta.hot) {
    import.meta.hot.accept(acceptHMRUpdate(useAppointmentStore, import.meta.hot))
}