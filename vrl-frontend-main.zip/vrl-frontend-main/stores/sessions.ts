import {defineStore} from 'pinia'
import type {User} from '~/stores/users'

const nuxtApp = useNuxtApp();

export interface Session {
    id: string
    userId: string
    ip: string
    userAgent: string
    expiresAt: string
    createdAt: string
    revokedAt: string | null
    user?: User
}

interface State {
    sessions: Session[]
    meta: any
    loading: boolean
    error: any
}

export const useSessionStore = defineStore('sessions', {
    state: (): State => ({
        sessions: [],
        meta: {},
        loading: false,
        error: null,
    }),
    actions: {
        async fetchSessions(params) {
            this.loading = true
            this.error = null
            try {
                const {$api} = nuxtApp;
                const response = await $api('/sessions', {params})
                this.sessions = response.data
                this.meta = response.meta
            } catch (error) {
                this.error = error
            } finally {
                this.loading = false
            }
        },
        async revokeSession(id: string) {
            this.loading = true
            this.error = null
            try {
                const {$api} = nuxtApp;
                await $api(`/sessions/${id}/revoke`, {method: 'POST'})
                await this.fetchSessions()
            } catch (error) {
                this.error = error
            } finally {
                this.loading = false
            }
        },
    },
})
