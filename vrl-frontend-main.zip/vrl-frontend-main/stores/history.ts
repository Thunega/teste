import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const useHistoryStore = defineStore('History', {
    state: () => ({
        data: [],
        meta: {},
    }),

    actions: {
        setData(response) {
            this.data = response.data
            this.meta = response.meta
        },

        async fetchData(id, params) {
            const { $api } = nuxtApp;
            const response = await $api(`/patients/${id}/history`,{params:params})

            this.setData(response)
        }
    }
})


if (import.meta.hot) {
    import.meta.hot.accept(acceptHMRUpdate(useHistoryStore, import.meta.hot))
}