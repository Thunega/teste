import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const useUsersStore = defineStore('Users', {
    state: () => ({
        data: [],
        meta: {},
    }),

    actions: {
        setData(response) {
            this.data = response.data
            this.meta = response.meta
        },

        async fetchData(params) {
            const { $api } = nuxtApp;
            const response = await $api('/users',{params:params})

            this.setData(response)
        },

        async create(data) {
            const { $api } = nuxtApp;
            const newPatient = await $api('/users', {
                method: 'POST',
                body: data
            });

            return newPatient;
        },


        async update(id: string, data) {
            const { $api } = nuxtApp;
            return await $api(`/users/${id}`, {
                method: 'PATCH',
                body: data
            });
        },

        async getById(id: string) {
            const { $api } = nuxtApp;
            try {
                const url = `/users/${id}`;
                return await $api(url);

            } catch (error: any) {
                console.error(`Failed to fetch patient with ID ${id}:`, error);
                return null;
            }
        },

        async delete(id: string) {
            const { $api } = nuxtApp;
            try {
                const url = `/users/${id}`;
                return await $api(url, { method: 'DELETE' });

            } catch (error: any) {
                console.error(`Failed to fetch patient with ID ${id}:`, error);
                return null;
            }
        }
    }
})


if (import.meta.hot) {
    import.meta.hot.accept(acceptHMRUpdate(useUsersStore, import.meta.hot))
}