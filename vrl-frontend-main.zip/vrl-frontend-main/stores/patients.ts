import {defineStore} from 'pinia';

const nuxtApp = useNuxtApp();

export const usePatientStore = defineStore('patient', {
    state: () => ({
        data: [],
        meta: {},
    }),

    actions: {
        setData(response) {
            this.data = response.data
            this.meta = response.meta
        },

        async fetchData(params) {
            const {$api} = nuxtApp;
            const response = await $api('/patients', {params: params})

            this.setData(response)
        },

        async createPatient(data) {
            const {$api} = nuxtApp;
            const newPatient = await $api('/patients/with-related', {
                method: 'POST',
                body: data
            });

            return newPatient;
        },


        async updatePatient(id: string, data) {
            const {$api} = nuxtApp;
            return await $api(`/patients/${id}`, {
                method: 'PATCH',
                body: data
            });
        },

        async getById(id: string) {
            const {$api} = nuxtApp;
            try {
                const url = `/patients/${id}`;
                return await $api(url);

            } catch (error: any) {
                console.error(`Failed to fetch patient with ID ${id}:`, error);
                return null;
            }
        },
        async getReport(id: string) {
            const {$api} = nuxtApp;
            try {
                const url = `/patients/${id}/report`;
                return await $api(url);

            } catch (error: any) {
                console.error(`Failed to fetch report with ID ${id}:`, error);
                return null;
            }
        },

        async delete(id: string) {
            const {$api} = nuxtApp;
            try {
                const url = `/patients/${id}`;
                return await $api(url, {method: 'DELETE'});

            } catch (error: any) {
                console.error(`Failed to fetch patient with ID ${id}:`, error);
                return null;
            }
        }
    }
})


if (import.meta.hot) {
    import.meta.hot.accept(acceptHMRUpdate(usePatientStore, import.meta.hot))
}