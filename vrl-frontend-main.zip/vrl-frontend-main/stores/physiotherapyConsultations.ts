import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const usePhysiotherapyConsultationsStore = defineStore('PhysiotherapyConsultations', {
    state: () => ({
        data: [],
        meta: {},
    }),

    actions: {
        setData(response) {
            this.data = response.data
            this.meta = response.meta
        },

        async fetchData(params) {
            const { $api } = nuxtApp;
            const response = await $api('/physiotherapy-consultations',{params:params})

            this.setData(response)
        },

        async create(data) {
            const { $api } = nuxtApp;
            const newPatient = await $api('/physiotherapy-consultations', {
                method: 'POST',
                body: data
            });

            return newPatient;
        },


        async updatePatient(id: string, data) {
            const { $api } = nuxtApp;
            return await $api(`/physiotherapy-consultations/${id}`, {
                method: 'PATCH',
                body: data
            });
        },

        async getById(id: string) {
            const { $api } = nuxtApp;
            try {
                const url = `/physiotherapy-consultations/${id}`;
                return await $api(url);

            } catch (error: any) {
                console.error(`Failed to fetch patient with ID ${id}:`, error);
                return null;
            }
        }
    }
})


if (import.meta.hot) {
    import.meta.hot.accept(acceptHMRUpdate(usePhysiotherapyConsultationsStore, import.meta.hot))
}