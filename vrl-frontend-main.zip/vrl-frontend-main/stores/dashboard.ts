import { defineStore } from 'pinia';
const nuxtApp = useNuxtApp();

export const useDashboardStore = defineStore('dashboard', {
  state: () => ({
    patients: [],
    appointments: [],
    patientsWithConsecutiveAbsences: [],
    activePatientsCount: 0,
    nextAppointmentsCount: 0,
    consultationsCount: 0,
    dailyAppointmentsCount: 0,
  }),

  actions: {
    setDashboardData(data) {
      if (data?.recentPatients.length > 0) {
        this.patients = data.recentPatients.map(({ id, name, updatedAt }) => ({
          id,
          name,
          updatedAt
        }))
      }
      if (data?.patientsWithConsecutiveAbsences?.length > 0) {
        this.patientsWithConsecutiveAbsences =
          data.patientsWithConsecutiveAbsences.map(
            ({ id, name, consecutiveAbsences }) => ({
              id,
              name,
              consecutiveAbsences
            })
          )
      }

      if (data?.previewDailyAppointments.length > 0) {
        this.appointments = data.previewDailyAppointments
      }

      this.activePatientsCount = data.activePatientsCount
      this.nextAppointmentsCount = data.nextAppointmentsCount
      this.consultationsCount = data.consultationsCount
      this.dailyAppointmentsCount = data.dailyAppointmentsCount
    },

    async fetchData() {
      const { $api } = nuxtApp;

      const data = await $api('/dashboard/display-data')

      this.setDashboardData(data)
    }
  },
});

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useDashboardStore, import.meta.hot))
}