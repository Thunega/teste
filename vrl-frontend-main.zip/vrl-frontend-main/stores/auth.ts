// ~/stores/auth.ts
import { defineStore } from 'pinia'
import {jwtDecode } from "jwt-decode";
import { useRuntimeConfig } from "#app";

interface SigInResponse {
  accessToken: string;
  refreshToken: string;
}

interface AuthState {
  name: string | null,
  email: string | null,
  token: string | null
  role: string | null
  isAuthenticated: boolean
  loading: boolean
}




export const useAuthStore = defineStore('auth', {
  state: (): AuthState => ({
    name: null,
    email: null,
    token: null,
    role: null,
    isAuthenticated: false,
    loading: true
  }),

  actions: {
    setUser(name: string, email: string, role: string) {
      this.name = name
      this.email = email
      this.role = role
      this.isAuthenticated = true
    },

    setToken(token: string) {
      this.token = token
      localStorage.setItem('token', token)
    },

    clearAuth() {
      this.name = null
      this.email =  null
      this.role = null
      this.token = null
      this.isAuthenticated = false
      localStorage.removeItem('token')
    },

    async login(email: string, password: string) {
      const apiBaseUrl = useRuntimeConfig().public.apiBaseUrl;
      try {
        const response = await $fetch<SigInResponse>(`${apiBaseUrl}/auth/sign-in`, {
          method: 'POST',
          body: { email, password }
        })

        const payload = jwtDecode<any>(response.accessToken)
        this.setToken(response.accessToken)
        this.setUser(payload.name, payload.email, payload.role)

        return true
      } catch (error) {
        console.error('Login error:', error)
        return false
      }
    },

    async logout() {
      try {
        const token = localStorage.getItem('token')
        if (!token) return
      } finally {
        this.clearAuth()
        await navigateTo('/login')
      }
    },

    async checkAuth() {
      const apiBaseUrl = useRuntimeConfig().public.apiBaseUrl;
      try {
        const token = localStorage.getItem('token')
        if (!token) return false
        const response = await $fetch(`${apiBaseUrl}/auth/me`, {
          headers: {
            Authorization: `Bearer ${token}`
          }
        })

        this.setToken(token)
        this.setUser(response.name, response.email, response.role)

        return true
      } catch {
        this.clearAuth();
        return false;
      } finally {
        this.loading = false;
      }
    }
  }
})

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useAuthStore, import.meta.hot))
}