import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const useDailyFoodLogsStore = defineStore('DailyFoodLogs', {
  state: () => ({
    data: [],
    meta: {},
    loading: false,
  }),

  actions: {
    setData(response) {
        this.data = response.data
        this.meta = response.meta
    },

    setLoading(loading: boolean) {
        this.loading = loading
    },

    async fetchData(params) {
        this.setLoading(true)
        try {
            const { $api } = nuxtApp;
            const response = await $api('/daily-food-logs', {params: params})
            this.setData(response)
        } finally {
            this.setLoading(false)
        }
    },

    async create(data) {
        const { $api } = nuxtApp;
        const newDailyFoodLog = await $api('/daily-food-logs', {
            method: 'POST',
            body: data
        });

        return newDailyFoodLog;
    },

    async update(id: string, data) {
        const { $api } = nuxtApp;
        return await $api(`/daily-food-logs/${id}`, {
            method: 'PATCH',
            body: data
        });
    },

    async delete(id: string) {
        const { $api } = nuxtApp;
        return await $api(`/daily-food-logs/${id}`, {
            method: 'DELETE'
        });
    },

    async getById(id: string) {
        const { $api } = nuxtApp;
        try {
            const url = `/daily-food-logs/${id}`;
            return await $api(url);

        } catch (error: any) {
            console.error(`Failed to fetch daily food log with ID ${id}:`, error);
            return null;
        }
    }
  }
})

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useDailyFoodLogsStore, import.meta.hot))
}