import { defineStore } from 'pinia';

const nuxtApp = useNuxtApp();

export const useNutritionalConsultationsStore = defineStore('NutritionalConsultations', {
  state: () => ({
    data: [],
    meta: {},
  }),

  actions: {
    setData(response) {
        this.data = response.data
        this.meta = response.meta
    },

    async fetchData(params) {
        const { $api } = nuxtApp;
        const response = await $api('/nutritional-consultations',{params:params})

        this.setData(response)
    },

    async create(data) {
        const { $api } = nuxtApp;
        const newConsultation = await $api('/nutritional-consultations', {
            method: 'POST',
            body: data
        });

        return newConsultation;
    },


    async update(id: string, data) {
        const { $api } = nuxtApp;
        return await $api(`/nutritional-consultations/${id}`, {
            method: 'PATCH',
            body: data
        });
    },

    async getById(id: string) {
        const { $api } = nuxtApp;
        try {
            const url = `/nutritional-consultations/${id}`;
            return await $api(url);

        } catch (error: any) {
            console.error(`Failed to fetch consultation with ID ${id}:`, error);
            return null;
        }
    },

    async delete(id: string) {
        const { $api } = nuxtApp;
        try {
            const url = `/nutritional-consultations/${id}`;
            return await $api(url, {method: 'DELETE'});

        } catch (error: any) {
            console.error(`Failed to delete consultation with ID ${id}:`, error);
            return null;
        }
    }
  }
})


if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useNutritionalConsultationsStore, import.meta.hot))
}