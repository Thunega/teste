<script setup lang="ts">
import { SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { Code2 } from "lucide-vue-next"

const auth = useAuthStore()
const isDev = process.env.NODE_ENV !== "production"
onBeforeMount(auth.checkAuth)
onMounted(auth.checkAuth)
</script>

<template>
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        <header class="flex justify-between h-16 shrink-0 items-center gap-2 border-b px-4">
          <div class="flex items-center gap-3">
            <SidebarTrigger />
            <span
              v-if="isDev"
              class="rounded-md border border-amber-500/60 bg-amber-100 px-2 py-1 text-xs font-semibold uppercase tracking-wide text-amber-700 dark:border-amber-400/60 dark:bg-amber-500/20 dark:text-amber-300 flex gap-1 items-center"
            >
              <Code2 class="w-4" /> AMBIENTE DE DESENVOLVIMENTO
            </span>
          </div>
          <DarkModeToggle />
        </header>  
        <section class="p-6">
          <slot/>
        </section>
      </SidebarInset>
    </SidebarProvider>
</template>
