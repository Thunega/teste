<template>
    <header class="border-b border-slate-300 flex flex-row dark:border-slate-700 p-4 justify-between">
        <h1 class="text-2xl font-bold flex items-center gap-2">
            <div class="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
                <HeartPulse class="size-6"/>
            </div>
            
            VR LEÃO
        </h1>
        <div>
            <DarkModeToggle/>
        </div>
    </header>
    <div>
        <slot />
    </div>
</template>

<script setup lang="ts">
import { HeartPulse } from 'lucide-vue-next'
</script>