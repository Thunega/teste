<script setup lang="ts">
useHead({
  title: "Política de Privacidade | VRLeao",
});

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Política de Privacidade",
    icon: "i-lucide-shield-check",
    to: "/privacy-policy",
  },
]);

definePageMeta({
  layout: "login",
});
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />

    <div class="max-w-4xl mx-auto">
      <div class="mb-8">
        <h1 class="text-3xl font-bold mb-2">Política de Privacidade</h1>
        <p class="text-gray-500">
          Última atualização: {{ new Date().toLocaleDateString("pt-BR") }}
        </p>
      </div>

      <Card class="prose prose-sm dark:prose-invert max-w-none">
        <div class="space-y-6">
          <section>
            <h2 class="text-xl font-semibold mb-3">1. Introdução</h2>
            <p class="text-gray-700 dark:text-gray-300">
              O VR LEÃO é uma plataforma de gerenciamento médico desenvolvida
              para coletar, armazenar e processar dados de saúde de pacientes
              atendidos pelo
              <strong>Fundo Municipal de Saúde - FMS</strong> (CNPJ
              20.826.697/0001-61), localizado em Vargem Grande do Rio Pardo.
              Esta Política de Privacidade descreve como coletamos, usamos,
              armazenamos e protegemos suas informações pessoais e de saúde.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">2. Dados Coletados</h2>
            <p class="text-gray-700 dark:text-gray-300 mb-2">
              Nossa aplicação coleta e processa os seguintes tipos de dados:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>
                <strong>Dados Pessoais:</strong> Nome, data de nascimento, CPF,
                endereço, telefone e e-mail
              </li>
              <li>
                <strong>Dados de Saúde:</strong> Histórico médico, resultados de
                exames laboratoriais, diagnósticos, prescrições médicas e
                acompanhamentos clínicos
              </li>
              <li>
                <strong>Registros Médicos:</strong> Consultas médicas,
                nutricionais, fisioterapêuticas e psicológicas
              </li>
              <li>
                <strong>Dados de Dispositivos:</strong> Informações
                sincronizadas de smartwatches e dispositivos vestíveis,
                incluindo frequência cardíaca, padrões de sono, níveis de
                atividade física e outros parâmetros de saúde
              </li>
              <li>
                <strong>Registros Diários:</strong> Logs de alimentação,
                desempenho diário, peso semanal e padrões de sono
              </li>
              <li>
                <strong>Imagens Médicas:</strong> Fotos de exames, refeições e
                outros registros visuais relacionados à saúde
              </li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">3. Uso dos Dados</h2>
            <p class="text-gray-700 dark:text-gray-300 mb-2">
              Os dados coletados são utilizados exclusivamente para:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>
                Prestação de serviços médicos e acompanhamento da saúde dos
                pacientes
              </li>
              <li>
                Elaboração de diagnósticos, tratamentos e planos terapêuticos
              </li>
              <li>Monitoramento contínuo da evolução clínica dos pacientes</li>
              <li>
                Sincronização e análise de dados de saúde provenientes de
                dispositivos vestíveis
              </li>
              <li>Geração de relatórios médicos e históricos de saúde</li>
              <li>
                Comunicação entre profissionais de saúde envolvidos no
                tratamento
              </li>
              <li>
                Cumprimento de obrigações legais e regulatórias da área da saúde
              </li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">4. Controlador de Dados</h2>
            <p class="text-gray-700 dark:text-gray-300">
              O controlador dos dados pessoais coletados e tratados pela
              plataforma VR LEÃO é o
              <strong>Fundo Municipal de Saúde - FMS</strong>, inscrito no CNPJ
              sob o nº 20.826.697/0001-61, com sede em Vargem Grande do Rio
              Pardo.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              5. Compartilhamento de Dados
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Seus dados de saúde são tratados com máxima confidencialidade.
              Compartilhamos informações apenas:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>
                Com profissionais de saúde autorizados envolvidos no seu
                tratamento, incluindo especialistas e profissionais externos
                quando necessário para a continuidade do cuidado
              </li>
              <li>Quando exigido por lei ou ordem judicial</li>
              <li>
                Com seu consentimento expresso para finalidades específicas
              </li>
              <li>
                Em situações de emergência médica, quando necessário para
                proteção da vida
              </li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              6. Segurança e Armazenamento
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Implementamos medidas técnicas e organizacionais rigorosas para
              proteger seus dados:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>Criptografia de dados em trânsito e em repouso</li>
              <li>
                Controle de acesso baseado em funções (RBAC) para profissionais
                autorizados
              </li>
              <li>Autenticação segura com tokens JWT</li>
              <li>
                Monitoramento contínuo de segurança e auditoria de acessos
              </li>
              <li>
                Backup regular de dados para prevenir perda de informações
              </li>
              <li>
                Armazenamento em servidores seguros com proteção contra acessos
                não autorizados
              </li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">6. Dados de Smartwatches</h2>
            <p class="text-gray-700 dark:text-gray-300">
              Nossa aplicação sincroniza dados de saúde de smartwatches para
              proporcionar um acompanhamento mais completo da sua saúde. Estes
              dados incluem:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>Frequência cardíaca e variabilidade cardíaca</li>
              <li>Padrões e qualidade do sono</li>
              <li>Níveis de atividade física e passos</li>
              <li>Calorias queimadas e distância percorrida</li>
              <li>Saturação de oxigênio (SpO2)</li>
              <li>Outros parâmetros de saúde monitorados pelo dispositivo</li>
            </ul>
            <p class="text-gray-700 dark:text-gray-300 mt-3">
              A sincronização destes dados é opcional e pode ser desativada a
              qualquer momento. Os dados sincronizados são tratados com o mesmo
              nível de segurança e confidencialidade que os demais dados de
              saúde.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">7. Seus Direitos</h2>
            <p class="text-gray-700 dark:text-gray-300 mb-2">
              De acordo com a Lei Geral de Proteção de Dados (LGPD), você tem
              direito a:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>Acessar seus dados pessoais e de saúde armazenados</li>
              <li>
                Solicitar correção de dados incompletos, inexatos ou
                desatualizados
              </li>
              <li>
                Solicitar a anonimização, bloqueio ou eliminação de dados
                desnecessários
              </li>
              <li>Solicitar a portabilidade dos seus dados de saúde</li>
              <li>
                Revogar o consentimento para tratamento de dados (quando
                aplicável)
              </li>
              <li>
                Ser informado sobre as entidades com as quais seus dados foram
                compartilhados
              </li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">8. Retenção de Dados</h2>
            <p class="text-gray-700 dark:text-gray-300">
              Os dados de saúde são armazenados conforme exigido pela legislação
              brasileira, incluindo o Código de Ética Médica e resoluções do
              Conselho Federal de Medicina (CFM). Prontuários médicos e
              registros clínicos são mantidos por no mínimo 20 anos, conforme
              determinado pela Resolução CFM nº 1.821/2007.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">9. Menores de Idade</h2>
            <p class="text-gray-700 dark:text-gray-300">
              O tratamento de dados de saúde de menores de idade requer o
              consentimento de pelo menos um dos pais ou responsável legal. Os
              dados de menores são tratados com proteção adicional conforme a
              LGPD.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              10. Alterações na Política
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Esta Política de Privacidade pode ser atualizada periodicamente
              para refletir mudanças em nossas práticas ou na legislação
              aplicável. Notificaremos sobre alterações significativas através
              da plataforma.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">11. Contato</h2>
            <p class="text-gray-700 dark:text-gray-300">
              Para exercer seus direitos, esclarecer dúvidas ou apresentar
              reclamações sobre o tratamento de seus dados pessoais, entre em
              contato com nosso suporte:
            </p>
            <div class="mt-3 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <p class="text-gray-700 dark:text-gray-300">
                <strong>E-mail:</strong> vrleao@vrleao.com<br />
              </p>
            </div>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">12. Legislação Aplicável</h2>
            <p class="text-gray-700 dark:text-gray-300">
              Esta Política de Privacidade é regida pela legislação brasileira,
              especialmente:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>
                Lei Geral de Proteção de Dados (LGPD - Lei nº 13.709/2018)
              </li>
              <li>Código de Ética Médica</li>
              <li>Resoluções do Conselho Federal de Medicina</li>
              <li>
                Constituição Federal (direito à privacidade e sigilo médico)
              </li>
            </ul>
          </section>
        </div>
      </Card>
    </div>
  </section>
</template>
