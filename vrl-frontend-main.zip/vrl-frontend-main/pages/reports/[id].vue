<script setup lang="ts">
useHead({
  title: "Detalhes do Relatório | VRLeao",
});

import { useRoute } from "#vue-router";
import { ref } from "vue";
import type { TabsItem } from "@nuxt/ui";
import { DailyFoodLogsReport } from "#components";

const route = useRoute();
const examStore = useExamStore();

const fetchData = async () => {
  const patientId = route.params.id as string;

  await examStore.fetchData({
    patientId: patientId,
    orderBy: "createdAt",
    sort: "desc",
  });
};

watch([], fetchData, { immediate: true });
onMounted(fetchData);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Pacientes",
    icon: "i-lucide-users",
    to: "/patients",
  },
  {
    label: "Relatório",
    icon: "i-lucide-bar-chart",
    to: `/reports/${route.params.id}`,
  },
]);

const tabItems: TabsItem[] = [
  {
    label: "Exames",
    icon: "i-lucide-test-tube-diagonal",
    slot: "exams",
  },
  {
    label: "Dados Antropométricos",
    icon: "i-lucide-utensils-crossed",
    slot: "nutritional",
  },
  {
    label: "Peso Semanal",
    icon: "i-lucide-weight",
    slot: "weight",
  },
  {
    label: "Relatório de performance diária",
    icon: "i-lucide-chart-line",
    slot: "performance",
  },
  {
    label: "Relatório de sono",
    icon: "i-lucide-bed-double",
    slot: "sleep",
  },
  {
    label: "Relatório alimentar",
    icon: "i-lucide-apple",
    slot: "food"
  }
];
</script>
<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">
          Relatório médico de {{ examStore.data[0]?.patient.name }}
        </h1>
      </div>
    </div>
    <UTabs :items="tabItems" class="w-full">
      <template #exams>
        <ExamReport :patientId="route.params.id as string" />
      </template>

      <template #nutritional>
        <NutritionalConsultationsReport
          :patient-id="route.params.id as string"
        />
      </template>

      <template #weight>
        <WeeklyWeightsReport :patient-id="route.params.id as string" />
      </template>

      <template #performance>
        <DailyPerformanceLogsReport :patientId="route.params.id as string" />
      </template>

      <template #sleep>
        <SleepLogsReport :patientId="route.params.id as string" />
      </template>

      <template #food>
        <DailyFoodLogsReport :patientId="route.params.id as string" />
      </template>
    </UTabs>
  </section>
</template>
