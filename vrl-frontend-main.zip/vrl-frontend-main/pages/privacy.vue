<script setup lang="ts">
useHead({
  title: "Privacidade | VRLeao",
});

definePageMeta({
  layout: "login",
});
</script>
<template>
  <div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold mb-4">Privacy Policy</h1>

    <p class="mb-4">
      This privacy policy has been compiled to better serve those who are
      concerned with how their 'Personally Identifiable Information' (PII) is
      being used online. PII, as described in US privacy law and information
      security, is information that can be used on its own or with other
      information to identify, contact, or locate a single person, or to
      identify an individual in context. Please read our privacy policy
      carefully to get a clear understanding of how we collect, use, protect or
      otherwise handle your Personally Identifiable Information in accordance
      with our website.
    </p>

    <h2 class="text-xl font-bold mb-2">
      What personal information do we collect from the people that visit our
      blog, website or app?
    </h2>
    <p class="mb-4">
      When ordering or registering on our site, as appropriate, you may be asked
      to enter your name, email address or other details to help you with your
      experience.
    </p>

    <h2 class="text-xl font-bold mb-2">When do we collect information?</h2>
    <p class="mb-4">
      We collect information from you when you register on our site, subscribe
      to a newsletter, fill out a form or enter information on our site.
    </p>

    <h2 class="text-xl font-bold mb-2">How do we use your information?</h2>
    <p class="mb-4">
      We may use the information we collect from you when you register, make a
      purchase, sign up for our newsletter, respond to a survey or marketing
      communication, surf the website, or use certain other site features in the
      following ways:
    </p>
    <ul class="list-disc list-inside mb-4">
      <li>
        To personalize your experience and to allow us to deliver the type of
        content and product offerings in which you are most interested.
      </li>
      <li>To improve our website in order to better serve you.</li>
      <li>
        To allow us to better service you in responding to your customer service
        requests.
      </li>
      <li>To administer a contest, promotion, survey or other site feature.</li>
      <li>To quickly process your transactions.</li>
      <li>To ask for ratings and reviews of services or products</li>
      <li>
        To follow up with them after correspondence (live chat, email or phone
        inquiries)
      </li>
    </ul>

    <h2 class="text-xl font-bold mb-2">How do we protect your information?</h2>
    <p class="mb-4">
      Our website is scanned on a regular basis for security holes and known
      vulnerabilities in order to make your visit to our site as safe as
      possible.
    </p>
    <p class="mb-4">We use regular Malware Scanning.</p>
    <p class="mb-4">
      Your personal information is contained behind secured networks and is only
      accessible by a limited number of persons who have special access rights
      to such systems, and are required to keep the information confidential. In
      addition, all sensitive/credit information you supply is encrypted via
      Secure Socket Layer (SSL) technology.
    </p>
    <p class="mb-4">
      We implement a variety of security measures when a user enters, submits,
      or accesses their information to maintain the safety of your personal
      information.
    </p>
    <p class="mb-4">
      All transactions are processed through a gateway provider and are not
      stored or processed on our servers.
    </p>

    <h2 class="text-xl font-bold mb-2">Third-party disclosure</h2>
    <p class="mb-4">
      We do not sell, trade, or otherwise transfer to outside parties your
      Personally Identifiable Information unless we provide users with advance
      notice. This does not include website hosting partners and other parties
      who assist us in operating our website, conducting our business, or
      serving our users, so long as those parties agree to keep this information
      confidential. We may also release information when it's release is
      appropriate to comply with the law, enforce our site policies, or protect
      ours or others' rights, property or safety.
    </p>
    <p class="mb-4">
      However, non-personally identifiable visitor information may be provided
      to other parties for marketing, advertising, or other uses.
    </p>

    <h2 class="text-xl font-bold mb-2">Contacting Us</h2>
    <p class="mb-4">
      If there are any questions regarding this privacy policy, you may contact
      us using the information below.
    </p>
    <p>
      [Your Website]<br />
      [Your Address]<br />
      [Your Email]
    </p>
  </div>
</template>

<script setup></script>

<style scoped></style>
