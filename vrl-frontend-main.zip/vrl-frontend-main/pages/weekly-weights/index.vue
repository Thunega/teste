<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";
import type { SelectItem } from "@nuxt/ui";

useHead({
  title: "Pesos Semanais | VRLeao",
});

const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const weeklyWeightsStore = useWeeklyWeightsStore();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const selectedPatientId = ref();
const editModalRef = ref(null);
const deleteButtonRef = ref(null);
const selectedWeeklyWeight = ref(null);
const orderBy = ref("weekStartDate");
const orderDirection = ref("asc");

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/weekly-weights/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  {
    header: "Início da Semana",
    accessorKey: "weekStartDate",
    cell: ({ row }) =>
      new Date(row.original.weekStartDate).toLocaleDateString("pt-BR", {
        timeZone: "UTC",
      }),
  },
  {
    header: "Peso (kg)",
    accessorKey: "weightKg",
    cell: ({ row }) => `${row.original.weightKg} kg`,
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          { content: { align: "end" }, items: getRowItems(row) },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

function getRowItems(row: Row<any>) {
  return [
    {
      label: "Ver detalhes",
      icon: "i-lucide-eye",
      onSelect: () => navigateTo(`/weekly-weights/${row.original.id}`),
    },
    {
      label: "Ver relatório do paciente",
      icon: "i-lucide-line-chart",
      onSelect: () => navigateTo(`/reports/${row.original.patientId}`),
    },
    {
      type: "separator",
    },
    {
      label: "Editar",
      icon: "i-lucide-pencil",
      onSelect: () => {
        selectedWeeklyWeight.value = row.original;
        editModalRef.value.open();
      },
    },
    {
      label: "Excluir",
      icon: "i-lucide-trash-2",
      class: "text-red-600",
      onSelect: () => {
        selectedWeeklyWeight.value = row.original;
        deleteButtonRef.value.open();
      },
    },
  ];
}

const fetchData = () => {
  weeklyWeightsStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
    orderBy: orderBy.value,
    sort: orderDirection.value,
  });
};

watch(selectedPatientId, () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  }
  fetchData();
});

watch(
  [orderBy, orderDirection],
  () => {
    if (pagination.value.pageIndex !== 0) {
      pagination.value.pageIndex = 0;
    }
    fetchData();
  },
  { immediate: true },
);

watch(() => pagination.value.pageIndex, fetchData);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Peso Semanal",
    icon: "i-lucide-weight",
    to: "/weekly-weights",
  },
]);

const orderByItems = ref<SelectItem[]>([
  {
    label: "Data do Registro",
    id: "weekStartDate",
  },
  {
    label: "Peso",
    id: "weightKg",
  },
]);

const sortItems = ref<SelectItem[]>([
  {
    label: "Crescente",
    id: "asc",
  },
  {
    label: "Decrescente",
    id: "desc",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Peso Semanal</h1>
        <p class="text-gray-500">
          Filtre e gerencie os registros de peso semanal dos pacientes.
        </p>
      </div>
      <WeeklyWeightsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex items-center gap-2 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Filtrar por Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>

      <UFormField label="Ordenar por">
        <USelect v-model="orderBy" value-key="id" :items="orderByItems" />
      </UFormField>

      <UFormField label="Ordem">
        <USelect v-model="orderDirection" value-key="id" :items="sortItems" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="weeklyWeightsStore.data"
        :columns="columns"
        :loading="weeklyWeightsStore.loading"
        class="flex-1"
      />

      <WeeklyWeightsEditModal
        v-if="selectedWeeklyWeight"
        ref="editModalRef"
        :weekly-weight="selectedWeeklyWeight"
        @updated="fetchData()"
      />

      <WeeklyWeightsDeleteButton
        v-if="selectedWeeklyWeight"
        ref="deleteButtonRef"
        :id="selectedWeeklyWeight.id"
        @deleted="fetchData()"
      />

      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            weeklyWeightsStore.meta &&
            weeklyWeightsStore.meta.total > weeklyWeightsStore.meta.perPage
          "
          :total="weeklyWeightsStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
