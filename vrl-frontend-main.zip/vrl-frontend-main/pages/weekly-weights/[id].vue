<script setup lang="ts">
import { ref, onMounted } from "vue";


useHead({
  title: "Detalhes do Peso Semanal | VRLeao",
});

const route = useRoute();
const weeklyWeightsStore = useWeeklyWeightsStore();

const weeklyWeight = ref(null);
const loading = ref(true);

onMounted(async () => {
  try {
    weeklyWeight.value = await weeklyWeightsStore.getById(
      route.params.id as string,
    );
    console.log(weeklyWeight.value);
  } finally {
    loading.value = false;
  }
});

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Peso Semanal",
    icon: "i-lucide-weight",
    to: "/weekly-weights",
  },
  {
    label: "Detalhes",
    icon: "i-lucide-eye",
    to: `/weekly-weights/${route.params.id}`,
  },
]);

const router = useRouter();

const handleDeleted = () => {
  router.push("/weekly-weights");
};
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />

    <div v-if="loading" class="text-center py-8">
      <div
        class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"
      ></div>
      <p class="mt-4 text-gray-600">Carregando registro de peso...</p>
    </div>

    <div v-else-if="!weeklyWeight" class="text-center py-8">
      <p class="text-red-600">Registro de peso não encontrado.</p>
    </div>

    <div v-else class="space-y-6">
      <!-- Header -->
      <div class="flex justify-between items-start">
        <div>
          <h1 class="text-2xl font-bold">Registro de Peso Semanal</h1>
          <p class="text-gray-500">
            Semana de
            {{
              new Date(weeklyWeight.weekStartDate).toLocaleDateString("pt-BR", {
                timeZone: "UTC",
              })
            }}
          </p>
        </div>
        <div class="flex gap-2">
          <WeeklyWeightsEditModal
            :weekly-weight="weeklyWeight"
            @updated="weeklyWeight = $event"
          />
          <WeeklyWeightsDeleteButton
            :id="weeklyWeight.id"
            @deleted="handleDeleted"
          />
        </div>
      </div>

      <!-- Info básica -->
      <Card>
        <div class="space-y-6">
          <div>
            <h3 class="font-medium text-gray-900 dark:text-gray-100 mb-4 px-10">
              Informações do Registro
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-1 gap-6">
              <div class="space-y-2 text-sm px-10">
                <div class="flex justify-between">
                  <span class="text-gray-600">Paciente:</span>
                  <span class="font-medium">{{
                    weeklyWeight.patient?.name || "N/A"
                  }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Início da Semana:</span>
                  <span>{{
                    new Date(weeklyWeight.weekStartDate).toLocaleDateString(
                      "pt-BR",
                      { timeZone: "UTC" },
                    )
                  }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Peso:</span>
                  <span class="font-semibold text-lg"
                    >{{ weeklyWeight.weightKg }} kg</span
                  >
                </div>
              </div>
            </div>
          </div>

          <div v-if="weeklyWeight.observations" class="border-t pt-6 px-10">
            <h3 class="font-medium text-gray-900 dark:text-gray-100 mb-2">
              Observações
            </h3>
            <p class="text-sm text-gray-600">{{ weeklyWeight.observations }}</p>
          </div>
        </div>
      </Card>
    </div>
  </section>
</template>
