<script setup lang="ts">
useHead({
  title: "Autenticação Fitbit | VRLeao",
});

definePageMeta({
  layout: "login",
  middleware: ["protected"],
});
</script>

<template>
  <div class="flex flex-col items-center justify-center scc p-6">
    <UCard variant="subtle">
      <template #header>
        <h1>Parabéns!</h1>
      </template>
      <div class="flex items-center">
        <Icon
          name="i-lucide-circle-check"
          class="size-36 text-emerald-500 mx-auto"
        />
        <!-- <Icon name="i-lucide-arrow-left-right" class="size-36 text-blue-500 mx-auto"  /> -->
      </div>
      <template #footer>
        <p>Seu Fitbit foi sincronizado com sucesso ao nosso sistema.</p>
      </template>
    </UCard>
  </div>
</template>

<style>
.scc {
  min-height: calc(100svh - 69px);
}
</style>
