<script setup lang="ts">
import { getPaginationRowModel } from "@tanstack/vue-table";
import { computed, h, ref, resolveComponent, watch } from "vue";
import type { Row } from "@tanstack/vue-table";

useHead({
  title: "Agendamentos | VRLeao",
});

const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");

const toast = useToast();
const router = useRouter();
const editModal = ref();

const pagination = ref({
  pageIndex: 0,
  pageSize: 10,
});

const appointmentStore = useAppointmentStore();
const selectedPatientId = ref();
const selectedAppointmentId = ref();
const deleteModal = ref();
const startDate = ref(new Date().toISOString().split("T")[0]);
const endDate = ref();

const fetchData = async () => {
  await appointmentStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
    startDate: startDate.value,
    endDate: endDate.value,
  });
};

onMounted(fetchData);

const columns = [
  {
    accessorKey: "responsibleUser.email",
    header: "Responsável",
    cell: ({ row }) => row.original.responsibleUser?.email || "N/A",
  },
  {
    accessorKey: "patient.name",
    header: "Paciente",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/appointments/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient?.name || "N/A",
      ),
  },
  {
    accessorKey: "patient.cpf",
    header: "CPF do Paciente",
    cell: ({ row }) => row.original.patient?.cpf || "N/A",
  },
  {
    accessorKey: "scheduledAt",
    header: "Data",
    cell: ({ row }) =>
      new Date(row.original.scheduledAt).toLocaleString("pt-BR", {
        dateStyle: "short",
        timeStyle: "short",
      }),
  },
  {
    accessorKey: "description",
    header: "Descrição",
    cell: ({ row }) =>
      (row.original.description?.substring(0, 30) || "") +
      (row.original.description?.length > 30 ? "..." : ""),
  },
  {
    id: "actions",
    cell: ({ row }) => {
      return h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          {
            content: { align: "end" },
            items: getRowItems(row),
            "aria-label": "Menu de Ações",
          },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
              "aria-label": "Abrir menu",
            }),
        ),
      );
    },
  },
];

function getRowItems(row: Row<any>) {
  return [
    {
      type: "label",
      label: "Ações",
    },
    {
      label: "Ver Detalhes",
      icon: "i-lucide-eye",
      onSelect: () => router.push(`/appointments/${row.original.id}`),
    },
    {
      type: "separator",
    },
    {
      label: "Editar Agendamento",
      icon: "i-lucide-pencil",
      onSelect: () => {
        selectedAppointmentId.value = row.original.id;
        editModal.value.open();
      },
    },
    {
      label: "Deletar Agendamento",
      icon: "i-lucide-x-circle",
      onSelect: () => {
        selectedAppointmentId.value = row.original.id;
        deleteModal.value.open();
      },
    },
  ];
}

watch([startDate, endDate, selectedPatientId], () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});
const currentPage = computed(() => pagination.value.pageIndex + 1);

watch(() => pagination.value.pageIndex, fetchData, { immediate: true });

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Agendamentos",
    icon: "i-lucide-calendar",
    to: "/appointments",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Agendamentos</h1>
        <p class="text-gray-500">Filtre e gerencie os agendamentos.</p>
      </div>
      <AppointmentsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex flex-wrap items-end gap-8 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>

      <UFormField label="Data Inicial">
        <UInput v-model="startDate" type="date" />
      </UFormField>

      <UFormField label="Data Final">
        <UInput v-model="endDate" type="date" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="appointmentStore.data"
        class="flex-1"
        :loading="appointmentStore.loading"
        :columns="columns"
      />
      <AppointmentsEditModal
        ref="editModal"
        :appointment-id="selectedAppointmentId"
        @updated="fetchData"
      />

      <DeleteModal
        ref="deleteModal"
        :id="selectedAppointmentId"
        :store="appointmentStore"
        @deleted="fetchData"
      />
      <div class="flex justify-center border-t border-default pt-4">
        <UPagination
          v-if="
            appointmentStore.meta &&
            appointmentStore.meta.total > appointmentStore.meta.perPage
          "
          :total="appointmentStore.meta.total"
          :page-count="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
