<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";

useHead({
  title: "Detalhes do Agendamento | VRLeao",
});

const route = useRoute();
const appointmentStore = useAppointmentStore();
const patientStore = usePatientStore();

const appointment = ref<any>(null);
const patient = ref<any>(null);
const isLoading = ref(true);
const error = ref<string | null>(null);

async function fetchData() {
  const appointmentId = route.params.id as string;
  if (!appointmentId) {
    error.value = "ID do agendamento não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const appointmentData = await appointmentStore.getById(appointmentId);

    if (appointmentData) {
      appointment.value = appointmentData;
      const patientData = await patientStore.getById(appointmentData.patientId);
      patient.value = patientData;
    } else {
      error.value = "Agendamento não encontrado.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados.";
  } finally {
    isLoading.value = false;
  }
}

onMounted(fetchData);

async function handleUpdate() {
  await fetchData();
}

const formatDateTime = (isoString: string) => {
  if (!isoString) return "N/A";
  const date = new Date(isoString);
  return date.toLocaleString("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
    timeZone: "America/Sao_Paulo",
  });
};

const fakeInputContainerClass =
  "block w-full rounded-md border-0 bg-gray-100 dark:bg-gray-800/50 px-3 py-2 shadow-sm ring-1 ring-inset ring-gray-200 dark:ring-gray-700";
const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Agendamentos",
    icon: "i-lucide-calendar",
    to: "/appointments",
  },
]);
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados do agendamento...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="appointment && patient">
      <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Agendamento de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Criado em:
            {{ new Date(appointment.createdAt).toLocaleDateString("pt-BR") }}
          </p>
        </div>
        <AppointmentsEditModal
          @updated="handleUpdate"
          :appointment="appointment"
        />
      </div>

      <UCard>
        <template #header>
          <h3 class="text-lg font-semibold">Detalhes do Agendamento</h3>
        </template>
        <div class="space-y-4">
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Paciente</label
              >
              <p class="text-sm font-semibold">{{ patient.name }}</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Data e Hora Agendada</label
              >
              <p class="text-sm font-semibold">
                {{ formatDateTime(appointment.scheduledAt) }}
              </p>
            </div>
          </div>
          <div :class="[fakeInputContainerClass, 'min-h-[120px]']">
            <label class="block text-xs font-medium text-gray-500"
              >Descrição / Motivo</label
            >
            <p class="text-sm font-semibold whitespace-pre-wrap">
              {{ appointment.description || "Nenhuma descrição fornecida." }}
            </p>
          </div>
        </div>
      </UCard>
    </div>
  </section>
</template>
