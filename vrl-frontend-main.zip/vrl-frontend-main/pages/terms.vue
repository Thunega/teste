<script setup lang="ts">
useHead({
  title: "Termos de Serviço | VRLeao",
});

definePageMeta({
  layout: "login",
});
</script>
<template>
  <div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold mb-4">Terms of Service</h1>

    <p class="mb-4">
      Welcome to our website. If you continue to browse and use this website,
      you are agreeing to comply with and be bound by the following terms and
      conditions of use, which together with our privacy policy govern our
      relationship with you in relation to this website. If you disagree with
      any part of these terms and conditions, please do not use our website.
    </p>

    <h2 class="text-xl font-bold mb-2">
      1. The use of this website is subject to the following terms of use:
    </h2>
    <ul class="list-disc list-inside mb-4">
      <li>
        The content of the pages of this website is for your general information
        and use only. It is subject to change without notice.
      </li>
      <li>
        This website uses cookies to monitor browsing preferences. If you do
        allow cookies to be used, the following personal information may be
        stored by us for use by third parties: [list of information].
      </li>
      <li>
        Neither we nor any third parties provide any warranty or guarantee as to
        the accuracy, timeliness, performance, completeness or suitability of
        the information and materials found or offered on this website for any
        particular purpose. You acknowledge that such information and materials
        may contain inaccuracies or errors and we expressly exclude liability
        for any such inaccuracies or errors to the fullest extent permitted by
        law.
      </li>
      <li>
        Your use of any information or materials on this website is entirely at
        your own risk, for which we shall not be liable. It shall be your own
        responsibility to ensure that any products, services or information
        available through this website meet your specific requirements.
      </li>
      <li>
        This website contains material which is owned by or licensed to us. This
        material includes, but is not limited to, the design, layout, look,
        appearance and graphics. Reproduction is prohibited other than in
        accordance with the copyright notice, which forms part of these terms
        and conditions.
      </li>
      <li>
        All trademarks reproduced in this website, which are not the property
        of, or licensed to the operator, are acknowledged on the website.
      </li>
      <li>
        Unauthorised use of this website may give rise to a claim for damages
        and/or be a criminal offence.
      </li>
      <li>
        From time to time, this website may also include links to other
        websites. These links are provided for your convenience to provide
        further information. They do not signify that we endorse the website(s).
        We have no responsibility for the content of the linked website(s).
      </li>
      <li>
        Your use of this website and any dispute arising out of such use of the
        website is subject to the laws of [your country].
      </li>
    </ul>

    <h2 class="text-xl font-bold mb-2">2. Disclaimer</h2>
    <p class="mb-4">
      The information contained in this website is for general information
      purposes only. The information is provided by us and while we endeavour to
      keep the information up to date and correct, we make no representations or
      warranties of any kind, express or implied, about the completeness,
      accuracy, reliability, suitability or availability with respect to the
      website or the information, products, services, or related graphics
      contained on the website for any purpose. Any reliance you place on such
      information is therefore strictly at your own risk.
    </p>
    <p>
      In no event will we be liable for any loss or damage including without
      limitation, indirect or consequential loss or damage, or any loss or
      damage whatsoever arising from loss of data or profits arising out of, or
      in connection with, the use of this website.
    </p>
  </div>
</template>

<script setup></script>

<style scoped></style>
