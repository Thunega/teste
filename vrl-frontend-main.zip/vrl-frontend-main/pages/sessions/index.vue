<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";
import { watchDebounced } from "@vueuse/core";

useHead({
  title: "Sessões | VRLeao",
});

const UBadge = resolveComponent("UBadge");
const sessionStore = useSessionStore();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const searchQuery = ref("");

const columns = [
  { header: "Usuário", accessorKey: "user.name" },
  { header: "User Agent", accessorKey: "userAgent" },
  {
    header: "Expira em",
    accessorKey: "expiresAt",
    cell: ({ row }) => new Date(row.original.expiresAt).toLocaleString(),
  },
  {
    header: "Criado em",
    accessorKey: "createdAt",
    cell: ({ row }) => new Date(row.original.createdAt).toLocaleString(),
  },
  {
    header: "Revogado em",
    accessorKey: "revokedAt",
    cell: ({ row }) =>
      row.original.revokedAt
        ? new Date(row.original.revokedAt).toLocaleString()
        : "-",
  },
  {
    id: "actions",
    header: "Ações",
    cell: ({ row }) =>
      h("div", { class: "flex gap-4" }, [
        h(resolveComponent("UButton"), {
          color: "red",
          variant: "ghost",
          icon: "i-heroicons-power",
          onClick: () => sessionStore.revokeSession(row.original.id),
        }),
      ]),
  },
];

const fetchData = () => {
  sessionStore.fetchSessions({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    query: searchQuery.value || undefined,
  });
};

watchDebounced(
  searchQuery,
  () => {
    if (pagination.value.pageIndex !== 0) {
      pagination.value.pageIndex = 0;
    } else {
      fetchData();
    }
  },
  { debounce: 300 },
);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

watch([currentPage, searchQuery], fetchData, { immediate: true });

const breadcrumbItems = ref([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Sessões",
    icon: "i-lucide-shield-user",
    to: "/sessions",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Sessões</h1>
        <p class="text-gray-500">Gerencie as sessões ativas no sistema.</p>
      </div>
    </div>
    <Card>
      <UTable
        :data="sessionStore.sessions"
        :columns="columns"
        :loading="sessionStore.loading"
        class="flex-1"
      />
      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            sessionStore.meta &&
            sessionStore.meta.total > sessionStore.meta.perPage
          "
          :total="sessionStore.meta.total"
          :page-count="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
