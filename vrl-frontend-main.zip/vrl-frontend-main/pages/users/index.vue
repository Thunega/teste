<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";
import { watchDebounced } from "@vueuse/core";

useHead({
  title: "Usuários | VRLeao",
});

const UserEditModal = resolveComponent("UserEditModal");
const DeleteButton = resolveComponent("DeleteButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const UBadge = resolveComponent("UBadge");
const userStore = useUsersStore();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const searchQuery = ref("");
const role = ref();

const getRoleBadge = (role: string) => {
  switch (role) {
    case "ADMIN":
      return { color: "info", text: "Admin", icon: "i-lucide-shield-user" };
    case "DOCTOR":
      return { color: "info", text: "Médico", icon: "i-lucide-stethoscope" };
    case "PHYSIOTHERAPIST":
      return {
        color: "info",
        text: "Fisioterapeuta",
        icon: "i-lucide-square-activity",
      };
    case "PSYCHOLOGIST":
      return { color: "info", text: "Psicólogo", icon: "i-lucide-brain" };
    case "NUTRITIONIST":
      return {
        color: "info",
        text: "Nutricionista",
        icon: "i-lucide-utensils-crossed",
      };
    case "EDUCATOR_VR":
      return {
        color: "info",
        text: "Educador VR",
        icon: "i-lucide-clipboard-plus",
      };
    case "DATA_COLLECTOR":
      return {
        color: "info",
        text: "Coletor de Dados",
        icon: "i-lucide-database",
      };
    default:
      return { color: "gray", text: role };
  }
};

const columns = [
  { header: "Nome", accessorKey: "name" },
  { header: "Email", accessorKey: "email" },
  {
    header: "Função",
    accessorKey: "role",
    cell: ({ row }) => {
      const badge = getRoleBadge(row.original.role);
      return h(
        UBadge,
        { color: badge.color, variant: "subtle", icon: badge.icon, size: "lg" },
        () => badge.text,
      );
    },
  },
  {
    id: "actions",
    header: "Ações",
    cell: ({ row }) =>
      h("div", { class: "flex gap-4" }, [
        h(UserEditModal, {
          userId: row.original.id,
          onUpdatedUser() {
            fetchData();
          },
        }),
        h(DeleteButton, {
          id: row.original.id,
          store: userStore,
          onDeleted() {
            fetchData();
          },
        }),
      ]),
  },
];

const fetchData = () => {
  userStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    query: searchQuery.value || undefined,
    role: role.value,
  });
};

watchDebounced(
  searchQuery,
  () => {
    if (pagination.value.pageIndex !== 0) {
      pagination.value.pageIndex = 0;
    } else {
      fetchData();
    }
  },
  { debounce: 300 },
);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

watch([currentPage, searchQuery, role], fetchData, { immediate: true });

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Usuários do Sistema",
    icon: "i-lucide-shield-user",
    to: "/users",
  },
]);

const roleOptions = [
  { value: "ADMIN", label: "Admin" },
  { value: "DOCTOR", label: "Médico" },
  { value: "PHYSIOTHERAPIST", label: "Fisioterapeuta" },
  { value: "PSYCHOLOGIST", label: "Psicólogo" },
  { value: "NUTRITIONIST", label: "Nutricionista" },
  { value: "EDUCATOR_VR", label: "Educador VR" },
  { value: "DATA_COLLECTOR", label: "Coletor de Dados" },
];
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Usuários do Sistema</h1>
        <p class="text-gray-500">Gerencie os usuários e suas permissões.</p>
      </div>
      <UserCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex items-center gap-6 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Filtrar por usuário">
        <UInput
          v-model="searchQuery"
          icon="i-lucide-search"
          placeholder="Buscar por nome ..."
        />
      </UFormField>

      <UFormField label="Filtrar por cargo">
        <USelect
          v-model="role"
          :items="roleOptions"
          option-attribute="label"
          value-attribute="value"
          placeholder="Selecione um cargo"
        />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="userStore.data"
        :columns="columns"
        :loading="userStore.loading"
        class="flex-1"
      />
      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="userStore.meta && userStore.meta.total > userStore.meta.perPage"
          :total="userStore.meta.total"
          :page-count="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
