<script setup lang="ts">
useHead({
  title: "Reminders | VRLeao",
});

const breadcrumbItems = [
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Reminders",
    icon: "i-lucide-timer",
    to: "#",
  },
];
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />

    <Card
      class="flex flex-col items-center justify-center text-center py-20 px-6"
    >
      <div
        class="w-20 h-20 flex items-center justify-center rounded-full bg-primary-100 dark:bg-primary-900/30 mb-6"
      >
        <UIcon
          name="i-lucide-construction"
          class="w-10 h-10 text-primary-500"
        />
      </div>

      <h1 class="text-3xl font-bold mb-3">
        Estamos trabalhando nisso 🚧
      </h1>

      <p class="text-gray-500 max-w-md mb-6">
        Essa funcionalidade ainda está em desenvolvimento.
        Em breve ela estará disponível para você!
      </p>

      <UButton
        icon="i-lucide-arrow-left"
        color="primary"
        variant="soft"
        @click="$router.back()"
      >
        Voltar
      </UButton>
    </Card>
  </section>
</template>