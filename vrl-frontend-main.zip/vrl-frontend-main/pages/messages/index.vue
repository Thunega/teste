﻿<script setup lang="ts">
import InboxPage from "~/modules/messages/pages/InboxPage.vue"
</script>

<template>
  <InboxPage />
</template>
