<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";

useHead({
  title: "Detalhes do Paciente | VRLeao",
});

import HistoryTable from "~/components/patients/HistoryTable.vue";
import FitbitPanel from "~/components/patients/FitbitPanel.vue";
import Medications from "~/components/patients/Medications.vue";

// --- Composables ---
const route = useRoute();
const router = useRouter();

// --- State ---
const patient = ref<any>(null);
const anamnesis = ref<any>(null);
const clinicalInfo = ref<any>(null);

const isLoading = ref(true);
const error = ref<string | null>(null);

// --- Tab Configuration ---
const tabItems = [
  {
    slot: "details",
    label: "Detalhes",
  },
  {
    slot: "history",
    label: "Histórico",
  },
  {
    slot: "medications",
    label: "Medicamentos",
  },
  {
    slot: "anamneses",
    label: "Anamnese",
  },
  {
    slot: "clinical-info",
    label: "Informações Clínicas",
  },
  {
    slot: "fitbit",
    label: "Fitbit",
  },
];

// Assuming stores are set up for each entity
const patientStore = usePatientStore();
const anamnesisStore = useAnamnesisStore();
const clinicalInfoStore = useClinicalInfoStore();
const breadcrumbItems = ref<BreadcrumbItem[]>();

async function fetchData() {
  const patientId = route.params.id as string;
  if (!patientId) {
    error.value = "ID do paciente não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const [patientData, anamnesisData, clinicalInfoData] = await Promise.all([
      patientStore.getById(patientId),
      anamnesisStore.getByPatientId(patientId).catch((e) => null),
      clinicalInfoStore.getByPatientId(patientId).catch((e) => null),
    ]);

    if (patientData) {
      patient.value = patientData;
      anamnesis.value = anamnesisData;
      clinicalInfo.value = clinicalInfoData;

      breadcrumbItems.value = [
        {
          label: "Painel",
          icon: "i-lucide-layout-dashboard",
          to: "/",
        },
        {
          label: "Pacientes",
          icon: "i-lucide-users",
          to: "/patients",
        },
        {
          label: `${patient.value.name}`,
          icon: "i-lucide-user",
          to: `/patients/${patient.value.id}`,
        },
      ];
    } else {
      error.value = "Paciente não encontrado.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados.";
  } finally {
    isLoading.value = false;
  }
}

const authStore = useAuthStore();
onMounted(fetchData);

const gender = computed(() => {
  switch (patient.value.gender?.toLowerCase()) {
    case "male":
      return "Masculino";
    case "female":
      return "Feminino";
    case "other":
      return "Outro";
    default:
      return "N/A";
  }
});

function formatDateTime(dateString: string) {
  if (!dateString) return "N/A";
  return new Date(dateString).toISOString().split("T")[0];
  // return new Date(dateString).toLocaleString('pt-BR');
}

async function handleUpdate() {
  await fetchData();
}

const medicationsRefreshKey = ref(0);
function handleMedicationCreated() {
  // A pagina nao busca medicamentos diretamente; o componente faz o fetch internamente.
  // Incrementar a key forca o remount e garante que a lista reflita o novo medicamento.
  medicationsRefreshKey.value += 1;
}
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados do paciente...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900 border border-red-300 dark:border-red-700 rounded-lg"
    >
      <p class="text-red-700 dark:text-red-200 font-semibold">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="patient">
      <UBreadcrumb class="mb-8" :items="breadcrumbItems" />
      <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
          {{ patient.name }}
        </h1>
        <div class="flex gap-4">
          <DeleteButton
            v-if="authStore.role == 'ADMIN'"
            :id="patient.id"
            :store="patientStore"
            @deleted="fetchData"
          />
          <UButton
            :to="`/reports/${patient.id}`"
            icon="i-lucide-chart-bar"
            color="primary"
            >Ver Relatório</UButton
          >
        </div>
      </div>

      <UTabs :items="tabItems" class="w-full">
        <template #details="{ item }">
          <UCard class="mt-4">
            <template #header>
              <div class="flex justify-between items-center">
                <h3 class="text-lg font-semibold">{{ item.label }}</h3>

                <PatientsEditModal
                  @patient-updated="handleUpdate"
                  :patient-id="patient.id"
                />
              </div>
            </template>
            <dl
              class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4"
            >
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  CPF
                </dt>
                <dd class="text-gray-900 dark:text-white">{{ patient.cpf }}</dd>
              </div>
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Data de Nascimento
                </dt>
                <dd class="text-gray-900 dark:text-white">
                  {{ formatDateTime(patient.dateOfBirth) }}
                </dd>
              </div>
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Gênero
                </dt>
                <dd class="text-gray-900 dark:text-white capitalize">
                  {{ gender }}
                </dd>
              </div>
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Email
                </dt>
                <dd class="text-gray-900 dark:text-white">
                  {{ patient.email || "N/A" }}
                </dd>
              </div>
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Telefone
                </dt>
                <dd class="text-gray-900 dark:text-white">
                  {{ patient.phone }}
                </dd>
              </div>
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Contato de Emergência
                </dt>
                <dd class="text-gray-900 dark:text-white">
                  {{ patient.emergencyContact || "N/A" }}
                </dd>
              </div>
              <div
                class="p-2 rounded-md bg-gray-50 dark:bg-gray-800 sm:col-span-3"
              >
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Endereço
                </dt>
                <dd class="text-gray-900 dark:text-white">
                  {{
                    `${patient.address}, ${patient.city} - ${patient.state}, ${patient.zipCode}`
                  }}
                </dd>
              </div>
              <div
                class="p-2 rounded-md bg-gray-50 dark:bg-gray-800 sm:col-span-3"
              >
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  ID do Paciente
                </dt>
                <dd class="text-gray-900 dark:text-white font-mono text-sm">
                  {{ patient.id }}
                </dd>
              </div>
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Criado em
                </dt>
                <dd class="text-gray-900 dark:text-white">
                  {{ formatDateTime(patient.createdAt) }}
                </dd>
              </div>
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Atualizado em
                </dt>
                <dd class="text-gray-900 dark:text-white">
                  {{ formatDateTime(patient.updatedAt) }}
                </dd>
              </div>
              <div class="p-2 rounded-md bg-gray-50 dark:bg-gray-800">
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  ID do Responsável
                </dt>
                <dd class="text-gray-900 dark:text-white font-mono text-sm">
                  {{ patient.ownerId }}
                </dd>
              </div>
              <div
                class="p-2 rounded-md bg-gray-50 dark:bg-gray-800 sm:col-span-3"
              >
                <dt class="font-medium text-gray-500 dark:text-gray-400">
                  Restrição Fisica
                </dt>
                <dd class="text-gray-900 dark:text-white font-mono text-sm">
                  {{ patient.exerciseAlert || "Sem restriçoes Fisicas" }}
                </dd>
              </div>
            </dl>
          </UCard>
        </template>

        <template #anamneses="{ item }">
          <UCard class="mt-4">
            <template #header>
              <div class="flex justify-between items-center">
                <h3 class="text-lg font-semibold">{{ item.label }}</h3>
                <AnamnesesEditModal
                  v-if="anamnesis"
                  @updated="handleUpdate"
                  :patient-id="patient.id"
                />
                <AnamnesesCreateModal
                  v-else
                  :patient-id="patient.id"
                  @created="handleUpdate"
                />
              </div>
            </template>

            <div v-if="anamnesis" class="space-y-4">
              <div>
                <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                  Queixa Principal
                </h4>
                <p class="text-gray-600 dark:text-gray-400">
                  {{ anamnesis.chiefComplaint || "N/A" }}
                </p>
              </div>
              <div>
                <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                  História da Doença Atual
                </h4>
                <p class="text-gray-600 dark:text-gray-400">
                  {{ anamnesis.historyOfCurrentIllness || "N/A" }}
                </p>
              </div>
              <div>
                <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                  Histórico Familiar
                </h4>
                <p class="text-gray-600 dark:text-gray-400">
                  {{ anamnesis.personalAndFamilyHistory || "N/A" }}
                </p>
              </div>
              <div>
                <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                  Hábitos De Vida
                </h4>
                <p class="text-gray-600 dark:text-gray-400">
                  {{ anamnesis.lifestyleHabits || "N/A" }}
                </p>
              </div>
            </div>
            <div v-else class="text-center py-8">
              <p class="text-gray-500 dark:text-gray-400">
                Nenhuma anamnese encontrada para este paciente.
              </p>
              <p class="text-sm text-gray-400 dark:text-gray-500">
                Clique em 'Criar' para adicionar uma.
              </p>
            </div>
          </UCard>
        </template>

        <template #clinical-info="{ item }">
          <UCard class="mt-4">
            <template #header>
              <div class="flex justify-between items-center">
                <h3 class="text-lg font-semibold">{{ item.label }}</h3>
                <!-- Conditional Edit/Create buttons for Clinical Info -->
                <ClinicalInfoEditModal
                  v-if="clinicalInfo"
                  @updated="handleUpdate"
                  :patient-id="patient.id"
                  :clinical-info="clinicalInfo"
                />
                <ClinicalInfoCreateModal
                  v-else
                  @created="handleUpdate"
                  :patient-id="patient.id"
                />
              </div>
            </template>

            <div v-if="clinicalInfo" class="space-y-4">
              <div class="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-4">
                <div>
                  <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                    Plano de Saúde
                  </h4>
                  <p class="text-gray-600 dark:text-gray-400">
                    {{ clinicalInfo.healthInsurance || "N/A" }}
                  </p>
                </div>
                <div>
                  <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                    Peso
                  </h4>
                  <p class="text-gray-600 dark:text-gray-400">
                    {{
                      clinicalInfo.weightKg
                        ? `${clinicalInfo.weightKg} kg`
                        : "N/A"
                    }}
                  </p>
                </div>
                <div>
                  <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                    Altura
                  </h4>
                  <p class="text-gray-600 dark:text-gray-400">
                    {{
                      clinicalInfo.heightCm
                        ? `${clinicalInfo.heightCm} cm`
                        : "N/A"
                    }}
                  </p>
                </div>
              </div>

              <div class="mt-4 space-y-4">
                <div>
                  <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                    Objetivo Principal do Tratamento
                  </h4>
                  <p class="text-gray-600 dark:text-gray-400">
                    {{ clinicalInfo.mainTreatmentGoal || "N/A" }}
                  </p>
                </div>
                <div>
                  <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                    Alergias
                  </h4>
                  <p class="text-gray-600 dark:text-gray-400">
                    {{ clinicalInfo.allergies || "N/A" }}
                  </p>
                </div>
                <div>
                  <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                    Comorbidades
                  </h4>
                  <p class="text-gray-600 dark:text-gray-400">
                    {{ clinicalInfo.comorbidities || "N/A" }}
                  </p>
                </div>
              </div>

              <div class="mt-6 border-t pt-4">
                <h4 class="font-semibold text-gray-700 dark:text-gray-300">
                  Última Atualização
                </h4>
                <p class="text-sm text-gray-500 dark:text-gray-400">
                  {{ new Date(clinicalInfo.updatedAt).toLocaleString("pt-BR") }}
                </p>
              </div>
            </div>
            <div v-else class="text-center py-8">
              <p class="text-gray-500 dark:text-gray-400">
                Nenhuma informação clínica encontrada.
              </p>
              <p class="text-sm text-gray-400 dark:text-gray-500">
                Clique em 'Criar' para adicionar.
              </p>
            </div>
          </UCard>
        </template>

        <template #history>
          <div class="flex justify-center w-full mt-6">
            <PatientsHistory :patient-id="patient.id" />
          </div>
        </template>

        <template #medications>
          <div class="m-4">
            <MedicationsCreateModal
                :patient-id="patient.id"
                @medication-created="handleMedicationCreated"
              />
          </div>
          <div class="flex justify-center w-full mt-6">
            <Medications :key="medicationsRefreshKey" :patient-id="patient.id" />
          </div>
        </template>

        <template #fitbit>
          <div class="flex justify-center w-full mt-6">
            <FitbitPanel :patient-id="patient.id" />
          </div>
        </template>
      </UTabs>
    </div>
  </section>
</template>
