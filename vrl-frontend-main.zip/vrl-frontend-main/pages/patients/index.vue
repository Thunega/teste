<script setup lang="ts">
import { h, resolveComponent, ref, watch, computed } from "vue";
import type { Row } from "@tanstack/vue-table";
import { useClipboard, watchDebounced } from "@vueuse/core";

useHead({
  title: "Pacientes | VRLeao",
});

// --- Component/UI Registration ---
const UButton = resolveComponent("UButton");
const ULink = resolveComponent("ULink");
const UDropdownMenu = resolveComponent("UDropdownMenu");

// --- Composables & Stores ---
const toast = useToast();
const router = useRouter();
const patientStore = usePatientStore();

const searchQuery = ref("");
const pagination = ref({
  pageIndex: 0,
  pageSize: 10,
});
const statusMap = {
  ACTIVE: {
    label: "Ativo",
    class: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",
  },
  TREATMENT_INTERRUPTED: {
    label: "Interrompido",
    class: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300",
  },
  TREATMENT_COMPLETED: {
    label: "Finalizado",
    class: "bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-200",
  },
};

const columns = [
  {
    accessorKey: "name",
    header: "Paciente",
    cell: ({ row }) =>
  h("div", { class: "flex items-center gap-2" }, [
    h(
      ULink,
      {
        to: `/patients/${row.original.id}`,
        class: "hover:underline font-medium",
      },
      () => row.original.name
    ),

    row.original.status
      ? h(
          "span",
          {
            class: `text-xs px-2 py-0.5 rounded-full font-medium ${
              statusMap[row.original.status]?.class
            }`,
          },
          statusMap[row.original.status]?.label
        )
      : null,
  ]),
  },
  
  {
    accessorKey: "cpf",
    header: "CPF",
  },
  {
    accessorKey: "dateOfBirth",
    header: "Data de nascimento",
    cell: ({ row }) =>
      new Date(row.original.dateOfBirth).toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        timeZone: "UTC",
      }),
  },
  {
    accessorKey: "phone",
    header: "Telefone",
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          {
            content: { align: "end" },
            items: getRowItems(row),
          },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

function getRowItems(row: Row<{ id: string }>) {
  return [
    {
      label: "Ver ficha do paciente",
      icon: "i-lucide-eye",
      onSelect: () => router.push(`/patients/${row.original.id}`),
    },
    {
      label: "Ver relatório do paciente",
      icon: "i-lucide-chart-line",
      onSelect: () => router.push(`/reports/${row.original.id}`),
    },
  ];
}

const currentPage = computed(() => pagination.value.pageIndex + 1);

const fetchData = () => {
  patientStore.fetchData({
    page: pagination.value.pageIndex + 1,
    orderBy: "name",
    perPage: pagination.value.pageSize,
    query: searchQuery.value || undefined,
  });
};

watch([currentPage, searchQuery], fetchData, { immediate: true });

watchDebounced(
  searchQuery,
  () => {
    if (pagination.value.pageIndex !== 0) {
      pagination.value.pageIndex = 0;
    } else {
      fetchData();
    }
  },
  { debounce: 300 },
);

async function handleCreated() {
  toast.add({ title: "Paciente criado com sucesso!" });
  await fetchData();
}

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Pacientes",
    icon: "i-lucide-users",
    to: "/patients",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Pacientes</h1>
        <p class="text-gray-500">Filtre e gerencie os pacientes.</p>
      </div>
      <PatientsCreateModal @patient-created="handleCreated" />
    </div>

    <div
      class="flex items-center gap-2 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Paciente">
        <UInput
          v-model="searchQuery"
          icon="i-lucide-search"
          placeholder="Buscar por nome..."
        />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="patientStore.data"
        :columns="columns"
        :loading="patientStore.loading"
        class="flex-1"
      />

      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            patientStore.meta && patientStore.meta.total > pagination.pageSize
          "
          :total="patientStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
