<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";
useHead({
  title: "Exames | VRLeao",
});
const router = useRouter();

const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const examStore = useExamStore();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const selectedPatientId = ref();
const selectedExamId = ref();
const editModal = ref();
const deleteModal = ref();

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/exams/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  {
    header: "Data do Exame",
    accessorKey: "examDate",
    cell: ({ row }) =>
      new Date(row.original.examDate).toLocaleDateString("pt-BR", {
        timeZone: "UTC",
      }),
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          { content: { align: "end" }, items: getRowItems(row) },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

function getRowItems(row: Row<any>) {
  return [
    {
      label: "Ver Detalhes",
      icon: "i-lucide-eye",
      onClick() {
        router.push(`/exams/${row.original.id}`);
      },
    },
    {
      label: "Ver relatório do paciente",
      icon: "i-lucide-chart-pie",
      onClick() {
        router.push(`/exams/report/${row.original.patientId}`);
      },
    },
    {
      type: "separator",
    },
    {
      label: "Editar Exame",
      icon: "i-lucide-pencil",
      onSelect: () => {
        selectedExamId.value = row.original.id;
        editModal.value.open();
      },
    },
    {
      label: "Deletar Exame",
      icon: "i-lucide-x-circle",
      onSelect: () => {
        selectedExamId.value = row.original.id;
        deleteModal.value.open();
      },
    },
  ];
}

const fetchData = () => {
  examStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
  });
};

watch(selectedPatientId, () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});

watch(() => pagination.value.pageIndex, fetchData);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Exames",
    icon: "i-lucide-test-tube-diagonal",
    to: "/exams",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Exames</h1>
        <p class="text-gray-500">Filtre e gerencie os exames dos pacientes.</p>
      </div>
      <ExamCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex items-center gap-2 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Filtrar por Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="examStore.data"
        :columns="columns"
        :loading="examStore.loading"
        class="flex-1"
      />
      <ExamEditModal
        ref="editModal"
        :exam-id="selectedExamId"
        @updated="fetchData"
      />

      <DeleteModal
        ref="deleteModal"
        :id="selectedExamId"
        :store="examStore"
        @deleted="fetchData"
      />

      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="examStore.meta && examStore.meta.total > pagination.pageSize"
          :total="examStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
