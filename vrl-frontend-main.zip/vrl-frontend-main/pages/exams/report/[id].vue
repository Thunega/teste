<script setup lang="ts">

import {useRoute} from "#vue-router";
import {ref} from "vue";

const route = useRoute();
const patientStore = usePatientStore()
const patient = ref()

const fetchData = async () => {
  const patientId = route.params.id as string
  patient.value = await patientStore.getById(patientId)
}
onMounted(fetchData)


const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: 'Painel',
    icon: 'i-lucide-layout-dashboard',
    to: '/'
  },
  {
    label: 'Exames',
    icon: 'i-lucide-test-tube-diagonal',
    to: '/exams'
  },
  {
    label: 'Relatório de exames',
    icon: 'i-lucide-pie-chart',
    to: `/exams/report/${route.params.id}`
  },
])
</script>
<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems"/>
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Relatório de {{ patient?.name }}</h1>
      </div>
    </div>
    <div>
      <ExamReport :patient-id="route.params.id as string"/>
    </div>
  </section>
</template>