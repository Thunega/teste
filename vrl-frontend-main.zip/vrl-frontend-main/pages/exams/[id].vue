<script setup lang="ts">
import { ref, onMounted, computed } from "vue";
import { useRoute } from "vue-router";
useHead({
  title: "Detalhes do Exame | VRLeao",
});
const route = useRoute();
const examStore = useExamStore();
const patientStore = usePatientStore();

const exam = ref<any>(null);
const patient = ref<any>(null);
const isLoading = ref(true);
const error = ref<string | null>(null);

async function fetchData() {
  const examId = route.params.id as string;
  if (!examId) {
    error.value = "ID do exame não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const examData = await examStore.getById(examId);

    if (examData) {
      exam.value = examData;
      const patientData = await patientStore.getById(examData.patientId);
      patient.value = patientData;
    } else {
      error.value = "Exame não encontrado.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados do exame.";
  } finally {
    isLoading.value = false;
  }
}

function getClassification(type: string, value: number) {
  if (value === null || value === undefined)
    return { text: "N/A", color: "gray" };

  switch (type) {
    case "totalCholesterol":
      if (value < 200) return { text: "Bom", color: "green" };
      if (value <= 239) return { text: "Normal", color: "yellow" };
      return { text: "Atenção", color: "red" };
    case "hdl":
      if (value > 60) return { text: "Bom", color: "green" };
      return { text: "Atenção", color: "red" };
    case "ldl":
      if (value < 100) return { text: "Bom", color: "green" };
      if (value <= 159) return { text: "Normal", color: "yellow" };
      return { text: "Atenção", color: "red" };
    case "fastingGlucose":
      if (value < 100) return { text: "Bom", color: "green" };
      if (value <= 125) return { text: "Normal", color: "yellow" };
      return { text: "Atenção", color: "red" };
    case "triglycerides":
      if (value < 150) return { text: "Bom", color: "green" };
      if (value <= 199) return { text: "Normal", color: "yellow" };
      return { text: "Atenção", color: "red" };
    case "tsh":
      if (value >= 0.4 && value <= 4.5)
        return { text: "Normal", color: "green" };
      return { text: "Atenção", color: "red" };
    default:
      return { text: "N/A", color: "gray" };
  }
}

const examResults = computed(() => {
  if (!exam.value) return [];
  const results = [
    {
      name: "Colesterol Total",
      key: "totalCholesterol",
      value: exam.value.totalCholesterol,
      unit: "mg/dL",
    },
    { name: "HDL", key: "hdl", value: exam.value.hdl, unit: "mg/dL" },
    { name: "LDL", key: "ldl", value: exam.value.ldl, unit: "mg/dL" },
    { name: "VLDL", key: "vldl", value: exam.value.vldl, unit: "mg/dL" },
    {
      name: "Triglicerídeos",
      key: "triglycerides",
      value: exam.value.triglycerides,
      unit: "mg/dL",
    },
    {
      name: "Glicemia de Jejum",
      key: "fastingGlucose",
      value: exam.value.fastingGlucose,
      unit: "mg/dL",
    },
    { name: "TGO (AST)", key: "sgot", value: exam.value.sgot, unit: "U/L" },
    { name: "TGP (ALT)", key: "sgpt", value: exam.value.sgpt, unit: "U/L" },
    { name: "Gama GT", key: "gammaGt", value: exam.value.gammaGt, unit: "U/L" },
    { name: "Ureia", key: "urea", value: exam.value.urea, unit: "mg/dL" },
    {
      name: "Creatinina",
      key: "creatinine",
      value: exam.value.creatinine,
      unit: "mg/dL",
    },
    { name: "T3", key: "t3", value: exam.value.t3, unit: "ng/dL" },
    { name: "T4", key: "t4", value: exam.value.t4, unit: "µg/dL" },
    { name: "TSH", key: "tsh", value: exam.value.tsh, unit: "µU/mL" },
  ];
  return results
    .filter((r) => r.value !== null && r.value !== undefined)
    .map((r) => ({ ...r, classification: getClassification(r.key, r.value) }));
});

const tableColumns = [
  { id: "name", accessorKey: "name", header: "Exame" },
  { id: "value", accessorKey: "value", header: "Resultado" },
  {
    id: "classification",
    accessorKey: "classification",
    header: "Classificação",
  },
];

onMounted(fetchData);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Exames",
    icon: "i-lucide-test-tube-diagonal",
    to: "/exams",
  },
]);
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados do exame...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="exam && patient">
      <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Exames de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Data do Exame:
            {{
              new Date(exam.examDate).toLocaleDateString("pt-BR", {
                timeZone: "UTC",
              })
            }}
          </p>
        </div>
        <div class="flex gap-4">
          <DeleteButton :id="exam.id" :store="examStore" @deleted="fetchData" />
          <ExamEditModal @updated="fetchData" :exam-id="exam.id" />
        </div>
      </div>

      <Card>
        <template #header>
          <h3 class="text-lg font-semibold">Resultados Laboratoriais</h3>
        </template>
        <div class="px-4">
          <ExamResults :exam-data="exam" />
        </div>

        <div
          v-if="exam.observations || exam.others"
          class="mt-6 space-y-4 p-4 border-t border-gray-200 dark:border-gray-800"
        >
          <div v-if="exam.observations">
            <h4 class="font-semibold text-gray-700 dark:text-gray-300">
              Observações
            </h4>
            <p
              class="text-gray-600 dark:text-gray-400 prose dark:prose-invert max-w-none"
            >
              {{ exam.observations }}
            </p>
          </div>
          <div v-if="exam.others">
            <h4 class="font-semibold text-gray-700 dark:text-gray-300">
              Outros Exames
            </h4>
            <p
              class="text-gray-600 dark:text-gray-400 prose dark:prose-invert max-w-none"
            >
              {{ exam.others }}
            </p>
          </div>
        </div>
      </Card>
    </div>
  </section>
</template>
