<script setup lang="ts">
import { ref, onMounted, computed } from "vue";
import { useRoute } from "vue-router";
useHead({
  title: "Detalhes da Consulta Psicológica | VRLeao",
});
const route = useRoute();
const psychologicalConsultationStore = usePsychologicalConsultationsStore();
const patientStore = usePatientStore();

const consultation = ref<any>(null);
const patient = ref<any>(null);
const isLoading = ref(true);
const error = ref<string | null>(null);

async function fetchData() {
  const consultationId = route.params.id as string;
  if (!consultationId) {
    error.value = "ID da consulta não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const consultationData =
      await psychologicalConsultationStore.getById(consultationId);

    if (consultationData) {
      consultation.value = consultationData;
      const patientData = await patientStore.getById(
        consultationData.patientId,
      );
      patient.value = patientData;
    } else {
      error.value = "Consulta não encontrada.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados.";
  } finally {
    isLoading.value = false;
  }
}

onMounted(fetchData);

async function handleUpdate() {
  await fetchData();
}

const getHumorBadge = (humor: string) => {
  switch (humor) {
    case "muito bom":
      return { color: "success", text: "Muito Bom", icon: "i-lucide-laugh" };
    case "bom":
      return { color: "success", text: "Bom", icon: "i-lucide-smile" };
    case "moderado":
      return { color: "warning", text: "Moderado", icon: "i-lucide-meh" };
    case "ruim":
      return { color: "error", text: "Ruim", icon: "i-lucide-frown" };
    case "muito ruim":
      return { color: "error", text: "Muito Ruim", icon: "i-lucide-angry" };
    default:
      return { color: "gray", text: humor, icon: "i-lucide-laugh" };
  }
};

const getAnxietyBadge = (level: string) => {
  switch (level) {
    case "muito baixa":
      return {
        color: "success",
        text: "Muito Baixa",
        icon: "i-lucide-battery",
      };
    case "baixa":
      return { color: "cyan", text: "Baixa", icon: "i-lucide-battery-low" };
    case "moderada":
      return {
        color: "warning",
        text: "Moderada",
        icon: "i-lucide-battery-medium",
      };
    case "alta":
      return { color: "error", text: "Alta", icon: "i-lucide-battery-full" };
    case "muito alta":
      return {
        color: "error",
        text: "Muito Alta",
        icon: "i-lucide-battery-warning",
      };
    default:
      return { color: "gray", text: level, icon: "i-lucide-battery" };
  }
};

const humorInfo = computed(() => getHumorBadge(consultation.value?.humor));
const anxietyInfo = computed(() =>
  getAnxietyBadge(consultation.value?.anxietyLevel),
);

const fakeInputContainerClass =
  "block w-full rounded-md border-0 bg-gray-100 dark:bg-gray-800/50 px-3 py-2 shadow-sm ring-1 ring-inset ring-gray-200 dark:ring-gray-700";
const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Acompanhamento Psicológico",
    icon: "i-lucide-brain",
    to: "/psychological-consultations",
  },
]);
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados da consulta...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="consultation && patient">
      <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Consulta Psicológica de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Data da Consulta:
            {{
              new Date(consultation.consultationDate).toLocaleDateString(
                "pt-BR",
                { timeZone: "UTC" },
              )
            }}
          </p>
        </div>
        <PsychologicalConsultationsEditModal
          @updated="handleUpdate"
          :consultation="consultation"
        />
      </div>

      <div class="space-y-6">
        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Estado do Paciente</h3>
          </template>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Humor</label
              >
              <div class="flex items-center gap-2">
                <UBadge
                  :color="humorInfo.color"
                  variant="soft"
                  size="lg"
                  :icon="humorInfo.icon"
                  >{{ humorInfo.text }}</UBadge
                >
              </div>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Nível de Ansiedade</label
              >
              <div class="flex items-center gap-2">
                <UBadge
                  :color="anxietyInfo.color"
                  variant="soft"
                  size="lg"
                  :icon="anxietyInfo.icon"
                  >{{ anxietyInfo.text }}</UBadge
                >
              </div>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Anotações da Sessão</h3>
          </template>
          <div :class="[fakeInputContainerClass, 'min-h-[120px]']">
            <label class="block text-xs font-medium text-gray-500"
              >Observações</label
            >
            <p class="text-sm font-semibold whitespace-pre-wrap">
              {{ consultation.observations || "Nenhuma observação." }}
            </p>
          </div>
        </UCard>
      </div>
    </div>
  </section>
</template>
