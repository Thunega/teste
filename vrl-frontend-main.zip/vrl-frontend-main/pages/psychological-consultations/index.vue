<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";

useHead({
  title: "Consultas Psicológicas | VRLeao",
});

const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const UBadge = resolveComponent("UBadge");
const psychologicalConsultationStore = usePsychologicalConsultationsStore();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const selectedPatientId = ref();

const getHumorBadge = (humor: string) => {
  switch (humor) {
    case "muito bom":
      return { color: "success", text: "Muito Bom", icon: "i-lucide-laugh" };
    case "bom":
      return { color: "success", text: "Bom", icon: "i-lucide-smile" };
    case "moderado":
      return { color: "warning", text: "Moderado", icon: "i-lucide-meh" };
    case "ruim":
      return { color: "error", text: "Ruim", icon: "i-lucide-frown" };
    case "muito ruim":
      return { color: "error", text: "Muito Ruim", icon: "i-lucide-angry" };
    default:
      return { color: "gray", text: humor, icon: "i-lucide-laugh" };
  }
};

const getAnxietyBadge = (level: string) => {
  switch (level) {
    case "muito baixa":
      return {
        color: "success",
        text: "Muito Baixa",
        icon: "i-lucide-battery",
      };
    case "baixa":
      return { color: "cyan", text: "Baixa", icon: "i-lucide-battery-low" };
    case "moderada":
      return {
        color: "warning",
        text: "Moderada",
        icon: "i-lucide-battery-medium",
      };
    case "alta":
      return { color: "error", text: "Alta", icon: "i-lucide-battery-full" };
    case "muito alta":
      return {
        color: "error",
        text: "Muito Alta",
        icon: "i-lucide-battery-warning",
      };
    default:
      return { color: "gray", text: level, icon: "i-lucide-battery" };
  }
};

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/psychological-consultations/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  {
    header: "Data",
    accessorKey: "consultationDate",
    cell: ({ row }) =>
      new Date(row.original.consultationDate).toLocaleDateString("pt-BR", {
        timeZone: "UTC",
      }),
  },
  {
    header: "Humor",
    accessorKey: "humor",
    cell: ({ row }) => {
      const badge = getHumorBadge(row.original.humor);
      return h(
        UBadge,
        { color: badge.color, variant: "subtle", icon: badge.icon, size: "lg" },
        () => badge.text,
      );
    },
  },
  {
    header: "Nível de Ansiedade",
    accessorKey: "anxietyLevel",
    cell: ({ row }) => {
      const badge = getAnxietyBadge(row.original.anxietyLevel);
      return h(
        UBadge,
        { color: badge.color, variant: "subtle", icon: badge.icon, size: "lg" },
        () => badge.text,
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          { content: { align: "end" }, items: getRowItems(row) },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

function getRowItems(row: Row<{ id: string }>) {
  return [
    { label: "Ver detalhes da consulta", icon: "i-lucide-eye" },
    { label: "Editar", icon: "i-lucide-pencil" },
  ];
}

const fetchData = () => {
  psychologicalConsultationStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
  });
};

watch([selectedPatientId], () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});

watch(() => pagination.value.pageIndex, fetchData);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Acompanhamento Psicológico",
    icon: "i-lucide-brain",
    to: "/psychological-consultations",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Consultas Psicológicas</h1>
        <p class="text-gray-500">Filtre e gerencie as consultas.</p>
      </div>
      <PsychologicalConsultationsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex items-center gap-2 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="psychologicalConsultationStore.data"
        :columns="columns"
        :loading="psychologicalConsultationStore.loading"
        class="flex-1"
      />
      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            psychologicalConsultationStore.meta &&
            psychologicalConsultationStore.meta.total >
              psychologicalConsultationStore.meta.perPage
          "
          :total="psychologicalConsultationStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
