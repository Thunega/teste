<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";

useHead({
  title: "Consultas de Fisioterapia | VRLeao",
});

const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const physiotherapyConsultationStore = usePhysiotherapyConsultationsStore();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const selectedPatientId = ref();

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/physiotherapy-consultations/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  {
    header: "Fisioterapeuta",
    accessorKey: "user.name",
  },
  {
    header: "Data da Consulta",
    accessorKey: "createdAt",
    cell: ({ row }) =>
      new Date(row.original.consultationDate).toLocaleDateString("pt-BR", {
        timeZone: "UTC",
      }),
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          { content: { align: "end" }, items: getRowItems(row) },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

function getRowItems(row: Row<{ id: string }>) {
  return [
    { label: "Ver detalhes da consulta", icon: "i-lucide-eye" },
    { label: "Editar", icon: "i-lucide-pencil" },
  ];
}

const fetchData = () => {
  physiotherapyConsultationStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
  });
};

watch(selectedPatientId, () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});

watch(() => pagination.value.pageIndex, fetchData);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Consultas de Fisioterapia",
    icon: "i-lucide-file-user",
    to: "/physiotherapy-consultations",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Consultas Fisioterapêuticas</h1>
        <p class="text-gray-500">Filtre e gerencie as consultas.</p>
      </div>
      <PhysiotherapyConsultationsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex items-center gap-2 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Filtrar por Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="physiotherapyConsultationStore.data"
        :columns="columns"
        :loading="physiotherapyConsultationStore.loading"
        class="flex-1"
      />
      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            physiotherapyConsultationStore.meta &&
            physiotherapyConsultationStore.meta.total >
              physiotherapyConsultationStore.meta.perPage
          "
          :total="physiotherapyConsultationStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
