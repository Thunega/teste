<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";

useHead({
  title: "Detalhes da Consulta de Fisioterapia | VRLeao",
});

const route = useRoute();
const physiotherapyConsultationStore = usePhysiotherapyConsultationsStore();
const patientStore = usePatientStore();

const consultation = ref<any>(null);
const patient = ref<any>(null);
const isLoading = ref(true);
const error = ref<string | null>(null);

async function fetchData() {
  const consultationId = route.params.id as string;
  if (!consultationId) {
    error.value = "ID da consulta não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const consultationData =
      await physiotherapyConsultationStore.getById(consultationId);

    if (consultationData) {
      consultation.value = consultationData;
      const patientData = await patientStore.getById(
        consultationData.patientId,
      );
      patient.value = patientData;
    } else {
      error.value = "Consulta não encontrada.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados.";
  } finally {
    isLoading.value = false;
  }
}

onMounted(fetchData);

async function handleUpdate() {
  await fetchData();
}

const functionalLevelMap = {
  INDEPENDENT: "Independente",
  SEMI_INDEPENDENT: "Semi-independente",
  DEPENDENT: "Dependente",
};

const fakeInputContainerClass =
  "block w-full rounded-md border-0 bg-gray-100 dark:bg-gray-800/50 px-3 py-2 shadow-sm ring-1 ring-inset ring-gray-200 dark:ring-gray-700";

const medicationColumns = [
  { accessorKey: "name", header: "Nome" },
  { accessorKey: "dosage", header: "Dosagem" },
  { accessorKey: "timetables", header: "Horários" },
  { accessorKey: "duration", header: "Duração" },
];

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Consultas de Fisioterapia",
    icon: "i-lucide-file-user",
    to: "/physiotherapy-consultations",
  },
]);
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados da consulta...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="consultation && patient">
      <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Consulta Fisioterapêutica de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Data da Consulta:
            {{
              new Date(consultation.consultationDate).toLocaleDateString(
                "pt-BR",
                { timeZone: "UTC" },
              )
            }}
          </p>
        </div>
        <PhysiotherapyConsultationsEditModal
          @updated="handleUpdate"
          :consultation="consultation"
        />
      </div>

      <div class="space-y-6">
        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Avaliação Inicial</h3>
          </template>
          <div class="space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div :class="[fakeInputContainerClass, 'min-h-[90px]']">
                <label class="block text-xs font-medium text-gray-500"
                  >Queixa Principal</label
                >
                <p class="text-sm font-semibold whitespace-pre-wrap">
                  {{ consultation.mainComplaint }}
                </p>
              </div>
              <div :class="[fakeInputContainerClass, 'min-h-[90px]']">
                <label class="block text-xs font-medium text-gray-500"
                  >Histórico Médico Relevante</label
                >
                <p class="text-sm font-semibold whitespace-pre-wrap">
                  {{ consultation.medicalHistory }}
                </p>
              </div>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div :class="fakeInputContainerClass">
                <label class="block text-xs font-medium text-gray-500"
                  >Nível de Dor (0-10)</label
                >
                <p class="text-sm font-semibold">
                  {{ consultation.painLevel }}
                </p>
              </div>
              <div :class="fakeInputContainerClass">
                <label class="block text-xs font-medium text-gray-500"
                  >Nível Funcional</label
                >
                <p class="text-sm font-semibold">
                  {{
                    functionalLevelMap[consultation.functionalLevel] ||
                    consultation.functionalLevel
                  }}
                </p>
              </div>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Medicamentos em Uso</h3>
          </template>
          <div
            v-if="
              consultation.medicationsInUse &&
              consultation.medicationsInUse.length > 0
            "
          >
            <UTable
              :data="consultation.medicationsInUse"
              :columns="medicationColumns"
            />
          </div>
          <p v-else class="text-sm text-gray-500">
            Nenhum medicamento registrado para esta consulta.
          </p>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Plano de Tratamento</h3>
          </template>
          <div class="space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div :class="[fakeInputContainerClass, 'min-h-[90px]']">
                <label class="block text-xs font-medium text-gray-500"
                  >Objetivos de Curto Prazo</label
                >
                <p class="text-sm font-semibold whitespace-pre-wrap">
                  {{ consultation.shortTermGoals }}
                </p>
              </div>
              <div :class="[fakeInputContainerClass, 'min-h-[90px]']">
                <label class="block text-xs font-medium text-gray-500"
                  >Objetivos de Longo Prazo</label
                >
                <p class="text-sm font-semibold whitespace-pre-wrap">
                  {{ consultation.longTermGoals }}
                </p>
              </div>
            </div>
            <div :class="[fakeInputContainerClass, 'min-h-[120px]']">
              <label class="block text-xs font-medium text-gray-500"
                >Plano de Tratamento Detalhado</label
              >
              <p class="text-sm font-semibold whitespace-pre-wrap">
                {{ consultation.treatmentPlan }}
              </p>
            </div>
            <div :class="[fakeInputContainerClass, 'max-w-xs']">
              <label class="block text-xs font-medium text-gray-500"
                >Frequência das Sessões</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.sessionFrequency }}
              </p>
            </div>
          </div>
        </UCard>
      </div>
    </div>
  </section>
</template>
