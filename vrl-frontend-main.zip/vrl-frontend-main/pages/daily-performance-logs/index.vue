<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";
useHead({
  title: "Registros de Performance Diária | VRLeao",
});
const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const UBadge = resolveComponent("UBadge");
const DailyPerformanceLogsEditModal = resolveComponent(
  "DailyPerformanceLogsEditModal",
);
const dailyPerformanceLogStore = useDailyPerformanceLogsStore();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const selectedPatientId = ref();
const startDate = ref();
const endDate = ref();

const isEditModalOpen = ref(false);
const selectedLogIdForEdit = ref(null);

const sleepQualityOptions = ["BAD", "AVERAGE", "GOOD"];

const getSleepQualityBadge = (quality: string) => {
  switch (quality) {
    case "GOOD":
      return { color: "success", text: "Bom" };
    case "AVERAGE":
      return { color: "warning", text: "Regular" };
    case "BAD":
      return { color: "error", text: "Ruim" };
    default:
      return { color: "gray", text: quality };
  }
};

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/daily-performance-logs/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  {
    header: "Data",
    accessorKey: "dateOfRegistration",
    cell: ({ row }) =>
      new Date(row.original.dateOfRegistration).toLocaleDateString("pt-BR", {
        timeZone: "UTC",
      }),
  },
  {
    header: "Qualidade do Sono",
    accessorKey: "sleepQuality",
    cell: ({ row }) => {
      const badge = getSleepQualityBadge(row.original.sleepQuality);
      return h(
        UBadge,
        { color: badge.color, variant: "soft" },
        () => badge.text,
      );
    },
  },
  {
    header: "Atividade Física",
    accessorKey: "physicalActivity",
    cell: ({ row }) => {
      const activity = row.original.physicalActivity;
      if (!activity || !activity.name) return "Nenhuma";
      return `${activity.name} (${activity.duration} min - ${activity.intensity})`;
    },
  },

  {
    id: "actions",
    cell: ({ row }) =>
      h(DailyPerformanceLogsEditModal, {
        logId: row.original.id,
        onUpdated() {
          fetchData();
        },
      }),
  },
];

function getRowItems(row: Row<{ id: string }>) {
  return [
    {
      label: "Ver detalhes do registro",
      icon: "i-lucide-eye",
      onSelect: () => navigateTo(`/daily-performance-logs/${row.original.id}`),
    },
    {
      label: "Editar",
      icon: "i-lucide-pencil",
      onSelect: () => {
        selectedLogIdForEdit.value = row.original.id;
        isEditModalOpen.value = true;
      },
    },
  ];
}

const fetchData = () => {
  dailyPerformanceLogStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
    startDate: startDate.value,
    endDate: endDate.value,
  });
};

watch([selectedPatientId, startDate, endDate], () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});

watch(() => pagination.value.pageIndex, fetchData);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Registro de performace diária",
    icon: "i-lucide-chart-line",
    to: "/daily-performance-logs",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Registros de Performance Diária</h1>
        <p class="text-gray-500">
          Filtre e gerencie os registros de performance.
        </p>
      </div>
      <DailyPerformanceLogsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex flex-wrap items-end gap-8 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>

      <UFormField label="Data Inicial">
        <UInput v-model="startDate" type="date" />
      </UFormField>

      <UFormField label="Data Final">
        <UInput v-model="endDate" type="date" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="dailyPerformanceLogStore.data"
        :columns="columns"
        :loading="dailyPerformanceLogStore.loading"
        class="flex-1"
      />
      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            dailyPerformanceLogStore.meta &&
            dailyPerformanceLogStore.meta.total >
              dailyPerformanceLogStore.meta.perPage
          "
          :total="dailyPerformanceLogStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
