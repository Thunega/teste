<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import EditModal from "~/components/DailyPerformanceLogs/EditModal.vue";

useHead({
  title: "Detalhes do Registro de Performance Diária | VRLeao",
});

const route = useRoute();
const dailyPerformanceLogStore = useDailyPerformanceLogsStore();
const patientStore = usePatientStore();

const dailyPerformanceLog = ref<any>(null);
const patient = ref<any>(null);
const isLoading = ref(true);
const error = ref<string | null>(null);

async function fetchData() {
  const logId = route.params.id as string;
  if (!logId) {
    error.value = "ID do registro não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const logData = await dailyPerformanceLogStore.getById(logId);

    if (logData) {
      dailyPerformanceLog.value = logData;
      const patientData = await patientStore.getById(logData.patientId);
      patient.value = patientData;
    } else {
      error.value = "Registro de performance diária não encontrado.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados.";
  } finally {
    isLoading.value = false;
  }
}

onMounted(fetchData);

async function handleUpdate() {
  await fetchData();
}

const fakeInputContainerClass =
  "block w-full rounded-md border-0 bg-gray-100 dark:bg-gray-800/50 px-3 py-2 shadow-sm ring-1 ring-inset ring-gray-200 dark:ring-gray-700";
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados do registro...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="dailyPerformanceLog && patient">
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Registro de Performance de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Data do Registro:
            {{
              new Date(
                dailyPerformanceLog.dateOfRegistration,
              ).toLocaleDateString("pt-BR", { timeZone: "UTC" })
            }}
          </p>
        </div>
        <div class="flex gap-2">
          <EditModal :log-id="dailyPerformanceLog.id" @updated="handleUpdate" />
          <DeleteButton
            :id="dailyPerformanceLog.id"
            :store="dailyPerformanceLogStore"
            @deleted="fetchData()"
          />
        </div>
      </div>

      <div class="space-y-6">
        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Sinais Vitais e Sono</h3>
          </template>
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Pressão Arterial</label
              >
              <p class="text-sm font-semibold">
                {{ dailyPerformanceLog.bloodPressure || "N/A" }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Saturação de O₂ (%)</label
              >
              <p class="text-sm font-semibold">
                {{ dailyPerformanceLog.oxygenSaturation || "N/A" }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Batimentos por Minuto</label
              >
              <p class="text-sm font-semibold">
                {{ dailyPerformanceLog.beatsPerMinute || "N/A" }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Qualidade do Sono</label
              >
              <p class="text-sm font-semibold">
                {{ dailyPerformanceLog.sleepQuality || "N/A" }}
              </p>
            </div>
          </div>
        </UCard>

        <UCard v-if="dailyPerformanceLog.physicalActivity">
          <template #header>
            <h3 class="text-lg font-semibold">Atividade Física</h3>
          </template>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Nome da Atividade</label
              >
              <p class="text-sm font-semibold">
                {{ dailyPerformanceLog.physicalActivity.name || "N/A" }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Duração (min)</label
              >
              <p class="text-sm font-semibold">
                {{ dailyPerformanceLog.physicalActivity.duration || "N/A" }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Intensidade</label
              >
              <p class="text-sm font-semibold">
                {{ dailyPerformanceLog.physicalActivity.intensity || "N/A" }}
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Observações</h3>
          </template>
          <div :class="[fakeInputContainerClass, 'min-h-[90px]']">
            <label class="block text-xs font-medium text-gray-500"
              >Notas Adicionais</label
            >
            <p class="text-sm font-semibold whitespace-pre-wrap">
              {{ dailyPerformanceLog.observations || "Nenhuma observação." }}
            </p>
          </div>
        </UCard>
      </div>
    </div>
  </section>
</template>
