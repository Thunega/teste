<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";

useHead({
  title: "Detalhes do Encaminhamento | VRLeao",
});

const route = useRoute();
const forwardingStore = useForwardingStore();
const patientStore = usePatientStore();
const userStore = useUsersStore();

const forwarding = ref<any>(null);
const patient = ref<any>(null);
const fromUser = ref<any>(null);
const toUser = ref<any>(null);
const isLoading = ref(true);
const error = ref<string | null>(null);

async function fetchData() {
  const forwardingId = route.params.id as string;
  if (!forwardingId) {
    error.value = "ID do encaminhamento não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const forwardingData = await forwardingStore.getById(forwardingId);

    if (forwardingData) {
      forwarding.value = forwardingData;

      const [patientData, fromUserData, toUserData] = await Promise.all([
        patientStore.getById(forwardingData.patientId),
        userStore.getById(forwardingData.fromUserId),
        userStore.getById(forwardingData.toUserId),
      ]);

      patient.value = patientData;
      fromUser.value = fromUserData;
      toUser.value = toUserData;
    } else {
      error.value = "Encaminhamento não encontrado.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados.";
  } finally {
    isLoading.value = false;
  }
}

onMounted(fetchData);

async function handleUpdate() {
  await fetchData();
}

const fakeInputContainerClass =
  "block w-full rounded-md border-0 bg-gray-100 dark:bg-gray-800/50 px-3 py-2 shadow-sm ring-1 ring-inset ring-gray-200 dark:ring-gray-700";

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Encaminhamento médico",
    icon: "i-lucide-circle-arrow-right",
    to: "/forwardings",
  },
]);
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados do encaminhamento...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="forwarding && patient && fromUser && toUser">
      <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Encaminhamento de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Data do Encaminhamento:
            {{
              new Date(forwarding.createdAt).toLocaleDateString("pt-BR", {
                timeZone: "UTC",
              })
            }}
          </p>
        </div>
        <ForwardingsEditModal
          @updated="handleUpdate"
          :forwardingId="forwarding.id"
        />
      </div>

      <UCard>
        <template #header>
          <h3 class="text-lg font-semibold">Detalhes do Encaminhamento</h3>
        </template>
        <div class="space-y-4">
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Paciente</label
              >
              <p class="text-sm font-semibold">{{ patient.name }}</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >De (Profissional)</label
              >
              <p class="text-sm font-semibold">{{ fromUser.name }}</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Para (Profissional)</label
              >
              <p class="text-sm font-semibold">{{ toUser.name }}</p>
            </div>
          </div>
          <div :class="[fakeInputContainerClass, 'min-h-[120px]']">
            <label class="block text-xs font-medium text-gray-500"
              >Notas Médicas / Justificativa</label
            >
            <p class="text-sm font-semibold whitespace-pre-wrap">
              {{ forwarding.medicalNotes || "Nenhuma nota cadastrada." }}
            </p>
          </div>
        </div>
      </UCard>
    </div>
  </section>
</template>
