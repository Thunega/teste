<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted } from "vue";
import type { Row } from "@tanstack/vue-table";
useHead({
  title: "Encaminhamentos | VRLeao",
});
const UButton = resolveComponent("UButton");
const ULink = resolveComponent("ULink");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const forwardingStore = useForwardingStore();
const router = useRouter();

const pagination = ref({ pageIndex: 0, pageSize: 10 });
const selectedPatientId = ref();
const selectedFromUserId = ref();
const selectedToUserId = ref();

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/forwardings/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  { header: "De", accessorKey: "fromUser.name" },
  { header: "Para", accessorKey: "toUser.name" },
  {
    header: "Data",
    accessorKey: "createdAt",
    cell: ({ row }) =>
      new Date(row.original.createdAt).toLocaleDateString("pt-BR"),
  },
  {
    header: "Notas Médicas",
    accessorKey: "medicalNotes",
    cell: ({ row }) =>
      h("span", { class: "line-clamp-2" }, row.original.medicalNotes),
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          { content: { align: "end" }, items: getRowItems(row) },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

function getRowItems(row: Row<{ id: string }>) {
  return [
    {
      label: "Ver detalhes",
      icon: "i-lucide-eye",
      onClick: () => {
        router.push(`/forwardings/${row.original.id}`);
      },
    },
    { label: "Imprimir", icon: "i-lucide-printer", disabled: true },
  ];
}

// --- Lógica de Busca de Dados ---
const fetchData = () => {
  forwardingStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
    fromUserId: selectedFromUserId.value,
    toUserId: selectedToUserId.value,
  });
};

// Observa os filtros e reseta a paginação
watch([selectedPatientId, selectedFromUserId, selectedToUserId], () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});

// Observa mudança de página
watch(() => pagination.value.pageIndex, fetchData);

// Busca inicial
onMounted(fetchData);
const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Encaminhamento médico",
    icon: "i-lucide-circle-arrow-right",
    to: "/forwardings",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Encaminhamentos</h1>
        <p class="text-gray-500">Filtre e gerencie os encaminhamentos.</p>
      </div>
      <ForwardingsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex items-center gap-6 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>
      <UFormField label="Author">
        <UserSelectInput @update:patient="selectedFromUserId = $event" />
      </UFormField>
      <UFormField label="Destinatário">
        <UserSelectInput @update:patient="selectedToUserId = $event" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="forwardingStore.data"
        :columns="columns"
        :loading="forwardingStore.loading"
        class="flex-1"
      />
      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            forwardingStore.meta &&
            forwardingStore.meta.total > pagination.pageSize
          "
          :total="forwardingStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
