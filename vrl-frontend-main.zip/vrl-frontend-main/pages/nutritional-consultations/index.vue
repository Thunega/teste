<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";

useHead({
  title: "Consultas Nutricionais | VRLeao",
});

const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const nutritionalConsultationStore = useNutritionalConsultationsStore();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const selectedPatientId = ref();
const selectedConsultationId = ref();
const editModal = ref();
const deleteModal = ref();

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/nutritional-consultations/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  {
    header: "Data da Consulta",
    accessorKey: "consultationDate",
    cell: ({ row }) =>
      new Date(row.original.consultationDate).toLocaleDateString("pt-BR", {
        timeZone: "UTC",
      }),
  },
  {
    header: "Peso",
    accessorKey: "weightKg",
    cell: ({ row }) =>
      row.original.weightKg ? `${row.original.weightKg} kg` : "N/A",
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          { content: { align: "end" }, items: getRowItems(row) },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

const router = useRouter();

function getRowItems(row: Row<any>) {
  return [
    {
      label: "Ver Detalhes",
      icon: "i-lucide-eye",
      onSelect: () =>
        router.push(`/nutritional-consultations/${row.original.id}`),
    },
    {
      type: "separator",
    },
    {
      label: "Editar Consulta",
      icon: "i-lucide-pencil",
      onSelect: () => {
        selectedConsultationId.value = row.original.id;
        editModal.value.open();
      },
    },
    {
      label: "Deletar Consulta",
      icon: "i-lucide-x-circle",
      onSelect: () => {
        selectedConsultationId.value = row.original.id;
        deleteModal.value.open();
      },
    },
  ];
}

const fetchData = () => {
  nutritionalConsultationStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
  });
};

watch(selectedPatientId, () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});

watch(() => pagination.value.pageIndex, fetchData);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Ficha Nutricional",
    icon: "i-lucide-utensils-crossed",
    to: "/nutritional-consultations",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Consultas Nutricionais</h1>
        <p class="text-gray-500">
          Filtre e gerencie as consultas dos pacientes.
        </p>
      </div>
      <NutritionalConsultationsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex items-center gap-2 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Filtrar por Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="nutritionalConsultationStore.data"
        :columns="columns"
        :loading="nutritionalConsultationStore.loading"
        class="flex-1"
      />
      <NutritionalConsultationsEditModal
        ref="editModal"
        :consultation-id="selectedConsultationId"
        @updated="fetchData"
      />

      <DeleteModal
        ref="deleteModal"
        :id="selectedConsultationId"
        :store="nutritionalConsultationStore"
        @deleted="fetchData"
      />

      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            nutritionalConsultationStore.meta &&
            nutritionalConsultationStore.meta.total >
              nutritionalConsultationStore.meta.perPage
          "
          :total="nutritionalConsultationStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
