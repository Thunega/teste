<script setup lang="ts">
import { computed } from "vue";
import { useRoute } from "vue-router";

useHead({
  title: "Detalhes da Consulta Nutricional | VRLeao",
});

const route = useRoute();
const nutritionalConsultationStore = useNutritionalConsultationsStore();
const patientStore = usePatientStore();

const consultationId = route.params.id as string;

const {
  data,
  pending: isLoading,
  error,
  refresh: handleUpdate,
} = await useAsyncData(
  `nutritional-consultation-${consultationId}`,
  async () => {
    if (!consultationId) {
      throw new Error("ID da consulta não fornecido.");
    }
    const consultationData =
      await nutritionalConsultationStore.getById(consultationId);
    if (!consultationData) {
      throw new Error("Consulta não encontrada.");
    }
    const patientData = await patientStore.getById(consultationData.patientId);
    if (!patientData) {
      throw new Error("Paciente não encontrado.");
    }
    return { consultation: consultationData, patient: patientData };
  },
);

const consultation = computed(() => data.value?.consultation);
const patient = computed(() => data.value?.patient);

const booleanToText = (value: boolean | null) => {
  if (value === null || value === undefined) return "Não informado";
  return value ? "Sim" : "Não";
};

const fakeInputContainerClass =
  "block w-full rounded-md border-0 bg-neutral-100 dark:bg-slate-800/50 px-3 py-2 ring-1 ring-inset ring-gray-200 dark:ring-gray-700";
const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Ficha Nutricional",
    icon: "i-lucide-utensils-crossed",
    to: "/nutritional-consultations",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados da consulta...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="consultation && patient">
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Consulta Nutricional de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Data da Consulta:
            {{
              new Date(consultation.consultationDate).toLocaleDateString(
                "pt-BR",
                { timeZone: "UTC" },
              )
            }}
          </p>
        </div>
        <NutritionalConsultationsEditModal
          @updated="handleUpdate"
          :consultation="consultation"
        />
      </div>

      <div class="space-y-6">
        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Dados Antropométricos</h3>
          </template>
          <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Peso</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.weightKg }} kg
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Altura</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.heightCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500">IMC</label>
              <p class="text-sm font-semibold">{{ consultation.bmi }}</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >% Gordura</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.fatPercentage }}%
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >% Massa Magra</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.leanMassPercentage }}%
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Idade Metabólica</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.metabolicAge }} anos
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Metabolismo em Repouso</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.restingMetabolismKcal }} kcal
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Gordura Visceral</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.visceralFatLevel }}
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Circunferências</h3>
          </template>
          <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Pescoço</label
              >
              <p class="text-sm font-semibold">{{ consultation.neckCm }} cm</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Busto</label
              >
              <p class="text-sm font-semibold">{{ consultation.bustCm }} cm</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Cintura Superior</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.upperWaistCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Cintura Média</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.midlineWaistCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Cintura Inferior</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.lowerWaistCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Abdômen</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.stomachCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Quadril</label
              >
              <p class="text-sm font-semibold">{{ consultation.hipCm }} cm</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Glúteo</label
              >
              <p class="text-sm font-semibold">{{ consultation.gluteCm }} cm</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Braço Esquerdo</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.leftArmCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Braço Direito</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.rightArmCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Coxa Esquerda</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.leftThighCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Coxa Direita</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.rightThighCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Panturrilha Esquerda</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.leftCalfCm }} cm
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Panturrilha Direita</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.rightCalfCm }} cm
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Hábitos Alimentares</h3>
          </template>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div :class="[fakeInputContainerClass, 'col-span-full']">
              <label class="block text-xs font-medium text-gray-500"
                >Restrições</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.dietaryRestrictions || "Nenhuma" }}
              </p>
            </div>
            <div :class="[fakeInputContainerClass, 'col-span-full']">
              <label class="block text-xs font-medium text-gray-500"
                >Preferências</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.dietaryPreferences || "Nenhuma" }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Frequência de Refeições</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.mealFrequency }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Horários</label
              >
              <p class="text-sm font-semibold">{{ consultation.mealTimes }}</p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Hábitos de Vida</h3>
          </template>
          <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Sedentário</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.sedentaryHabits) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Sono Adequado</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.sleepDurationAdequate) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Já fez dieta</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.hasBeenOnDiet) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Cozinha as refeições</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.cooksOwnMeals) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Intestino regular</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.regularBowelFunction) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Pratica atividade física</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.practicesPhysicalActivity) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Usa drogas lícitas</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.usesLicitDrugs) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Dieta balanceada</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.balancedDiet) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Ingere líquidos</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.frequentLiquidIntake) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Gestante</label
              >
              <p class="text-sm font-semibold">
                {{ booleanToText(consultation.isPregnant) }}
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Plano Nutricional</h3>
          </template>
          <div class="space-y-4">
            <div :class="[fakeInputContainerClass, 'min-h-[60px]']">
              <label class="block text-xs font-medium text-gray-500"
                >Motivo da Consulta</label
              >
              <p class="text-sm font-semibold">{{ consultation.reason }}</p>
            </div>
            <div :class="[fakeInputContainerClass, 'min-h-[60px]']">
              <label class="block text-xs font-medium text-gray-500"
                >Objetivo Principal</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.mainObjective }}
              </p>
            </div>
            <div :class="[fakeInputContainerClass, 'min-h-[120px]']">
              <label class="block text-xs font-medium text-gray-500"
                >Orientações Nutricionais</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.nutritionalGuidance }}
              </p>
            </div>
          </div>
        </UCard>
      </div>
    </div>
  </section>
</template>
