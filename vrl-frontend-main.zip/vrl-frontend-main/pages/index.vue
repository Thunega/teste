<script setup lang="ts">
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { TestTubeDiagonal, HeartPulse, CalendarCheck } from "lucide-vue-next";

useHead({
  title: "Painel | VRLeao",
});

definePageMeta({
  middleware: ["protected"],
});

const dashboardStore = useDashboardStore();
await dashboardStore.fetchData();
</script>

<template>
  <div class="flex flex-1 flex-col gap-8 p-4 pt-0">
    <div class="grid auto-rows-min gap-4 md:grid-cols-4">
      <Card class="flex flex-row items-center justify-between">
        <CardHeader class="flex flex-row flex-1 items-center gap-3">
          <div
            class="flex aspect-square size-12 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground"
          >
            <HeartPulse class="size-8" />
          </div>
          <div class="flex flex-col flex-1 gap-2">
            <CardTitle class="text-xl">Pacientes Ativos</CardTitle>
          </div>
        </CardHeader>
        <CardContent class="text-3xl font-bold">{{
          dashboardStore.activePatientsCount
        }}</CardContent>
      </Card>

      <Card class="flex flex-row items-center justify-between">
        <CardHeader class="flex flex-row flex-1 items-center gap-3">
          <div
            class="flex aspect-square size-12 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground"
          >
            <CalendarCheck class="size-8" />
          </div>
          <div class="flex flex-col flex-1 gap-2">
            <CardTitle class="text-xl">Consultas do dia</CardTitle>
          </div>
        </CardHeader>
        <CardContent class="text-3xl font-bold">{{
          dashboardStore.dailyAppointmentsCount
        }}</CardContent>
      </Card>

      <Card class="flex flex-row items-center justify-between">
        <CardHeader class="flex flex-row flex-1 items-center gap-3">
          <div
            class="flex aspect-square size-12 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground"
          >
            <CalendarCheck class="size-8" />
          </div>
          <div class="flex flex-col flex-1 gap-2">
            <CardTitle class="text-xl">Próximas Consultas</CardTitle>
          </div>
        </CardHeader>
        <CardContent class="text-3xl font-bold">{{
          dashboardStore.nextAppointmentsCount
        }}</CardContent>
      </Card>

      <Card class="flex flex-row items-center justify-between">
        <CardHeader class="flex flex-row flex-1 items-center gap-3">
          <div
            class="flex aspect-square size-12 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground"
          >
            <TestTubeDiagonal class="size-8" />
          </div>
          <div class="flex flex-col flex-1 gap-2">
            <CardTitle class="text-xl">Novos exames</CardTitle>
          </div>
        </CardHeader>
        <CardContent class="text-3xl font-bold">{{
          dashboardStore.consultationsCount
        }}</CardContent>
      </Card>
    </div>

    <div class="grid gap-4 md:grid-cols-2">
      <!-- <DashboardGraphExample />-->
      <DashboardRecentPatients :patients="dashboardStore.patients" />
      <DashboardNextConsults :appoitments="dashboardStore.appointments" />
      <DashboardPatientsAbsenses :patients="dashboardStore.patientsWithConsecutiveAbsences" />
    </div>
  </div>
</template>
