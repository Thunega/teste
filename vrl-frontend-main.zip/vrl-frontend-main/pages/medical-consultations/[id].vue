<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";

useHead({
  title: "Detalhes da Consulta Médica | VRLeao",
});

const route = useRoute();
const medicalConsultationStore = useMedicalConsultationsStore();
const patientStore = usePatientStore();

const consultation = ref<any>(null);
const patient = ref<any>(null);
const isLoading = ref(true);
const error = ref<string | null>(null);

async function fetchData() {
  const consultationId = route.params.id as string;
  if (!consultationId) {
    error.value = "ID da consulta não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const consultationData =
      await medicalConsultationStore.getById(consultationId);

    if (consultationData) {
      consultation.value = consultationData;
      const patientData = await patientStore.getById(
        consultationData.patientId,
      );
      patient.value = patientData;
    } else {
      error.value = "Consulta não encontrada.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados.";
  } finally {
    isLoading.value = false;
  }
}

onMounted(fetchData);

async function handleUpdate() {
  await fetchData();
}

const fakeInputContainerClass =
  "block w-full rounded-md border-0 bg-gray-100 dark:bg-gray-800/50 px-3 py-2 shadow-sm ring-1 ring-inset ring-gray-200 dark:ring-gray-700";

const medicationColumns = [
  { accessorKey: "name", header: "Nome" },
  { accessorKey: "dosage", header: "Dosagem" },
  { accessorKey: "timetables", header: "Horários" },
  { accessorKey: "duration", header: "Duração" },
];

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Consultas Médicas",
    icon: "i-lucide-search",
    to: "/medical-consultations",
  },
]);
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados da consulta...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="consultation && patient">
      <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Consulta Médica de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Data da Consulta:
            {{
              new Date(consultation.consultationDate).toLocaleDateString(
                "pt-BR",
                { timeZone: "UTC" },
              )
            }}
          </p>
        </div>
        <!--        <MedicalConsultationsEditModal @updated="handleUpdate" :consultation="consultation" />-->
      </div>

      <div class="space-y-6">
        <UCard v-if="consultation.vitalSigns">
          <template #header>
            <h3 class="text-lg font-semibold">Sinais Vitais</h3>
          </template>
          <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Pressão Arterial</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.vitalSigns.bloodPressure || "N/A" }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Frequência Cardíaca</label
              >
              <p class="text-sm font-semibold">
                {{ consultation.vitalSigns.heartRate || "N/A" }} bpm
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Medicamentos em Uso</h3>
          </template>
          <div
            v-if="
              consultation.medicationsInUse &&
              consultation.medicationsInUse.length > 0
            "
          >
            <UTable
              var
              :data="consultation.medicationsInUse"
              :columns="medicationColumns"
            />
          </div>
          <p v-else class="text-sm text-gray-500">
            Nenhum medicamento registrado para esta consulta.
          </p>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Exames Associados</h3>
          </template>
          <div v-if="consultation.exams && consultation.exams.length > 0">
            <ul class="list-disc list-inside">
              <li v-for="exam in consultation.exams" :key="exam.id">
                <ULink
                  :to="`/exams/${exam.id}`"
                  class="text-primary-500 dark:text-primary-400 hover:underline"
                >
                  Ver Exame #{{ exam.id.substring(0, 8) }}
                </ULink>
              </li>
            </ul>
          </div>
          <p v-else class="text-sm text-gray-500">
            Nenhum exame associado a esta consulta.
          </p>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">
              Observações e Evolução Clínica
            </h3>
          </template>
          <div :class="[fakeInputContainerClass, 'min-h-[120px]']">
            <label class="block text-xs font-medium text-gray-500"
              >Observações</label
            >
            <p class="text-sm font-semibold whitespace-pre-wrap">
              {{ consultation.observations || "Nenhuma observação." }}
            </p>
          </div>
        </UCard>
      </div>
    </div>
  </section>
</template>
