<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";

useHead({
  title: "Registros Alimentares | VRLeao",
});

const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const dailyFoodLogsStore = useDailyFoodLogsStore();
const router = useRouter();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const selectedPatientId = ref();
const selectedDailyFoodLogId = ref();
const editModal = ref();
const deleteModal = ref();

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/daily-food-logs/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  {
    header: "Data de Registro",
    accessorKey: "dateOfRegistration",
    cell: ({ row }) =>
      new Date(row.original.dateOfRegistration).toLocaleDateString("pt-BR", {
        timeZone: "UTC",
      }),
  },
  {
    header: "Refeições",
    accessorKey: "meals",
    cell: ({ row }) => row.original.meals?.length || 0,
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          { content: { align: "end" }, items: getRowItems(row) },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

function getRowItems(row: Row<any>) {
  return [
    {
      type: "label",
      label: "Ações",
    },
    {
      label: "Ver Detalhes",
      icon: "i-lucide-eye",
      onSelect: () => router.push(`/daily-food-logs/${row.original.id}`),
    },
    {
      type: "separator",
    },
    {
      label: "Editar Registro",
      icon: "i-lucide-pencil",
      onSelect: () => {
        selectedDailyFoodLogId.value = row.original.id;
        editModal.value.open();
      },
    },
    {
      label: "Deletar Registro",
      icon: "i-lucide-x-circle",
      onSelect: () => {
        selectedDailyFoodLogId.value = row.original.id;
        deleteModal.value.open();
      },
    },
  ];
}

const fetchData = () => {
  dailyFoodLogsStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
  });
};

watch(selectedPatientId, () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});

watch(() => pagination.value.pageIndex, fetchData);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Registros Alimentares",
    icon: "i-lucide-utensils",
    to: "/daily-food-logs",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Registros Alimentares Diários</h1>
        <p class="text-gray-500">
          Filtre e gerencie os registros alimentares dos pacientes.
        </p>
      </div>
      <DailyFoodLogsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex items-center gap-2 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Filtrar por Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="dailyFoodLogsStore.data"
        :columns="columns"
        :loading="dailyFoodLogsStore.loading"
        class="flex-1"
      />

      <DailyFoodLogsEditModal
        ref="editModal"
        :daily-food-log-id="selectedDailyFoodLogId"
        @updated="fetchData"
      />

      <DeleteModal
        ref="deleteModal"
        :id="selectedDailyFoodLogId"
        :store="dailyFoodLogsStore"
        @deleted="fetchData"
      />

      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            dailyFoodLogsStore.meta &&
            dailyFoodLogsStore.meta.total > dailyFoodLogsStore.meta.perPage
          "
          :total="dailyFoodLogsStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>
  </section>
</template>
