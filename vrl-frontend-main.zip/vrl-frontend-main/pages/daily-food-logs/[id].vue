<script setup lang="ts">
import { ref, onMounted } from "vue";

useHead({
  title: "Detalhes do Registro Alimentar | VRLeao",
});

const route = useRoute();
const dailyFoodLogsStore = useDailyFoodLogsStore();

const dailyFoodLog = ref(null);
const loading = ref(true);

onMounted(async () => {
  try {
    dailyFoodLog.value = await dailyFoodLogsStore.getById(
      route.params.id as string,
    );
  } finally {
    loading.value = false;
  }
});

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Registros Alimentares",
    icon: "i-lucide-utensils",
    to: "/daily-food-logs",
  },
  {
    label: "Detalhes",
    icon: "i-lucide-eye",
    to: `/daily-food-logs/${route.params.id}`,
  },
]);

function formatNutrient(value: number | undefined, unit: string = "") {
  return value !== undefined && value !== null ? `${value}${unit}` : "N/A";
}
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />

    <div v-if="loading" class="text-center py-8">
      <div
        class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto"
      ></div>
      <p class="mt-4 text-gray-600">Carregando registro alimentar...</p>
    </div>

    <div v-else-if="!dailyFoodLog" class="text-center py-8">
      <p class="text-red-600">Registro alimentar não encontrado.</p>
    </div>

    <div v-else class="space-y-6">
      <!-- Header -->
      <div class="flex justify-between items-start">
        <div>
          <h1 class="text-2xl font-bold">Registro Alimentar Diário</h1>
          <p class="text-gray-500">
            {{
              new Date(dailyFoodLog.dateOfRegistration).toLocaleDateString(
                "pt-BR",
                { timeZone: "UTC" },
              )
            }}
          </p>
        </div>
        <div class="text-right">
          <p class="text-sm text-gray-600">Paciente</p>
          <p class="font-semibold">{{ dailyFoodLog.patient?.name || "N/A" }}</p>
        </div>
      </div>

      <!-- Info básica -->
      <Card>
        <div class="grid grid-cols-1 md:grid-cols-1 gap-6">
          <div>
            <h3 class="font-medium text-gray-900 dark:text-gray-100 mb-2 px-10">
              Informações Gerais
            </h3>
            <div class="space-y-2 text-sm px-10">
              <div class="flex justify-between">
                <span class="text-gray-600">Data de Registro:</span>
                <span>{{
                  new Date(dailyFoodLog.dateOfRegistration).toLocaleDateString(
                    "pt-BR",
                    { timeZone: "UTC" },
                  )
                }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">Total de Refeições:</span>
                <span>{{ dailyFoodLog.meals?.length || 0 }}</span>
              </div>
            </div>
          </div>

          <div v-if="dailyFoodLog.observations">
            <h3 class="font-medium text-gray-900 dark:text-gray-100 mb-2">
              Observações Gerais
            </h3>
            <p class="text-sm text-gray-600">{{ dailyFoodLog.observations }}</p>
          </div>
        </div>
      </Card>

      <!-- Refeições -->
      <div
        v-if="dailyFoodLog.meals && dailyFoodLog.meals.length > 0"
        class="space-y-4"
      >
        <h2 class="text-xl font-semibold">Refeições</h2>

        <UAccordion
          :items="
            dailyFoodLog.meals.map((meal, idx) => ({
              label: `Refeição ${idx + 1} - ${meal.mealTime}`,
              icon: 'i-lucide-utensils',
              slot: `meal-${idx}`,
              defaultOpen: idx === 0,
            }))
          "
          :ui="{ item: { base: 'mb-2' } }"
        >
          <template
            v-for="(meal, index) in dailyFoodLog.meals"
            :key="index"
            #[`meal-${index}`]
          >
            <Card>
              <div class="border-b pb-4 mb-4 px-10">
                <div class="flex justify-between items-start">
                  <div>
                    <h3 class="font-semibold">Refeição {{ index + 1 }}</h3>
                    <p class="text-sm text-gray-600">{{ meal.mealTime }}</p>
                  </div>
                </div>

                <div v-if="meal.description" class="mt-2">
                  <p class="text-sm text-gray-700">{{ meal.description }}</p>
                </div>
              </div>

              <!-- Alimentos da refeição -->
              <div v-if="meal.foods && meal.foods.length > 0" class="space-y-4 px-10">
                <h4 class="font-medium">Alimentos Consumidos</h4>

                <UAccordion
                  :items="
                    meal.foods.map((food, idx) => ({
                      label: `${food.name} ${food.brand ? '(' + food.brand + ')' : ''} - ${food.quantity} ${food.unit}`,
                      icon: 'i-lucide-apple',
                      slot: `food-${index}-${idx}`,
                      defaultOpen: false,
                    }))
                  "
                  :ui="{ item: { base: 'mb-2' } }"
                >
                  <template
                    v-for="(food, foodIndex) in meal.foods"
                    :key="foodIndex"
                    #[`food-${index}-${foodIndex}`]
                  >
                    <div class="p-4 space-y-3">
                      <!-- Informações nutricionais -->
                      <div
                        v-if="
                          food.calories ||
                          food.carbohydrates ||
                          food.proteins ||
                          food.totalFats
                        "
                        class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm"
                      >
                        <div v-if="food.calories">
                          <span class="text-gray-600">Calorias:</span>
                          {{ formatNutrient(food.calories) }}
                        </div>
                        <div v-if="food.carbohydrates">
                          <span class="text-gray-600">Carboidratos:</span>
                          {{ formatNutrient(food.carbohydrates, "g") }}
                        </div>
                        <div v-if="food.proteins">
                          <span class="text-gray-600">Proteínas:</span>
                          {{ formatNutrient(food.proteins, "g") }}
                        </div>
                        <div v-if="food.totalFats">
                          <span class="text-gray-600">Gorduras:</span>
                          {{ formatNutrient(food.totalFats, "g") }}
                        </div>
                      </div>

                      <!-- Minerais importantes -->
                      <div
                        v-if="
                          food.sodium ||
                          food.calcium ||
                          food.iron ||
                          food.potassium
                        "
                        class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mt-2"
                      >
                        <div v-if="food.sodium">
                          <span class="text-gray-600">Sódio:</span>
                          {{ formatNutrient(food.sodium, "mg") }}
                        </div>
                        <div v-if="food.calcium">
                          <span class="text-gray-600">Cálcio:</span>
                          {{ formatNutrient(food.calcium, "mg") }}
                        </div>
                        <div v-if="food.iron">
                          <span class="text-gray-600">Ferro:</span>
                          {{ formatNutrient(food.iron, "mg") }}
                        </div>
                        <div v-if="food.potassium">
                          <span class="text-gray-600">Potássio:</span>
                          {{ formatNutrient(food.potassium, "mg") }}
                        </div>
                      </div>

                      <!-- Vitaminas importantes -->
                      <div
                        v-if="
                          food.vitaminC ||
                          food.vitaminD ||
                          food.vitaminB12 ||
                          food.vitaminA
                        "
                        class="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mt-2"
                      >
                        <div v-if="food.vitaminC">
                          <span class="text-gray-600">Vit. C:</span>
                          {{ formatNutrient(food.vitaminC, "mg") }}
                        </div>
                        <div v-if="food.vitaminD">
                          <span class="text-gray-600">Vit. D:</span>
                          {{ formatNutrient(food.vitaminD, "mcg") }}
                        </div>
                        <div v-if="food.vitaminB12">
                          <span class="text-gray-600">Vit. B12:</span>
                          {{ formatNutrient(food.vitaminB12, "mcg") }}
                        </div>
                        <div v-if="food.vitaminA">
                          <span class="text-gray-600">Vit. A:</span>
                          {{ formatNutrient(food.vitaminA, "mcg") }}
                        </div>
                      </div>

                      <div v-if="food.notes" class="mt-3 pt-3 border-t">
                        <p class="text-sm text-gray-600">
                          <strong>Observações:</strong> {{ food.notes }}
                        </p>
                      </div>
                    </div>
                  </template>
                </UAccordion>
              </div>
            </Card>
          </template>
        </UAccordion>
      </div>

      <!-- Estado vazio -->
      <Card v-else>
        <div class="text-center py-8">
          <p class="text-gray-500">
            Nenhuma refeição registrada para este dia.
          </p>
        </div>
      </Card>
    </div>
  </section>
</template>
