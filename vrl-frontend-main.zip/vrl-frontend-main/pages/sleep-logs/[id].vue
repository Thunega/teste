<script setup lang="ts">
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";

useHead({
  title: "Detalhes do Registro de Sono | VRLeao",
});

const route = useRoute();
const sleepLogStore = useSleepLogsStore();
const patientStore = usePatientStore();

const sleepLog = ref<any>(null);
const patient = ref<any>(null);
const isLoading = ref(true);
const error = ref<string | null>(null);
const editModal = ref();

async function fetchData() {
  const sleepLogId = route.params.id as string;
  if (!sleepLogId) {
    error.value = "ID do registro de sono não fornecido.";
    isLoading.value = false;
    return;
  }

  try {
    isLoading.value = true;
    const sleepLogData = await sleepLogStore.getById(sleepLogId);

    if (sleepLogData) {
      sleepLog.value = sleepLogData;
      const patientData = await patientStore.getById(sleepLogData.patientId);
      patient.value = patientData;
    } else {
      error.value = "Registro de sono não encontrado.";
    }
  } catch (e: any) {
    error.value = e.message || "Ocorreu um erro ao buscar os dados.";
  } finally {
    isLoading.value = false;
  }
}

onMounted(fetchData);

async function handleUpdate() {
  await fetchData();
}

const formatMinutesToHours = (totalMinutes: number) => {
  if (totalMinutes === null || totalMinutes === undefined) return "N/A";
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${hours}h ${minutes}m`;
};

const fakeInputContainerClass =
  "block w-full rounded-md border-0 bg-gray-100 dark:bg-gray-800/50 px-3 py-2 shadow-sm ring-1 ring-inset ring-gray-200 dark:ring-gray-700";
</script>

<template>
  <section>
    <div v-if="isLoading" class="text-center p-10">
      <p>Carregando dados do registro de sono...</p>
    </div>

    <div
      v-else-if="error"
      class="text-center p-10 bg-red-100 dark:bg-red-900/50 rounded-lg"
    >
      <p class="font-semibold text-red-700 dark:text-red-200">Erro</p>
      <p class="text-red-600 dark:text-red-300">{{ error }}</p>
    </div>

    <div v-else-if="sleepLog && patient">
      <div class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-3xl font-bold text-gray-800 dark:text-gray-100">
            Registro de Sono de {{ patient.name }}
          </h1>
          <p class="text-gray-500 dark:text-gray-400">
            Data do Registro:
            {{
              new Date(sleepLog.dateOfRegistration).toLocaleDateString(
                "pt-BR",
                { timeZone: "UTC" },
              )
            }}
          </p>
        </div>
        <div class="flex gap-2">
          <UButton
            icon="i-lucide-pencil"
            @click="editModal.open()"
            variant="outline"
            >Editar</UButton
          >
          <DeleteButton
            :id="sleepLog.id"
            :store="sleepLogStore"
            @deleted="fetchData()"
          />
        </div>
      </div>

      <SleepLogsEditModal
        ref="editModal"
        :sleep-log-id="sleepLog.id"
        @updated="handleUpdate"
      />

      <div class="space-y-6">
        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Resumo do Sono</h3>
          </template>
          <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Score do Sono (0-100)</label
              >
              <p class="text-sm font-semibold">{{ sleepLog.score }}</p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Tempo Dormindo</label
              >
              <p class="text-sm font-semibold">
                {{ formatMinutesToHours(sleepLog.sleepTime) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Tempo Acordado</label
              >
              <p class="text-sm font-semibold">
                {{ formatMinutesToHours(sleepLog.agreedTime) }}
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Estágios do Sono</h3>
          </template>
          <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Sono Leve</label
              >
              <p class="text-sm font-semibold">
                {{ formatMinutesToHours(sleepLog.lightSleep) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Sono Profundo</label
              >
              <p class="text-sm font-semibold">
                {{ formatMinutesToHours(sleepLog.deepSleep) }}
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Sono REM</label
              >
              <p class="text-sm font-semibold">
                {{ formatMinutesToHours(sleepLog.remTime) }}
              </p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Métricas de Saúde</h3>
          </template>
          <div class="grid grid-cols-2 gap-4">
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Saturação Média de Oxigênio (%)</label
              >
              <p class="text-sm font-semibold">
                {{ sleepLog.avgOxygenSaturation }}%
              </p>
            </div>
            <div :class="fakeInputContainerClass">
              <label class="block text-xs font-medium text-gray-500"
                >Frequência Cardíaca Média (bpm)</label
              >
              <p class="text-sm font-semibold">{{ sleepLog.avgHeartRate }}</p>
            </div>
          </div>
        </UCard>

        <UCard>
          <template #header>
            <h3 class="text-lg font-semibold">Observações</h3>
          </template>
          <div :class="[fakeInputContainerClass, 'min-h-[90px]']">
            <label class="block text-xs font-medium text-gray-500"
              >Notas Adicionais</label
            >
            <p class="text-sm font-semibold whitespace-pre-wrap">
              {{ sleepLog.observations || "Nenhuma observação." }}
            </p>
          </div>
        </UCard>
      </div>
    </div>
  </section>
</template>
