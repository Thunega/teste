<script setup lang="ts">
import { h, resolveComponent, ref, watch, onMounted, computed } from "vue";
import type { Row } from "@tanstack/vue-table";

useHead({
  title: "Registros de Sono | VRLeao",
});

const UButton = resolveComponent("UButton");
const UDropdownMenu = resolveComponent("UDropdownMenu");
const ULink = resolveComponent("ULink");
const sleepLogStore = useSleepLogsStore();
const router = useRouter();

const pagination = ref({ pageIndex: 0, pageSize: 15 });
const selectedPatientId = ref();
const startDate = ref();
const endDate = ref();
const editModal = ref();
const deleteModal = ref();
const selectedSleepLogId = ref();

const formatMinutesToHours = (totalMinutes: number) => {
  if (totalMinutes === null || totalMinutes === undefined || totalMinutes === 0)
    return "N/A";
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${hours}h ${minutes}m`;
};

const columns = [
  {
    header: "Paciente",
    accessorKey: "patient.name",
    cell: ({ row }) =>
      h(
        ULink,
        {
          to: `/sleep-logs/${row.original.id}`,
          class: "hover:underline",
        },
        () => row.original.patient.name,
      ),
  },
  {
    header: "Data do Registro",
    accessorKey: "dateOfRegistration",
    cell: ({ row }) =>
      new Date(row.original.dateOfRegistration).toLocaleDateString("pt-BR", {
        timeZone: "UTC",
      }),
  },
  {
    header: "Score do Sono",
    accessorKey: "score",
  },
  {
    header: "Tempo Dormindo",
    accessorKey: "sleepTime",
    cell: ({ row }) => formatMinutesToHours(row.original.sleepTime),
  },
  {
    header: "Tempo Acordado",
    accessorKey: "agreedTime",
    cell: ({ row }) => formatMinutesToHours(row.original.agreedTime),
  },
  {
    id: "actions",
    cell: ({ row }) =>
      h(
        "div",
        { class: "text-right" },
        h(
          UDropdownMenu,
          { content: { align: "end" }, items: getRowItems(row) },
          () =>
            h(UButton, {
              icon: "i-lucide-ellipsis-vertical",
              color: "neutral",
              variant: "ghost",
              class: "ml-auto",
            }),
        ),
      ),
  },
];

function getRowItems(row: Row<{ id: string }>) {
  return [
    {
      label: "Ver detalhes do registro",
      icon: "i-lucide-eye",
      onSelect: () => router.push(`/sleep-logs/${row.original.id}`),
    },
    {
      label: "Editar",
      icon: "i-lucide-pencil",
      onSelect: () => {
        selectedSleepLogId.value = row.original.id;
        editModal.value.open();
      },
    },
    {
      label: "Deletar",
      icon: "i-lucide-x-circle",
      onSelect: () => {
        selectedSleepLogId.value = row.original.id;
        deleteModal.value.open();
      },
    },
  ];
}

const fetchData = () => {
  sleepLogStore.fetchData({
    page: pagination.value.pageIndex + 1,
    perPage: pagination.value.pageSize,
    patientId: selectedPatientId.value,
    startDate: startDate.value,
    endDate: endDate.value,
  });
};

watch([selectedPatientId, startDate, endDate], () => {
  if (pagination.value.pageIndex !== 0) {
    pagination.value.pageIndex = 0;
  } else {
    fetchData();
  }
});

watch(() => pagination.value.pageIndex, fetchData);

onMounted(fetchData);

const currentPage = computed(() => pagination.value.pageIndex + 1);

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Registro de sono",
    icon: "i-lucide-bed-double",
    to: "/sleep-logs",
  },
]);
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />
    <div class="flex justify-between items-start mb-6 gap-4">
      <div>
        <h1 class="text-2xl font-bold">Registros de Sono</h1>
        <p class="text-gray-500">
          Filtre e gerencie os registros de sono dos pacientes.
        </p>
      </div>
      <SleepLogsCreateModal @created="fetchData()" />
    </div>

    <div
      class="flex flex-wrap items-end gap-8 mb-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg"
    >
      <UFormField label="Paciente">
        <PatientsSelectInput @update:patient="selectedPatientId = $event" />
      </UFormField>

      <UFormField label="Data Inicial">
        <UInput v-model="startDate" type="date" />
      </UFormField>

      <UFormField label="Data Final">
        <UInput v-model="endDate" type="date" />
      </UFormField>
    </div>

    <Card>
      <UTable
        :data="sleepLogStore.data"
        :columns="columns"
        :loading="sleepLogStore.loading"
        class="flex-1"
      />
      <div
        class="flex justify-center border-t border-gray-200 dark:border-gray-800 pt-4 mt-4"
      >
        <UPagination
          v-if="
            sleepLogStore.meta &&
            sleepLogStore.meta.total > sleepLogStore.meta.perPage
          "
          :total="sleepLogStore.meta.total"
          :items-per-page="pagination.pageSize"
          :model-value="currentPage"
          @update:page="(p) => (pagination.pageIndex = p - 1)"
        />
      </div>
    </Card>

    <SleepLogsEditModal
      ref="editModal"
      :sleep-log-id="selectedSleepLogId"
      @updated="fetchData"
    />

    <DeleteModal
      ref="deleteModal"
      :id="selectedSleepLogId"
      :store="sleepLogStore"
      @deleted="fetchData"
    />
  </section>
</template>
