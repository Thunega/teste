<script setup lang="ts">
useHead({
  title: "Acordo do Usuário | VRLeao",
});

const breadcrumbItems = ref<BreadcrumbItem[]>([
  {
    label: "Painel",
    icon: "i-lucide-layout-dashboard",
    to: "/",
  },
  {
    label: "Termo de Uso",
    icon: "i-lucide-file-text",
    to: "/user-agreement",
  },
]);

definePageMeta({
  layout: "login",
});
</script>

<template>
  <section>
    <UBreadcrumb class="mb-6" :items="breadcrumbItems" />

    <div class="max-w-4xl mx-auto">
      <div class="mb-8">
        <h1 class="text-3xl font-bold mb-2">Termo de Uso e Consentimento</h1>
        <p class="text-gray-500">
          Última atualização: {{ new Date().toLocaleDateString("pt-BR") }}
        </p>
      </div>

      <Card class="prose prose-sm dark:prose-invert max-w-none">
        <div class="space-y-6">
          <section>
            <h2 class="text-xl font-semibold mb-3">1. Aceitação dos Termos</h2>
            <p class="text-gray-700 dark:text-gray-300">
              Ao utilizar a plataforma VR LEÃO, você concorda com este Termo de
              Uso e com nossa Política de Privacidade. Se você não concordar com
              estes termos, não deve utilizar a plataforma.
            </p>
            <p class="text-gray-700 dark:text-gray-300 mt-3">
              Este documento estabelece as condições de uso da plataforma VR
              LEÃO, um sistema de gerenciamento médico destinado a profissionais
              de saúde e pacientes atendidos pelo
              <strong>Fundo Municipal de Saúde - FMS</strong>
              (CNPJ 20.826.697/0001-61), localizado em Vargem Grande do Rio
              Pardo, para registro, acompanhamento e sincronização de dados de
              saúde.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              2. Natureza da Plataforma
            </h2>
            <p class="text-gray-700 dark:text-gray-300 mb-2">
              O VR LEÃO é uma aplicação médica que:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>Coleta e armazena dados pessoais e de saúde de pacientes</li>
              <li>Registra resultados de exames médicos e laboratoriais</li>
              <li>
                Documenta consultas médicas, nutricionais, fisioterapêuticas e
                psicológicas
              </li>
              <li>Sincroniza dados de saúde provenientes de smartwatches</li>
              <li>
                Monitora parâmetros de saúde como peso, sono, alimentação e
                desempenho físico
              </li>
              <li>Armazena históricos médicos e registros clínicos</li>
              <li>Facilita o acompanhamento multidisciplinar da saúde</li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              3. Consentimento para Tratamento de Dados de Saúde
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Ao aceitar este termo, você consente expressamente com:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>
                A coleta, armazenamento e processamento de seus dados pessoais e
                de saúde pelo Fundo Municipal de Saúde - FMS
              </li>
              <li>
                O registro de todas as informações médicas fornecidas durante
                consultas e exames
              </li>
              <li>
                A sincronização automática de dados de saúde de smartwatches
                conectados
              </li>
              <li>
                O compartilhamento de seus dados com profissionais de saúde
                autorizados envolvidos no seu tratamento, incluindo
                especialistas e profissionais externos quando necessário
              </li>
              <li>
                A manutenção de um histórico médico completo conforme exigido
                por lei
              </li>
              <li>
                O uso de suas informações para elaboração de diagnósticos e
                planos terapêuticos
              </li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              4. Sincronização com Smartwatches
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              A plataforma oferece a funcionalidade de sincronização com
              smartwatches para monitoramento contínuo da saúde.
            </p>
            <div
              class="mt-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800"
            >
              <p class="text-gray-700 dark:text-gray-300 font-medium mb-2">
                Ao ativar a sincronização, você autoriza:
              </p>
              <ul
                class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
              >
                <li>A coleta automática de dados de frequência cardíaca</li>
                <li>O registro de padrões de sono e qualidade do descanso</li>
                <li>
                  O monitoramento de níveis de atividade física e exercícios
                </li>
                <li>A captura de dados de saturação de oxigênio (SpO2)</li>
                <li>
                  O armazenamento de outros parâmetros de saúde fornecidos pelo
                  smartwatch
                </li>
              </ul>
            </div>
            <p class="text-gray-700 dark:text-gray-300 mt-3">
              <strong>Importante:</strong> A sincronização pode ser desativada a
              qualquer momento através das configurações da plataforma. Os dados
              já sincronizados permanecerão no histórico médico conforme a
              legislação vigente.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              5. Responsabilidades do Usuário
            </h2>
            <p class="text-gray-700 dark:text-gray-300 mb-2">
              Como usuário da plataforma, você concorda em:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>
                Fornecer informações verdadeiras, precisas e atualizadas sobre
                sua saúde
              </li>
              <li>Manter a confidencialidade de suas credenciais de acesso</li>
              <li>
                Notificar imediatamente sobre qualquer uso não autorizado de sua
                conta
              </li>
              <li>Atualizar regularmente seus dados pessoais e de contato</li>
              <li>
                Informar aos profissionais de saúde sobre quaisquer alterações
                relevantes em sua condição
              </li>
              <li>
                Utilizar a plataforma de forma ética e em conformidade com a
                legislação
              </li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              6. Responsabilidades dos Profissionais de Saúde
            </h2>
            <p class="text-gray-700 dark:text-gray-300 mb-2">
              Os profissionais de saúde que utilizam a plataforma comprometem-se
              a:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>
                Respeitar o sigilo médico e a confidencialidade dos dados dos
                pacientes
              </li>
              <li>
                Utilizar os dados exclusivamente para fins de diagnóstico e
                tratamento
              </li>
              <li>Manter suas credenciais profissionais atualizadas</li>
              <li>Registrar informações de forma precisa e completa</li>
              <li>
                Cumprir as normas do Código de Ética de sua categoria
                profissional
              </li>
              <li>Seguir as melhores práticas de segurança da informação</li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              7. Limitações da Plataforma
            </h2>
            <div
              class="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800"
            >
              <p class="text-gray-700 dark:text-gray-300 font-medium mb-2">
                <strong>Atenção:</strong> A plataforma VR LEÃO é uma ferramenta
                de apoio médico e NÃO substitui:
              </p>
              <ul
                class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
              >
                <li>Consultas presenciais com profissionais de saúde</li>
                <li>Avaliação médica em situações de emergência</li>
                <li>Diagnósticos clínicos que exijam exames físicos</li>
                <li>O julgamento profissional de médicos e especialistas</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              8. Privacidade e Segurança
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Seus dados de saúde são protegidos por:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>Criptografia de ponta a ponta para transmissão de dados</li>
              <li>Armazenamento seguro em servidores protegidos</li>
              <li>Controle de acesso rigoroso baseado em funções</li>
              <li>Autenticação de dois fatores (quando disponível)</li>
              <li>Auditoria regular de acessos e atividades</li>
              <li>Conformidade com a LGPD e regulamentações de saúde</li>
            </ul>
            <p class="text-gray-700 dark:text-gray-300 mt-3">
              Para mais informações, consulte nossa
              <NuxtLink
                to="/privacy-policy"
                class="text-primary-600 dark:text-primary-400 hover:underline"
                >Política de Privacidade</NuxtLink
              >.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              9. Propriedade Intelectual
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Todo o conteúdo da plataforma VR LEÃO, incluindo design, código,
              textos e funcionalidades, é de propriedade exclusiva da empresa ou
              de seus licenciadores e está protegido por leis de propriedade
              intelectual.
            </p>
            <p class="text-gray-700 dark:text-gray-300 mt-3">
              Seus dados de saúde permanecem de sua propriedade. Você mantém
              todos os direitos sobre suas informações pessoais e de saúde
              armazenadas na plataforma.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              10. Disponibilidade do Serviço
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Embora nos esforcemos para manter a plataforma disponível 24/7,
              podem ocorrer interrupções para manutenção, atualizações ou por
              motivos técnicos. Não nos responsabilizamos por:
            </p>
            <ul
              class="list-disc pl-6 space-y-2 text-gray-700 dark:text-gray-300"
            >
              <li>Indisponibilidade temporária do serviço</li>
              <li>Perda de conectividade com dispositivos vestíveis</li>
              <li>Falhas em sincronizações automáticas</li>
              <li>Problemas causados por dispositivos de terceiros</li>
            </ul>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              11. Alterações nos Termos
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Reservamo-nos o direito de modificar estes Termos de Uso a
              qualquer momento. Alterações significativas serão comunicadas
              através da plataforma com antecedência razoável. O uso continuado
              da plataforma após as alterações constitui aceitação dos novos
              termos.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">
              12. Encerramento de Conta
            </h2>
            <p class="text-gray-700 dark:text-gray-300">
              Você pode solicitar o encerramento de sua conta a qualquer
              momento. Seus dados serão mantidos pelo período legalmente exigido
              (mínimo de 20 anos para prontuários médicos) e depois podem ser
              anonimizados ou excluídos conforme sua solicitação e a legislação
              aplicável.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">13. Legislação e Foro</h2>
            <p class="text-gray-700 dark:text-gray-300">
              Este Termo de Uso é regido pelas leis brasileiras. Quaisquer
              disputas serão resolvidas no foro de sua comarca, conforme
              previsto no Código de Defesa do Consumidor.
            </p>
          </section>

          <section>
            <h2 class="text-xl font-semibold mb-3">14. Contato</h2>
            <p class="text-gray-700 dark:text-gray-300">
              Para dúvidas, sugestões ou reclamações sobre estes Termos de Uso:
            </p>
            <div class="mt-3 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <p class="text-gray-700 dark:text-gray-300">
                <strong>E-mail:</strong> vrleao@vrleao.com<br />
              </p>
            </div>
          </section>

          <div
            class="mt-8 p-6 bg-primary-50 dark:bg-primary-900/20 rounded-lg border-2 border-primary-200 dark:border-primary-800"
          >
            <p
              class="text-gray-800 dark:text-gray-200 font-semibold text-center"
            >
              Ao utilizar a plataforma VR LEÃO, você declara ter lido,
              compreendido e concordado com todos os termos aqui estabelecidos,
              incluindo o consentimento para tratamento de dados de saúde e
              sincronização com dispositivos vestíveis.
            </p>
          </div>
        </div>
      </Card>
    </div>
  </section>
</template>
