import { reactive } from "vue";
import type { ZodError, ZodTypeAny } from "zod";

type ErrorsMap = Record<string, string>;

export function useZodForm(schema: ZodTypeAny, state: any) {
  const errors = reactive<ErrorsMap>({});

  function clearErrors() {
    for (const k in errors) delete errors[k];
  }

  function setErrorsFromZod(err: ZodError) {
    clearErrors();
    for (const e of err.errors) {
      const path = (e.path || []).join(".") || "_form";
      if (!errors[path]) errors[path] = e.message;
    }
  }

  function setErrorsFromServer(serverErrors: Record<string, any>) {
    clearErrors();
    if (!serverErrors) return;
    for (const k in serverErrors) {
      const v = serverErrors[k];
      if (Array.isArray(v)) errors[k] = v[0];
      else if (typeof v === "string") errors[k] = v;
      else errors[k] = JSON.stringify(v);
    }
  }

  function getError(path: string) {
    return errors[path];
  }

  function hasError(path: string) {
    return !!errors[path];
  }

  function validate() {
    try {
      const parsed = schema.safeParse(state);
      if (!parsed.success) {
        setErrorsFromZod(parsed.error);
        return false;
      }
      clearErrors();
      return true;
    } catch (e: any) {
      return true;
    }
  }

  return {
    errors,
    validate,
    getError,
    hasError,
    setErrorsFromServer,
    clearErrors,
  };
}
