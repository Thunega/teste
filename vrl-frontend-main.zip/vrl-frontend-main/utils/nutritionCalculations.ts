// Recommended Daily Allowances (RDA) - can be customized per patient
export const RDA = {
  calories: { min: 1800, max: 2500, target: 2000 },
  carbohydrates: { min: 225, max: 325, target: 275 }, // grams
  proteins: { min: 46, max: 56, target: 50 }, // grams
  totalFats: { min: 44, max: 78, target: 65 }, // grams
  fiber: { min: 25, max: 38, target: 30 }, // grams
  sugar: { max: 50 }, // grams
  sodium: { max: 2300 }, // mg

  // Vitamins
  vitaminA: 900, // μg
  vitaminB1: 1.2, // mg
  vitaminB2: 1.3, // mg
  vitaminB3: 16, // mg
  vitaminB5: 5, // mg
  vitaminB6: 1.7, // mg
  vitaminB7: 30, // μg
  vitaminB9: 400, // μg
  vitaminB12: 2.4, // μg
  vitaminC: 90, // mg
  vitaminD: 20, // μg
  vitaminE: 15, // mg
  vitaminK: 120, // μg

  // Minerals
  calcium: 1000, // mg
  iron: 8, // mg
  magnesium: 420, // mg
  phosphorus: 700, // mg
  potassium: 3400, // mg
  zinc: 11, // mg
  copper: 0.9, // mg
  manganese: 2.3, // mg
  selenium: 55, // μg
  iodine: 150, // μg

  // Others
  omega3: 1.6, // g
  omega6: 17, // g
  caffeine: { max: 400 } // mg
}

export interface FoodItem {
  name: string
  brand?: string
  quantity: number
  unit: string
  calories?: number
  carbohydrates?: number
  proteins?: number
  totalFats?: number
  saturatedFats?: number
  transFats?: number
  monounsaturatedFats?: number
  polyunsaturatedFats?: number
  cholesterol?: number
  fiber?: number
  sugar?: number
  sodium?: number
  vitaminA?: number
  vitaminB1?: number
  vitaminB2?: number
  vitaminB3?: number
  vitaminB5?: number
  vitaminB6?: number
  vitaminB7?: number
  vitaminB9?: number
  vitaminB12?: number
  vitaminC?: number
  vitaminD?: number
  vitaminE?: number
  vitaminK?: number
  calcium?: number
  iron?: number
  magnesium?: number
  phosphorus?: number
  potassium?: number
  zinc?: number
  copper?: number
  manganese?: number
  selenium?: number
  iodine?: number
  omega3?: number
  omega6?: number
  caffeine?: number
  notes?: string
}

export interface Meal {
  mealTime: string
  description?: string
  foods?: FoodItem[]
}

export interface DailyFoodLog {
  id: string
  dateOfRegistration: string
  patientId: string
  meals?: Meal[]
}

// Calculate total nutrients for a single meal
export function calculateMealNutrients(meal: Meal) {
  const totals: any = {
    calories: 0,
    carbohydrates: 0,
    proteins: 0,
    totalFats: 0,
    saturatedFats: 0,
    transFats: 0,
    monounsaturatedFats: 0,
    polyunsaturatedFats: 0,
    cholesterol: 0,
    fiber: 0,
    sugar: 0,
    sodium: 0,
    vitaminA: 0,
    vitaminB1: 0,
    vitaminB2: 0,
    vitaminB3: 0,
    vitaminB5: 0,
    vitaminB6: 0,
    vitaminB7: 0,
    vitaminB9: 0,
    vitaminB12: 0,
    vitaminC: 0,
    vitaminD: 0,
    vitaminE: 0,
    vitaminK: 0,
    calcium: 0,
    iron: 0,
    magnesium: 0,
    phosphorus: 0,
    potassium: 0,
    zinc: 0,
    copper: 0,
    manganese: 0,
    selenium: 0,
    iodine: 0,
    omega3: 0,
    omega6: 0,
    caffeine: 0
  }

  if (!meal.foods) return totals

  meal.foods.forEach(food => {
    Object.keys(totals).forEach(nutrient => {
      if (food[nutrient] !== undefined && food[nutrient] !== null) {
        totals[nutrient] += Number(food[nutrient])
      }
    })
  })

  return totals
}

// Calculate total nutrients for a day
export function calculateDailyNutrients(log: DailyFoodLog) {
  const totals: any = {
    calories: 0,
    carbohydrates: 0,
    proteins: 0,
    totalFats: 0,
    saturatedFats: 0,
    transFats: 0,
    monounsaturatedFats: 0,
    polyunsaturatedFats: 0,
    cholesterol: 0,
    fiber: 0,
    sugar: 0,
    sodium: 0,
    vitaminA: 0,
    vitaminB1: 0,
    vitaminB2: 0,
    vitaminB3: 0,
    vitaminB5: 0,
    vitaminB6: 0,
    vitaminB7: 0,
    vitaminB9: 0,
    vitaminB12: 0,
    vitaminC: 0,
    vitaminD: 0,
    vitaminE: 0,
    vitaminK: 0,
    calcium: 0,
    iron: 0,
    magnesium: 0,
    phosphorus: 0,
    potassium: 0,
    zinc: 0,
    copper: 0,
    manganese: 0,
    selenium: 0,
    iodine: 0,
    omega3: 0,
    omega6: 0,
    caffeine: 0
  }

  if (!log.meals) return totals

  log.meals.forEach(meal => {
    const mealNutrients = calculateMealNutrients(meal)
    Object.keys(totals).forEach(nutrient => {
      totals[nutrient] += mealNutrients[nutrient]
    })
  })

  return totals
}

// Calculate macronutrient percentages
export function calculateMacroPercentages(nutrients: any) {
  const { calories, carbohydrates, proteins, totalFats } = nutrients

  if (!calories || calories === 0) {
    return { carbsPercent: 0, proteinsPercent: 0, fatsPercent: 0 }
  }

  const carbsCal = (carbohydrates || 0) * 4
  const proteinsCal = (proteins || 0) * 4
  const fatsCal = (totalFats || 0) * 9

  return {
    carbsPercent: (carbsCal / calories) * 100,
    proteinsPercent: (proteinsCal / calories) * 100,
    fatsPercent: (fatsCal / calories) * 100
  }
}

// Calculate nutrient adequacy (% of RDA met)
export function calculateNutrientAdequacy(nutrient: string, value: number): number {
  const rdaValue = RDA[nutrient]

  if (typeof rdaValue === 'object' && 'target' in rdaValue) {
    return (value / rdaValue.target) * 100
  } else if (typeof rdaValue === 'number') {
    return (value / rdaValue) * 100
  }

  return 0
}

// Get color based on adequacy percentage
export function getAdequacyColor(percentage: number): string {
  if (percentage < 50) return 'rgb(239, 68, 68)' // red-500
  if (percentage < 80) return 'rgb(251, 146, 60)' // orange-400
  if (percentage < 100) return 'rgb(250, 204, 21)' // yellow-400
  if (percentage <= 120) return 'rgb(34, 197, 94)' // green-500
  return 'rgb(251, 146, 60)' // orange-400 (excess)
}

// Calculate food diversity score
export function calculateFoodDiversityScore(logs: DailyFoodLog[]): number {
  const uniqueFoods = new Set<string>()

  logs.forEach(log => {
    log.meals?.forEach(meal => {
      meal.foods?.forEach(food => {
        if (food.name) {
          uniqueFoods.add(food.name.toLowerCase().trim())
        }
      })
    })
  })

  // Score based on unique foods (0-100 scale)
  // 30+ unique foods = 100 points
  return Math.min((uniqueFoods.size / 30) * 100, 100)
}

// Calculate meal timing consistency
export function calculateMealConsistency(logs: DailyFoodLog[]): number {
  const mealTimes: { [key: string]: string[] } = {}

  logs.forEach(log => {
    log.meals?.forEach(meal => {
      if (meal.mealTime) {
        const hour = meal.mealTime.split(':')[0]
        if (!mealTimes[hour]) mealTimes[hour] = []
        mealTimes[hour].push(meal.mealTime)
      }
    })
  })

  // Calculate consistency based on regular meal times
  const regularMealCount = Object.keys(mealTimes).length
  return Math.min((regularMealCount / 6) * 100, 100) // 6 meal times = perfect
}

// Get nutrient status (deficient, adequate, excess)
export function getNutrientStatus(nutrient: string, value: number): 'deficient' | 'low' | 'adequate' | 'high' | 'excess' {
  const percentage = calculateNutrientAdequacy(nutrient, value)

  if (percentage < 50) return 'deficient'
  if (percentage < 80) return 'low'
  if (percentage <= 120) return 'adequate'
  if (percentage <= 150) return 'high'
  return 'excess'
}

// Calculate average nutrients over multiple days
export function calculateAverageNutrients(logs: DailyFoodLog[]) {
  if (logs.length === 0) return null

  const totals = logs.reduce((acc, log) => {
    const dailyNutrients = calculateDailyNutrients(log)
    Object.keys(dailyNutrients).forEach(nutrient => {
      acc[nutrient] = (acc[nutrient] || 0) + dailyNutrients[nutrient]
    })
    return acc
  }, {} as any)

  Object.keys(totals).forEach(nutrient => {
    totals[nutrient] = totals[nutrient] / logs.length
  })

  return totals
}

// Group logs by week
export function groupLogsByWeek(logs: DailyFoodLog[]): { [week: string]: DailyFoodLog[] } {
  const weeks: { [week: string]: DailyFoodLog[] } = {}

  logs.forEach(log => {
    const date = new Date(log.dateOfRegistration)
    const weekStart = new Date(date)
    weekStart.setDate(date.getDate() - date.getDay()) // Sunday
    const weekKey = weekStart.toISOString().split('T')[0]

    if (!weeks[weekKey]) weeks[weekKey] = []
    weeks[weekKey].push(log)
  })

  return weeks
}

// Calculate omega-3 to omega-6 ratio
export function calculateOmegaRatio(omega3: number, omega6: number): number {
  if (omega6 === 0) return 0
  return omega3 / omega6
}

// Get ideal omega ratio assessment
export function getOmegaRatioStatus(ratio: number): 'poor' | 'fair' | 'good' | 'excellent' {
  if (ratio >= 1/2) return 'excellent' // 1:2 or better
  if (ratio >= 1/4) return 'good' // 1:4
  if (ratio >= 1/8) return 'fair' // 1:8
  return 'poor' // worse than 1:8
}
