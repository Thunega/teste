export const calculateAge = (dateOfBirthString) => {
    const birthDate = new Date(dateOfBirthString);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

export const getLabReference = (dateOfBirth, gender): any => {
    const age = calculateAge(dateOfBirth);
    const referenceValues = {
        totalCholesterol: { value: 190, ref: '< 190 mg/dL' },
        hdl: { value: gender === 'MALE' ? 40 : 50, ref: gender === 'MALE' ? '> 40 mg/dL' : '> 50 mg/dL' },
        ldl: { value: 100, ref: '< 100 mg/dL' },
        vldl: { value: 30, ref: '< 30 mg/dL' },
        fastingGlucose: { value: 99, ref: '< 99 mg/dL' },
        triglycerides: { value: 150, ref: '< 150 mg/dL' },
        sgot: { value: gender === 'MALE' ? 40 : 32, ref: gender === 'MALE' ? '< 40 U/L' : '< 32 U/L' },
        sgpt: { value: gender === 'MALE' ? 41 : 33, ref: gender === 'MALE' ? '< 41 U/L' : '< 33 U/L' },
        gammaGt: { value: gender === 'MALE' ? 60 : 40, ref: gender === 'MALE' ? '< 60 U/L' : '< 40 U/L' },
        urea: { value: age < 60 ? 43 : 49, ref: age < 60 ? '< 43 mg/dL' : '< 49 mg/dL' },
        creatinine: { value: gender === 'MALE' ? 1.3 : 1.1, ref: gender === 'MALE' ? '< 1.3 mg/dL' : '< 1.1 mg/dL' },
        t3: { value: 200, ref: '< 200 ng/dL' },
        t4: { value: 12.0, ref: '< 12.0 ug/dL' },
        tsh: { value: 4.5, ref: '< 4.5 mU/L' },
    };
    return referenceValues;
}

export const timeToMinutes = (timeString: string): number => {
    if (!timeString || timeString === '') return 0;
    const [hours, minutes] = timeString.split(':').map(Number);
    return (hours || 0) * 60 + (minutes || 0);
}

export const minutesToTime = (totalMinutes: number): string => {
    if (totalMinutes === null || totalMinutes === undefined || totalMinutes === 0) return '00:00';
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}